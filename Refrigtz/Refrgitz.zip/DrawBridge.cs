﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawBridge
    {
        //Iniatite Global Variable.
        public static double MaxHuristicxB = -20000000000000000;
        public float Row, Column;
        public Color color;
        public ThinkingChess[] BridgeThinking = new ThinkingChess[AllDraw.BridgeMovments];
        public int[,] Table = null;
        public int Current = 0;
        public int Order;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText(FormRefrigtz.Root + "\\ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { Log(t); }
        }
        public bool MaxFound(ref bool MaxNotFound)
        {
            try
            {
                double a = ReturnHuristic();
                if (MaxHuristicxB < a)
                {
                    MaxNotFound = false;
                    if (ThinkingChess.MaxHuristicx < MaxHuristicxB)
                        ThinkingChess.MaxHuristicx = a;
                    MaxHuristicxB = a;
                    return true;
                }
            }
            catch (Exception t)
            {
                Log(t);

            }
            MaxNotFound = true;
            return false;
        }
        public double ReturnHuristic()
        {
            double a = 0;
            for (int ii = 0; ii < AllDraw.BridgeMovments; ii++)
                try
                {
                    a += BridgeThinking[ii].ReturnHuristic(-1,-1);
                }
                catch (Exception t)
                {
                    Log(t);
                }

            return a;
        }


        //Constructor 1.
        public DrawBridge() { }
        //constructor 2.
        public DrawBridge(float i, float j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            //Initiate Global Variable By Local Parmenter.
            Table = Tab;
            for (int ii = 0; ii < AllDraw.BridgeMovments; ii++)
                BridgeThinking[ii] = new ThinkingChess((int)i, (int)j, a, Tab, 16, Ord, TB, Cur, 4);

            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;

        }
        //Clone a Copy.
        public void Clone(ref DrawBridge AA, ref FormRefrigtz THIS)
        {
            //Initiate a Constructed Brideges an Clone a Copy.
            AA = new DrawBridge(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.BridgeMovments; i++)
            {
                try
                {
                    AA.BridgeThinking[i] = new ThinkingChess((int)this.Row, (int)this.Column);
                    this.BridgeThinking[i].Clone(ref AA.BridgeThinking[i], ref THIS);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.BridgeThinking[i] = null;
                }
            }
        }
        //Draw An Instatnt Brideges Images On the Table Method.
        public void DrawBridgeOnTable(ref Graphics g, int CellW, int CellH)
        {
            try
            {
                //Gray Color.
                if (color == Color.Gray)
                {
                    //Draw a Gray Bridges Instatnt Image On hte Tabe.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "BrG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                }
                else
                {
                    //Draw an Instatnt of Brown Bridges On the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "BrB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                }
            }
            catch (Exception t)
            {
                Log(t);
            }
        }
    }
}
//End of Documents.