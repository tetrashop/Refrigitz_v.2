﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;

namespace Refrigtz
{
    public class DrawKing
    {
        //Initiate Global Variables.
        public static double MaxHuristicxK = -20000000000000000;
        public float Row, Column;
        public Color color;
        public int[,] Table = null;
        public ThinkingChess[] KingThinking = new ThinkingChess[AllDraw.KingMovments];
        public int Current = 0;
        public int Order;

        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText(FormRefrigtz.Root + "\\ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { Log(t); }
        }
        public double ReturnHuristic()
        {
            double a = 0;
            for (int ii = 0; ii < AllDraw.KingMovments; ii++)
                try
                {
                    a += KingThinking[ii].ReturnHuristic(-1,-1);
                }
                catch (Exception t)
                {
                    Log(t);
                }

            return a;
        }
        public bool MaxFound(ref bool MaxNotFound)
        {
            try
            {
                double a = ReturnHuristic();
                if (MaxHuristicxK < a)
                {
                    MaxNotFound = false;
                    if (ThinkingChess.MaxHuristicx < MaxHuristicxK)
                        ThinkingChess.MaxHuristicx = a;
                    MaxHuristicxK = a;
                    return true;
                }
            }
            catch (Exception t)
            {
                Log(t);

            }
            MaxNotFound = true;
            return false;
        }
        //Constructor 1.
        public DrawKing() { }
        //Constructor 2.
        public DrawKing(float i, float j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            //Iniatite Global Variables.
            Table = Tab;
            for (int ii = 0; ii < AllDraw.KingMovments; ii++)
                KingThinking[ii] = new ThinkingChess((int)i, (int)j, a, Tab, 8, Ord, TB, Cur, 2);

            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;

        }
        //Clone a Copy.
        public void Clone(ref DrawKing AA, ref FormRefrigtz THIS)
        {
            //Initiate a Construction Object and Clone a Copy.
            AA = new DrawKing(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.KingMovments; i++)
            {
                try
                {
                    AA.KingThinking[i] = new ThinkingChess((int)this.Row, (int)this.Column);
                    this.KingThinking[i].Clone(ref AA.KingThinking[i], ref THIS);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.KingThinking[i] = null;
                }
            }
        }
        //Draw an Instatnt King on the Table Method.
        public void DrawKingOnTable(ref Graphics g, int CellW, int CellH)
        {

            try
            {
                //Gray Order.
                if (color == Color.Gray)
                {
                    //Draw an Instatnt Gray King Image On the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "KG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));

                }
                else
                {
                    //Draw an Instatnt Brown King Image On the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "KB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                }
            }
            catch (Exception t) { Log(t); }

        }
    }
}
//End of Documentation.