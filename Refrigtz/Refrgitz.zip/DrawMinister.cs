﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawMinister//:DrawKing
    {
        //Initiate Global Variable.
        public static double MaxHuristicxM = -20000000000000000;
        public float Row, Column;
        public Color color;
        public int[,] Table = null;
        public int Current = 0;
        public int Order;
        public ThinkingChess[] MinisterThinking = new ThinkingChess[AllDraw.MinisterMovments];
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText(FormRefrigtz.Root + "\\ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { Log(t); }
        }
        public bool MaxFound(ref bool MaxNotFound)
        {
            try
            {
                double a = ReturnHuristic();
                if (MaxHuristicxM < a)
                {
                    MaxNotFound = false;
                    if (ThinkingChess.MaxHuristicx < MaxHuristicxM)
                        ThinkingChess.MaxHuristicx = a;
                    MaxHuristicxM = a;
                    return true;
                }
            }
            catch (Exception t)
            {
                Log(t);

            }
            MaxNotFound = true;
            return false;
        }
        public double ReturnHuristic()
        {
            double a = 0;
            for (int ii = 0; ii < AllDraw.MinisterMovments; ii++)
                try
                {
                    a += MinisterThinking[ii].ReturnHuristic(-1,-1);
                }
                catch (Exception t)
                {
                    Log(t);
                }
            return a;
        }
        //constructor 1.
        public DrawMinister() { }
        //Constructor 2.
        public DrawMinister(float i, float j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            //Initiate Global Variables.
            Table = Tab;
            for (int ii = 0; ii < AllDraw.MinisterMovments; ii++)
                MinisterThinking[ii] = new ThinkingChess((int)i, (int)j, a, Tab, 32, Ord, TB, Cur, 2);

            Row = i;
            Column = j;
            color = a;
            Current = Cur;
            Order = Ord;

        }
        //Clone a Copy.
        public void Clone(ref DrawMinister AA, ref FormRefrigtz THIS)
        {
            //Initiate an Object and Clone a Construction Objectve.
            AA = new DrawMinister(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.MinisterMovments; i++)
            {
                try
                {
                    AA.MinisterThinking[i] = new ThinkingChess((int)this.Row, (int)this.Column);
                    this.MinisterThinking[i].Clone(ref AA.MinisterThinking[i], ref THIS);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.MinisterThinking[i] = null;
                }

            }
        }
        //Draw an Mnister on the Table.
        public void DrawMinisterOnTable(ref Graphics g, int CellW, int CellH)
        {
            try
            {
                //Gray Order.
                if (color == Color.Gray)
                {
                    //Draw a Gray Instatnt Minister Image on the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                }
                else
                {
                    //Draw a Brown Instatnt Minister Image on the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MB.png"), new Rectangle((int)(Row * CellW), (int)(Column * (float)CellH), CellW, CellH));
                }

            }
            catch (Exception t) { Log(t); }
        }
    }
}
//End of Documentation.