﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Data.OleDb;
using System.Media;
using System.IO;

namespace Refrigtz
{
    partial class AboutBoxChessRefrigitz : Form
    {
        public AboutBoxChessRefrigitz()
        {
            InitializeComponent();
            }

        
        private void okButton_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        /*private void AboutBoxChessRefrigitz_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel_Paint(object sender, PaintEventArgs e)
        {

        }*/
    }
}
