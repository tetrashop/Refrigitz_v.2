﻿namespace Refrigtz
{
    partial class FormRefrigtz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRefrigtz));
            this.menuStripChessRefrigitz = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemNewGame = new System.Windows.Forms.ToolStripMenuItem();
            this.computerWithComputerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.computerWithComputerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemRandomGeneticGames = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.hardestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.medumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.easestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonPrevious = new System.Windows.Forms.Button();
            this.textBoxText = new System.Windows.Forms.TextBox();
            this.pictureBoxRefrigtz = new System.Windows.Forms.PictureBox();
            this.pictureBoxTimerGray = new System.Windows.Forms.PictureBox();
            this.pictureBoxTimerBrown = new System.Windows.Forms.PictureBox();
            this.textBoxStatistic = new System.Windows.Forms.TextBox();
            this.checkBoxDeptHuristic = new System.Windows.Forms.CheckBox();
            this.checkBoxOnlySelf = new System.Windows.Forms.CheckBox();
            this.checkBoxPredictHuristci = new System.Windows.Forms.CheckBox();
            this.checkBoxBestMovments = new System.Windows.Forms.CheckBox();
            this.radioButtonOriginalImages = new System.Windows.Forms.RadioButton();
            this.radioButtonBigFittingImages = new System.Windows.Forms.RadioButton();
            this.radioButtonSmallFittingImages = new System.Windows.Forms.RadioButton();
            this.buttonStop = new System.Windows.Forms.Button();
            this.checkBoxDeptFirstSearch = new System.Windows.Forms.CheckBox();
            this.buttonPauseStart = new System.Windows.Forms.Button();
            this.checkBoxDeptMovement = new System.Windows.Forms.CheckBox();
            this.checkBoxUseDoubleTime = new System.Windows.Forms.CheckBox();
            this.checkBoxUsePenaltyRegradMechnisam = new System.Windows.Forms.CheckBox();
            this.checkBoxDynamicProgrammingDeptFirst = new System.Windows.Forms.CheckBox();
            this.helpProviderChessRefregitz2016 = new System.Windows.Forms.HelpProvider();
            this.menuStripChessRefrigitz.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefrigtz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTimerGray)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTimerBrown)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStripChessRefrigitz
            // 
            this.menuStripChessRefrigitz.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.aboutToolStripMenuItem});
            this.menuStripChessRefrigitz.Location = new System.Drawing.Point(0, 0);
            this.menuStripChessRefrigitz.Name = "menuStripChessRefrigitz";
            this.menuStripChessRefrigitz.Size = new System.Drawing.Size(1020, 24);
            this.menuStripChessRefrigitz.TabIndex = 1;
            this.menuStripChessRefrigitz.Text = "menuStrip1";
            this.menuStripChessRefrigitz.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStripChessRefrigitz_ItemClicked);
            this.menuStripChessRefrigitz.Enter += new System.EventHandler(this.menuStripChessRefrigitz_Enter);
            this.menuStripChessRefrigitz.Leave += new System.EventHandler(this.menuStripChessRefrigitz_Leave);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemNewGame,
            this.computerWithComputerToolStripMenuItem,
            this.computerWithComputerToolStripMenuItem1,
            this.toolStripMenuItemRandomGeneticGames,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItemNewGame
            // 
            this.toolStripMenuItemNewGame.Name = "toolStripMenuItemNewGame";
            this.toolStripMenuItemNewGame.Size = new System.Drawing.Size(213, 22);
            this.toolStripMenuItemNewGame.Text = "New Game";
            this.toolStripMenuItemNewGame.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // computerWithComputerToolStripMenuItem
            // 
            this.computerWithComputerToolStripMenuItem.Name = "computerWithComputerToolStripMenuItem";
            this.computerWithComputerToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.computerWithComputerToolStripMenuItem.Text = "Computer With Computer";
            this.computerWithComputerToolStripMenuItem.Click += new System.EventHandler(this.computerWithComputerToolStripMenuItem_Click);
            // 
            // computerWithComputerToolStripMenuItem1
            // 
            this.computerWithComputerToolStripMenuItem1.Name = "computerWithComputerToolStripMenuItem1";
            this.computerWithComputerToolStripMenuItem1.Size = new System.Drawing.Size(213, 22);
            this.computerWithComputerToolStripMenuItem1.Text = "Computer With Person";
            this.computerWithComputerToolStripMenuItem1.Click += new System.EventHandler(this.computerWithComputerToolStripMenuItem1_Click);
            // 
            // toolStripMenuItemRandomGeneticGames
            // 
            this.toolStripMenuItemRandomGeneticGames.Enabled = false;
            this.toolStripMenuItemRandomGeneticGames.Name = "toolStripMenuItemRandomGeneticGames";
            this.toolStripMenuItemRandomGeneticGames.Size = new System.Drawing.Size(213, 22);
            this.toolStripMenuItemRandomGeneticGames.Text = "Random Genetic Games";
            this.toolStripMenuItemRandomGeneticGames.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hardestToolStripMenuItem,
            this.medumToolStripMenuItem,
            this.easestToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(46, 20);
            this.toolStripMenuItem2.Text = "Level";
            // 
            // hardestToolStripMenuItem
            // 
            this.hardestToolStripMenuItem.Name = "hardestToolStripMenuItem";
            this.hardestToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.hardestToolStripMenuItem.Text = "Hardest";
            this.hardestToolStripMenuItem.Click += new System.EventHandler(this.hardestToolStripMenuItem_Click);
            // 
            // medumToolStripMenuItem
            // 
            this.medumToolStripMenuItem.Name = "medumToolStripMenuItem";
            this.medumToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.medumToolStripMenuItem.Text = "Medum";
            this.medumToolStripMenuItem.Click += new System.EventHandler(this.medumToolStripMenuItem_Click);
            // 
            // easestToolStripMenuItem
            // 
            this.easestToolStripMenuItem.Name = "easestToolStripMenuItem";
            this.easestToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.easestToolStripMenuItem.Text = "Easest";
            this.easestToolStripMenuItem.Click += new System.EventHandler(this.easestToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.aboutToolStripMenuItem1});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(107, 22);
            this.toolStripMenuItem3.Text = "Help";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click_1);
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Location = new System.Drawing.Point(698, 501);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(75, 23);
            this.buttonNext.TabIndex = 2;
            this.buttonNext.Text = "Next";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonPrevious
            // 
            this.buttonPrevious.Location = new System.Drawing.Point(613, 501);
            this.buttonPrevious.Name = "buttonPrevious";
            this.buttonPrevious.Size = new System.Drawing.Size(75, 23);
            this.buttonPrevious.TabIndex = 3;
            this.buttonPrevious.Text = "Previous";
            this.buttonPrevious.UseVisualStyleBackColor = true;
            this.buttonPrevious.Click += new System.EventHandler(this.buttonPrevious_Click);
            // 
            // textBoxText
            // 
            this.textBoxText.Location = new System.Drawing.Point(590, 332);
            this.textBoxText.Multiline = true;
            this.textBoxText.Name = "textBoxText";
            this.textBoxText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxText.Size = new System.Drawing.Size(368, 163);
            this.textBoxText.TabIndex = 4;
            this.textBoxText.TextChanged += new System.EventHandler(this.textBoxText_TextChanged);
            // 
            // pictureBoxRefrigtz
            // 
            this.pictureBoxRefrigtz.BackgroundImage = global::Refrigtz.Properties.Resources.Refregitz;
            this.pictureBoxRefrigtz.Image = global::Refrigtz.Properties.Resources.Refregitz;
            this.pictureBoxRefrigtz.Location = new System.Drawing.Point(12, 27);
            this.pictureBoxRefrigtz.Name = "pictureBoxRefrigtz";
            this.pictureBoxRefrigtz.Size = new System.Drawing.Size(572, 494);
            this.pictureBoxRefrigtz.TabIndex = 0;
            this.pictureBoxRefrigtz.TabStop = false;
            this.pictureBoxRefrigtz.Click += new System.EventHandler(this.pictureBoxRefrigtz_Click);
            this.pictureBoxRefrigtz.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBoxRefrigtz_Paint);
            this.pictureBoxRefrigtz.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxRefrigtz_MouseClick);
            this.pictureBoxRefrigtz.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxRefrigtz_MouseDoubleClick);
            this.pictureBoxRefrigtz.MouseLeave += new System.EventHandler(this.pictureBoxRefrigtz_MouseLeave);
            this.pictureBoxRefrigtz.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxRefrigtz_MouseMove);
            // 
            // pictureBoxTimerGray
            // 
            this.pictureBoxTimerGray.BackgroundImage = global::Refrigtz.Properties.Resources.Gray;
            this.pictureBoxTimerGray.Image = global::Refrigtz.Properties.Resources.Gray;
            this.pictureBoxTimerGray.Location = new System.Drawing.Point(613, 38);
            this.pictureBoxTimerGray.Name = "pictureBoxTimerGray";
            this.pictureBoxTimerGray.Size = new System.Drawing.Size(104, 66);
            this.pictureBoxTimerGray.TabIndex = 7;
            this.pictureBoxTimerGray.TabStop = false;
            this.pictureBoxTimerGray.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBoxTimerGray_Paint);
            // 
            // pictureBoxTimerBrown
            // 
            this.pictureBoxTimerBrown.BackgroundImage = global::Refrigtz.Properties.Resources.Brown;
            this.pictureBoxTimerBrown.Image = global::Refrigtz.Properties.Resources.Brown;
            this.pictureBoxTimerBrown.Location = new System.Drawing.Point(784, 38);
            this.pictureBoxTimerBrown.Name = "pictureBoxTimerBrown";
            this.pictureBoxTimerBrown.Size = new System.Drawing.Size(114, 66);
            this.pictureBoxTimerBrown.TabIndex = 8;
            this.pictureBoxTimerBrown.TabStop = false;
            this.pictureBoxTimerBrown.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBoxTimerBrown_Paint_1);
            // 
            // textBoxStatistic
            // 
            this.textBoxStatistic.Location = new System.Drawing.Point(613, 111);
            this.textBoxStatistic.Multiline = true;
            this.textBoxStatistic.Name = "textBoxStatistic";
            this.textBoxStatistic.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxStatistic.Size = new System.Drawing.Size(285, 69);
            this.textBoxStatistic.TabIndex = 9;
            // 
            // checkBoxDeptHuristic
            // 
            this.checkBoxDeptHuristic.AutoSize = true;
            this.checkBoxDeptHuristic.Location = new System.Drawing.Point(871, 192);
            this.checkBoxDeptHuristic.Name = "checkBoxDeptHuristic";
            this.checkBoxDeptHuristic.Size = new System.Drawing.Size(87, 17);
            this.checkBoxDeptHuristic.TabIndex = 10;
            this.checkBoxDeptHuristic.Text = "Dept Huristic";
            this.checkBoxDeptHuristic.UseVisualStyleBackColor = true;
            this.checkBoxDeptHuristic.CheckedChanged += new System.EventHandler(this.checkBoxDeptHuristic_CheckedChanged);
            // 
            // checkBoxOnlySelf
            // 
            this.checkBoxOnlySelf.AutoSize = true;
            this.checkBoxOnlySelf.Location = new System.Drawing.Point(794, 192);
            this.checkBoxOnlySelf.Name = "checkBoxOnlySelf";
            this.checkBoxOnlySelf.Size = new System.Drawing.Size(71, 17);
            this.checkBoxOnlySelf.TabIndex = 11;
            this.checkBoxOnlySelf.Text = "Only Self ";
            this.checkBoxOnlySelf.UseVisualStyleBackColor = true;
            this.checkBoxOnlySelf.CheckedChanged += new System.EventHandler(this.checkBoxOnlySelf_CheckedChanged);
            // 
            // checkBoxPredictHuristci
            // 
            this.checkBoxPredictHuristci.AutoSize = true;
            this.checkBoxPredictHuristci.Location = new System.Drawing.Point(691, 192);
            this.checkBoxPredictHuristci.Name = "checkBoxPredictHuristci";
            this.checkBoxPredictHuristci.Size = new System.Drawing.Size(97, 17);
            this.checkBoxPredictHuristci.TabIndex = 12;
            this.checkBoxPredictHuristci.Text = "Predict Huristic";
            this.checkBoxPredictHuristci.UseVisualStyleBackColor = true;
            this.checkBoxPredictHuristci.CheckedChanged += new System.EventHandler(this.checkBoxPredictHuristci_CheckedChanged);
            // 
            // checkBoxBestMovments
            // 
            this.checkBoxBestMovments.AutoSize = true;
            this.checkBoxBestMovments.Location = new System.Drawing.Point(590, 192);
            this.checkBoxBestMovments.Name = "checkBoxBestMovments";
            this.checkBoxBestMovments.Size = new System.Drawing.Size(99, 17);
            this.checkBoxBestMovments.TabIndex = 13;
            this.checkBoxBestMovments.Text = "Best Movments";
            this.checkBoxBestMovments.UseVisualStyleBackColor = true;
            this.checkBoxBestMovments.Visible = false;
            this.checkBoxBestMovments.CheckedChanged += new System.EventHandler(this.checkBoxBestMovments_CheckedChanged);
            // 
            // radioButtonOriginalImages
            // 
            this.radioButtonOriginalImages.AutoSize = true;
            this.radioButtonOriginalImages.Location = new System.Drawing.Point(641, 216);
            this.radioButtonOriginalImages.Name = "radioButtonOriginalImages";
            this.radioButtonOriginalImages.Size = new System.Drawing.Size(97, 17);
            this.radioButtonOriginalImages.TabIndex = 14;
            this.radioButtonOriginalImages.Text = "Original Images";
            this.radioButtonOriginalImages.UseVisualStyleBackColor = true;
            this.radioButtonOriginalImages.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButtonBigFittingImages
            // 
            this.radioButtonBigFittingImages.AutoSize = true;
            this.radioButtonBigFittingImages.Location = new System.Drawing.Point(641, 239);
            this.radioButtonBigFittingImages.Name = "radioButtonBigFittingImages";
            this.radioButtonBigFittingImages.Size = new System.Drawing.Size(105, 17);
            this.radioButtonBigFittingImages.TabIndex = 15;
            this.radioButtonBigFittingImages.Text = "Big Fiting Images";
            this.radioButtonBigFittingImages.UseVisualStyleBackColor = true;
            this.radioButtonBigFittingImages.CheckedChanged += new System.EventHandler(this.radioButtonBigFittingImages_CheckedChanged);
            // 
            // radioButtonSmallFittingImages
            // 
            this.radioButtonSmallFittingImages.AutoSize = true;
            this.radioButtonSmallFittingImages.Checked = true;
            this.radioButtonSmallFittingImages.Location = new System.Drawing.Point(641, 262);
            this.radioButtonSmallFittingImages.Name = "radioButtonSmallFittingImages";
            this.radioButtonSmallFittingImages.Size = new System.Drawing.Size(118, 17);
            this.radioButtonSmallFittingImages.TabIndex = 16;
            this.radioButtonSmallFittingImages.TabStop = true;
            this.radioButtonSmallFittingImages.Text = "Small Fitting Images";
            this.radioButtonSmallFittingImages.UseVisualStyleBackColor = true;
            this.radioButtonSmallFittingImages.CheckedChanged += new System.EventHandler(this.radioButtonSmallFittingImages_CheckedChanged);
            // 
            // buttonStop
            // 
            this.buttonStop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonStop.Location = new System.Drawing.Point(784, 256);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStop.TabIndex = 17;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // checkBoxDeptFirstSearch
            // 
            this.checkBoxDeptFirstSearch.AutoSize = true;
            this.checkBoxDeptFirstSearch.Location = new System.Drawing.Point(753, 210);
            this.checkBoxDeptFirstSearch.Name = "checkBoxDeptFirstSearch";
            this.checkBoxDeptFirstSearch.Size = new System.Drawing.Size(108, 17);
            this.checkBoxDeptFirstSearch.TabIndex = 18;
            this.checkBoxDeptFirstSearch.Text = "Dept First Search";
            this.checkBoxDeptFirstSearch.UseVisualStyleBackColor = true;
            this.checkBoxDeptFirstSearch.CheckedChanged += new System.EventHandler(this.checkBoxDeptFirstSearch_CheckedChanged);
            // 
            // buttonPauseStart
            // 
            this.buttonPauseStart.Location = new System.Drawing.Point(865, 256);
            this.buttonPauseStart.Name = "buttonPauseStart";
            this.buttonPauseStart.Size = new System.Drawing.Size(75, 23);
            this.buttonPauseStart.TabIndex = 19;
            this.buttonPauseStart.Text = "Pause";
            this.buttonPauseStart.UseVisualStyleBackColor = true;
            this.buttonPauseStart.Click += new System.EventHandler(this.buttonPause_Click);
            // 
            // checkBoxDeptMovement
            // 
            this.checkBoxDeptMovement.AutoSize = true;
            this.checkBoxDeptMovement.Location = new System.Drawing.Point(784, 285);
            this.checkBoxDeptMovement.Name = "checkBoxDeptMovement";
            this.checkBoxDeptMovement.Size = new System.Drawing.Size(123, 17);
            this.checkBoxDeptMovement.TabIndex = 20;
            this.checkBoxDeptMovement.Text = "Use Dept Movments";
            this.checkBoxDeptMovement.UseVisualStyleBackColor = true;
            this.checkBoxDeptMovement.CheckedChanged += new System.EventHandler(this.checkBoxDeptMovement_CheckedChanged);
            this.checkBoxDeptMovement.Enter += new System.EventHandler(this.checkBoxDeptMovement_Enter);
            // 
            // checkBoxUseDoubleTime
            // 
            this.checkBoxUseDoubleTime.AutoSize = true;
            this.checkBoxUseDoubleTime.Location = new System.Drawing.Point(762, 233);
            this.checkBoxUseDoubleTime.Name = "checkBoxUseDoubleTime";
            this.checkBoxUseDoubleTime.Size = new System.Drawing.Size(102, 17);
            this.checkBoxUseDoubleTime.TabIndex = 21;
            this.checkBoxUseDoubleTime.Text = "UseDoubleTime";
            this.checkBoxUseDoubleTime.UseVisualStyleBackColor = true;
            this.checkBoxUseDoubleTime.Visible = false;
            this.checkBoxUseDoubleTime.CheckedChanged += new System.EventHandler(this.checkBoxUseDoubleTime_CheckedChanged);
            // 
            // checkBoxUsePenaltyRegradMechnisam
            // 
            this.checkBoxUsePenaltyRegradMechnisam.AutoSize = true;
            this.checkBoxUsePenaltyRegradMechnisam.Location = new System.Drawing.Point(598, 285);
            this.checkBoxUsePenaltyRegradMechnisam.Name = "checkBoxUsePenaltyRegradMechnisam";
            this.checkBoxUsePenaltyRegradMechnisam.Size = new System.Drawing.Size(184, 17);
            this.checkBoxUsePenaltyRegradMechnisam.TabIndex = 22;
            this.checkBoxUsePenaltyRegradMechnisam.Text = "Use Penalty Regard Mechanisam";
            this.checkBoxUsePenaltyRegradMechnisam.UseVisualStyleBackColor = true;
            this.checkBoxUsePenaltyRegradMechnisam.CheckedChanged += new System.EventHandler(this.checkBoxUsePenaltyRegradMechnisam_CheckedChanged);
            // 
            // checkBoxDynamicProgrammingDeptFirst
            // 
            this.checkBoxDynamicProgrammingDeptFirst.AutoSize = true;
            this.checkBoxDynamicProgrammingDeptFirst.Location = new System.Drawing.Point(598, 309);
            this.checkBoxDynamicProgrammingDeptFirst.Name = "checkBoxDynamicProgrammingDeptFirst";
            this.checkBoxDynamicProgrammingDeptFirst.Size = new System.Drawing.Size(179, 17);
            this.checkBoxDynamicProgrammingDeptFirst.TabIndex = 23;
            this.checkBoxDynamicProgrammingDeptFirst.Text = "Dynamic Programming Dept First";
            this.checkBoxDynamicProgrammingDeptFirst.UseVisualStyleBackColor = true;
            this.checkBoxDynamicProgrammingDeptFirst.CheckedChanged += new System.EventHandler(this.checkBoxDynamicProgrammingDeptFirst_CheckedChanged);
            // 
            // FormRefrigtz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 533);
            this.Controls.Add(this.checkBoxDynamicProgrammingDeptFirst);
            this.Controls.Add(this.checkBoxUsePenaltyRegradMechnisam);
            this.Controls.Add(this.checkBoxUseDoubleTime);
            this.Controls.Add(this.checkBoxDeptMovement);
            this.Controls.Add(this.buttonPauseStart);
            this.Controls.Add(this.checkBoxDeptFirstSearch);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.radioButtonSmallFittingImages);
            this.Controls.Add(this.radioButtonBigFittingImages);
            this.Controls.Add(this.radioButtonOriginalImages);
            this.Controls.Add(this.checkBoxBestMovments);
            this.Controls.Add(this.checkBoxPredictHuristci);
            this.Controls.Add(this.checkBoxOnlySelf);
            this.Controls.Add(this.checkBoxDeptHuristic);
            this.Controls.Add(this.textBoxStatistic);
            this.Controls.Add(this.pictureBoxTimerBrown);
            this.Controls.Add(this.pictureBoxTimerGray);
            this.Controls.Add(this.textBoxText);
            this.Controls.Add(this.buttonPrevious);
            this.Controls.Add(this.buttonNext);
            this.Controls.Add(this.pictureBoxRefrigtz);
            this.Controls.Add(this.menuStripChessRefrigitz);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStripChessRefrigitz;
            this.Name = "FormRefrigtz";
            this.Text = "Chess Refrigtz 2016";
            this.MaximumSizeChanged += new System.EventHandler(this.FormRefrigtz_MaximumSizeChanged);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FormRefrigtz_Paint);
            this.Enter += new System.EventHandler(this.FormRefrigtz_Enter);
            this.Leave += new System.EventHandler(this.FormRefrigtz_Leave);
            this.menuStripChessRefrigitz.ResumeLayout(false);
            this.menuStripChessRefrigitz.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefrigtz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTimerGray)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTimerBrown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxRefrigtz;
        private System.Windows.Forms.MenuStrip menuStripChessRefrigitz;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem computerWithComputerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem computerWithComputerToolStripMenuItem1;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonPrevious;
        public System.Windows.Forms.TextBox textBoxText;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemNewGame;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBoxTimerGray;
        private System.Windows.Forms.PictureBox pictureBoxTimerBrown;
        private System.Windows.Forms.TextBox textBoxStatistic;
        private System.Windows.Forms.CheckBox checkBoxDeptHuristic;
        private System.Windows.Forms.CheckBox checkBoxOnlySelf;
        private System.Windows.Forms.CheckBox checkBoxPredictHuristci;
        private System.Windows.Forms.CheckBox checkBoxBestMovments;
        private System.Windows.Forms.RadioButton radioButtonOriginalImages;
        private System.Windows.Forms.RadioButton radioButtonBigFittingImages;
        private System.Windows.Forms.RadioButton radioButtonSmallFittingImages;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemRandomGeneticGames;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.CheckBox checkBoxDeptFirstSearch;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem hardestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem medumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem easestToolStripMenuItem;
        private System.Windows.Forms.Button buttonPauseStart;
        private System.Windows.Forms.CheckBox checkBoxDeptMovement;
        private System.Windows.Forms.CheckBox checkBoxUseDoubleTime;
        private System.Windows.Forms.CheckBox checkBoxUsePenaltyRegradMechnisam;
        private System.Windows.Forms.CheckBox checkBoxDynamicProgrammingDeptFirst;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.HelpProvider helpProviderChessRefregitz2016;
    }
}

