﻿/*********************************************************************************************
 * tring to predictative orderly movments.****************************************************
 * Ramin Edjlal*******************************************************************************
 * This Class should Predict the Validity Movements Of Current Order an Enemy of Current Order*(_)
 * Predict Not Working************************************************************************(+)
 * Chess Predict Taking A Lot Of Time*********************************************************(+)
 * Chess Prediction Caused to Initial AllDraw Method in Achmaz state not Working.**********(+)
 * 'Kish' Achmaz Attacker by Gray Minister to Brown 'King' Not Removed by Brown Soldier****(+)
 * The State of Soldier Supporter By Soldier Brown Doesn’t Detected.**************************(+)
 * Chess Predict Doesn’t Act The Supporter of Soldier*****************************************(+)
 * Chess Predict Supporter Successful For Kishing 'Alice' by Person***************************(+)
 * Chess 'Alice' By 'Bob' Supporter Misleading************************************************(+)
 * Chess Predict at Tow Level Taking a lot of time.*******************************************(+)
 * Chess Predict Not Working******************************************************************(+)
 * *******************************************************************************************(+:Sum(10)) (_:Sum(1))*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading;
using System.IO;
namespace Refrigtz
{
    class ChessPerdict
    {
                           
        ChessPerdict APredict = null;
      
        int OrderDummy = 0;
        bool KishHuristic = false;
         bool KishG = false, KishB = false;
        public static int SodierValue = 1;
        public static int ElefantValue = 2;
        public static int HourseValue = 3;
        public static int BridgeValue = 5;
        public static int MinisterValue = 7;
        public static int KingValue = 10;
        int RW = 0;
        int CL = 0;
        int Ki = 0;
        public static int LoopHuristicIndex = 0;
        static List<int> RWList = new List<int>();
        static List<int> ClList = new List<int>();
        static List<int> KiList = new List<int>();
        static public List<int[,]> TableListAction = new List<int[,]>();
        public int Move = 0;
        static public int MouseClick = 0;
        int[] DeptIndex = new int[20];
        int DeptIndexVlue = 0;

        public List<AllDraw> A = null;
        public List<int[,]> TableList = new List<int[,]>();
        public int Dept = 0;
        public DrawSoldier[] SolderesOnTable = null;
        public DrawElefant[] ElephantOnTable = null;
        public DrawHourse[] HoursesOnTable = null;
        public DrawBridge[] BridgesOnTable = null;
        public DrawMinister[] MinisterOnTable = null;
        public DrawKing[] KingOnTable = null;
        FormRefrigtz THIS;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
        
        public ChessPerdict(ref FormRefrigtz Th)
        {
            THIS = Th;
            A = new List<AllDraw>();
            SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
            for (int i = 0; i < AllDraw.SodierHigh; i++)
                SolderesOnTable[i] = new DrawSoldier();
            ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
            for (int i = 0; i < AllDraw.ElefantHigh; i++)
                ElephantOnTable[i] = new DrawElefant();
            HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
            for (int i = 0; i < AllDraw.HourseHight; i++)
                HoursesOnTable[i] = new DrawHourse();
            BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
            for (int i = 0; i < AllDraw.BridgeHigh; i++)
                BridgesOnTable[i] = new DrawBridge();
            MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
            for (int i = 0; i < AllDraw.MinisterHigh; i++)
                MinisterOnTable[i] = new DrawMinister();
            KingOnTable = new DrawKing[AllDraw.KingHigh];
            for (int i = 0; i < AllDraw.KingHigh; i++)
                KingOnTable[i] = new DrawKing();
        
        }
        public bool AllCurrentDeptThinkingFinished(AllDraw Dum, int i, int j, int Kind)
        {
            bool Finished = false;
            if (Kind == 1)
            {
                if (Dum.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 2)
            {
                if (Dum.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 3)
            {
                if (Dum.HoursesOnTable[i].HourseThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 4)
            {
                if (Dum.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 5)
            {
                if (Dum.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 6)
            {
                if (Dum.KingOnTable[i].KingThinking[j].ThinkingFinished)
                    return true;
            }
            return Finished;

        }
        void Wait(AllDraw Dum, int i, int j, int Kind)
        {
            do
            {
                THIS.SetBoxText("\r\nDept Predict :" + AllDraw.SyntaxToWrite);
                THIS.RefreshBoxText();
          
            } while (!AllCurrentDeptThinkingFinished(Dum, i, j, Kind));


        }
        public void InitiateForEveryKindThingHome(AllDraw DummyHA, int ii, int jj, Color a, int[,] Table, int Order, bool TB, int IN)
        {
            //Order = Order * -1;
            //ChessRules.CurrentOrder *= -1;
            
            int i = 0, j = 0;
            AllDraw Dummy = new AllDraw(ref THIS);
            if (Order == 1)
            {
                for (i = 0; i < AllDraw.SodierMidle; i++)
                {
                    try
                    {
                        if (SolderesOnTable[i] == null)
                            continue;
                        ii = SolderesOnTable[i].Row;
                        jj = SolderesOnTable[i].Column;

                        Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < 4; j++)
                        {


                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingBegin = true;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished = false;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[j].Thinking));
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t.Start();
                            Wait(Dummy, i, j, 1);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.SolderesOnTable[i] =null;Log(t);
                    }
                }
                for (i = 0; i < AllDraw.ElefantMidle; i++)
                {
                    try
                    {
                        if (ElephantOnTable[i] == null)
                            continue;
                        ii = ElephantOnTable[i].Row;
                        jj = ElephantOnTable[i].Column;

                        Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < 16; j++)
                        {

                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingBegin = true;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished = false;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[j].Thinking));
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t.Start();
                            Wait(Dummy, i, j, 2);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.ElephantOnTable[i] =null;Log(t);
                    }
                }



                for (i = 0; i < AllDraw.HourseMidle; i++)
                {
                    try
                    {
                        if (HoursesOnTable[i] == null)
                            continue;
                        ii = HoursesOnTable[i].Row;
                        jj = HoursesOnTable[i].Column;

                        Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 8; j++)
                        {

                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingBegin = true;
                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingFinished = false;
                            Dummy.HoursesOnTable[i].HourseThinking[j].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[j].Thinking));
                            Dummy.HoursesOnTable[i].HourseThinking[j].t.Start();
                            Wait(Dummy, i, j, 3);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.HoursesOnTable[i] =null;Log(t);
                    }
                }




                for (i = 0; i < AllDraw.BridgeMidle; i++)
                {
                    try
                    {
                        if (BridgesOnTable[i] == null)
                            continue;
                        ii = BridgesOnTable[i].Row;
                        jj = BridgesOnTable[i].Column;

                        Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 16; j++)
                        {
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingBegin = true;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished = false;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[j].Thinking));
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t.Start();
                            Wait(Dummy, i, j, 4);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.BridgesOnTable[i] =null;Log(t);
                    }
                }
                for (i = 0; i < AllDraw.MinisterMidle; i++)
                {
                    try
                    {
                        if (MinisterOnTable[i] == null)
                            continue;
                        ii = MinisterOnTable[i].Row;
                        jj = MinisterOnTable[i].Column;

                        Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 32; j++)
                        {

                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingBegin = true;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished = false;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[j].Thinking));
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t.Start();
                            Wait(Dummy, i, j, 5);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.MinisterOnTable[i] =null;Log(t);
                    }
                }


                for (i = 0; i < AllDraw.KingMidle; i++)
                {
                    try
                    {
                        if (KingOnTable[i] == null)
                            continue;
                        ii = KingOnTable[i].Row;
                        jj = KingOnTable[i].Column;

                        Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 8; j++)
                        {

                            Dummy.KingOnTable[i].KingThinking[j].ThinkingBegin = true;
                            Dummy.KingOnTable[i].KingThinking[j].ThinkingFinished = false;
                            Dummy.KingOnTable[i].KingThinking[j].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[j].Thinking));
                            Dummy.KingOnTable[i].KingThinking[j].t.Start();
                            Wait(Dummy, i, j, 6);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.KingOnTable[i] =null;Log(t);
                    }
                }
            }
            else
            {
                for (i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        if (SolderesOnTable[i] == null)
                            continue;
                        ii = SolderesOnTable[i].Row;
                        jj = SolderesOnTable[i].Column;

                        Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < 4; j++)
                        {


                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingBegin = true;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished = false;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[j].Thinking));
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t.Start();
                            Wait(Dummy, i, j, 1);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.SolderesOnTable[i] =null;Log(t);
                    }
                }
                for (i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {
                        if (ElephantOnTable[i] == null)
                            continue;
                        ii = ElephantOnTable[i].Row;
                        jj = ElephantOnTable[i].Column;

                        Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < 16; j++)
                        {

                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingBegin = true;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished = false;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[j].Thinking));
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t.Start();
                            Wait(Dummy, i, j, 2);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.ElephantOnTable[i] =null;Log(t);
                    }
                }



                for (i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        if (HoursesOnTable[i] == null)
                            continue;
                        ii = HoursesOnTable[i].Row;
                        jj = HoursesOnTable[i].Column;

                        Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 8; j++)
                        {

                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingBegin = true;
                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingFinished = false;
                            Dummy.HoursesOnTable[i].HourseThinking[j].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[j].Thinking));
                            Dummy.HoursesOnTable[i].HourseThinking[j].t.Start();
                            Wait(Dummy, i, j, 3);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.HoursesOnTable[i] =null;Log(t);
                    }
                }




                for (i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {
                        if (BridgesOnTable[i] == null)
                            continue;
                        ii = BridgesOnTable[i].Row;
                        jj = BridgesOnTable[i].Column;

                        Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 16; j++)
                        {
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingBegin = true;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished = false;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[j].Thinking));
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t.Start();
                            Wait(Dummy, i, j, 4);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.BridgesOnTable[i] =null;Log(t);
                    }
                }
                for (i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {
                        if (MinisterOnTable[i] == null)
                            continue;
                        ii = MinisterOnTable[i].Row;
                        jj = MinisterOnTable[i].Column;

                        Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 32; j++)
                        {

                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingBegin = true;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished = false;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[j].Thinking));
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t.Start();
                            Wait(Dummy, i, j, 5);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.MinisterOnTable[i] =null;Log(t);
                    }
                }


                for (i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                {
                    try
                    {
                        if (KingOnTable[i] == null)
                            continue;
                        ii = KingOnTable[i].Row;
                        jj = KingOnTable[i].Column;

                        Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < 8; j++)
                        {

                            Dummy.KingOnTable[i].KingThinking[j].ThinkingBegin = true;
                            Dummy.KingOnTable[i].KingThinking[j].ThinkingFinished = false;
                            Dummy.KingOnTable[i].KingThinking[j].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[j].Thinking));
                            Dummy.KingOnTable[i].KingThinking[j].t.Start();
                            Wait(Dummy, i, j, 6);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.KingOnTable[i] =null;Log(t);
                    }
                }
            }
           
            //AllDraw Store = new AllDraw();
            //Dummy.Clone(ref Store);
            A.Add(Dummy);

        }
        public void SetRowColumn(int index)
        {
            try
            {
                Move = 0;
                int So1 = 0;
                int So2 = AllDraw.SodierMidle;
                int El1 = 0;
                int El2 = AllDraw.ElefantMidle;
                int Ho1 = 0;
                int Ho2 = AllDraw.HourseMidle;
                int Br1 = 0;
                int Br2 = AllDraw.BridgeMidle;
                int Mi1 = 0;
                int Mi2 = AllDraw.MinisterMidle;
                int Ki1 = 0;
                int Ki2 = AllDraw.KingMidle;
                //A = new List<AllDraw>();
                if (AllDraw.SodierConversionOcuured)
                {
                    //A = new List<AllDraw>();
                    SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
                    for (int i = 0; i < AllDraw.SodierHigh; i++)
                        SolderesOnTable[i] = new DrawSoldier();
                    ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
                    for (int i = 0; i < AllDraw.ElefantHigh; i++)
                        ElephantOnTable[i] = new DrawElefant();
                    HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
                    for (int i = 0; i < AllDraw.HourseHight; i++)
                        HoursesOnTable[i] = new DrawHourse();
                    BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
                    for (int i = 0; i < AllDraw.BridgeHigh; i++)
                        BridgesOnTable[i] = new DrawBridge();
                    MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
                    for (int i = 0; i < AllDraw.MinisterHigh; i++)
                        MinisterOnTable[i] = new DrawMinister();
                    KingOnTable = new DrawKing[AllDraw.KingHigh];
                    for (int i = 0; i < AllDraw.KingHigh; i++)
                        KingOnTable[i] = new DrawKing();
                    AllDraw.SodierConversionOcuured = false;

                }
                if (TableList.Count > 0)
                {
                    for (int Column = 0; Column < 8; Column++)
                        for (int Row = 0; Row < 8; Row++)
                        {

                            if (System.Math.Abs(this.TableList[index][Row, Column]) == 1)
                            {
                                Color a;

                                if (this.TableList[index][Row, Column] > 0)
                                    a = Color.Gray;
                                else
                                    a = Color.Brown;
                                if (a == Color.Gray)
                                {
                                    try
                                    {
                                        if (SolderesOnTable[So1].Row != Row || SolderesOnTable[So1].Column != Column)
                                            Move++;else

                                        SolderesOnTable[So1] = new DrawSoldier(Row, Column, a, this.TableList[index], 1, false, So1);
                                        So1++;
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                                else
                                {
                                    try
                                    {
                                        if (SolderesOnTable[So2].Row != Row ||
                                            SolderesOnTable[So2].Column != Column)
                                            Move++;
                                        SolderesOnTable[So2] = new DrawSoldier(Row, Column, a, this.TableList[index], -1, false, So2);
                                        So2++;
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                            }
                            else
                                if (System.Math.Abs(this.TableList[index][Row, Column]) == 2)
                                {
                                    Color a;

                                    if (this.TableList[index][Row, Column] > 0)
                                        a = Color.Gray;
                                    else
                                        a = Color.Brown;
                                    if (a == Color.Gray)
                                    {
                                        try
                                        {
                                            if (ElephantOnTable[El1].Row != Row ||
                                            ElephantOnTable[El1].Column != Column)
                                                Move++;
                                            ElephantOnTable[El1] = new DrawElefant(Row, Column, a, this.TableList[index], 1, false, El1);
                                            El1++;
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                    else
                                    {
                                        try
                                        {
                                            if (ElephantOnTable[El2].Row != Row ||
                                            ElephantOnTable[El2].Column != Column)
                                                Move++;
                                            ElephantOnTable[El2] = new DrawElefant(Row, Column, a, this.TableList[index], -1, false, El2);
                                            El2++;
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }

                                    }
                                }
                                else
                                    if (System.Math.Abs(this.TableList[index][Row, Column]) == 3)
                                    {
                                        Color a;

                                        if (this.TableList[index][Row, Column] > 0)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        if (a == Color.Gray)
                                        {

                                            try
                                            {
                                                if (HoursesOnTable[Ho1].Row != Row ||
                                                HoursesOnTable[Ho1].Column != Column)
                                                    Move++;
                                                HoursesOnTable[Ho1] = new DrawHourse(Row, Column, a, this.TableList[index], 1, false, Ho1);
                                                Ho1++;
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        else
                                        {
                                            try
                                            {
                                                if (HoursesOnTable[Ho2].Row != Row |
                                                HoursesOnTable[Ho2].Column != Column)
                                                    Move++;

                                                HoursesOnTable[Ho2] = new DrawHourse(Row, Column, a, this.TableList[index], -1, false, Ho2);
                                                Ho2++;
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                    }
                                    else
                                        if (System.Math.Abs(this.TableList[index][Row, Column]) == 4)
                                        {
                                            Color a;

                                            if (this.TableList[index][Row, Column] > 0)
                                                a = Color.Gray;
                                            else
                                                a = Color.Brown;
                                            if (a == Color.Gray)
                                            {

                                                try
                                                {
                                                    if (BridgesOnTable[Br1].Row != Row ||
                                                    BridgesOnTable[Br1].Column != Column)
                                                        Move++;

                                                    BridgesOnTable[Br1] = new DrawBridge(Row, Column, a, this.TableList[index], 1, false, Br1);
                                                    Br1++;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (BridgesOnTable[Br2].Row != Row ||
                                                    BridgesOnTable[Br2].Column != Column)
                                                        Move++;
                                                    BridgesOnTable[Br2] = new DrawBridge(Row, Column, a, this.TableList[index], -1, false, Br2);
                                                    Br2++;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        else
                                            if (System.Math.Abs(this.TableList[index][Row, Column]) == 5)
                                            {
                                                Color a;

                                                if (this.TableList[index][Row, Column] > 0)
                                                    a = Color.Gray;
                                                else
                                                    a = Color.Brown;
                                                if (a == Color.Gray)
                                                {

                                                    try
                                                    {
                                                        if (MinisterOnTable[Mi1].Row != Row ||
                                                        MinisterOnTable[Mi1].Column != Column)
                                                            Move++;
                                                        MinisterOnTable[Mi1] = new DrawMinister(Row, Column, a, this.TableList[index], 1, false, Mi1);
                                                        Mi1++;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }

                                                }
                                                else
                                                {
                                                    try
                                                    {
                                                        if (MinisterOnTable[Mi2].Row != Row ||
                                                        MinisterOnTable[Mi2].Column != Column)
                                                            Move++;
                                                        MinisterOnTable[Mi2] = new DrawMinister(Row, Column, a, this.TableList[index], -1, false, Mi2);
                                                        Mi2++;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }
                                                }
                                            }
                                            else
                                                if (System.Math.Abs(this.TableList[index][Row, Column]) == 6)
                                                {
                                                    Color a;

                                                    if (this.TableList[index][Row, Column] > 0)
                                                        a = Color.Gray;
                                                    else
                                                        a = Color.Brown;
                                                    if (a == Color.Gray)
                                                    {

                                                        try
                                                        {
                                                            if (KingOnTable[Ki1].Row != Row ||
                                                       KingOnTable[Ki1].Column != Column)
                                                                Move++;

                                                            KingOnTable[Ki1] = new DrawKing(Row, Column, a, this.TableList[index], 1, false, Ki1);
                                                            Ki1++;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        try
                                                        {
                                                            if (KingOnTable[Ki2].Row != Row ||
                                                       KingOnTable[Ki2].Column != Column)
                                                                Move++;
                                                            KingOnTable[Ki2] = new DrawKing(Row, Column, a, this.TableList[index], -1, false, Ki2);
                                                            Ki2++;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                        }
                                                    }

                                                }
                        }
                    for (int i = So1; i < AllDraw.SodierMidle; i++)
                        SolderesOnTable[i] = null;

                    for (int i = So2; i < AllDraw.SodierHigh; i++)
                        SolderesOnTable[i] = null;

                    for (int i = El1; i < AllDraw.ElefantMidle; i++)
                        ElephantOnTable[i] = null;

                    for (int i = El2; i < AllDraw.ElefantHigh; i++)
                        ElephantOnTable[i] = null;

                    for (int i = Ho1; i < AllDraw.HourseMidle; i++)
                        HoursesOnTable[i] = null;

                    for (int i = Ho2; i < AllDraw.HourseHight; i++)
                        HoursesOnTable[i] = null;

                    for (int i = Br1; i < AllDraw.BridgeMidle; i++)
                        BridgesOnTable[i] = null;

                    for (int i = Br2; i < AllDraw.BridgeHigh; i++)
                        BridgesOnTable[i] = null;

                    for (int i = Mi1; i < AllDraw.MinisterMidle; i++)
                        MinisterOnTable[i] = null;

                    for (int i = Mi2; i < AllDraw.MinisterHigh; i++)
                        MinisterOnTable[i] = null;

                    for (int i = Ki1; i < AllDraw.KingMidle; i++)
                        KingOnTable[i] = null;

                    for (int i = Ki2; i < AllDraw.KingHigh; i++)
                        KingOnTable[i] = null;

                }
                AllDraw.RedrawTable = true;
            }
            catch (Exception t)
            {
                Log(t);
            }
        }
        public int[,] HuristicKish(List<AllDraw> A, Color a, int ij, ref double Less, int Order)
        {
            int i = 0, j = 0;
            int[,] Table = new int[8, 8];
            bool Act = false;

            //KishB = ChessRules.KishBrown;
            //KishG = ChessRules.KishGray;
            int ii = ij;
            if (A.Count > 0)
            {
                for (i = 0; i < AllDraw.SodierHigh; i++)
                {


                    for (int k = 0; k < 4; k++)
                        for (j = 0; A[ii].SolderesOnTable[i] != null && A[ii].SolderesOnTable[i].SoldierThinking[k] != null && j < A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder.Count; j++)
                        {
                            try
                            {   //     A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicAttack(A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, a);
                                //   A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicMovment(A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], a);
                                if (A[ii].SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0)
                                    continue;
                                //if (KishG || KishB)
                                //{
                                
                                if (A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] > Less)
                                {
                                    int[,] TableS = A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                    if ((new ChessRules(1, TableS, OrderDummy).AchmazKingMove(OrderDummy, TableS, true)))
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    // }
                                    else
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    KishHuristic = true;
                                    RW = i;
                                    CL = k;
                                    Ki = 1;
                                    Act = true;
                                    Less = A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];


                                    Table = A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                    ThingsConverter.ActOfClickEqualTow = true;
                                    A[ii].SolderesOnTable[i].ConvertOperation(A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], a, A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, false, i);
                                    int Sign = 1;
                                    if (a == Color.Brown)
                                        Sign = -1;
                                    if (A[ii].SolderesOnTable[i].Convert)
                                    {
                                        
                                        if (A[ii].SolderesOnTable[i].ConvertedToMinister)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 5 * Sign;
                                        else if (A[ii].SolderesOnTable[i].ConvertedToBridge)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 4 * Sign;
                                        else if (A[ii].SolderesOnTable[i].ConvertedToHourse)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 3 * Sign;
                                        else if (A[ii].SolderesOnTable[i].ConvertedToElefant)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 2 * Sign;
                                        TableList.Clear();
                                        TableList.Add(Table);
                                        A[ii].SetRowColumn(0);
                                        TableList.Clear();
                                    }
                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.ElefantHigh; i++)
                {
                    for (int k = 0; k < 16; k++)
                        for (j = 0; A[ii].ElephantOnTable[i] != null && A[ii].ElephantOnTable[i].ElefantThinking[k] != null && j < A[ii].ElephantOnTable[i].ElefantThinking[k].TableListElefant.Count; j++)
                        {
                            try
                            {
                                //   A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicAttack(A[ii].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j], Order, a);
                                //    A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicMovment(A[ii].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j], a);
                                if (A[ii].ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0 )
                                    continue;
                                //if (KishG || KishB)
                                //{
                                
                                if (A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] > Less)
                                {
                                    int[,] TableS = A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                    if ((new ChessRules(2, TableS, OrderDummy).AchmazKingMove(OrderDummy, TableS, true)))
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    //}
                                    else
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    KishHuristic = true;
                                    RW = i;
                                    CL = k;
                                    Ki = 2;
                                    Act = true;
                                    Less = A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];
                                    Table = A[ii].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.HourseHight; i++)
                {

                    for (int k = 0; k < 8; k++)
                        for (j = 0; A[ii].HoursesOnTable[i] != null && A[ii].HoursesOnTable[i].HourseThinking[k] != null && j < A[ii].HoursesOnTable[i].HourseThinking[k].TableListHourse.Count; j++)
                        {
                            try
                            {    //  A[ii].HoursesOnTable[i].HourseThinking[k].HuristicAttack(A[ii].HoursesOnTable[i].HourseThinking[k].TableListHourse[j], Order, a);
                                //   A[ii].HoursesOnTable[i].HourseThinking[k].HuristicMovment(A[ii].HoursesOnTable[i].HourseThinking[k].TableListHourse[j], a);
                                if (A[ii].HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0 )
                                    continue;
                                //if (KishG || KishB)
                                {
                                    
                                }

                                if (A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] > Less)
                                {

                                    int[,] TableS = A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                    if ((new ChessRules(3, TableS, OrderDummy).AchmazKingMove(OrderDummy, TableS, true)))
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGray)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrown)
                                                continue;

                                        }
                                    }
                                    KishHuristic = true; 
                                    RW = i;
                                    CL = k;
                                    Ki = 3;
                                    Act = true;
                                    Less = A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                    Table = A[ii].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }


                }

                for (i = 0; i < AllDraw.BridgeHigh; i++)
                {
                    for (int k = 0; k < 16; k++)
                        for (j = 0; A[ii].BridgesOnTable[i] != null && A[ii].BridgesOnTable[i].BridgeThinking[k] != null && j < A[ii].BridgesOnTable[i].BridgeThinking[k].TableListBridge.Count; j++)
                        {
                            try
                            {
                                //   A[ii].A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicAttack(A[ii].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j], Order, a);
                                //    A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicMovment(A[ii].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j], a);
                                if (A[ii].BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListBridge[j].IsPenaltyAction() == 0)
                                    continue;
                                //if (KishG || KishB)
                                {
                                    
                                }
                                if (A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] > Less)
                                {

                                    int[,] TableS = A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                    if ((new ChessRules(4, TableS, OrderDummy).AchmazKingMove(OrderDummy, TableS, true)))
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGray)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrown)
                                                continue;

                                        }
                                    }
                                    KishHuristic = true; 
                                    RW = i;
                                    CL = k;
                                    Ki = 4;
                                    Act = true;
                                    Less = A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];
                                    Table = A[ii].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }


                for (i = 0; i < AllDraw.MinisterHigh; i++)
                {

                    for (int k = 0; k < 32; k++)
                        for (j = 0; A[ii].MinisterOnTable[i] != null && A[ii].MinisterOnTable[i].MinisterThinking[k] != null && j < A[ii].MinisterOnTable[i].MinisterThinking[k].TableListMinister.Count; j++)
                        {
                            try
                            {       //   A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicAttack(A[ii].MinisterOnTable[i].MinisterThinking[k].TableListBridge[j], Order, a);
                                //    A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicMovment(A[ii].MinisterOnTable[i].MinisterThinking[k].TableListBridge[j], a);
                                if (A[ii].MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0)
                                    continue;
                                //if (KishG || KishB)
                                {
                                    
                                }
                                if (A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] > Less)
                                {
                                    int[,] TableS = A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                    if ((new ChessRules(5, TableS, OrderDummy).AchmazKingMove(OrderDummy, TableS, true)))
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    KishHuristic = true; 
                                    RW = i;
                                    CL = k;
                                    Ki = 5;
                                    Act = true;
                                    Less = A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3];
                                    Table = A[ii].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.KingHigh; i++)
                {
                    for (int k = 0; k < 8; k++)
                        for (j = 0; A[ii].KingOnTable[i] != null && A[ii].KingOnTable[i].KingThinking[k] != null && j < A[ii].KingOnTable[i].KingThinking[k].TableListKing.Count; j++)
                        {
                            try
                            {
                                //      A[ii].KingOnTable[i].KingThinking[k].HuristicAttack(A[ii].KingOnTable[i].KingThinking[k].TableListKing[j], Order, a);
                                //     A[ii].KingOnTable[i].KingThinking[k].HuristicMovment(A[ii].KingOnTable[i].KingThinking[k].TableListKing[j], a);
                                if (A[ii].KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                    continue;
                                //if (KishG || KishB)
                                {
                                    
                                }
                                if (A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] > Less)
                                {
                                    int[,] TableS = A[0].KingOnTable[i].KingThinking[k].TableListKing[j];
                                    if ((new ChessRules(6, TableS, OrderDummy).AchmazKingMove(OrderDummy, TableS, true)))
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (OrderDummy == 1)
                                        {
                                            if (ChessRules.KishGrayAchmaz)
                                                continue;
                                        }
                                        else
                                        {
                                            if (ChessRules.KishBrownAchmaz)
                                                continue;

                                        }
                                    }
                                    KishHuristic = true; 
                                    RW = i;
                                    CL = k;
                                    Ki = 6;
                                    Act = true;
                                    Less = A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                    Table = A[ii].KingOnTable[i].KingThinking[k].TableListKing[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }
            }
            if (KishHuristic)
                return Table;
            return null;
        }

        public int[,] InitiatePerdictKish(int ii, int jj, Color a, int[,] Table, int Order, bool TB)
        {
            int[,] TablInit = new int[8, 8];

            int[,] TablInitOne = new int[8, 8];
            int[,] TablInitKish = new int[8, 8];

            int Current = ChessRules.CurrentOrder;
            OrderDummy = Order;
            A.Clear();
            TableList.Clear();
              bool Dummy = ThinkingChess.NotSolvedKingDanger;
            ThinkingChess.NotSolvedKingDanger = false;
            LoopHuristicIndex = 0;
            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                {
                    TablInitOne[iii, jjj] = Table[iii, jjj];
                }
            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                {
                    TablInitKish[iii, jjj] = TablInitOne[iii, jjj];
                }
            if (new ChessRules(1, TablInitKish, Order).Kish(TablInitKish, Order))
            {
                if (OrderDummy == 1)
                {
                    if (ChessRules.KishGray)
                        return null;

                }
                else
                {
                    if (ChessRules.KishGray)
                        return null;
                }
            }      
            for (int i = 0; i < 2; i++)
            {
                
                if (i != 0)
                    this.SetRowColumn(i);
               if (Order == 1)
                {
                    THIS.SetBoxText("\r\nChess Predict Thinking Dept " + (i + 1).ToString() + " By Bob!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nChess Predict Thinking Dept " + (i + 1).ToString() + " By Alice!");
                    THIS.RefreshBoxText();
                }
               
                if (Order == 1)
                    a = Color.Gray;
                else
                    a = Color.Brown;
                int In = 0;
                int iiii = 0;
                do
                {
                    if (Order == 1)
                        In = (new System.Random()).Next(0, 8);
                    else
                        
                        In = (new System.Random()).Next(8, 16);
                    iiii++;
                } while (SolderesOnTable[In] == null && iiii < 16);
                if (iiii < 16)
                    this.InitiateForEveryKindThingHome(new AllDraw(ref THIS), SolderesOnTable[In].Row, SolderesOnTable[In].Column, a, TablInit, Order, false, In);
                else                
                    this.InitiateForEveryKindThingHome(new AllDraw(ref THIS), 1, 2, a, TablInit, Order, false, In);
                

                double Less = -100000;
                int[,] Tab = null;
                if (A.Count > 0)
                {
                    if (Order == 1)
                    {
                        THIS.SetBoxText("\r\nHuristic Kish Considerasion Movements Dept " + i.ToString() + " By Bob!");
                        THIS.RefreshBoxText();
                    }
                    else
                    {
                        THIS.SetBoxText("\r\nHuristic Kish Considerasion Movements Dept " + i.ToString() + " By Alice!");
                        THIS.RefreshBoxText();

                    }
                    Tab = HuristicKish(A, a, i, ref Less, Order);
                }
                if (Tab == null)
                {
                    ThinkingChess.NotSolvedKingDanger = Dummy;
                    ChessRules.CurrentOrder = Current;
                    Order = OrderDummy;
                    return null;
                }

               /* if (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                {
                    while (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                    {
                        TableListAction.RemoveAt(LoopHuristicIndex);
                    }
                    ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                    Tab = R.GenerateTable(TableListAction, LoopHuristicIndex, Order);

                }
                */

                if (Tab != null)
                {
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            TablInit[iii, jjj] = Tab[iii, jjj];
                        }

                    TableList.Add(TablInit);
                    ClList.Add(CL);
                    RWList.Add(RW);
                    KiList.Add(Ki);
                    //Order = Order * -1;
                    //ChessRules.CurrentOrder = Order;

                    Dept++;
                    ChessRules.CurrentOrder *= -1;
                    Order *= -1;



                }
                else
                {
                    ThinkingChess.NotSolvedKingDanger = Dummy;
                    ChessRules.CurrentOrder = Current;
                    Order = OrderDummy;
            
                    return null;
                }
            }
            ThinkingChess.NotSolvedKingDanger = Dummy;
            ChessRules.CurrentOrder = Current;
            Order = OrderDummy;
            
            return TablInitOne;
        }
        public bool InitiatePerdictKishEnemy(int ii, int jj, Color a, int[,] Table, int Order, bool TB)
        {
            int Current = ChessRules.CurrentOrder;
            int OrderDummy = Order;
            A.Clear();
            TableList.Clear();
            ChessRules.CurrentOrder *= -1;
            Order *= -1;
            bool Dummy = ThinkingChess.NotSolvedKingDanger;
            ThinkingChess.NotSolvedKingDanger = false;
            LoopHuristicIndex = 0;
            for (int i = 0; i < 1; i++)
            {
                 int[,] TablInit = new int[8, 8];
                if (Order == 1)
                    a = Color.Gray;
                else
                    a = Color.Brown;
                int In = 0;

                do
                {
                    if (Order == 1)
                        In = (new System.Random()).Next(0, 8);
                    else
                        In = (new System.Random()).Next(8, 16);
                } while (SolderesOnTable[In] == null);

                this.InitiateForEveryKindThingHome(new AllDraw(ref THIS), SolderesOnTable[In].Row, SolderesOnTable[In].Column, a, Table, Order, false, In);

                double Less = 0;
                int[,] Tab = null;
                if (A.Count > 0)
                    Tab = HuristicKish(A, a, i, ref Less, Order);
                if (Tab == null)
                {
                    ThinkingChess.NotSolvedKingDanger = Dummy;
                    ChessRules.CurrentOrder = Current;
                    Order = OrderDummy;
                    return false;
                }

                if (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                {
                    while (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                    {
                        TableListAction.RemoveAt(LoopHuristicIndex);
                    }
                    ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                    Tab = R.GenerateTable(TableListAction, LoopHuristicIndex, Order);

                }

                if (Tab != null)
                {
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            TablInit[iii, jjj] = Tab[iii, jjj];
                        }
                    Table = new int[8, 8];
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            Table[iii, jjj] = TablInit[iii, jjj];
                        }
                    TableList.Add(TablInit);
                    ClList.Add(CL);
                    RWList.Add(RW);
                    KiList.Add(Ki);
                    Order = Order * -1;
                    ChessRules.CurrentOrder = Order;
                    Dept++;

                }
            }
            ThinkingChess.NotSolvedKingDanger = Dummy;
            ChessRules.CurrentOrder = Current;
            Order = OrderDummy;
            return true;
        }


    }
}


    

