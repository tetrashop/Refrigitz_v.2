﻿/****************************************************************************
 * Thinking Operation class.*************************************************
 * Ramin Edjlal**************************************************************
 * Drived Classess of Autamata Cellular Quantum Thinking Kernel**************
 * 1394/12/19****************************************************************
 * Crashed with Stack Overflow Exception*************************************(+)
 * Drives Caused Memory lack*************************************************(+)
 * New Version Cased Stack Overflow******************************************(+)
 * Scanning Four Dimension Homes of Thing Existences Taking A lot Of Time****(+)
 * All Data in This Scope From AllDraw Become Clear When Scope Changes*******(+)
 * Heuristic Work but the Movements And Attack Method Doesn’t work***********(+)
 * Probability Heuristic constant Table return*******************************(+)
 * Heuristic Working Not Constant Immunity***********************************(+)
 * Heuristic Constant Result Mechanism***************************************(+)
 * Things Order and Virtualization Error*************************************(+)
 * Misleading Things Order movement******************************************(+)
 * Multi Movements (3 ) In Chess Thinking************************************(+)
 * Location of Horse 'Bob' (Gray) After Hitting Un logically Unsupported*****(+)
 * Kish Thinking 'Alice' Malfunction*****************************************(+)
 * 'Mate' By 'Bob' Have Not Been Recognized.*********************************(+)
 * 'Kish' By 'Bob' Not Recognized.*******************************************(+)
 * 'Kish' 'Alice' Detected. No Action Was Done.******************************(+)
 * 'Kish' Mechanism Failure.*************************************************(+)
 * Strategy By 'Alice' Changed. 'Kish' Not Recognized By 'Alice'.************(+)
 * Heuristic Loop************************************************************(+)
 * 'Kish' Mechanism For Penalty Regard Is Malfunction************************(*)
 * Things Location Failure. Row and Column of this Objects class Malfunction*(+)
 * Malfunction Of Operating Lists in this class.*****************************(+)
 * Some Movements of All Possible Movements is not Identified****************(+)
 * Malfunction Clone Data To be Copied. List Will be erased******************(+)
 * King Cannot Hit Unsupported Enemy Things at Kish.*************************(+)
 * Thinking Time Taking al lot of time.**************************************(+)
 * There is No Reason For Mal Function of Thinking.**************************[+]
 * Huristic Supported at horse huristic cal at table content malfunction.****[+]
 * No Reason for malfunctioning of table content at huristic supported.******[+]
 * Thinking Finished Misleading.bool Variable of Think Finished Not Work on.* 
 * A non Identified King Table List Alice is in List and Unhabitly ignored.** 
 * The Location of Penalty Regard Mechansim is Misleading.*******************
 * Penalty Reagrd List is Empty.No Misleading List of Penalty Regard Mec.****
 * No Ilegal Non Achmaz and Kish By 'Alice' at Current Game in PR Mech.******
 * **************************************************************************(+:Sum(26)) (*:Sum(1)) 5:(+:Sum(3))
 * **************************************************************************
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading;
using LearningMachine;
using System.IO;
namespace Refrigtz
{
    public class ThinkingChess
    {
        public static bool UsePenaltyRegardMechnisam = false;
        public static bool BestMovments = true;
        public static bool PredictHuristic = false;
        public static bool OnlySelf = false;
        public static bool DeptHuristic = false;
        public List<int> HitNumber = new List<int>();
        public static bool NotSolvedKingDanger = false;
        // public LearningKrinskyAtamata Current = null;
        public static bool ThinkingRun = false;
        int ThingsNumber = 0;
        bool Init = false;
        int CurrentArray = 0;
        static bool ExistEnemy = false;
        public double HuristicValue = 0;
        public double HuristicValueMovement = 0;
        public double HuristicValueSupported = 0;
        public double HuristicValueAchmaz = 0;
        public bool ThinkingBegin = false;
        public bool ThinkingFinished = false;
        public int IndexSoldier = 0;
        public int IndexElefant = 0;
        public int IndexHourse = 0;
        public int IndexBridge = 0;
        public int IndexMinister = 0;
        public int IndexKing = 0;
        static public int Index = 0;

        static public int[,] RowColumn;
        public List<int[]> RowColumnSoldier;
        public List<int[]> RowColumnElefant;
        public List<int[]> RowColumnHourse;
        public List<int[]> RowColumnBridge;
        public List<int[]> RowColumnMinister;
        public List<int[]> RowColumnKing;
        public int[,] Table;
        public List<int> HitNumberSoldier;
        public List<int> HitNumberElefant;
        public List<int> HitNumberHourse;
        public List<int> HitNumberBridge;
        public List<int> HitNumberMinister;
        public List<int> HitNumberKing;

        public int[,] TableConst;
        public List<int[,]> TableListSolder = new List<int[,]>();
        public List<int[,]> TableListElefant = new List<int[,]>();
        public List<int[,]> TableListHourse = new List<int[,]>();
        public List<int[,]> TableListBridge = new List<int[,]>();
        public List<int[,]> TableListMinister = new List<int[,]>();
        public List<int[,]> TableListKing = new List<int[,]>();

        public List<double[]> HuristicListSolder = new List<double[]>();
        public List<double[]> HuristicListElefant = new List<double[]>();
        public List<double[]> HuristicListHourse = new List<double[]>();
        public List<double[]> HuristicListBridge = new List<double[]>();
        public List<double[]> HuristicListMinister = new List<double[]>();
        public List<double[]> HuristicListKing = new List<double[]>();

        public List<QuantumAtamata> PenaltyRegardListSolder = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListElefant = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListHourse = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListBridge = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListMinister = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListKing = new List<QuantumAtamata>();
        public int Max;
        public int Row, Column;
        Color color;
        int Order;
        public Thread t = null;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
        public ThinkingChess()
        {

            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            RowColumnSoldier = new List<int[]>();
            RowColumnElefant = new List<int[]>();
            RowColumnHourse = new List<int[]>();
            RowColumnBridge = new List<int[]>();
            RowColumnMinister = new List<int[]>();
            RowColumnKing = new List<int[]>();
            RowColumn = new int[32 * 64, 2];
            HitNumberSoldier = new List<int>();
            HitNumberElefant = new List<int>();
            HitNumberHourse = new List<int>();
            HitNumberBridge = new List<int>();
            HitNumberMinister = new List<int>();
            HitNumberKing = new List<int>();

            PenaltyRegardListSolder = new List<QuantumAtamata>();
            PenaltyRegardListElefant = new List<QuantumAtamata>();
            PenaltyRegardListHourse = new List<QuantumAtamata>();
            PenaltyRegardListBridge = new List<QuantumAtamata>();
            PenaltyRegardListMinister = new List<QuantumAtamata>();
            PenaltyRegardListKing = new List<QuantumAtamata>();

        }
        public ThinkingChess(int i, int j, Color a, int[,] Tab, int Ma, int Ord, bool ThinkingBeg, int CurA, int ThingN)
        {

            ThingsNumber = ThingN;
            CurrentArray = CurA;
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            RowColumnSoldier = new List<int[]>();
            RowColumnElefant = new List<int[]>();
            RowColumnHourse = new List<int[]>();
            RowColumnBridge = new List<int[]>();
            RowColumnMinister = new List<int[]>();
            RowColumnKing = new List<int[]>();
            RowColumn = new int[1000000, 2];
            HitNumberSoldier = new List<int>();
            HitNumberElefant = new List<int>();
            HitNumberHourse = new List<int>();
            HitNumberBridge = new List<int>();
            HitNumberMinister = new List<int>();
            HitNumberKing = new List<int>();

            PenaltyRegardListSolder = new List<QuantumAtamata>();
            PenaltyRegardListElefant = new List<QuantumAtamata>();
            PenaltyRegardListHourse = new List<QuantumAtamata>();
            PenaltyRegardListBridge = new List<QuantumAtamata>();
            PenaltyRegardListMinister = new List<QuantumAtamata>();
            PenaltyRegardListKing = new List<QuantumAtamata>();

            Row = i;
            Column = j;
            color = a;
            Max = Ma;
            Table = Tab;
            Index = 0;
            IndexSoldier = 0;
            IndexElefant = 0;
            IndexHourse = 0;
            IndexBridge = 0;
            IndexMinister = 0;
            IndexKing = 0;
            TableConst = new int[8, 8];
            for (int ii = 0;
                ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    TableConst[ii, jj] = Table[ii, jj];
                }
            Order = Ord;
            ThinkingBegin = ThinkingBeg;

        }

        public void Clone(ref ThinkingChess AA)
        {
            AA = new ThinkingChess();
            AA.color = color;
            AA.Column = Column;
            AA.HuristicValue = HuristicValue;
            AA.HuristicValueMovement = HuristicValueMovement;
            AA.HuristicValueAchmaz = HuristicValueAchmaz;
            AA.HuristicValueSupported = HuristicValueSupported;
            AA.HitNumber = HitNumber;
            AA.HitNumberBridge = HitNumberBridge;
            AA.HitNumberElefant = HitNumberElefant;
            AA.HitNumberHourse = HitNumberHourse;
            AA.HitNumberKing = HitNumberKing;
            AA.HitNumberMinister = HitNumberMinister;
            AA.HitNumberSoldier = HitNumberSoldier;
            AA.IndexBridge = IndexBridge;
            AA.IndexElefant = IndexElefant;
            AA.IndexHourse = IndexHourse;
            AA.IndexKing = IndexKing;
            AA.IndexMinister = IndexMinister;
            AA.IndexSoldier = IndexSoldier;
            AA.Max = Max;
            AA.Order = Order;
            AA.Row = Row;

            for (int j = 0; j < RowColumnSoldier.Count; j++)
                AA.RowColumnSoldier.Add(RowColumnSoldier[j]);

            for (int j = 0; j < RowColumnBridge.Count; j++)
                AA.RowColumnBridge.Add(RowColumnBridge[j]);


            for (int j = 0; j < RowColumnElefant.Count; j++)
                AA.RowColumnElefant.Add(RowColumnElefant[j]);
           
            for (int j = 0; j < RowColumnHourse.Count; j++)
                     AA.RowColumnHourse.Add(RowColumnHourse[j]);

            for (int j = 0; j < RowColumnKing.Count; j++)
                AA.RowColumnKing.Add(RowColumnKing[j]);

            for (int j = 0; j < RowColumnMinister.Count; j++)
                AA.RowColumnMinister.Add(RowColumnMinister[j]);

            AA.t = t;
            AA.Table = new int[8, 8];
            AA.TableConst = new int[8, 8];
            if (Table != null)
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        AA.Table[i, j] = Table[i, j];
            if (TableConst != null)
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        AA.TableConst[i, j] = TableConst[i, j];
            for (int i = 0; i < TableListBridge.Count; i++)
                AA.TableListBridge.Add(TableListBridge[i]);

            for (int i = 0; i < TableListElefant.Count; i++)
                AA.TableListElefant.Add(TableListElefant[i]);

            for (int i = 0; i < TableListHourse.Count; i++)
                AA.TableListHourse.Add(TableListHourse[i]);

            for (int i = 0; i < TableListKing.Count; i++)
                AA.TableListKing.Add(TableListKing[i]);

            for (int i = 0; i < TableListMinister.Count; i++)
                AA.TableListMinister.Add(TableListMinister[i]);

            for (int i = 0; i < TableListSolder.Count; i++)
                AA.TableListSolder.Add(TableListSolder[i]);


            for (int i = 0; i < HuristicListSolder.Count; i++)
                AA.HuristicListSolder.Add(HuristicListSolder[i]);


            for (int i = 0; i < HuristicListElefant.Count; i++)
                AA.HuristicListElefant.Add(HuristicListElefant[i]);

            for (int i = 0; i < HuristicListHourse.Count; i++)
                AA.HuristicListHourse.Add(HuristicListHourse[i]);


            for (int i = 0; i < HuristicListBridge.Count; i++)
                AA.HuristicListBridge.Add(HuristicListBridge[i]);

            for (int i = 0; i < HuristicListMinister.Count; i++)
                AA.HuristicListMinister.Add(HuristicListMinister[i]);

            for (int i = 0; i < HuristicListKing.Count; i++)
                AA.HuristicListKing.Add(HuristicListKing[i]);

         

            for (int i = 0; i < PenaltyRegardListSolder.Count; i++)
                AA.PenaltyRegardListSolder.Add(PenaltyRegardListSolder[i]);


            for (int i = 0; i < PenaltyRegardListElefant.Count; i++)
                AA.PenaltyRegardListElefant.Add(PenaltyRegardListElefant[i]);

            for (int i = 0; i < PenaltyRegardListHourse.Count; i++)
                AA.PenaltyRegardListHourse.Add(PenaltyRegardListHourse[i]);


            for (int i = 0; i < PenaltyRegardListBridge.Count; i++)
                AA.PenaltyRegardListBridge.Add(PenaltyRegardListBridge[i]);

            for (int i = 0; i < PenaltyRegardListMinister.Count; i++)
                AA.PenaltyRegardListMinister.Add(PenaltyRegardListMinister[i]);

            for (int i = 0; i < PenaltyRegardListKing.Count; i++)
                AA.PenaltyRegardListKing.Add(PenaltyRegardListKing[i]);

            AA.ThinkingBegin = ThinkingBegin;
            AA.ThinkingFinished = ThinkingFinished;

        }
        int MaxOrderEnemyAndSelf(int[,] Tab, int i, int j, int ii, int jj, int Order)
        {
            int MaxOrder = 0;
            if (Order == 1)
            {
                if (Tab[i, j] > 0)
                {
                    int Store = Tab[ii, jj];
                    Tab[ii, jj] = 0;
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                            if (!Attack(Tab, iii, jjj, i, j, Color.Brown, Order))
                            {
                                if (System.Math.Abs(Tab[i, j]) < System.Math.Abs(Tab[ii, jj]))
                                    MaxOrder = Tab[ii, jj];
                                else
                                    MaxOrder = Tab[i, j];
                            }
                    Tab[ii, jj] = Store;

                }

            }
            if (Order == -1)
            {
                if (Tab[i, j] < 0)
                {
                    int Store = Tab[ii, jj];
                    Tab[ii, jj] = 0;
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                            if (!Attack(Tab, iii, jjj, i, j, Color.Brown, Order))
                            {
                                if (System.Math.Abs(Tab[i, j]) < System.Math.Abs(Tab[ii, jj]))
                                    MaxOrder = Tab[ii, jj];
                                else
                                    MaxOrder = Tab[i, j];
                            }
                    Tab[ii, jj] = Store;
                }

            }
            return MaxOrder;

        }
        float HuristicAttack(int[,] Table, int Order, Color a)
        {
            int HA = 0;

            if (!DeptHuristic)
            {
                int i = Row, j = Column;
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        if (i == ii && j == jj)
                            continue;
                        int Sign = 1;
                        if (BestMovments)
                        {
                            if (Table[i, j] > 0)
                            {
                                a = Color.Gray;
                                Order = 1;
                            }
                            else
                                if (Table[i, j] < 0)
                                {
                                    Order = -1;
                                    a = Color.Brown;
                                }
                                else
                                    continue;
                        }
                        if (!OnlySelf)
                        {
                            if (Order == 1 && Table[i, j] < 0)
                                Sign = -1;
                            if (Order == -1 && Table[i, j] > 0)
                                Sign = -1;
                        }



                        if (Attack(Table, i, j, ii, jj, a, Order))
                        {
                            if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                                HA -= MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                            else
                            {
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    HA -= AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    HA -= AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    HA -= AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    HA -= AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    HA -= AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    HA -= AllDraw.KingValue * Sign;
                            }



                        }





                    }
                }

            }
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                int Sign = 1;
                                if (Table[i, j] > 0)
                                {
                                    a = Color.Gray;
                                    Order = 1;
                                }
                                else
                                    if (Table[i, j] < 0)
                                    {
                                        Order = -1;
                                        a = Color.Brown;
                                    }
                                    else
                                        continue;


                                if (Order == 1 && Table[i, j] < 0)
                                    Sign = -1;
                                if (Order == -1 && Table[i, j] > 0)
                                    Sign = -1;


                                if (Attack(Table, i, j, ii, jj, a, Order))
                                {

                                    if (System.Math.Abs(Table[i, j]) == 1)
                                        HA -= AllDraw.SodierValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 2)
                                        HA -= AllDraw.ElefantValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 3)
                                        HA -= AllDraw.HourseValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 4)
                                        HA -= AllDraw.BridgeValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 5)
                                        HA -= AllDraw.MinisterValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 6)
                                        HA -= AllDraw.KingValue * Sign;
                                }
                            }
                        }
                    }
                }
            }
            HuristicValue += HA;
            return HA;
        }
        float HuristicAchmaz(int[,] Table, int Order, Color a)
        {
            int HA = 0;

            if (!DeptHuristic)
            {
                int i = Row, j = Column;
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        if (i == ii && j == jj)
                            continue;
                        int Sign = 1;
                        if (!OnlySelf)
                        {
                            if (Order == 1 && Table[i, j] < 0)
                                Sign = -1;
                            if (Order == -1 && Table[i, j] > 0)
                                Sign = -1;

                        }
                        if (BestMovments)
                        {
                            if (Table[ii, jj] > 0)
                            {
                                a = Color.Gray;
                                Order = 1;
                            }
                            else
                                if (Table[ii, jj] < 0)
                                {
                                    Order = -1;
                                    a = Color.Brown;
                                }
                                else
                                    continue;
                        }
                        if (Achmaz(Table, ii, jj, i, j, a, Order))
                        {

                            if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                                HA -= MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                            else
                            {
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    HA -= AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    HA -= AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    HA -= AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    HA -= AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    HA -= AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    HA -= AllDraw.KingValue * Sign;
                            }



                        }





                    }
                }

            }
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                int Sign = 1;
                                if (Order == 1 && Table[i, j] < 0)
                                    Sign = -1;
                                if (Order == -1 && Table[i, j] > 0)
                                    Sign = -1;
                                if (Table[ii, jj] > 0)
                                {
                                    a = Color.Gray;
                                    Order = 1;
                                }
                                else
                                    if (Table[ii, jj] < 0)
                                    {
                                        Order = -1;
                                        a = Color.Brown;
                                    }
                                    else
                                        continue;


                                if (Achmaz(Table, ii, jj, i, j, a, Order))
                                {

                                    if (System.Math.Abs(Table[i, j]) == 1)
                                        HA -= AllDraw.SodierValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 2)
                                        HA -= AllDraw.ElefantValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 3)
                                        HA -= AllDraw.HourseValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 4)
                                        HA -= AllDraw.BridgeValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 5)
                                        HA -= AllDraw.MinisterValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 6)
                                        HA -= AllDraw.KingValue * Sign;



                                }





                            }
                        }
                    }
                }
            }
            HuristicValueAchmaz += HA;
            return HA;
        }
        float HuristicSupported(int[,] Tab, int Order, Color a)
        {
            int HA = 0;
            if (!DeptHuristic)
            {
                int i = Row, j = Column;
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        if (i == ii && j == jj)
                            continue;
                        int Sign = 1;
                        if (BestMovments)
                        {
                            if (Tab[ii, jj] > 0)
                            {
                                a = Color.Gray;
                                Order = 1;
                            }
                            else
                                if (Tab[ii, jj] < 0)
                                {
                                    Order = -1;
                                    a = Color.Brown;
                                }
                                else
                                    continue;
                        }
                        if (!OnlySelf)
                        {
                            if (Order == 1 && (Tab[i, j] < 0 || Tab[ii, jj] < 0))
                                Sign = -1;
                            if (Order == -1 && (Tab[i, j] > 0 || Tab[ii, jj] < 0))
                                Sign = -1;
                        }



                        if (Support(Tab, ii, jj, i, j, a, Order))
                        {
                            if (System.Math.Abs(Tab[i, j]) < MaxOrderEnemyAndSelf(Tab, i, j, ii, jj, Order))
                                HA += MaxOrderEnemyAndSelf(Tab, i, j, ii, jj, Order) * Sign;
                            else
                            {
                                if (System.Math.Abs(Tab[i, j]) == 1)
                                    HA += AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 2)
                                    HA += AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 3)
                                    HA += AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 4)
                                    HA += AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 5)
                                    HA += AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 6)
                                    HA += AllDraw.KingValue * Sign;
                            }
                        }


                    }
                }

            }
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                int Sign = 1;
                                /*if (Table[ii, jj] > 0)
                                {
                                   a = Color.Gray;
                                    Order = 1;
                                }
                                else
                                    if (Table[ii, jj] < 0)
                                    {
                                        Order = -1;
                                        a = Color.Brown;
                                    }
                                    else
                                        continue;
                                 */
                                if (Order == 1 && (Tab[i, j] < 0 || Tab[ii, jj] < 0))
                                    Sign = -1;
                                if (Order == -1 && (Tab[i, j] > 0 || Tab[ii, jj] < 0))
                                    Sign = -1;


                                if (Support(Table, ii, jj, i, j, a, Order))
                                {
                                    if (System.Math.Abs(Tab[i, j]) == 1)
                                        HA += AllDraw.SodierValue * Sign;
                                    else if (System.Math.Abs(Tab[i, j]) == 2)
                                        HA += AllDraw.ElefantValue * Sign;
                                    else if (System.Math.Abs(Tab[i, j]) == 3)
                                        HA += AllDraw.HourseValue * Sign;
                                    else if (System.Math.Abs(Tab[i, j]) == 4)
                                        HA += AllDraw.BridgeValue * Sign;
                                    else if (System.Math.Abs(Tab[i, j]) == 5)
                                        HA += AllDraw.MinisterValue * Sign;
                                    else if (System.Math.Abs(Tab[i, j]) == 6)
                                        HA += AllDraw.KingValue * Sign;
                                }


                            }
                        }
                    }
                }
            }
            HuristicValueSupported += HA;
            return HA;
        }
        static bool TableEqual(int[,] Tab1, int[,] Tab2)
        {
            try
            {
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        if (Tab1[i, j] != Tab2[i, j])
                            return false;
                    }
                return true;
            }
            catch (Exception t)
            {
                Log(t);
                return false;
            }
        }
        static public bool ExistTableInList(int[,] Tab, List<int[,]> List, int Index)
        {
            bool Exist = false;
            for (int i = Index; i < List.Count; i++)
            {
                bool Eq = TableEqual(Tab, List[i]);
                if (Eq)
                {
                    AllDraw.LoopHuristicIndex = i;
                    return Eq;
                }
                Exist |= Eq;
            }
            return Exist;
        }

        public bool ThinkMate(int i, int j)
        {
            if (System.Math.Abs(Table[Row, Column]) == 6)
            {
                if ((new ChessRules(Table[Row, Column], Table, Order)).Rules(Row, Column, i, j, color, 1))
                {
                    Table[i, j] = Table[Row, Column];
                    Table[i, j] = 0;
                    return false;
                }
            }
            return true;
        }
        public bool Movable(int[,] Table, int i, int j, int ii, int jj, Color a, int Order)
        {
            int Store = Table[ii, jj];
            //Table[ii, jj] = 0;

            if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Table[i, j]))
            {
                Table[ii, jj] = 0;
                Table[ii, jj] = Table[i, j];
                int Ord = 1;
                if (Table[ii, jj] < 0)
                    Ord = -1;
                int Dummy = ChessRules.CurrentOrder;
                ChessRules.CurrentOrder = Ord;
                (new ChessRules(Table[ii, jj], Table, Ord)).Kish(Table, Ord);
                ChessRules.CurrentOrder = Dummy;
                Table[i, j] = Table[ii, jj];

                if (Table[i, j] > 0)
                {
                    Table[ii, jj] = Store;
                    if (ChessRules.MateGray)
                        return false;


                    return true;
                }


                if (Table[i, j] < 0)
                {
                    Table[ii, jj] = Store;
                    if (ChessRules.MateBrown)
                        return false;
                    return true;
                }


            }

            Table[ii, jj] = Store;
            return false;
        }
        public void HuristicKishAndMate(int[,] Table, Color a)
        {
            if (DeptHuristic)
            {
                if ((new ChessRules(1, Table, Order)).Mate(Table, Order))
                {
                    if (ChessRules.MateGray || ChessRules.MateBrown)
                    {

                        if (Order == 1 && ChessRules.MateBrown)
                        {
                            HuristicValue += 100000;
                            HuristicValueMovement += 100000;
                            HuristicValueSupported += 100000;
                        }
                        if (Order == -1 && ChessRules.MateGray)
                        {
                            HuristicValue += 100000;
                            HuristicValueMovement += 100000;
                            HuristicValueSupported += 100000;
                        }
                    }
                    else
                        if (ChessRules.KishGray || ChessRules.KishBrown)
                        {

                            if (Order == 1 && ChessRules.KishBrown)
                            {
                                HuristicValue += 50000;
                                HuristicValueMovement += 50000;
                                HuristicValueSupported += 50000;
                            }
                            if (Order == -1 && ChessRules.KishGray)
                            {
                                HuristicValue += 50000;
                                HuristicValueMovement += 50000;
                                HuristicValueSupported += 50000;
                            }
                        }
                        else
                            if (ChessRules.KishGrayAchmaz || ChessRules.KishBrownAchmaz)
                            {

                                if (Order == 1 && ChessRules.KishBrownAchmaz)
                                {
                                    HuristicValue += 30000;
                                    HuristicValueMovement += 30000;
                                    HuristicValueSupported += 30000;
                                }
                                if (Order == -1 && ChessRules.KishGrayAchmaz)
                                {
                                    HuristicValue += 30000;
                                    HuristicValueMovement += 30000;
                                    HuristicValueSupported += 30000;
                                }
                            }
                    if (ChessRules.MateGray || ChessRules.MateBrown)
                    {

                        if (Order == 1 && ChessRules.MateGray)
                        {
                            HuristicValue -= 100000;
                            HuristicValueMovement -= 100000;
                            HuristicValueSupported -= 100000;
                        }
                        if (Order == -1 && ChessRules.MateBrown)
                        {
                            HuristicValue -= 100000;
                            HuristicValueMovement -= 100000;
                            HuristicValueSupported -= 100000;
                        }
                    }
                    else
                        if (ChessRules.KishGray || ChessRules.KishBrown)
                        {

                            if (Order == 1 && ChessRules.KishGray)
                            {
                                HuristicValue -= 50000;
                                HuristicValueMovement -= 50000;
                                HuristicValueSupported -= 50000;
                            }
                            if (Order == -1 && ChessRules.KishBrown)
                            {
                                HuristicValue -= 50000;
                                HuristicValueMovement -= 50000;
                                HuristicValueSupported -= 50000;
                            }
                        }
                        else if (ChessRules.KishBrownAchmaz || ChessRules.KishGrayAchmaz)
                        {

                            if (Order == 1 && ChessRules.KishGrayAchmaz)
                            {
                                HuristicValue -= 30000;
                                HuristicValueMovement -= 30000;
                                HuristicValueSupported -= 30000;
                            }
                            if (Order == -1 && ChessRules.KishBrownAchmaz)
                            {
                                HuristicValue -= 30000;
                                HuristicValueMovement -= 30000;
                                HuristicValueSupported -= 30000;
                            }
                        }

                }
            }
        }
        public float HuristicMovment(int[,] Table, Color a)
        {
            int HA = 0;
            if (!DeptHuristic)
            {
                int i = Row, j = Column;
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        if (i == ii && j == jj)
                            continue;
                        int Sign = 1;
                        if (BestMovments)
                        {
                            if (Table[i, j] > 0)
                            {
                                a = Color.Gray;
                                Order = 1;
                            }
                            else
                                if (Table[i, j] < 0)
                                {
                                    a = Color.Brown;
                                    Order = -1;
                                }
                                else
                                    continue;
                        }
                        if (!OnlySelf)
                        {
                            if (Order == 1 && Table[i, j] < 0)
                                Sign = -1;
                            if (Order == -1 && Table[i, j] > 0)
                                Sign = -1;
                        }


                        if (Movable(Table, i, j, ii, jj, a, Order))
                        {
                            if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                                HA += MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                            else
                            {
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    HA += AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    HA += AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    HA += AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    HA += AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    HA += AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    HA += AllDraw.KingValue * Sign;
                            }
                        }

                    }
                }

            }
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                int Sign = 1;
                                /*if (Table[i, j] > 0)
                                {
                                    a = Color.Gray;
                                    Order = 1;
                                }
                                else
                                    if (Table[i, j] < 0)
                                    {
                                        a = Color.Brown;
                                        Order = -1;
                                    }
                                    else
                                        continue;
                                 */
                                if (Order == 1 && Table[i, j] < 0)
                                    Sign = -1;
                                if (Order == -1 && Table[i, j] > 0)
                                    Sign = -1;

                                if (Movable(Table, i, j, ii, jj, a, Order))
                                {
                                    if (System.Math.Abs(Table[i, j]) == 1)
                                        HA += AllDraw.SodierValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 2)
                                        HA += AllDraw.ElefantValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 3)
                                        HA += AllDraw.HourseValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 4)
                                        HA += AllDraw.BridgeValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 5)
                                        HA += AllDraw.MinisterValue * Sign;
                                    else if (System.Math.Abs(Table[i, j]) == 6)
                                        HA += AllDraw.KingValue * Sign;
                                }

                            }
                        }
                    }
                }
            }
            HuristicValueMovement += HA;
            return HA;

        }

        public bool ExistRowClolumnInArray(int ii, int jj)
        {
            for (int j = 0; j < Index; j++)
            {
                //    if (RowColumn[0, j] == ii && RowColumn[1, j] == jj)
                //        return true;
            }
            return false;
        }
        public bool Attack(int[,] Table, int i, int j, int ii, int jj, Color a, int Order)
        {
            int Store = Table[ii, jj];
            //  Table[ii, jj] = 0;
            ChessRules.KingAttacker = true;
            if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Table[i, j]))
            {
                if (Table[i, j] > 0 && Store < 0)
                {
                    Table[ii, jj] = Store;
                    ChessRules.KingAttacker = false;
                    return true;
                }

                if (Table[i, j] < 0 && Store > 0)
                {
                    Table[ii, jj] = Store;
                    ChessRules.KingAttacker = false;
                    return true;
                }
            }

            Table[ii, jj] = Store;
            ChessRules.KingAttacker = false;
            return false;
        }
        public bool Achmaz(int[,] Table, int i, int j, int ii, int jj, Color a, int Order)
        {
            int Store = Table[ii, jj];
            Table[ii, jj] = 0;

            if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Table[i, j]))
            {

                if (Table[i, j] > 0 && Store < 0)
                {
                    Table[ii, jj] = Store;
                    return true;
                }


                if (Table[i, j] < 0 && Store > 0)
                {
                    Table[ii, jj] = Store;
                    return true;
                }
            }

            Table[ii, jj] = Store;
            return false;
        }
        public bool Support(int[,] Tab, int i, int j, int ii, int jj, Color a, int Order)
        {
            int[,] Table = new int[8, 8];

            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                    Table[iii, jjj] = Tab[iii, jjj];
            if (Table[i, j] > 0 && Table[ii, jj] > 0)
            {
                int Store = Table[ii, jj];
                Table[ii, jj] = 0;
                if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Table[i, j]))
                {
                    Table[ii, jj] = Store;
                    return true;
                }
                Table[ii, jj] = Store;
            }

            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                    Table[iii, jjj] = Tab[iii, jjj];

            if (Table[i, j] < 0 && Table[ii, jj] < 0)
            {
                int Store = Table[ii, jj];
                Table[ii, jj] = 0;
                if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Table[i, j]))
                {
                    Table[ii, jj] = Store;
                    return true;
                }
                Table[ii, jj] = Store;
            }

            return false;
        }


        public void Thinking()
        {

            ExistEnemy = true;
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            HuristicListBridge.Clear();
            HuristicListElefant.Clear();
            HuristicListHourse.Clear();
            HuristicListKing.Clear();
            HuristicListMinister.Clear();
            HuristicListSolder.Clear();
            RowColumnSoldier.Clear();
            RowColumnElefant.Clear();
            RowColumnHourse.Clear();
            RowColumnBridge.Clear();
            RowColumnMinister.Clear();
            RowColumnKing.Clear();
            HitNumberSoldier.Clear();
            HitNumberElefant.Clear();
            HitNumberHourse.Clear();
            HitNumberBridge.Clear();
            HitNumberMinister.Clear();
            HitNumberKing.Clear();


            IndexSoldier = 0;
            IndexElefant = 0;
            IndexHourse = 0;
            IndexBridge = 0;
            IndexMinister = 0;
            IndexKing = 0;

            //if (ThinkingBegin)
            {
                int ii = Row;
                int jj = Column;
                //for (int ii = 0; ii < 8; ii++)
                {
                    //for (int jj = 0; jj < 8; jj++)
                    {

                        for (int i = 0; i < 8; i++)
                        {
                            for (int j = 0; j < 8; j++)
                            {
                                if (ii == i && jj == j)
                                    continue;

                                int[,] TableS = new int[8, 8];
                                //"Inizialization of This New Class (Current is Dynamic class Object) is MalFunction (Constant Variable Count).
                                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);

                                for (int iii = 0; iii < 8; iii++)
                                    for (int jjj = 0; jjj < 8; jjj++)
                                    {
                                        TableS[iii, jjj] = TableConst[iii, jjj];
                                    }

                                if (TableS[ii, jj] > 0 && CurrentArray < ThingsNumber / 2 && Order == 1)
                                    color = Color.Gray;
                                else
                                    if (TableS[ii, jj] < 0 && CurrentArray >= ThingsNumber / 2 && Order == -1)
                                        color = Color.Brown;
                                    else
                                    {
                                        if (!ThinkingBegin)
                                        {
                                            ThinkingFinished = true;
                                            ThinkingRun = false;
                                            return;
                                        }
                                        continue;
                                    }


                                if (Order == 1 && TableS[i, j] > 0)
                                    continue;
                                if (Order == -1 && TableS[i, j] < 0)
                                    continue;
                                if (Order == 1 && TableS[ii, jj] < 0)
                                    continue;
                                if (Order == -1 && TableS[ii, jj] > 0)
                                    continue;
                                bool Bridge = false;
                                ChessRules.ExistInDestinationEnemy = false;
                                if (!ChessRules.BridgeActGray && Order == 1 && TableS[ii, jj] == 6)
                                {
                                    if ((new ChessRules(7, TableS, Order)).Rules(ii, jj, i, j, color, 7))
                                    {


                                        ThinkingRun = true;

                                        HuristicAttack(TableS, Order, color);
                                        HuristicMovment(TableS, color);
                                        HuristicSupported(TableS, Order, color);
                                        HuristicKishAndMate(TableS, color);
                                        HuristicAchmaz(TableS, Order, color);
                                        HuristicAchmaz(TableS, Order, color);
                                        TableS[ii, jj] = 0;
                                        TableS[i, j] = 6;

                                        if (i < ii)
                                            TableS[i + 1, j] = 4;

                                        else
                                            TableS[i - 1, j] = 4;
                                        TableS[ii, jj] = 0;


                                        int[] AS = new int[2];
                                        AS[0] = i;
                                        AS[1] = j;
                                        RowColumnKing.Add(AS);
                                        RowColumn[Index, 0] = i;
                                        RowColumn[Index, 1] = j;

                                        Index++;
                                        TableListKing.Add(TableS);
                                        IndexKing++;
                                        Row = i;
                                        Column = j;
                                        if (PredictHuristic)
                                        {
                                            HuristicAttack(TableS, Order, color);
                                            HuristicMovment(TableS, color);
                                            HuristicSupported(TableS, Order, color);
                                            HuristicKishAndMate(TableS, color);
                                            HuristicAchmaz(TableS, Order, color);
                                        }
                                        double[] Hu = new double[4];
                                        Hu[0] = HuristicValue;
                                        Hu[1] = HuristicValueMovement;
                                        Hu[2] = HuristicValueSupported;
                                        Hu[3] = HuristicValueAchmaz;
                                        HuristicListKing.Add(Hu);
                                        ChessRules.BridgeActGray = true;

                                        Bridge = true;
                                    }
                                }
                                
                                    if (!ChessRules.BridgeActBrown && Order == -1 && TableS[ii, jj] == -6)
                                    {
                                        if ((new ChessRules(-7, TableS, Order)).Rules(ii, jj, i, j, color, -7))
                                        {
                                            ThinkingRun = true;
                                            HuristicAttack(TableS, Order, color);
                                            HuristicMovment(TableS, color);
                                            HuristicSupported(TableS, Order, color);
                                            HuristicKishAndMate(TableS, color);
                                            HuristicAchmaz(TableS, Order, color);
                                            TableS[ii, jj] = 0;
                                            TableS[i, j] = -6;
                                            if (i < ii)
                                                TableS[i + 1, j] = -4;

                                            else
                                                TableS[i - 1, j] = -4;
                                            TableS[ii, jj] = 0;


                                            int[] AS = new int[2];
                                            AS[0] = i;
                                            AS[1] = j;
                                            RowColumnKing.Add(AS);
                                            RowColumn[Index, 0] = i;
                                            RowColumn[Index, 1] = j;
                                            Index++;
                                            TableListKing.Add(TableS);
                                            IndexKing++;
                                            Row = i;
                                            Column = j;

                                            if (PredictHuristic)
                                            {
                                                HuristicAttack(TableS, Order, color);
                                                HuristicMovment(TableS, color);
                                                HuristicSupported(TableS, Order, color);
                                                HuristicKishAndMate(TableS, color);
                                                HuristicAchmaz(TableS, Order, color);
                                            }

                                            double[] Hu = new double[4];
                                            Hu[0] = HuristicValue;
                                            Hu[1] = HuristicValueMovement;
                                            Hu[2] = HuristicValueSupported;
                                            Hu[3] = HuristicValueAchmaz;
                                            HuristicListKing.Add(Hu);
                                            ChessRules.BridgeActBrown = true;
                                            Bridge = true;
                                        }

                                    }
                                    if (Bridge)
                                        continue;
                                        if (System.Math.Abs(TableS[ii, jj]) == 1)
                                        {

                                            if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                            {
                                                bool Hit = false;
                                                int HitNumber = TableS[i, j];
                                                if (System.Math.Abs(TableS[i, j]) > 0)
                                                    Hit = true;

                                                HitNumberSoldier.Add(TableS[i, j]);
                                                ThinkingRun = true;
                                                HuristicAttack(TableS, Order, color);
                                                HuristicMovment(TableS, color);
                                                HuristicSupported(TableS, Order, color);
                                                HuristicKishAndMate(TableS, color);
                                                HuristicAchmaz(TableS, Order, color);
                                                TableS[i, j] = TableS[ii, jj];
                                                TableS[ii, jj] = 0;

                                                if (ThinkingChess.ExistTableInList(TableS, TableListSolder, 0))
                                                {
                                                    TableS[ii, jj] = TableS[i, j];
                                                    TableS[i, j] = 0;
                                                    HuristicValue = 0;
                                                    HuristicValueMovement = 0;
                                                    HuristicValueSupported = 0;
                                                    HuristicValueAchmaz = 0;

                                                    continue;
                                                }
                                                if (UsePenaltyRegardMechnisam)
                                                {
                                                    ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                    if (A.AchmazKingMove(Order, TableS, false))
                                                    {
                                                        if (Order == 1 && (ChessRules.KishGray))
                                                            Current.LearningAlgorithmPenalty();
                                                        else
                                                            if (Order == -1 && (ChessRules.KishBrown))
                                                                Current.LearningAlgorithmPenalty();
                                                        PenaltyRegardListSolder.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListSolder.Add(Current);
                                                }
                                                else
                                                    PenaltyRegardListSolder.Add(Current);
                                                int[] AS = new int[2];
                                                AS[0] = i;
                                                AS[1] = j;
                                                RowColumnSoldier.Add(AS);
                                                RowColumn[Index, 0] = i;
                                                RowColumn[Index, 1] = j;
                                                Index++;
                                                TableListSolder.Add(TableS);
                                                IndexSoldier++;
                                                Row = i;
                                                Column = j;

                                                if (PredictHuristic)
                                                {
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                }
                                                double[] Hu = new double[4];
                                                Hu[0] = HuristicValue;
                                                Hu[1] = HuristicValueMovement;
                                                Hu[2] = HuristicValueSupported;
                                                Hu[3] = HuristicValueAchmaz;
                                                HuristicListSolder.Add(Hu);
                                                if (Order == 1)
                                                    AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 1, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                else
                                                    AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -1, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();

                                            }
                                        }
                                        else
                                            if (System.Math.Abs(TableS[ii, jj]) == 2)
                                            {

                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;

                                                    HitNumberElefant.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    if (ThinkingChess.ExistTableInList(TableS, TableListElefant, 0))
                                                    {
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmaz = 0;

                                                        continue;
                                                    }

                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListElefant.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListElefant.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListElefant.Add(Current);
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnElefant.Add(AS);

                                                    RowColumn[Index, 0] = i;
                                                    RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListElefant.Add(TableS);
                                                    IndexElefant++;
                                                    Row = i;
                                                    Column = j;

                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);
                                                    }
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmaz;
                                                    HuristicListElefant.Add(Hu);
                                                    //ThinkingFinished = true;
                                                    //break;
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 2, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -2, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                            else if (System.Math.Abs(TableS[ii, jj]) == 3)
                                            {
                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;

                                                    HitNumberHourse.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    if (ThinkingChess.ExistTableInList(TableS, TableListHourse, 0))
                                                    {
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmaz = 0;

                                                        continue;
                                                    }
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListHourse.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListHourse.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListHourse.Add(Current);
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnHourse.Add(AS);

                                                    ThinkingChess.RowColumn[Index, 0] = i;
                                                    ThinkingChess.RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListHourse.Add(TableS);
                                                    IndexHourse++;
                                                    Row = i;
                                                    Column = j;
                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);
                                                    }
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmaz;
                                                    HuristicListHourse.Add(Hu);
                                                    //ThinkingFinished = true;
                                                    //break;
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 3, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -3, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                            else if (System.Math.Abs(TableS[ii, jj]) == 4)
                                            {

                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;

                                                    HitNumberBridge.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    if (ExistTableInList(TableS, TableListBridge, 0))
                                                    {
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;

                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmaz = 0;

                                                        continue;
                                                    }
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListBridge.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListBridge.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListBridge.Add(Current);
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnBridge.Add(AS);
                                                    ThinkingChess.RowColumn[Index, 0] = i;
                                                    ThinkingChess.RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListBridge.Add(TableS);
                                                    IndexBridge++;
                                                    Row = i;
                                                    Column = j;

                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);

                                                    }
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmaz;
                                                    HuristicListBridge.Add(Hu);
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 4, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -4, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                            else if (System.Math.Abs(TableS[ii, jj]) == 5)
                                            {

                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;

                                                    HitNumberMinister.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    if (ExistTableInList(TableS, TableListMinister, 0))
                                                    {
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmaz = 0;

                                                        continue;
                                                    }
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListMinister.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListMinister.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListMinister.Add(Current);
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnMinister.Add(AS);
                                                    RowColumn[Index, 0] = i;
                                                    RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListMinister.Add(TableS);
                                                    IndexMinister++;
                                                    Row = i;
                                                    Column = j;

                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);
                                                    }
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmaz;
                                                    HuristicListMinister.Add(Hu);
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 5, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -5, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                            else if (System.Math.Abs(TableS[ii, jj]) == 6)
                                            {

                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;

                                                    HitNumberKing.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);

                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;

                                                    if (ExistTableInList(TableS, TableListKing, 0))
                                                    {
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmaz = 0;

                                                        continue;
                                                    }
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListKing.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListKing.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListKing.Add(Current);

                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnKing.Add(AS);
                                                    RowColumn[Index, 0] = i;
                                                    RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListKing.Add(TableS);
                                                    IndexKing++;
                                                    Row = i;
                                                    Column = j;
                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);

                                                    }
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmaz;
                                                    HuristicListKing.Add(Hu);
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 6, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -6, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();

                                                }
                                            }

                            }
                            if (ThinkingFinished)
                                break;

                        }

                    }
                }
                ThinkingBegin = false;
                //This Variable Not Work! 
                ThinkingFinished = true;

            }
            return;
        }

    }
}
