﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawMinister//:DrawKing
    {
        public int Row, Column;
        public Color color;
        public int[,] Table = null;
        public int Current = 0;
        public int Order;
        public ThinkingChess[] MinisterThinking = new ThinkingChess[AllDraw.MinisterMovments];
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
       
        public DrawMinister() { }
        public DrawMinister(int i, int j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            Table = Tab;
            for (int ii = 0; ii < AllDraw.MinisterMovments; ii++)
                MinisterThinking[ii] = new ThinkingChess(i, j, a, Tab, 32, Ord, TB, Cur, 2);

            Row = i;
            Column = j;
            color = a;
            Current = Cur;
            Order = Ord;

        }
        public void Clone(ref DrawMinister AA)
        {
            AA = new DrawMinister(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.MinisterMovments; i++)
            {
                try
                {
                    AA.MinisterThinking[i] = new ThinkingChess();
                    this.MinisterThinking[i].Clone(ref AA.MinisterThinking[i]);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.MinisterThinking[i] = null;
                }

            }
        }
        public void DrawMinisterOnTable(ref Graphics g, int CellW, int CellH)
        {
            try
            {
                if (color == Color.Gray)
                {
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }
                else
                {
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }

            }
            catch (Exception t) { Log(t); }
        }
    }
}