﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Refrigtz
{

    public class ThingsConverter
    {
        public static bool ActOfClickEqualTow = false;
        public bool Convert = false;
        public bool ConvertedToMinister = false;
        public bool ConvertedToBridge = false;
        public bool ConvertedToElefant = false;
        public bool ConvertedToHourse = false;
        public int Max;
        public int Row, Column;
        Color color;
        int Order;
        int Current = 0;
        public ThingsConverter()
        { }

        public ThingsConverter(int i, int j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;


        }
        public bool ConvertOperation(int i, int j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;
            if (!Convert&&ActOfClickEqualTow)
            {
                ActOfClickEqualTow = false;
                if (color == Color.Gray && Column == 7)
                    Convert = true;
                if (color == Color.Brown && Column == 0)
                    Convert = true;

                if (Convert)
                {

                    AllDraw.SodierConversionOcuured = true;
                    int Rand = (new Random()).Next(0, 4);
                    if (Rand == 0)
                    {
                        if (color == Color.Gray)
                        {
                            AllDraw.MinisterMidle++;
                            AllDraw.MinisterHigh++;
                            Tab[Row, Column] = 5;
                        }
                        else if (color == Color.Brown)
                        {
                            AllDraw.MinisterHigh++;
                            Tab[Row, Column] = -5;
                        }
                        ConvertedToMinister = true;
                    }
                    else if (Rand == 1)
                    {
                        if (color == Color.Gray)
                        {
                            AllDraw.BridgeMidle++;
                            AllDraw.BridgeHigh++;
                            Tab[Row, Column] = 4;
                        }
                        else if (color == Color.Brown)
                        {
                            AllDraw.BridgeHigh++;
                            Tab[Row, Column] = -4;
                        }
                        ConvertedToBridge = true;
                    }
                    else if (Rand == 2)
                    {
                        if (color == Color.Gray)
                        {
                            AllDraw.HourseMidle++;
                            AllDraw.HourseHight++;
                            Tab[Row, Column] = 3;
                        }
                        else if (color == Color.Brown)
                        {
                            AllDraw.HourseHight++;
                            Tab[Row, Column] = -3;
                            
                        }
                        ConvertedToHourse = true;
                    }
                    else
                    {
                        if (color == Color.Gray)
                        {
                            AllDraw.ElefantMidle++;
                            AllDraw.ElefantHigh++;
                            Tab[Row, Column] = 2;
                        }
                        else if (color == Color.Brown)
                        {
                            AllDraw.ElefantHigh++;
                            Tab[Row, Column] = -2;                            
                        }
                        ConvertedToElefant = true;
                    }
                    return Convert;
                }
            }
            return Convert;

        }
    }
}

