﻿/*******************************************************************************************
 * Initiate and Decision making class.******************************************************
 * Ramin Edjlal*****************************************************************************
 * Call Of Constructor From Constructor*****************************************************(+)
 * The Storing AllDraw Object in Self Constructor Caused Stack Overflow*********************(+)
 * Link List Of Storing String Caused A Stack Over Flow*************************************(+)
 * Wait For Finished Current Dept Caused To Long Time***************************************(+)
 * Need To Heuristic (Arvin) Function(s) to Manage Cell in Form1****************************(+)
 * First Scanning Movements of Things Anomaly***********************************************(+)
 * In Current Version of Heuristic Table Doesn’t Reached(Zero)******************************(+)
 * In Current Version InitiateForEveryThisngsHome Dosn't Work*******************************(+)
 * In This Version Thinking Taking A LotofTime(DeptFirst Array Tree)************************(+)
 * Heuristic Work In Depts. But Scanning Dosen’t Works**************************************(+)
 * Adding Clone Caused To Stack Overflow****************************************************(+)
 * Clone Caused To StackOverFlow************************************************************(+)
 * Row And Column Become Zero in Virtualization*********************************************(+)
 * Initiate Error***************************************************************************(+)
 * Seems To Be Logical Drawing *************************************************************(+)
 * Color Suddenly Changing******************************************************************(+)
 * AllDraw Object Sub Objects List When Return from local Scope Become Zero*****************(+)
 * Huristic Dosn't Work*********************************************************************(+)
 * Color Order Of Visualization Changed Suddenly********************************************(+)
 * Color Changes with no movement***********************************************************(+)
 * Table Not Gate (Inversion of Table List) Doesn’t help to do Normally*********************(+)
 * Literally Errors Correction**************************************************************(+)
 * From Arrangements of Things Reaches Suddenly Things Location Occurs**********************(+)
 * The Arrangements is Logical**************************************************************(+)
 * The Color changes and the arrangements changes are not clearly obvious*******************(+)
 * Color Changes Solved. no movements*******************************************************(-+)
 * Things movements Anomally****************************************************************(+)
 * Chess Rules Anomally*********************************************************************(+)
 * Heuristic Function Not Work**************************************************************(+)
 * Heuristic Work But the Table is Empty****************************************************(+)
 * Table is Not Empty But the Movement is Not Logical***************************************(+)
 * Clear Dirty Part.************************************************************************(*)
 * Need to Restricted Approval. Taking a lot of time Thinking Computation*******************(+)
 * No movements In Virtualization***********************************************************(+)
 * Chess Rules Abnormal thinking movements. No movement greater than 2**********************(+)
 * Problem For Drawing of Thinking Things***************************************************(+)
 * Heuristic Constant Result****************************************************************(+)
 * One movements Right .Heuristic Remaining Constant Results********************************(+)
 * Constant Heuristic Result****************************************************************(+)
 * Need To Add A Heuristic Useful Another***************************************************(+)
 * Heuristic Function Does’ Work Allis suddenly Become Zero that Previously Working*********(+)
 * No Movement Greater than one order in Computer 'Alice'***********************************(+)
 * Tow movements in Computer 'Alice' Of two Different Order Color***************************(+)
 * Heuristic Not Work Greater than 3 Length Count of A**************************************(+)
 * 'They Don't Really Take care about us'. Misleading in Heuristic King Supported***********(+)
 * Non Order Movments***********************************************************************(+)
 * Misleading at Stage three. no illegal movement greater than three************************(+)
 * Thinking Order Misleading****************************************************************(+)
 * Hit Mechanism Malfunctional**************************************************************(+)
 * Tow movements At One 'Alice' Order time**************************************************(+)
 * Heuristic Computer By Computer 'Alice' by 'Bob' Caused to Loop Heuristic*****************(+)
 * Learning Automata of Quantum also leads to re loop heuristic*****************************(*)
 * Heuristic Learning Automata 'Alice' By 'Bob' Leads to Re loop****************************(+)
 * Heuristic Things Loop 'Alice' By 'Bob'***************************************************(+)
 * Self 'Kish' Detection Failure By 'Alice'*************************************************(+)
 * 'Penalty' Value Of All Become zero althouth the one should be non Penalty****************(*)
 * Clone Dosn't Copy All Content of AllDraw Dummy*******************************************(+)
 * KishRemovable By Self King Solved.Penalty Action Misleading******************************(-*)
 * 'Kish' Detection Failure*****************************************************************(+)
 * Mechanisam Of Order in Predict Failed.***************************************************(+)
 * 'Alice' King Virtualization or Table Content of King Misleading**************************(+)
 * With The All Things Huristic Signing Mechnisam Some Movments become null Table.**********(+)
 * Dept First Search Not Working. Misleading MalFunction Virtualization.********************(+)
 * Dept First Table is Null at Bob Order.***************************************************(+)
 * Dept First SetVirtualization and Table Misleading By Alice.******************************(+)
 * No Reason Logically For MalFunction  Timer Dept First Dynamic Timer.*********************(+)
 * DeptFirst Thinking Taking a lot of time.*************************************************[+]
 * Dept First Not Work.*********************************************************************[+]
 * Dept First Not Work.Timer Stop At Greater than 2,3,4,5,6,7 Movments.*********************[+]
 * No Reason For MalFunction of DeptFirstNotFoundHuristicDeptFirst.*****************
 * ********[+]
 * Problem Solved.No Reason to NullExeption of DeptFirstHuristic Algorithm.*****************[-*]
 * Function Evaluation Disabled .At Initiate DeptFirstGenetic Found Sysntax.****************[*]
 * Index Was Out Of Range Exeption Was Not Handled.Colud Not Be Handle.*********************{+}
 * No Logical Mechanism To Reconstructe Current AllDraw Objects.****************************{+}
 * Dept First Sysntax is legal and The table is constant table.*****************************{+}
 * Table Content Empty. No Syntax Exist.****************************************************{+}
 * Game Begin From First When the Soldiers Move Ordinary Complete in Dept First*************{*}
 * New Instatnt Of Program Cuase to Begin Fron First.***************************************<+>
 * No Logically Reason For New Game Of Program. New Instatnt Not Detected.******************<+>
 * Internal New Instatnt Of FormeRefregitz is MalFunction.**********************************<+>
 * Dept First CC Changes to CC Normal Game.*************************************************<+>
 * Game CC UnContoroled.********************************************************************<+>
 * MalFunction of Syntax and Movments.By Alice and Bob.*************************************<+>
 * Threading Solved! The OutOfRangeIndex Not Work.******************************************[-+]
 * Vituallization error!No Best Matches between Truth of table content and irtualization****[+]
 * Dynamic Programming for Stroring ADraw THISDummy Adraw Value MalFunction.****************(+)
 * Order is Constant in Dynamic Programming.************************************************(+)
 * Table MalFunction at Dynamic Programming.At Step 3.**************************************(+)
 * Some Movments are MalFuncational at Dynamic Programming.*********************************(+)
 * Huristic Overlay Tow Part of ADraw and StoreADraw Sections at Different levels Tab Cal.**(+)
 * Not to be needing again calculation. MalFunction is depend of tow part.******************(+)
 * BackWard Loos of Things AllDraw Mechnisam.***********************************************(*)
 * Some Dynamic Programming MalFunction Movments.*******************************************(*)
 * Syntax and Forward and Backward Movments Syntax is MalFunction.**************************<+>
 * Database and Virtualization Forward and Backward MalFunction*****************************<+>
 * Reproduction of Thinfs Missleading.******************************************************<*>
 * Reproduction of Some Things are MalFunction Movments.************************************{+}
 * Dept Count of Dynamic Programming Misleadig.Dept Operation Count Mal Function.***********(*)
 * Huristic By Alice is MalFunction.********************************************************(+)
 * Achmaz Identification By Alice is MalFunction.*******************************************(+)
 * Kish Identification By Alice is MalFunction.*********************************************(+)
 * Kish Recognized But Mate Not Recognized!*************************************************(_+)
 * Penalty Regard Mechanism Misleading.*****************************************************{+}
 * Inhereted LearningAtamata Caused to Shared Parent Allocated Variable.********************{+}
 * 'Kish' By 'Alice' Not Removed Unreasonably.**********************************************{*}
 * DeptFirst Huristic Found MalFunction at Kish Alice.**************************************{+}
 * Sortments of ADRAW and Construction is MalFunction at Dept Dynamic Programming.**********{+}
 * Huristic Dept First were Worked Out Unreasonably such Situation(Golden Sword Magic).*****{*}
 * Converted 'King' of 'Alice' to 'Elephant' UnReasonably.**********************************(+)
 * 'Long Game' ; But MalFunction of Game.***************************************************(+)
 * 'Always' in Current game is 'Bob'.*******************************************************(+)
 * Current Table of ADRAW is Correct Table But the Game is MalFunction.*********************(+)
 * Move of Current Table Dept First Huristic found ;found an ovelay in 'Bob' and 'Alice'****(+)
 * Current Table in High Level Become Null and prevent of 'LongGame' Strategy.**************(+)
 * 'LongGame' Become short Undetectably Unreasonably;Clear Store Non Detectably.************(*)
 * All Draw Dept First section some movments have not been accurred considerably.***********(*)
 * 'Long Game' Breaks Suddendly without Monitor Caused.*************************************{+}
 * Overlay Some Movments of 'Long Game' Breaked.Caused Probability to break.****************{+}
 * SomeTimes All Situation of Current Games Become Cleared and No Table Founded.************{+}
 * Gray Soldeir is Only Movmnets and Converts in Huristic and No Move are detectable.*******{+}
 * *****************************************************************************************(+:Sum(63)) 
 * 1394/12/19*******************************************************************************(*:Sum(4))
 * *****************************************************************************************(-:sum(2)) (_:Sum(0)):2:(+:Sum(3)) (-:Sum(1)) (*:Sum(2)) 3: (+:Sum(4)) (*:Sum(1)) 4:(+:Sum(6))  5:(+:Sum(2)) (-:Sum(1)) 6:(+:Sum(6)) (*:Sum(2)) 7.(+:Sum(2)) (*:Sum(1)) 8.(+:Sum(1)) 9.(+:Sum(4)) (*:Sum(1)) (-:Sum(1)) 10.(+:Sum(4)) (*:Sum(2)) 11.(+:Sum(4)) 12.(+:Sum(2)) (*:Sum(2)) 13.(+:Sum(4))
 */


using System;
using System.Collections.Generic;

using System.Text;
using System.Drawing;
using System.Threading;
using System.IO;
namespace Refrigtz
{
    public class AllDraw
    {
        public static List<int[,]> TableCurrent = new List<int[,]>();
        static bool NoTableFound = false;
        bool LastDynamicNotFound = false;
        public static bool DynamicDeptFirstPrograming = false;
        public static List<AllDraw> StoreADraw = new List<AllDraw>();
        static int LevelDeptFirsDynamic = 1;
        public static bool UseDoubleTime = false;
        public static int DeptiLevelMax = 2;
        public static bool DeptFirstSearch = false;
        public static String ImageRoot = "Images";
        public static String ImagesSubRoot = AllDraw.ImageRoot + "\\Fit\\Small\\";
        public static bool RedrawTable = true;
        public static String SyntaxToWrite = "";
        public static bool SodierConversionOcuured = false;
        public static int SodierMovments = 1;
        public static int ElefantMovments = 1;
        public static int HourseMovments = 1;
        public static int BridgeMovments = 1;
        public static int MinisterMovments = 1;
        public static int KingMovments = 1;

        public static int SodierMidle = 8;
        public static int SodierHigh = 16;
        public static int ElefantMidle = 2;
        public static int ElefantHigh = 4;
        public static int HourseMidle = 2;
        public static int HourseHight = 4;
        public static int BridgeMidle = 2;
        public static int BridgeHigh = 4;
        public static int MinisterMidle = 1;
        public static int MinisterHigh = 2;
        public static int KingMidle = 1;
        public static int KingHigh = 2;

        ChessPerdict APredict = null;
        bool KishG = false, KishB = false;
        public static int SodierValue = 1;
        public static int ElefantValue = 2;
        public static int HourseValue = 8;
        public static int BridgeValue = 16;
        public static int MinisterValue = 32;
        public static int KingValue = 8;
        int RW = 0;
        int CL = 0;
        int Ki = 0;
        public static int LoopHuristicIndex = 0;
        static List<int> RWList = new List<int>();
        static List<int> ClList = new List<int>();
        static List<int> KiList = new List<int>();
        static public List<int[,]> TableListAction = new List<int[,]>();
        public int Move = 0;
        static public int MouseClick = 0;
        int[] DeptIndex = new int[20];
        int DeptIndexVlue = 0;
        public int[,] CurrentTable = new int[8, 8];
        public List<AllDraw> ADraw = null;
        public List<int[,]> TableList = new List<int[,]>();

        public int Dept = 0;
        public DrawSoldier[] SolderesOnTable = null;
        public DrawElefant[] ElephantOnTable = null;
        public DrawHourse[] HoursesOnTable = null;
        public DrawBridge[] BridgesOnTable = null;
        public DrawMinister[] MinisterOnTable = null;
        public DrawKing[] KingOnTable = null;
        FormRefrigtz THIS;
        public FormRefrigtz THISDummy;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
        public AllDraw(ref FormRefrigtz th)
        {
            THIS = th;
            APredict = new ChessPerdict(ref th);
            ADraw = new List<AllDraw>();
            SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
            for (int i = 0; i < AllDraw.SodierHigh; i++)
                SolderesOnTable[i] = new DrawSoldier();
            ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
            for (int i = 0; i < AllDraw.ElefantHigh; i++)
                ElephantOnTable[i] = new DrawElefant();
            HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
            for (int i = 0; i < AllDraw.HourseHight; i++)
                HoursesOnTable[i] = new DrawHourse();
            BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
            for (int i = 0; i < AllDraw.BridgeHigh; i++)
                BridgesOnTable[i] = new DrawBridge();
            MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
            for (int i = 0; i < AllDraw.MinisterHigh; i++)
                MinisterOnTable[i] = new DrawMinister();
            KingOnTable = new DrawKing[AllDraw.KingHigh];
            for (int i = 0; i < AllDraw.KingHigh; i++)
                KingOnTable[i] = new DrawKing();


        }
        public void Clone(AllDraw AA)
        {

            AA.SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
            for (int i = 0; i < AllDraw.SodierHigh; i++)
            {
                try
                {
                    AA.SolderesOnTable[i] = new DrawSoldier(SolderesOnTable[i].Row, SolderesOnTable[i].Column, SolderesOnTable[i].color, SolderesOnTable[i].Table, SolderesOnTable[i].Order, false, SolderesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            AA.ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
            for (int i = 0; i < AllDraw.ElefantHigh; i++)
            {
                try
                {
                    AA.ElephantOnTable[i] = new DrawElefant(ElephantOnTable[i].Row, ElephantOnTable[i].Column, ElephantOnTable[i].color, ElephantOnTable[i].Table, ElephantOnTable[i].Order, false, ElephantOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            AA.HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
            for (int i = 0; i < AllDraw.HourseHight; i++)
            {
                try
                {
                    AA.HoursesOnTable[i] = new DrawHourse(HoursesOnTable[i].Row, HoursesOnTable[i].Column, HoursesOnTable[i].color, HoursesOnTable[i].Table, HoursesOnTable[i].Order, false, HoursesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            AA.BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
            for (int i = 0; i < AllDraw.BridgeHigh; i++)
            {
                try
                {
                    AA.BridgesOnTable[i] = new DrawBridge(BridgesOnTable[i].Row, BridgesOnTable[i].Column, BridgesOnTable[i].color, BridgesOnTable[i].Table, BridgesOnTable[i].Order, false, BridgesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            AA.MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
            for (int i = 0; i < AllDraw.MinisterHigh; i++)
            {
                try
                {
                    AA.MinisterOnTable[i] = new DrawMinister(MinisterOnTable[i].Row, MinisterOnTable[i].Column, MinisterOnTable[i].color, MinisterOnTable[i].Table, MinisterOnTable[i].Order, false, MinisterOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            AA.KingOnTable = new DrawKing[AllDraw.KingHigh];
            for (int i = 0; i < AllDraw.KingHigh; i++)
            {
                try
                {
                    AA.KingOnTable[i] = new DrawKing(KingOnTable[i].Row, KingOnTable[i].Column, KingOnTable[i].color, KingOnTable[i].Table, KingOnTable[i].Order, false, KingOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            AA.ADraw = new List<AllDraw>();
            AA.Dept = this.Dept;
            for (int i = 0; i < this.ADraw.Count; i++)
            {

                AA.ADraw.Add(this.ADraw[i]);
            }
            for (int i = 0; i < this.TableList.Count; i++)
                AA.TableList.Add(this.TableList[i]);

        }
        public AllDraw(AllDraw THi)
        {
        }
        public bool AllCurrentDeptThinkingFinished(AllDraw Dum, int i, int j, int Kind)
        {
            bool Finished = false;
            if (Kind == 1)
            {
                if (Dum.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 2)
            {
                if (Dum.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 3)
            {
                if (Dum.HoursesOnTable[i].HourseThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 4)
            {
                if (Dum.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 5)
            {
                if (Dum.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished)
                    return true;
            }
            else if (Kind == 6)
            {
                if (Dum.KingOnTable[i].KingThinking[j].ThinkingFinished)
                    return true;
            }
            return Finished;

        }
        void Wait(AllDraw Dum, int i, int j, int Kind)
        {
            do
            {
                Thread.Sleep(10);
            } while (!AllCurrentDeptThinkingFinished(Dum, i, j, Kind));


        }
        public void InitiateForEveryKindThingHome(AllDraw DummyHA, int ii, int jj, Color a, int[,] Table, int Order, bool TB, int IN)
        {

            int i = 0, j = 0;
            AllDraw Dummy = new AllDraw(ref THIS);
            if (Order == 1)
            {
                for (i = 0; i < AllDraw.SodierMidle; i++)
                {
                    try
                    {
                        if (SolderesOnTable[i] == null)
                            continue;
                        ii = SolderesOnTable[i].Row;
                        jj = SolderesOnTable[i].Column;
                        Table = SolderesOnTable[i].Table;
                        Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < AllDraw.SodierMovments; j++)
                        {


                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingBegin = true;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished = false;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[j].Thinking));
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t.Start();
                            Wait(Dummy, i, j, 1);

                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.SolderesOnTable[i] = null;
                        Log(t);
                    }
                }
                for (i = 0; i < AllDraw.ElefantMidle; i++)
                {
                    try
                    {
                        if (ElephantOnTable[i] == null)
                            continue;
                        ii = ElephantOnTable[i].Row;
                        jj = ElephantOnTable[i].Column;
                        Table = ElephantOnTable[i].Table;
                        Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < AllDraw.ElefantMovments; j++)
                        {

                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingBegin = true;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished = false;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[j].Thinking));
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t.Start();
                            Wait(Dummy, i, j, 2);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.ElephantOnTable[i] = null;
                        Log(t);
                    }
                }



                for (i = 0; i < AllDraw.HourseMidle; i++)
                {
                    try
                    {
                        if (HoursesOnTable[i] == null)
                            continue;
                        ii = HoursesOnTable[i].Row;
                        jj = HoursesOnTable[i].Column;
                        Table = HoursesOnTable[i].Table;
                        Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.HourseMovments; j++)
                        {

                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingBegin = true;
                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingFinished = false;
                            Dummy.HoursesOnTable[i].HourseThinking[j].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[j].Thinking));
                            Dummy.HoursesOnTable[i].HourseThinking[j].t.Start();
                            Wait(Dummy, i, j, 3);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.HoursesOnTable[i] = null;
                        Log(t);
                    }
                }




                for (i = 0; i < AllDraw.BridgeMidle; i++)
                {
                    try
                    {
                        if (BridgesOnTable[i] == null)
                            continue;
                        ii = BridgesOnTable[i].Row;
                        jj = BridgesOnTable[i].Column;
                        Table = BridgesOnTable[i].Table;
                        Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.BridgeMovments; j++)
                        {
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingBegin = true;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished = false;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[j].Thinking));
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t.Start();
                            Wait(Dummy, i, j, 4);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.BridgesOnTable[i] = null;
                        Log(t);
                    }
                }
                for (i = 0; i < AllDraw.MinisterMidle; i++)
                {
                    try
                    {
                        if (MinisterOnTable[i] == null)
                            continue;
                        ii = MinisterOnTable[i].Row;
                        jj = MinisterOnTable[i].Column;
                        Table = MinisterOnTable[i].Table;
                        Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.MinisterMovments; j++)
                        {

                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingBegin = true;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished = false;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[j].Thinking));
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t.Start();
                            Wait(Dummy, i, j, 5);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.MinisterOnTable[i] = null;
                        Log(t);
                    }
                }


                for (i = 0; i < AllDraw.KingMidle; i++)
                {
                    try
                    {
                        if (KingOnTable[i] == null)
                            continue;
                        ii = KingOnTable[i].Row;
                        jj = KingOnTable[i].Column;
                        Table = KingOnTable[i].Table;
                        Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.KingMovments; j++)
                        {

                            Dummy.KingOnTable[i].KingThinking[j].ThinkingBegin = true;
                            Dummy.KingOnTable[i].KingThinking[j].ThinkingFinished = false;
                            Dummy.KingOnTable[i].KingThinking[j].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[j].Thinking));
                            Dummy.KingOnTable[i].KingThinking[j].t.Start();
                            Wait(Dummy, i, j, 6);
                        }
                    }
                    catch (Exception t)
                    {
                        Log(t);
                        Dummy.KingOnTable[i] = null;
                    }
                }
            }
            else
            {
                for (i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        if (SolderesOnTable[i] == null)
                            continue;
                        ii = SolderesOnTable[i].Row;
                        jj = SolderesOnTable[i].Column;
                        Table = SolderesOnTable[i].Table;
                        Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < AllDraw.SodierMovments; j++)
                        {


                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingBegin = true;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished = false;
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[j].Thinking));
                            Dummy.SolderesOnTable[i].SoldierThinking[j].t.Start();
                            Wait(Dummy, i, j, 1);

                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.SolderesOnTable[i] = null; Log(t);
                    }
                }
                for (i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {
                        if (ElephantOnTable[i] == null)
                            continue;
                        ii = ElephantOnTable[i].Row;
                        jj = ElephantOnTable[i].Column;
                        Table = ElephantOnTable[i].Table;
                        Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                        for (j = 0; j < AllDraw.ElefantMovments; j++)
                        {

                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingBegin = true;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished = false;
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[j].Thinking));
                            Dummy.ElephantOnTable[i].ElefantThinking[j].t.Start();
                            Wait(Dummy, i, j, 2);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.ElephantOnTable[i] = null; Log(t);
                    }
                }



                for (i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        if (HoursesOnTable[i] == null)
                            continue;
                        ii = HoursesOnTable[i].Row;
                        jj = HoursesOnTable[i].Column;
                        Table = HoursesOnTable[i].Table;
                        Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.HourseMovments; j++)
                        {
                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingBegin = true;
                            Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingFinished = false;
                            Dummy.HoursesOnTable[i].HourseThinking[j].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[j].Thinking));
                            Dummy.HoursesOnTable[i].HourseThinking[j].t.Start();
                            Wait(Dummy, i, j, 3);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.HoursesOnTable[i] = null; Log(t);
                    }
                }




                for (i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {
                        if (BridgesOnTable[i] == null)
                            continue;
                        ii = BridgesOnTable[i].Row;
                        jj = BridgesOnTable[i].Column;
                        Table = BridgesOnTable[i].Table;
                        Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.BridgeMovments; j++)
                        {
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingBegin = true;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished = false;
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[j].Thinking));
                            Dummy.BridgesOnTable[i].BridgeThinking[j].t.Start();
                            Wait(Dummy, i, j, 4);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.BridgesOnTable[i] = null; Log(t);
                    }
                }
                for (i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {
                        if (MinisterOnTable[i] == null)
                            continue;
                        ii = MinisterOnTable[i].Row;
                        jj = MinisterOnTable[i].Column;
                        Table = MinisterOnTable[i].Table;
                        Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.MinisterMovments; j++)
                        {

                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingBegin = true;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished = false;
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[j].Thinking));
                            Dummy.MinisterOnTable[i].MinisterThinking[j].t.Start();
                            Wait(Dummy, i, j, 5);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.MinisterOnTable[i] = null; Log(t);
                    }
                }


                for (i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                {
                    try
                    {
                        if (KingOnTable[i] == null)
                            continue;
                        ii = KingOnTable[i].Row;
                        jj = KingOnTable[i].Column;
                        Table = KingOnTable[i].Table;
                        Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                        for (j = 0; j < AllDraw.KingMovments; j++)
                        {

                            Dummy.KingOnTable[i].KingThinking[j].ThinkingBegin = true;
                            Dummy.KingOnTable[i].KingThinking[j].ThinkingFinished = false;
                            Dummy.KingOnTable[i].KingThinking[j].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[j].Thinking));
                            Dummy.KingOnTable[i].KingThinking[j].t.Start();
                            Wait(Dummy, i, j, 6);
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.KingOnTable[i] = null; Log(t);
                    }
                }
            }

            if (AllDraw.DeptFirstSearch)
            {
                AllDraw AdumnmyConstructed = this.CopyRemeiningItems(Dummy, Order);
                if (ADraw != null)
                    this.ADraw.Clear();
                else
                    this.ADraw = new List<AllDraw>();
                this.ADraw.Add(AdumnmyConstructed);
            }
            else
            {
                if (ADraw != null)
                    this.ADraw = new List<AllDraw>();
                else
                    this.ADraw.Clear();
                this.ADraw.Add(Dummy);
            }

        }
        public void SetRowColumn(int index)
        {
            try
            {
                Move = 0;
                //Intiate Dummy Variables.
                int So1 = 0;
                int So2 = AllDraw.SodierMidle;
                int El1 = 0;
                int El2 = AllDraw.ElefantMidle;
                int Ho1 = 0;
                int Ho2 = AllDraw.HourseMidle;
                int Br1 = 0;
                int Br2 = AllDraw.BridgeMidle;
                int Mi1 = 0;
                int Mi2 = AllDraw.MinisterMidle;
                int Ki1 = 0;
                int Ki2 = AllDraw.KingMidle;
                //Wen Conversion Occured.
                //if (AllDraw.SodierConversionOcuured)
                {
                    //A = new List<AllDraw>();
                    SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
                    for (int i = 0; i < AllDraw.SodierHigh; i++)
                        SolderesOnTable[i] = new DrawSoldier();
                    ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
                    for (int i = 0; i < AllDraw.ElefantHigh; i++)
                        ElephantOnTable[i] = new DrawElefant();
                    HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
                    for (int i = 0; i < AllDraw.HourseHight; i++)
                        HoursesOnTable[i] = new DrawHourse();
                    BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
                    for (int i = 0; i < AllDraw.BridgeHigh; i++)
                        BridgesOnTable[i] = new DrawBridge();
                    MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
                    for (int i = 0; i < AllDraw.MinisterHigh; i++)
                        MinisterOnTable[i] = new DrawMinister();
                    KingOnTable = new DrawKing[AllDraw.KingHigh];
                    for (int i = 0; i < AllDraw.KingHigh; i++)
                        KingOnTable[i] = new DrawKing();
                    AllDraw.SodierConversionOcuured = false;

                }
                //When Table Exist.
                if (TableList.Count > 0)
                {
                    //For Every Table Things.
                    for (int Column = 0; Column < 8; Column++)
                        for (int Row = 0; Row < 8; Row++)
                        {
                            //When Things are Soldiers.
                            if (System.Math.Abs(this.TableList[index][Row, Column]) == 1)
                            {
                                //Determine Color
                                Color a;

                                if (this.TableList[index][Row, Column] > 0)
                                    a = Color.Gray;
                                else
                                    a = Color.Brown;
                                //When Color is Gray. 
                                if (a == Color.Gray)
                                {
                                    try
                                    {
                                        //When Solders ate current location differs add move.
                                        try
                                        {
                                            if (SolderesOnTable[So1].Row != Row || SolderesOnTable[So1].Column != Column)
                                                Move++;
                                        }
                                        catch (Exception t) { Log(t); }
                                        //Construct Soder Gray.
                                        SolderesOnTable[So1] = new DrawSoldier(Row, Column, a, this.TableList[index], 1, false, So1);
                                        //Increase So1.
                                        So1++;
                                        if (So1 > SodierMidle)
                                        {
                                            SodierMidle++;
                                            SodierHigh++;
                                        }

                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                                //When Color is Brown
                                else
                                {
                                    try
                                    {
                                        //When Solders ate current location differs add move.
                                        try
                                        {
                                            if (SolderesOnTable[So2].Row != Row ||
                                            SolderesOnTable[So2].Column != Column)
                                                Move++;
                                        }
                                        catch (Exception t) { Log(t); }
                                        //Construct Soldeir Brown.
                                        SolderesOnTable[So2] = new DrawSoldier(Row, Column, a, this.TableList[index], -1, false, So2);
                                        //Increase So2.
                                        So2++;
                                        if (So2 > SodierHigh)
                                            SodierHigh++;
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                            }
                            else //Reamaining are the same and correct.
                                if (System.Math.Abs(this.TableList[index][Row, Column]) == 2)
                                {
                                    Color a;

                                    if (this.TableList[index][Row, Column] > 0)
                                        a = Color.Gray;
                                    else
                                        a = Color.Brown;
                                    if (a == Color.Gray)
                                    {
                                        try
                                        {
                                            try
                                            {
                                                if (ElephantOnTable[El1].Row != Row ||
                                                    ElephantOnTable[El1].Column != Column)
                                                    Move++;
                                            }
                                            catch (Exception t) { Log(t); }
                                            ElephantOnTable[El1] = new DrawElefant(Row, Column, a, this.TableList[index], 1, false, El1);
                                            El1++;
                                            if (El1 > ElefantMidle)
                                            {
                                                ElefantMidle++;
                                                ElefantHigh++;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                    else
                                    {
                                        try
                                        {
                                            try
                                            {
                                                if (ElephantOnTable[El2].Row != Row ||
                                                    ElephantOnTable[El2].Column != Column)
                                                    Move++;
                                            }
                                            catch (Exception t) { Log(t); }
                                            ElephantOnTable[El2] = new DrawElefant(Row, Column, a, this.TableList[index], -1, false, El2);
                                            El2++;
                                            if (El2 > ElefantHigh)
                                                ElefantHigh++;

                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }

                                    }
                                }
                                else
                                    if (System.Math.Abs(this.TableList[index][Row, Column]) == 3)
                                    {
                                        Color a;

                                        if (this.TableList[index][Row, Column] > 0)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        if (a == Color.Gray)
                                        {

                                            try
                                            {
                                                try
                                                {
                                                    if (HoursesOnTable[Ho1].Row != Row ||
                                                        HoursesOnTable[Ho1].Column != Column)
                                                        Move++;
                                                }
                                                catch (Exception t) { Log(t); }
                                                HoursesOnTable[Ho1] = new DrawHourse(Row, Column, a, this.TableList[index], 1, false, Ho1);
                                                Ho1++;
                                                if (Ho1 > HourseMidle)
                                                {
                                                    HourseMidle++;
                                                    HourseHight++;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        else
                                        {
                                            try
                                            {
                                                try
                                                {
                                                    if (HoursesOnTable[Ho2].Row != Row |
                                                        HoursesOnTable[Ho2].Column != Column)
                                                        Move++;
                                                }
                                                catch (Exception t) { Log(t); }
                                                HoursesOnTable[Ho2] = new DrawHourse(Row, Column, a, this.TableList[index], -1, false, Ho2);
                                                Ho2++;
                                                if (Ho2 > HourseHight)
                                                    HourseHight++;
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                    }
                                    else
                                        if (System.Math.Abs(this.TableList[index][Row, Column]) == 4)
                                        {
                                            Color a;

                                            if (this.TableList[index][Row, Column] > 0)
                                                a = Color.Gray;
                                            else
                                                a = Color.Brown;
                                            if (a == Color.Gray)
                                            {

                                                try
                                                {
                                                    try
                                                    {
                                                        if (BridgesOnTable[Br1].Row != Row ||
                                                            BridgesOnTable[Br1].Column != Column)
                                                            Move++;
                                                    }
                                                    catch (Exception t) { Log(t); }
                                                    BridgesOnTable[Br1] = new DrawBridge(Row, Column, a, this.TableList[index], 1, false, Br1);
                                                    Br1++;
                                                    if (Br1 > BridgeMidle)
                                                    {
                                                        BridgeMidle++;
                                                        BridgeHigh++;
                                                    }

                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    try
                                                    {
                                                        if (BridgesOnTable[Br2].Row != Row ||
                                                            BridgesOnTable[Br2].Column != Column)
                                                            Move++;
                                                    }
                                                    catch (Exception t) { Log(t); } BridgesOnTable[Br2] = new DrawBridge(Row, Column, a, this.TableList[index], -1, false, Br2);
                                                    Br2++;
                                                    if (Br2 > BridgeHigh)
                                                        BridgeHigh++;

                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        else
                                            if (System.Math.Abs(this.TableList[index][Row, Column]) == 5)
                                            {
                                                Color a;

                                                if (this.TableList[index][Row, Column] > 0)
                                                    a = Color.Gray;
                                                else
                                                    a = Color.Brown;
                                                if (a == Color.Gray)
                                                {

                                                    try
                                                    {
                                                        try
                                                        {
                                                            if (MinisterOnTable[Mi1].Row != Row ||
                                                                MinisterOnTable[Mi1].Column != Column)
                                                                Move++;
                                                        }
                                                        catch (Exception t) { Log(t); } MinisterOnTable[Mi1] = new DrawMinister(Row, Column, a, this.TableList[index], 1, false, Mi1);
                                                        Mi1++;
                                                        if (Mi1 > MinisterMidle)
                                                        {
                                                            MinisterMidle++;
                                                            MinisterHigh++;
                                                        }
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }

                                                }
                                                else
                                                {
                                                    try
                                                    {
                                                        try
                                                        {
                                                            if (MinisterOnTable[Mi2].Row != Row ||
                                                                MinisterOnTable[Mi2].Column != Column)
                                                                Move++;
                                                        }
                                                        catch (Exception t) { Log(t); } MinisterOnTable[Mi2] = new DrawMinister(Row, Column, a, this.TableList[index], -1, false, Mi2);
                                                        Mi2++;
                                                        if (Mi2 > MinisterHigh)
                                                            MinisterHigh++;

                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }
                                                }
                                            }
                                            else
                                                if (System.Math.Abs(this.TableList[index][Row, Column]) == 6)
                                                {
                                                    Color a;

                                                    if (this.TableList[index][Row, Column] > 0)
                                                        a = Color.Gray;
                                                    else
                                                        a = Color.Brown;
                                                    if (a == Color.Gray)
                                                    {

                                                        try
                                                        {
                                                            try
                                                            {
                                                                if (KingOnTable[Ki1].Row != Row ||
                                                                    KingOnTable[Ki1].Column != Column)
                                                                    Move++;

                                                            }
                                                            catch (Exception t) { Log(t); } KingOnTable[Ki1] = new DrawKing(Row, Column, a, this.TableList[index], 1, false, Ki1);
                                                            Ki1++;
                                                            if (Ki1 > KingMidle)
                                                            {
                                                                KingMidle++;
                                                                KingHigh++;

                                                            }

                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        try
                                                        {
                                                            try
                                                            {
                                                                if (KingOnTable[Ki2].Row != Row ||
                                                                    KingOnTable[Ki2].Column != Column)
                                                                    Move++;
                                                            }
                                                            catch (Exception t) { Log(t); } KingOnTable[Ki2] = new DrawKing(Row, Column, a, this.TableList[index], -1, false, Ki2);
                                                            Ki2++;
                                                            if (Ki2 > KingHigh)
                                                                KingHigh++;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                        }
                                                    }

                                                }
                        }
                    for (int i = So1; i < AllDraw.SodierMidle; i++)
                        SolderesOnTable[i] = null;

                    for (int i = So2; i < AllDraw.SodierHigh; i++)
                        SolderesOnTable[i] = null;

                    for (int i = El1; i < AllDraw.ElefantMidle; i++)
                        ElephantOnTable[i] = null;

                    for (int i = El2; i < AllDraw.ElefantHigh; i++)
                        ElephantOnTable[i] = null;

                    for (int i = Ho1; i < AllDraw.HourseMidle; i++)
                        HoursesOnTable[i] = null;

                    for (int i = Ho2; i < AllDraw.HourseHight; i++)
                        HoursesOnTable[i] = null;

                    for (int i = Br1; i < AllDraw.BridgeMidle; i++)
                        BridgesOnTable[i] = null;

                    for (int i = Br2; i < AllDraw.BridgeHigh; i++)
                        BridgesOnTable[i] = null;

                    for (int i = Mi1; i < AllDraw.MinisterMidle; i++)
                        MinisterOnTable[i] = null;

                    for (int i = Mi2; i < AllDraw.MinisterHigh; i++)
                        MinisterOnTable[i] = null;

                    for (int i = Ki1; i < AllDraw.KingMidle; i++)
                        KingOnTable[i] = null;

                    for (int i = Ki2; i < AllDraw.KingHigh; i++)
                        KingOnTable[i] = null;

                }
                /*  AllDraw.RedrawTable = true;
                  AllDraw.SodierMidle = So1;
                  AllDraw.SodierHigh = So2;
                  AllDraw.ElefantMidle = El1;
                  AllDraw.ElefantHigh = El2;
                  AllDraw.HourseMidle = Ho1;
                  AllDraw.HourseHight = Ho2;
                  AllDraw.BridgeMidle = Br1;
                  AllDraw.BridgeHigh = Br2;
                  AllDraw.MinisterMidle = Mi1;
                  AllDraw.MinisterHigh = Mi2;
                  AllDraw.KingMidle = Ki1;
                  AllDraw.KingHigh = Ki2;*/

            }
            catch (Exception t)
            {
                Log(t);
            }
        }
        public int[,] HuristicDeptSearch(List<AllDraw> A, Color a, ref double Less, int Order, bool CurrentTableHuristic)
        {
            int i = 0, j = 0;
            int[,] Table = new int[8, 8];
            bool Act = false;
            int CurrentHuristicDeptFirstOrder = Order;
            //When There is Some A.Count
            if (A.Count > 0)
            {
                //FormatException Every BridgeMovments.
                for (int ii = 0; ii < A.Count; ii++)
                {
                    if (CurrentHuristicDeptFirstOrder == 1)
                    {
                        //For Every Soldeir
                        for (i = 0; i < AllDraw.SodierMidle; i++)
                        {


                            //For Every Soldier Movments Dept.
                            for (int k = 0; k < AllDraw.SodierMovments; k++)
                                //When There is an Movment in such situation.
                                try
                                {
                                    for (j = 0; A[ii].SolderesOnTable[i] != null && A[0].SolderesOnTable[i] != null && A[ii].SolderesOnTable[i].SoldierThinking[k] != null && A[0].SolderesOnTable[i].SoldierThinking[k] != null && j < A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder.Count; j++)
                                    {
                                        try
                                        {
                                            //For Penalty Reagrad Mechanisam of Current Kish Mate Current Movments.
                                            if (A[ii].SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (A[0].SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0)
                                                continue;
                                            //When There is No Movments in Such Order Enemy continue.
                                            if (Order != CurrentHuristicDeptFirstOrder)
                                                if (A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                                    continue;
                                            //When There is greater Huristic Movments.
                                            if (A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                            {
                                                //if (KishG || KishB)
                                                //{
                                                //retrive table of current huristic.
                                                int[,] TableS = A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                                int[,] TableSS = A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];

                                                //checked for Legal Movments ArgumentOutOfRangeException curnt game.
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                            continue;

                                                    }

                                                }
                                                //When there is not Penalty regard mechanism.
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    //If there iss kish or kshachamaz Order.
                                                    if ((new ChessRules(1, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        //When Orderis Gray.
                                                        if (Order == 1)
                                                        {
                                                            //Continue When is kish KishAchmaz and DeptFirstSearch .
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            //Continue when KishBrown and DeptFirstSearch. 
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    // }
                                                    else
                                                    {

                                                    }
                                                    //When Order is gray.
                                                    if (Order == 1)
                                                    {
                                                        //When KishGrayAchmaz and There is not DeptFirst search.
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            //Predic Search.
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;
                                                            else
                                                            {
                                                                RW = i;
                                                                CL = k;
                                                                Ki = 1;
                                                                Act = true;
                                                                Less = A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];

                                                                continue;


                                                            }

                                                        }
                                                    }
                                                    else
                                                    {
                                                        //When Order is Bromn and there is not DeptFirstSearch.
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            //Prdedict Kish.
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;

                                                        }
                                                    }
                                                }
                                                //Set Table and Huristic Value and Syntax.
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                FormRefrigtz.LastRow = A[0].SolderesOnTable[i].SoldierThinking[k].Row;
                                                FormRefrigtz.LastColumn = A[0].SolderesOnTable[i].SoldierThinking[k].Column;

                                                Less = A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];


                                                Table = A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                                bool Hit = false;
                                                if (A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                    Hit = true;
                                                if (Order == 1)
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);
                                                else
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);


                                                ThingsConverter.ActOfClickEqualTow = true;
                                                A[0].SolderesOnTable[i].ConvertOperation(A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], a, A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, false, i);
                                                int Sign = 1;
                                                if (a == Color.Brown)
                                                    Sign = -1;
                                                //If there is Soldier Convert.
                                                if (A[0].SolderesOnTable[i].Convert)
                                                {
                                                    Hit = false;
                                                    if (A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);

                                                    if (A[0].SolderesOnTable[i].ConvertedToMinister)
                                                        Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 5 * Sign;
                                                    else if (A[0].SolderesOnTable[i].ConvertedToBridge)
                                                        Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 4 * Sign;
                                                    else if (A[0].SolderesOnTable[i].ConvertedToHourse)
                                                        Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 3 * Sign;
                                                    else if (A[0].SolderesOnTable[i].ConvertedToElefant)
                                                        Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 2 * Sign;
                                                    TableList.Clear();
                                                    TableList.Add(Table);
                                                    if (A.Count > 1)
                                                        A[0].SetRowColumn(0);
                                                    TableList.Clear();

                                                }


                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }
                        //Do For Remaining Objects same as Soldeir Documentation.
                        for (i = 0; i < AllDraw.ElefantMidle; i++)
                        {
                            for (int k = 0; k < AllDraw.ElefantMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].ElephantOnTable[i] != null && A[0].ElephantOnTable[i] != null && A[ii].ElephantOnTable[i].ElefantThinking[k] != null && A[0].ElephantOnTable[i].ElefantThinking[k] != null && j < A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant.Count; j++)
                                    {
                                        try
                                        {
                                            if (A[ii].ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (A[0].ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (Order != CurrentHuristicDeptFirstOrder)
                                                if (A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                                    continue;
                                            if (A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                            {
                                                //if (KishG || KishB)
                                                //{

                                                int[,] TableS = A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                                int[,] TableSS = A[ii].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                            continue;

                                                    }


                                                }
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(2, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;
                                                            else
                                                            {
                                                                RW = i;
                                                                CL = k;
                                                                Ki = 1;
                                                                Act = true;
                                                                Less = A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];

                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(ii);
                                                            Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;


                                                        }
                                                    }

                                                }
                                                bool Hit = false;
                                                if (A[0].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j] > 0)
                                                    Hit = true;
                                                if (Order == 1)
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 2, A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, A[0].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);
                                                else
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -2, A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, A[0].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);

                                                FormRefrigtz.LastRow = A[0].ElephantOnTable[i].ElefantThinking[k].Row;
                                                FormRefrigtz.LastColumn = A[0].ElephantOnTable[i].ElefantThinking[k].Column;

                                                RW = i;
                                                CL = k;
                                                Ki = 2;
                                                Act = true;
                                                Less = A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];
                                                Table = A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];

                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                        for (i = 0; i < AllDraw.HourseHight; i++)
                        {

                            for (int k = 0; k < AllDraw.HourseMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].HoursesOnTable[i] != null && A[0].HoursesOnTable[i] != null && A[ii].HoursesOnTable[i].HourseThinking[k] != null && A[0].HoursesOnTable[i].HourseThinking[k] != null && j < A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse.Count; j++)
                                    {
                                        try
                                        {
                                            if (A[ii].HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (A[0].HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0)
                                                continue;

                                            if (Order != CurrentHuristicDeptFirstOrder)
                                                if (A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)
                                                    continue;
                                            if (A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)
                                            {
                                                int[,] TableS = A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                                int[,] TableSS = A[ii].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                                {
                                                    if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                                    {
                                                        try
                                                        {
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                                continue;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                                continue;

                                                        }

                                                    }
                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        if ((new ChessRules(3, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            if (Order == 1)
                                                            {
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        else
                                                        {

                                                        }
                                                    }


                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;

                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;
                                                            else
                                                            {
                                                                RW = i;
                                                                CL = k;
                                                                Ki = 1;
                                                                Act = true;
                                                                Less = A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                                continue;
                                                            }

                                                        }
                                                    }
                                                }
                                                bool Hit = false;
                                                if (A[0].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j] > 0)
                                                    Hit = true;
                                                if (Order == 1)
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 3, A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, A[0].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                                else
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -3, A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, A[0].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                                FormRefrigtz.LastRow = A[0].HoursesOnTable[i].HourseThinking[k].Row;
                                                FormRefrigtz.LastColumn = A[0].HoursesOnTable[i].HourseThinking[k].Column;

                                                RW = i;
                                                CL = k;
                                                Ki = 3;
                                                Act = true;
                                                Less = A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                Table = A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];

                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }

                        for (i = 0; i < AllDraw.BridgeMidle; i++)
                        {
                            for (int k = 0; k < AllDraw.BridgeMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].BridgesOnTable[i] != null && A[0].BridgesOnTable[i] != null && A[ii].BridgesOnTable[i].BridgeThinking[k] != null && A[0].BridgesOnTable[i].BridgeThinking[k] != null && j < A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge.Count; j++)
                                    {
                                        try
                                        {
                                            if (A[ii].BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (A[0].BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (Order != CurrentHuristicDeptFirstOrder)
                                                if (A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                                    continue;
                                            if (A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                            {
                                                int[,] TableS = A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                                int[,] TableSS = A[ii].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                            continue;

                                                    }


                                                }
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(4, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.BridgesOnTable[i].Row, APredict.BridgesOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;

                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(A[ii].BridgesOnTable[i].Row, A[ii].BridgesOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;
                                                            else
                                                            {
                                                                RW = i;
                                                                CL = k;
                                                                Ki = 1;
                                                                Act = true;
                                                                Less = A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];

                                                                continue;
                                                            }
                                                        }
                                                    }
                                                }
                                                bool Hit = false;
                                                if (A[0].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j] > 0)
                                                    Hit = true;
                                                if (Order == 1)
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 4, A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, A[0].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                                else
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -4, A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, A[0].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                                FormRefrigtz.LastRow = A[0].BridgesOnTable[i].BridgeThinking[k].Row;
                                                FormRefrigtz.LastColumn = A[0].BridgesOnTable[i].BridgeThinking[k].Column;

                                                RW = i;
                                                CL = k;
                                                Ki = 4;
                                                Act = true;
                                                Less = A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];
                                                Table = A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];

                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }


                        for (i = 0; i < AllDraw.MinisterMidle; i++)
                        {

                            for (int k = 0; k < AllDraw.MinisterMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].MinisterOnTable[i] != null && A[0].MinisterOnTable[i] != null && A[ii].MinisterOnTable[i].MinisterThinking[k] != null && A[0].MinisterOnTable[i].MinisterThinking[k] != null && j < A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister.Count; j++)
                                    {

                                        if (A[ii].MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (A[0].MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (Order != CurrentHuristicDeptFirstOrder)
                                            if (A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                                continue;
                                        if (A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                        {
                                            int[,] TableS = A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                            int[,] TableSS = A[ii].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                            if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                            {
                                                try
                                                {
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                        continue;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                        continue;

                                                }

                                            }
                                            {
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(5, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }
                                                }

                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;

                                                    }

                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        if (null == APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false))
                                                            continue;

                                                    }
                                                }

                                            }
                                            bool Hit = false;
                                            if (A[0].MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                                Hit = true;
                                            if (Order == 1)
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 5, A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, A[0].MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                            else
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -5, A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, A[0].MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                            FormRefrigtz.LastRow = A[0].MinisterOnTable[i].MinisterThinking[k].Row;
                                            FormRefrigtz.LastColumn = A[0].MinisterOnTable[i].MinisterThinking[k].Column;

                                            RW = i;
                                            CL = k;
                                            Ki = 5;
                                            Act = true;
                                            Less = A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3];
                                            Table = A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];

                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }

                        for (i = 0; i < AllDraw.KingMidle; i++)
                        {
                            for (int k = 0; k < AllDraw.KingMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].KingOnTable[i] != null && A[0].KingOnTable[i] != null && A[ii].KingOnTable[i].KingThinking[k] != null && A[0].KingOnTable[i].KingThinking[k] != null && j < A[0].KingOnTable[i].KingThinking[k].TableListKing.Count; j++)
                                    {
                                        try
                                        {
                                            if (A[ii].KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (A[0].KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (Order != CurrentHuristicDeptFirstOrder)
                                                if (A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                                    continue;
                                            if (A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                            {
                                                int[,] TableS = A[0].KingOnTable[i].KingThinking[k].TableListKing[j];
                                                int[,] TableSS = A[ii].KingOnTable[i].KingThinking[k].TableListKing[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                            continue;

                                                    }
                                                }
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(6, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;

                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                            if (Table == null)
                                                                continue;
                                                            else
                                                            {
                                                                RW = i;
                                                                CL = k;
                                                                Ki = 1;
                                                                Act = true;
                                                                Less = A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                                continue;
                                                            }

                                                        }
                                                    }

                                                }
                                                bool Hit = false;
                                                if (A[0].KingOnTable[i].KingThinking[k].HitNumberKing[j] > 0)
                                                    Hit = true;
                                                if (Order == 1)
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 6, A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][1], A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, A[0].KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);
                                                else
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -6, A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][1], A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, A[0].KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);

                                                FormRefrigtz.LastRow = A[0].KingOnTable[i].KingThinking[k].Row;
                                                FormRefrigtz.LastColumn = A[0].KingOnTable[i].KingThinking[k].Column;

                                                RW = i;
                                                CL = k;
                                                Ki = 6;
                                                Act = true;
                                                Less = A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                Table = A[0].KingOnTable[i].KingThinking[k].TableListKing[j];

                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                    }
                    else
                    {
                        //For Every Soldeir
                        for (i = SodierMidle; i < AllDraw.SodierHigh; i++)
                        {


                            //For Every Soldier Movments Dept.
                            for (int k = 0; k < AllDraw.SodierMovments; k++)
                                //When There is an Movment in such situation.
                                try
                                {
                                    for (j = 0; A[ii].SolderesOnTable[i] != null && A[0].SolderesOnTable[i] != null && A[ii].SolderesOnTable[i].SoldierThinking[k] != null && A[0].SolderesOnTable[i].SoldierThinking[k] != null && j < A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder.Count; j++)
                                    {

                                        //For Penalty Reagrad Mechanisam of Current Kish Mate Current Movments.
                                        if (A[ii].SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (A[0].SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0)
                                            continue;
                                        //When There is No Movments in Such Order Enemy continue.
                                        if (Order != CurrentHuristicDeptFirstOrder)
                                            if (A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                                continue;
                                        //When There is greater Huristic Movments.
                                        if (A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                        {
                                            //if (KishG || KishB)
                                            //{
                                            //retrive table of current huristic.
                                            int[,] TableS = A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                            int[,] TableSS = A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];

                                            //checked for Legal Movments ArgumentOutOfRangeException curnt game.
                                            if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                            {
                                                try
                                                {
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                        continue;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                        continue;

                                                }
                                            }
                                            //When there is not Penalty regard mechanism.
                                            if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                            {
                                                //If there iss kish or kshachamaz Order.
                                                if ((new ChessRules(1, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                {
                                                    //When Orderis Gray.
                                                    if (Order == 1)
                                                    {
                                                        //Continue When is kish KishAchmaz and DeptFirstSearch .
                                                        if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                    else
                                                    {
                                                        //Continue when KishBrown and DeptFirstSearch. 
                                                        if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                }
                                                // }
                                                else
                                                {

                                                }
                                                //When Order is gray.
                                                if (Order == 1)
                                                {
                                                    //When KishGrayAchmaz and There is not DeptFirst search.
                                                    if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                    {
                                                        //Predic Search.
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;
                                                        else
                                                        {
                                                            RW = i;
                                                            CL = k;
                                                            Ki = 1;
                                                            Act = true;
                                                            Less = A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];

                                                            continue;


                                                        }

                                                    }
                                                }
                                                else
                                                {
                                                    //When Order is Bromn and there is not DeptFirstSearch.
                                                    if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                    {
                                                        //Prdedict Kish.
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;

                                                    }
                                                }
                                            }
                                            //Set Table and Huristic Value and Syntax.
                                            RW = i;
                                            CL = k;
                                            Ki = 1;
                                            Act = true;
                                            FormRefrigtz.LastRow = A[0].SolderesOnTable[i].SoldierThinking[k].Row;
                                            FormRefrigtz.LastColumn = A[0].SolderesOnTable[i].SoldierThinking[k].Column;

                                            Less = A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[0].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];


                                            Table = A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                            bool Hit = false;
                                            if (A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                Hit = true;
                                            if (Order == 1)
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);
                                            else
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);


                                            ThingsConverter.ActOfClickEqualTow = true;
                                            A[0].SolderesOnTable[i].ConvertOperation(A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], a, A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, false, i);
                                            int Sign = 1;
                                            if (a == Color.Brown)
                                                Sign = -1;
                                            //If there is Soldier Convert.
                                            if (A[0].SolderesOnTable[i].Convert)
                                            {
                                                Hit = false;
                                                if (A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                    Hit = true;
                                                if (Order == 1)
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);
                                                else
                                                    SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[0].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);

                                                if (A[0].SolderesOnTable[i].ConvertedToMinister)
                                                    Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 5 * Sign;
                                                else if (A[0].SolderesOnTable[i].ConvertedToBridge)
                                                    Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 4 * Sign;
                                                else if (A[0].SolderesOnTable[i].ConvertedToHourse)
                                                    Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 3 * Sign;
                                                else if (A[0].SolderesOnTable[i].ConvertedToElefant)
                                                    Table[A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[0].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 2 * Sign;
                                                TableList.Clear();
                                                TableList.Add(Table);
                                                if (A.Count > 1)
                                                    A[0].SetRowColumn(0);
                                                TableList.Clear();

                                            }


                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }
                        //Do For Remaining Objects same as Soldeir Documentation.
                        for (i = ElefantMidle; i < AllDraw.ElefantHigh; i++)
                        {
                            for (int k = 0; k < AllDraw.ElefantMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].ElephantOnTable[i] != null && A[0].ElephantOnTable[i] != null && A[ii].ElephantOnTable[i].ElefantThinking[k] != null && A[0].ElephantOnTable[i].ElefantThinking[k] != null && j < A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant.Count; j++)
                                    {

                                        if (A[ii].ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (A[0].ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (Order != CurrentHuristicDeptFirstOrder)
                                            if (A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                                continue;
                                        if (A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                        {
                                            //if (KishG || KishB)
                                            //{

                                            int[,] TableS = A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                            int[,] TableSS = A[ii].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                            if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                            {
                                                try
                                                {
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                        continue;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                        continue;

                                                }
                                            }
                                            if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                            {
                                                if ((new ChessRules(2, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                {
                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                }
                                                else
                                                {

                                                }

                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;
                                                        else
                                                        {
                                                            RW = i;
                                                            CL = k;
                                                            Ki = 1;
                                                            Act = true;
                                                            Less = A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];

                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(ii);
                                                        Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;


                                                    }
                                                }

                                            }
                                            bool Hit = false;
                                            if (A[0].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j] > 0)
                                                Hit = true;
                                            if (Order == 1)
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 2, A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, A[0].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);
                                            else
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -2, A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], A[0].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, A[0].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);

                                            FormRefrigtz.LastRow = A[0].ElephantOnTable[i].ElefantThinking[k].Row;
                                            FormRefrigtz.LastColumn = A[0].ElephantOnTable[i].ElefantThinking[k].Column;

                                            RW = i;
                                            CL = k;
                                            Ki = 2;
                                            Act = true;
                                            Less = A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[0].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];
                                            Table = A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];

                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                        for (i = HourseMidle; i < AllDraw.HourseHight; i++)
                        {

                            for (int k = 0; k < AllDraw.HourseMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].HoursesOnTable[i] != null && A[0].HoursesOnTable[i] != null && A[ii].HoursesOnTable[i].HourseThinking[k] != null && A[0].HoursesOnTable[i].HourseThinking[k] != null && j < A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse.Count; j++)
                                    {

                                        if (A[ii].HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (A[0].HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0)
                                            continue;

                                        if (Order != CurrentHuristicDeptFirstOrder)
                                            if (A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)
                                                continue;
                                        if (A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)
                                        {
                                            int[,] TableS = A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                            int[,] TableSS = A[ii].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                            {
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                            continue;

                                                    }

                                                }

                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(3, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }
                                                }


                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;

                                                    }
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;
                                                        else
                                                        {
                                                            RW = i;
                                                            CL = k;
                                                            Ki = 1;
                                                            Act = true;
                                                            Less = A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                            continue;
                                                        }

                                                    }
                                                }
                                            }
                                            bool Hit = false;
                                            if (A[0].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j] > 0)
                                                Hit = true;
                                            if (Order == 1)
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 3, A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, A[0].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                            else
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -3, A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], A[0].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, A[0].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                            FormRefrigtz.LastRow = A[0].HoursesOnTable[i].HourseThinking[k].Row;
                                            FormRefrigtz.LastColumn = A[0].HoursesOnTable[i].HourseThinking[k].Column;

                                            RW = i;
                                            CL = k;
                                            Ki = 3;
                                            Act = true;
                                            Less = A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[0].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                            Table = A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];

                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }

                        for (i = BridgeMidle; i < AllDraw.BridgeHigh; i++)
                        {
                            for (int k = 0; k < AllDraw.BridgeMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].BridgesOnTable[i] != null && A[0].BridgesOnTable[i] != null && A[ii].BridgesOnTable[i].BridgeThinking[k] != null && A[0].BridgesOnTable[i].BridgeThinking[k] != null && j < A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge.Count; j++)
                                    {

                                        if (A[ii].BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (A[0].BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (Order != CurrentHuristicDeptFirstOrder)
                                            if (A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                                continue;
                                        if (A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                        {
                                            int[,] TableS = A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                            int[,] TableSS = A[ii].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                            if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                            {
                                                try
                                                {
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                        continue;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                        continue;

                                                }

                                            }
                                            if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                            {
                                                if ((new ChessRules(4, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                {
                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                }
                                                else
                                                {

                                                }

                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.BridgesOnTable[i].Row, APredict.BridgesOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;

                                                    }
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(A[ii].BridgesOnTable[i].Row, A[ii].BridgesOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;
                                                        else
                                                        {
                                                            RW = i;
                                                            CL = k;
                                                            Ki = 1;
                                                            Act = true;
                                                            Less = A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];

                                                            continue;
                                                        }
                                                    }
                                                }
                                            }
                                            bool Hit = false;
                                            if (A[0].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j] > 0)
                                                Hit = true;
                                            if (Order == 1)
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 4, A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, A[0].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                            else
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -4, A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], A[0].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, A[0].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                            FormRefrigtz.LastRow = A[0].BridgesOnTable[i].BridgeThinking[k].Row;
                                            FormRefrigtz.LastColumn = A[0].BridgesOnTable[i].BridgeThinking[k].Column;

                                            RW = i;
                                            CL = k;
                                            Ki = 4;
                                            Act = true;
                                            Less = A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + A[0].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];
                                            Table = A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];

                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }


                        for (i = MinisterMidle; i < AllDraw.MinisterHigh; i++)
                        {

                            for (int k = 0; k < AllDraw.MinisterMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].MinisterOnTable[i] != null && A[0].MinisterOnTable[i] != null && A[ii].MinisterOnTable[i].MinisterThinking[k] != null && A[0].MinisterOnTable[i].MinisterThinking[k] != null && j < A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister.Count; j++)
                                    {

                                        if (A[ii].MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (A[0].MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (Order != CurrentHuristicDeptFirstOrder)
                                            if (A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                                continue;
                                        if (A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                        {
                                            int[,] TableS = A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                            int[,] TableSS = A[ii].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                            if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                            {
                                                try
                                                {
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                        continue;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                        continue;

                                                }
                                            }
                                            {
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(5, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }
                                                }

                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;

                                                    }

                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        if (null == APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false))
                                                            continue;

                                                    }
                                                }

                                            }
                                            bool Hit = false;
                                            if (A[0].MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                                Hit = true;
                                            if (Order == 1)
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 5, A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, A[0].MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                            else
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -5, A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], A[0].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, A[0].MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                            FormRefrigtz.LastRow = A[0].MinisterOnTable[i].MinisterThinking[k].Row;
                                            FormRefrigtz.LastColumn = A[0].MinisterOnTable[i].MinisterThinking[k].Column;

                                            RW = i;
                                            CL = k;
                                            Ki = 5;
                                            Act = true;
                                            Less = A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[0].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3];
                                            Table = A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];

                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                        for (i = KingMidle; i < AllDraw.KingHigh; i++)
                        {
                            for (int k = 0; k < AllDraw.KingMovments; k++)
                                try
                                {
                                    for (j = 0; A[ii].KingOnTable[i] != null && A[0].KingOnTable[i] != null && A[ii].KingOnTable[i].KingThinking[k] != null && A[0].KingOnTable[i].KingThinking[k] != null && j < A[0].KingOnTable[i].KingThinking[k].TableListKing.Count; j++)
                                    {

                                        if (A[ii].KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (A[0].KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                            continue;
                                        if (Order != CurrentHuristicDeptFirstOrder)
                                            if (A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                                continue;
                                        if (A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                        {
                                            int[,] TableS = A[0].KingOnTable[i].KingThinking[k].TableListKing[j];
                                            int[,] TableSS = A[ii].KingOnTable[i].KingThinking[k].TableListKing[j];
                                            if (DynamicDeptFirstPrograming && !CurrentTableHuristic)
                                            {
                                                try
                                                {
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Order))
                                                        continue;
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                    if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], CurrentHuristicDeptFirstOrder))
                                                        continue;

                                                }

                                            }
                                            if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                            {
                                                if ((new ChessRules(6, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                {
                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                            continue;
                                                    }
                                                }
                                                else
                                                {

                                                }

                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;

                                                    }
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                    {
                                                        Color B;
                                                        if (a == Color.Gray)
                                                            B = Color.Brown;
                                                        else
                                                            B = Color.Gray;
                                                        APredict.TableList.Clear();
                                                        APredict.TableList.Add(TableS);
                                                        APredict.SetRowColumn(0);
                                                        Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                        if (Table == null)
                                                            continue;
                                                        else
                                                        {
                                                            RW = i;
                                                            CL = k;
                                                            Ki = 1;
                                                            Act = true;
                                                            Less = A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                            continue;
                                                        }

                                                    }
                                                }

                                            }
                                            bool Hit = false;
                                            if (A[0].KingOnTable[i].KingThinking[k].HitNumberKing[j] > 0)
                                                Hit = true;
                                            if (Order == 1)
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 6, A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][1], A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, A[0].KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);
                                            else
                                                SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -6, A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][1], A[0].KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, A[0].KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);

                                            FormRefrigtz.LastRow = A[0].KingOnTable[i].KingThinking[k].Row;
                                            FormRefrigtz.LastColumn = A[0].KingOnTable[i].KingThinking[k].Column;

                                            RW = i;
                                            CL = k;
                                            Ki = 6;
                                            Act = true;
                                            Less = A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[0].KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                            Table = A[0].KingOnTable[i].KingThinking[k].TableListKing[j];

                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }
                    }
                    CurrentHuristicDeptFirstOrder *= -1;
                }

            }
            if (Act)
                return Table;
            return null;
        }
        public int[,] Huristic(List<AllDraw> A, Color a, int ij, ref double Less, int Order)
        {
            int i = 0, j = 0;
            int[,] Table = new int[8, 8];
            bool Act = false;
            int ii = ij;
            if (A.Count > 0)
            {
                for (i = 0; i < AllDraw.SodierHigh; i++)
                {


                    for (int k = 0; k < AllDraw.SodierMovments; k++)
                        for (j = 0; A[ii].SolderesOnTable[i] != null && A[ii].SolderesOnTable[i].SoldierThinking[k] != null && j < A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder.Count; j++)
                        {
                            try
                            {
                                if (A[ii].SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;


                                if (A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] > Less)
                                {
                                    int[,] TableS = A[0].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];

                                    {
                                        if ((new ChessRules(1, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];

                                                continue;


                                            }

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    RW = i;
                                    CL = k;
                                    Ki = 1;
                                    Act = true;
                                    FormRefrigtz.LastRow = A[ii].SolderesOnTable[i].SoldierThinking[k].Row;
                                    FormRefrigtz.LastColumn = A[ii].SolderesOnTable[i].SoldierThinking[k].Column;

                                    Less = A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + A[ii].SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];


                                    Table = A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                    bool Hit = false;
                                    if (A[ii].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[ii].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[ii].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);


                                    ThingsConverter.ActOfClickEqualTow = true;
                                    A[ii].SolderesOnTable[i].ConvertOperation(A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], a, A[ii].SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, false, i);
                                    int Sign = 1;
                                    if (a == Color.Brown)
                                        Sign = -1;
                                    if (A[ii].SolderesOnTable[i].Convert)
                                    {
                                        Hit = false;
                                        if (A[ii].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                            Hit = true;
                                        if (Order == 1)
                                            SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[ii].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);
                                        else
                                            SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, A[ii].SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);

                                        if (A[ii].SolderesOnTable[i].ConvertedToMinister)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 5 * Sign;
                                        else if (A[ii].SolderesOnTable[i].ConvertedToBridge)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 4 * Sign;
                                        else if (A[ii].SolderesOnTable[i].ConvertedToHourse)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 3 * Sign;
                                        else if (A[ii].SolderesOnTable[i].ConvertedToElefant)
                                            Table[A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], A[ii].SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 2 * Sign;
                                        TableList.Clear();
                                        TableList.Add(Table);
                                        A[ii].SetRowColumn(0);
                                        TableList.Clear();

                                    }


                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.ElefantHigh; i++)
                {
                    for (int k = 0; k < AllDraw.ElefantMovments; k++)
                        for (j = 0; A[ii].ElephantOnTable[i] != null && A[ii].ElephantOnTable[i].ElefantThinking[k] != null && j < A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant.Count; j++)
                        {
                            try
                            {
                                if (A[ii].ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;

                                if (A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] > Less)
                                {

                                    int[,] TableS = A[0].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                    {
                                        if ((new ChessRules(2, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        //}
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];

                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(ii);
                                            Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;


                                        }
                                    }
                                    bool Hit = false;
                                    if (A[ii].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 2, A[ii].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], A[ii].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, A[ii].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -2, A[ii].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], A[ii].ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, A[ii].ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = A[ii].ElephantOnTable[i].ElefantThinking[k].Row;
                                    FormRefrigtz.LastColumn = A[ii].ElephantOnTable[i].ElefantThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 2;
                                    Act = true;
                                    Less = A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + A[ii].ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];
                                    Table = A[ii].ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.HourseHight; i++)
                {

                    for (int k = 0; k < AllDraw.HourseMovments; k++)
                        for (j = 0; A[ii].HoursesOnTable[i] != null && A[ii].HoursesOnTable[i].HourseThinking[k] != null && j < A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse.Count; j++)
                        {
                            try
                            {
                                if (A[ii].HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;


                                if (A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] > Less)
                                {
                                    int[,] TableS = A[0].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                    {
                                        {
                                            if ((new ChessRules(3, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                            {
                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                            }
                                            else
                                            {

                                            }
                                        }
                                    }

                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                continue;
                                            }

                                        }
                                    }
                                    bool Hit = false;
                                    if (A[ii].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 3, A[ii].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], A[ii].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, A[ii].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -3, A[ii].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], A[ii].HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, A[ii].HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                    FormRefrigtz.LastRow = A[ii].HoursesOnTable[i].HourseThinking[k].Row;
                                    FormRefrigtz.LastColumn = A[ii].HoursesOnTable[i].HourseThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 3;
                                    Act = true;
                                    Less = A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + A[ii].HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                    Table = A[ii].HoursesOnTable[i].HourseThinking[k].TableListHourse[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }


                }

                for (i = 0; i < AllDraw.BridgeHigh; i++)
                {
                    for (int k = 0; k < AllDraw.BridgeMovments; k++)
                        for (j = 0; A[ii].BridgesOnTable[i] != null && A[ii].BridgesOnTable[i].BridgeThinking[k] != null && j < A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge.Count; j++)
                        {
                            try
                            {
                                if (A[ii].BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListBridge[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;
                                if (A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] > Less)
                                {
                                    int[,] TableS = A[0].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                    {
                                        if ((new ChessRules(4, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.BridgesOnTable[i].Row, APredict.BridgesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(A[ii].BridgesOnTable[i].Row, A[ii].BridgesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];

                                                continue;
                                            }
                                        }
                                    }
                                    bool Hit = false;
                                    if (A[ii].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 4, A[ii].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], A[ii].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, A[ii].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -4, A[ii].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], A[ii].BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, A[ii].BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = A[ii].BridgesOnTable[i].BridgeThinking[k].Row;
                                    FormRefrigtz.LastColumn = A[ii].BridgesOnTable[i].BridgeThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 4;
                                    Act = true;
                                    Less = A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + A[ii].BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];
                                    Table = A[ii].BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }


                for (i = 0; i < AllDraw.MinisterHigh; i++)
                {

                    for (int k = 0; k < AllDraw.MinisterMovments; k++)
                        for (j = 0; A[ii].MinisterOnTable[i] != null && A[ii].MinisterOnTable[i].MinisterThinking[k] != null && j < A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister.Count; j++)
                        {
                            try
                            {
                                if (A[ii].MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;
                                if (A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] > Less)
                                {
                                    int[,] TableS = A[0].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                    {
                                        {
                                            if ((new ChessRules(5, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                            {
                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                            }
                                            else
                                            {

                                            }
                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }

                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            if (null == APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false))
                                                continue;

                                        }
                                    }
                                    bool Hit = false;
                                    if (A[ii].MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 5, A[ii].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], A[ii].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, A[ii].MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -5, A[ii].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], A[ii].MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, A[ii].MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = A[ii].MinisterOnTable[i].MinisterThinking[k].Row;
                                    FormRefrigtz.LastColumn = A[ii].MinisterOnTable[i].MinisterThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 5;
                                    Act = true;
                                    Less = A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + A[ii].MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3];
                                    Table = A[ii].MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.KingHigh; i++)
                {
                    for (int k = 0; k < AllDraw.KingMovments; k++)
                        for (j = 0; A[ii].KingOnTable[i] != null && A[ii].KingOnTable[i].KingThinking[k] != null && j < A[0].KingOnTable[i].KingThinking[k].TableListKing.Count; j++)
                        {
                            try
                            {
                                if (A[ii].KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;
                                if (A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3] > Less)
                                {
                                    int[,] TableS = A[0].KingOnTable[i].KingThinking[k].TableListKing[j];
                                    {
                                        if ((new ChessRules(6, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                continue;
                                            }

                                        }
                                    }
                                    bool Hit = false;
                                    if (A[ii].MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 6, A[ii].KingOnTable[i].KingThinking[k].RowColumnKing[j][1], A[ii].KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, A[ii].MinisterOnTable[i].MinisterThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -6, A[ii].KingOnTable[i].KingThinking[k].RowColumnKing[j][1], A[ii].KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, A[ii].MinisterOnTable[i].MinisterThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = A[ii].KingOnTable[i].KingThinking[k].Row;
                                    FormRefrigtz.LastColumn = A[ii].KingOnTable[i].KingThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 6;
                                    Act = true;
                                    Less = A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + A[ii].KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                    Table = A[ii].KingOnTable[i].KingThinking[k].TableListKing[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }
            }
            if (Act)
                return Table;
            return null;
        }
        public void InitiateGenetic(int ii, int jj, Color a, int[,] Table, int Order, bool TB)
        {
            int Current = ChessRules.CurrentOrder;
            int DummyOrder = Order;
            ADraw.Clear();
            TableList.Clear();
            TableList.Add(Table);
            SetRowColumn(0);
            TableList.Clear();
            ThinkingChess.NotSolvedKingDanger = false;
            LoopHuristicIndex = 0;
            for (int i = 0; i < 1; i++)
            {
                if (Order == 1)
                {
                    THIS.SetBoxText("\r\nChess Genetic By Bob!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nChess Genetic By Alice!");
                    THIS.RefreshBoxText();

                }

                int[,] TablInit = new int[8, 8];
                if (Order == 1)
                    a = Color.Gray;
                else
                    a = Color.Brown;
                int In = 0;

                do
                {
                    if (Order == 1)
                        In = (new System.Random()).Next(0, 8);
                    else
                        In = (new System.Random()).Next(8, 16);
                } while (SolderesOnTable[In] == null);



                if (Order == 1)
                {
                    THIS.SetBoxText("\r\nGenetic Algorithm Begin Dept " + i.ToString() + " By Bob!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nGenetic Algirithm Begin Dept " + i.ToString() + " By Alice!");
                    THIS.RefreshBoxText();

                }
                ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                int[,] Tab = R.GenerateTable(TableListAction, 0, Order);
                if (Order == 1)
                {
                    THIS.SetBoxText("\r\nGenetic Algorithm Finsished Dept " + i.ToString() + " By Bob!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nGenetic Algirithm Finished Dept " + i.ToString() + " By Alice!");
                    THIS.RefreshBoxText();

                }


                if (Tab != null)
                {
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            TablInit[iii, jjj] = Tab[iii, jjj];
                        }
                    Table = new int[8, 8];
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            Table[iii, jjj] = TablInit[iii, jjj];
                        }
                    TableList.Add(TablInit);
                    ClList.Add(CL);
                    RWList.Add(RW);
                    KiList.Add(Ki);
                    // Order = Order * -1;
                    // ChessRules.CurrentOrder = Order;
                    Dept++;
                    //return;

                }
            }
            (new ChessRules(1, Table, Order)).Mate(Table, Order);


            Order = DummyOrder;
            ChessRules.CurrentOrder = Current;


        }
        public void InitiateDeptFirst(int iDept, int ii, int jj, Color a, int[,] Table, int Order, bool TB, ref Timer timer, ref Timer TimerColor)
        {
            timer.MidleDeptFirstTimer(iDept);
            //Mathematicall Formula for Calculation DeptFirstMaxLevel Not Work.
            int S = (timer.DeptiLevelMaxInitiate(TimerColor, iDept));
            if (S == 1)
                DeptiLevelMax += 1;
            else
                //have to Zero. Non Decreamet Algorithm not found.
                DeptiLevelMax = 0;

            if (iDept > DeptiLevelMax)
                return;
            int i = 0;
            if (Order == 1)
            {
                THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Bob!");
                THIS.RefreshBoxText();
            }
            else
            {
                THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Alice!");
                THIS.RefreshBoxText();
            }
            int[,] TablInit = new int[8, 8];
            if (Order == 1)
                a = Color.Gray;
            else
                a = Color.Brown;
            int In = 0;
            if (iDept == AllDraw.StoreADraw.Count)
            {
                DeptIndexVlue = Dept;
                do
                {
                    if (Order == 1)
                        In = (new System.Random()).Next(0, 8);
                    else
                        In = (new System.Random()).Next(8, 16);
                } while (SolderesOnTable[In] == null);

                this.InitiateForEveryKindThingHome(new AllDraw(ref THIS), SolderesOnTable[In].Row, SolderesOnTable[In].Column, a, Table, Order, false, In);
                Dept++;
            }
            else
            {

                AllDraw Dummy = new AllDraw(ref THIS);
                int j = 0;
                //for (int j = DeptIndexVlue; j < ADraw.Count; j++)
                {

                    if (Order == 1)
                    {
                        for (i = 0; i < AllDraw.SodierMidle; i++)
                        {
                            try
                            {
                                if (SolderesOnTable[i] == null)
                                    continue;

                                ii = SolderesOnTable[i].Row;
                                jj = SolderesOnTable[i].Column;
                                Table = SolderesOnTable[i].Table;
                                Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                                for (j = 0; j < AllDraw.SodierMovments; j++)
                                {
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingBegin = true;
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished = false;
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[j].Thinking));
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].t.Start();
                                    Wait(Dummy, i, j, 1);

                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.SolderesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        for (i = 0; i < AllDraw.ElefantMidle; i++)
                        {
                            try
                            {
                                if (ElephantOnTable[i] == null)
                                    continue;
                                ii = ElephantOnTable[i].Row;
                                jj = ElephantOnTable[i].Column;
                                Table = ElephantOnTable[i].Table;
                                Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                                for (j = 0; j < AllDraw.ElefantMovments; j++)
                                {
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingBegin = true;
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished = false;
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[j].Thinking));
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].t.Start();
                                    Wait(Dummy, i, j, 2);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.ElephantOnTable[i] = null;
                                Log(t);
                            }
                        }



                        for (i = 0; i < AllDraw.HourseMidle; i++)
                        {
                            try
                            {
                                if (HoursesOnTable[i] == null)
                                    continue;
                                ii = HoursesOnTable[i].Row;
                                jj = HoursesOnTable[i].Column;
                                Table = HoursesOnTable[i].Table;
                                Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.HourseMovments; j++)
                                {
                                    Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingBegin = true;
                                    Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingFinished = false;
                                    Dummy.HoursesOnTable[i].HourseThinking[j].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[j].Thinking));
                                    Dummy.HoursesOnTable[i].HourseThinking[j].t.Start();
                                    Wait(Dummy, i, j, 3);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.HoursesOnTable[i] = null;
                                Log(t);
                            }
                        }




                        for (i = 0; i < AllDraw.BridgeMidle; i++)
                        {
                            try
                            {
                                if (BridgesOnTable[i] == null)
                                    continue;
                                ii = BridgesOnTable[i].Row;
                                jj = BridgesOnTable[i].Column;
                                Table = BridgesOnTable[i].Table;
                                Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.BridgeMovments; j++)
                                {
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingBegin = true;
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished = false;
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[j].Thinking));
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].t.Start();
                                    Wait(Dummy, i, j, 4);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.BridgesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        for (i = 0; i < AllDraw.MinisterMidle; i++)
                        {
                            try
                            {
                                if (MinisterOnTable[i] == null)
                                    continue;
                                ii = MinisterOnTable[i].Row;
                                jj = MinisterOnTable[i].Column;
                                Table = MinisterOnTable[i].Table;
                                Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.MinisterMovments; j++)
                                {
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingBegin = true;
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished = false;
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[j].Thinking));
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].t.Start();
                                    Wait(Dummy, i, j, 5);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.MinisterOnTable[i] = null;
                                Log(t);
                            }
                        }


                        for (i = 0; i < AllDraw.KingMidle; i++)
                        {
                            try
                            {
                                if (KingOnTable[i] == null)
                                    continue;
                                ii = KingOnTable[i].Row;
                                jj = KingOnTable[i].Column;
                                Table = KingOnTable[i].Table;
                                Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.KingMovments; j++)
                                {
                                    Dummy.KingOnTable[i].KingThinking[j].ThinkingBegin = true;
                                    Dummy.KingOnTable[i].KingThinking[j].ThinkingFinished = false;
                                    Dummy.KingOnTable[i].KingThinking[j].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[j].Thinking));
                                    Dummy.KingOnTable[i].KingThinking[j].t.Start();
                                    Wait(Dummy, i, j, 6);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.KingOnTable[i] = null;
                                Log(t);
                            }
                        }
                    }
                    else
                    {
                        for (i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                        {
                            try
                            {
                                if (SolderesOnTable[i] == null)
                                    continue;
                                ii = SolderesOnTable[i].Row;
                                jj = SolderesOnTable[i].Column;
                                Table = SolderesOnTable[i].Table;
                                Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                                for (j = 0; j < AllDraw.SodierMovments; j++)
                                {
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingBegin = true;
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].ThinkingFinished = false;
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[j].Thinking));
                                    Dummy.SolderesOnTable[i].SoldierThinking[j].t.Start();
                                    Wait(Dummy, i, j, 1);

                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.SolderesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        for (i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                        {
                            try
                            {
                                if (ElephantOnTable[i] == null)
                                    continue;
                                ii = ElephantOnTable[i].Row;
                                jj = ElephantOnTable[i].Column;
                                Table = ElephantOnTable[i].Table;
                                Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                                for (j = 0; j < AllDraw.ElefantMovments; j++)
                                {
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingBegin = true;
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].ThinkingFinished = false;
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[j].Thinking));
                                    Dummy.ElephantOnTable[i].ElefantThinking[j].t.Start();
                                    Wait(Dummy, i, j, 2);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.ElephantOnTable[i] = null;
                                Log(t);
                            }
                        }



                        for (i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                        {
                            try
                            {
                                if (HoursesOnTable[i] == null)
                                    continue;
                                ii = HoursesOnTable[i].Row;
                                jj = HoursesOnTable[i].Column;
                                Table = HoursesOnTable[i].Table;
                                Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.HourseMovments; j++)
                                {
                                    Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingBegin = true;
                                    Dummy.HoursesOnTable[i].HourseThinking[j].ThinkingFinished = false;
                                    Dummy.HoursesOnTable[i].HourseThinking[j].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[j].Thinking));
                                    Dummy.HoursesOnTable[i].HourseThinking[j].t.Start();
                                    Wait(Dummy, i, j, 3);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.HoursesOnTable[i] = null;
                                Log(t);
                            }
                        }




                        for (i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                        {
                            try
                            {
                                if (BridgesOnTable[i] == null)
                                    continue;
                                ii = BridgesOnTable[i].Row;
                                jj = BridgesOnTable[i].Column;
                                Table = BridgesOnTable[i].Table;
                                Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.BridgeMovments; j++)
                                {
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingBegin = true;
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].ThinkingFinished = false;
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[j].Thinking));
                                    Dummy.BridgesOnTable[i].BridgeThinking[j].t.Start();
                                    Wait(Dummy, i, j, 4);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.BridgesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        for (i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                        {
                            try
                            {
                                if (MinisterOnTable[i] == null)
                                    continue;
                                ii = MinisterOnTable[i].Row;
                                jj = MinisterOnTable[i].Column;
                                Table = MinisterOnTable[i].Table;
                                Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.MinisterMovments; j++)
                                {
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingBegin = true;
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].ThinkingFinished = false;
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[j].Thinking));
                                    Dummy.MinisterOnTable[i].MinisterThinking[j].t.Start();
                                    Wait(Dummy, i, j, 5);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.MinisterOnTable[i] = null;
                                Log(t);
                            }
                        }


                        for (i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                        {
                            try
                            {
                                if (KingOnTable[i] == null)
                                    continue;
                                ii = KingOnTable[i].Row;
                                jj = KingOnTable[i].Column;
                                Table = KingOnTable[i].Table;
                                Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                                for (j = 0; j < AllDraw.KingMovments; j++)
                                {
                                    Dummy.KingOnTable[i].KingThinking[j].ThinkingBegin = true;
                                    Dummy.KingOnTable[i].KingThinking[j].ThinkingFinished = false;
                                    Dummy.KingOnTable[i].KingThinking[j].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[j].Thinking));
                                    Dummy.KingOnTable[i].KingThinking[j].t.Start();
                                    Wait(Dummy, i, j, 6);
                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.KingOnTable[i] = null;
                                Log(t);
                            }
                        }
                    }
                }
                AllDraw AdumnmyConstructed = this.CopyRemeiningItems(Dummy, Order);
                if (ADraw != null)
                    ADraw = new List<AllDraw>();
                else
                    ADraw.Clear();
                ADraw.Add(AdumnmyConstructed);
                DeptIndexVlue = Dept;
                Dept++;


            }
            if (Order == 1)
                a = Color.Gray;
            else
                a = Color.Brown;
            int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
            ChessRules.CurrentOrder *= -1;
            if (Order * -1 == 1)
                a = Color.Gray;
            else
                a = Color.Brown;

            ADraw[0].InitiateDeptFirst(++iDept, ii, jj, a, Taba, Order * -1, false, ref timer, ref TimerColor);
        }
        public int[,] HuristicCurrentTable(AllDraw ADra, Color a, int Order)
        {
            AllDraw.SyntaxToWrite = "";
            int[,] Tab = new int[8, 8];
            List<AllDraw> Ad = new List<AllDraw>();
            Ad.Add(ADra);
            double Less = -200000;


            Tab = this.HuristicDeptSearch(Ad, a, ref Less, Order, true);
            if (Tab != null)
            {
                //When Current Table Found.
                TableCurrent.Add(Tab);
                for (int i = 0; i < SodierHigh; i++)
                    try
                    {
                        SolderesOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < ElefantHigh; i++)
                    try
                    {
                        ElephantOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < HourseHight; i++)
                    try
                    {
                        HoursesOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < BridgeHigh; i++)
                    try
                    {
                        BridgesOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < MinisterHigh; i++)
                    try
                    {
                        MinisterOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < KingHigh; i++)
                    try
                    {
                        KingOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
            }

            THIS.SetBoxText("\r\nCurrent Table Syntax:" + AllDraw.SyntaxToWrite);
            THIS.RefreshBoxText();
            return Tab;

        }
        public AllDraw CopyRemeiningItems(AllDraw ADummy, int Order)
        {
            AllDraw Dummy = new AllDraw(ref THIS);
            Dummy.SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
            Dummy.ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
            Dummy.HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
            Dummy.BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
            Dummy.MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
            Dummy.KingOnTable = new DrawKing[AllDraw.KingHigh];
            for (int i = 0; i < AllDraw.SodierHigh; i++)
            {
                try
                {
                    Dummy.SolderesOnTable[i] = new DrawSoldier(ADummy.SolderesOnTable[i].Row, ADummy.SolderesOnTable[i].Column, ADummy.SolderesOnTable[i].color, ADummy.SolderesOnTable[i].Table, ADummy.SolderesOnTable[i].Order, false, ADummy.SolderesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.ElefantHigh; i++)
            {
                try
                {
                    Dummy.ElephantOnTable[i] = new DrawElefant(ADummy.ElephantOnTable[i].Row, ADummy.ElephantOnTable[i].Column, ADummy.ElephantOnTable[i].color, ADummy.ElephantOnTable[i].Table, ADummy.ElephantOnTable[i].Order, false, ADummy.ElephantOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.HourseHight; i++)
            {
                try
                {
                    Dummy.HoursesOnTable[i] = new DrawHourse(ADummy.HoursesOnTable[i].Row, ADummy.HoursesOnTable[i].Column, ADummy.HoursesOnTable[i].color, ADummy.HoursesOnTable[i].Table, ADummy.HoursesOnTable[i].Order, false, ADummy.HoursesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.BridgeHigh; i++)
            {
                try
                {
                    Dummy.BridgesOnTable[i] = new DrawBridge(ADummy.BridgesOnTable[i].Row, ADummy.BridgesOnTable[i].Column, ADummy.BridgesOnTable[i].color, ADummy.BridgesOnTable[i].Table, ADummy.BridgesOnTable[i].Order, false, ADummy.BridgesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.MinisterHigh; i++)
            {
                try
                {
                    Dummy.MinisterOnTable[i] = new DrawMinister(ADummy.MinisterOnTable[i].Row, ADummy.MinisterOnTable[i].Column, ADummy.MinisterOnTable[i].color, ADummy.MinisterOnTable[i].Table, ADummy.MinisterOnTable[i].Order, false, ADummy.MinisterOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.KingHigh; i++)
            {
                try
                {
                    Dummy.KingOnTable[i] = new DrawKing(ADummy.KingOnTable[i].Row, ADummy.KingOnTable[i].Column, ADummy.KingOnTable[i].color, ADummy.KingOnTable[i].Table, ADummy.KingOnTable[i].Order, false, ADummy.KingOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            if (Order == 1)
            {
                for (int i = 0; i < AllDraw.SodierMidle; i++)
                {
                    try
                    {
                        ADummy.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i]);
                    }
                    catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        this.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i]);
                    }
                    catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.ElefantMidle; i++)
                {
                    try
                    {

                        ADummy.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i]);
                    }
                    catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {

                        this.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i]);
                    }
                    catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                }
                for (int i = 0; i < AllDraw.HourseMidle; i++)
                {
                    try
                    {

                        ADummy.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i]);
                    }
                    catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        this.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i]);
                    }
                    catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.BridgeMidle; i++)
                {
                    try
                    {

                        ADummy.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i]);
                    }
                    catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {

                        this.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i]);
                    }
                    catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                }
                for (int i = 0; i < AllDraw.MinisterMidle; i++)
                {
                    try
                    {


                        ADummy.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i]);
                    }
                    catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {

                        this.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i]);
                    }
                    catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.KingMidle; i++)
                {
                    try
                    {

                        ADummy.KingOnTable[i].Clone(ref Dummy.KingOnTable[i]);
                    }
                    catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                }

                for (int i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                {
                    try
                    {

                        this.KingOnTable[i].Clone(ref Dummy.KingOnTable[i]);
                    }
                    catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        Dummy.SolderesOnTable[i].Table = ADummy.SolderesOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {
                        Dummy.ElephantOnTable[i].Table = ADummy.ElephantOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        Dummy.HoursesOnTable[i].Table = ADummy.HoursesOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {
                        Dummy.BridgesOnTable[i].Table = ADummy.BridgesOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {
                        Dummy.MinisterOnTable[i].Table = ADummy.MinisterOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.KingHigh; i++)
                {
                    try
                    {
                        Dummy.KingOnTable[i].Table = ADummy.KingOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }

            }
            else
            {
                {
                    for (int i = 0; i < AllDraw.SodierMidle; i++)
                    {
                        try
                        {
                            this.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i]);
                        }
                        catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                    {
                        try
                        {
                            ADummy.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i]);
                        }
                        catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.ElefantMidle; i++)
                    {
                        try
                        {

                            this.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i]);
                        }
                        catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                    {
                        try
                        {

                            ADummy.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i]);
                        }
                        catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.HourseMidle; i++)
                    {
                        try
                        {

                            this.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i]);
                        }
                        catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                    {
                        try
                        {
                            ADummy.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i]);
                        }
                        catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                    }

                    for (int i = 0; i < AllDraw.BridgeMidle; i++)
                    {
                        try
                        {

                            this.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i]);
                        }
                        catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.BridgeMidle; i < AllDraw.BridgeMidle; i++)
                    {
                        try
                        {

                            ADummy.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i]);
                        }
                        catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.MinisterMidle; i++)
                    {
                        try
                        {


                            this.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i]);
                        }
                        catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                    {
                        try
                        {

                            ADummy.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i]);
                        }
                        catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                    }

                    for (int i = 0; i < AllDraw.KingMidle; i++)
                    {
                        try
                        {


                            this.KingOnTable[i].Clone(ref Dummy.KingOnTable[i]);
                        }
                        catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                    }

                    for (int i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                    {
                        try
                        {

                            ADummy.KingOnTable[i].Clone(ref Dummy.KingOnTable[i]);
                        }
                        catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.SodierHigh; i++)
                    {
                        try
                        {
                            Dummy.SolderesOnTable[i].Table = ADummy.SolderesOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.ElefantHigh; i++)
                    {
                        try
                        {
                            Dummy.ElephantOnTable[i].Table = ADummy.ElephantOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.HourseHight; i++)
                    {
                        try
                        {
                            Dummy.HoursesOnTable[i].Table = ADummy.HoursesOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.BridgeHigh; i++)
                    {
                        try
                        {
                            Dummy.BridgesOnTable[i].Table = ADummy.BridgesOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.MinisterHigh; i++)
                    {
                        try
                        {
                            Dummy.MinisterOnTable[i].Table = ADummy.MinisterOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.KingHigh; i++)
                    {
                        try
                        {
                            Dummy.KingOnTable[i].Table = ADummy.KingOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }

                }
            }

            return Dummy;


        }


        public void RecoonstructADraw(ref List<AllDraw> ADrawAll)
        {
            if (ADraw.Count == 0)
                return;
            ADrawAll.Add(this.ADraw[0]);
            ADraw[0].RecoonstructADraw(ref ADrawAll);
        }
        public void Initiate(int ii, int jj, Color a, int[,] Table, int Order, bool TB, ref Timer timer, ref Timer TimerColor)
        {
            ChessRules.KishBrownAchmazFirstTimesOcured = false;
            ChessRules.KishGrayAchmazFirstTimesOcured = false;
            int Current = ChessRules.CurrentOrder;
            int DummyOrder = Order;

            if (!AllDraw.DeptFirstSearch)
            {
                AllDraw.StoreADraw.Clear();
                int[,] Tab = null;
                int[,] TablInit = null;

                ADraw.Clear();
                TableList.Clear();
                TableList.Add(Table);
                SetRowColumn(0);
                TableList.Clear();
                ThinkingChess.NotSolvedKingDanger = false;
                LoopHuristicIndex = 0;
                for (int i = 0; i < 1; i++)
                {
                    if (Order == 1)
                    {
                        THIS.SetBoxText("\r\nChess Thinking Dept " + i.ToString() + " By Bob!");
                        THIS.RefreshBoxText();
                    }
                    else
                    {
                        THIS.SetBoxText("\r\nChess Thinking Dept " + i.ToString() + " By Alice!");
                        THIS.RefreshBoxText();

                    }

                    TablInit = new int[8, 8];
                    if (Order == 1)
                        a = Color.Gray;
                    else
                        a = Color.Brown;
                    int In = 0;

                    do
                    {
                        if (Order == 1)
                            In = (new System.Random()).Next(0, 8);
                        else
                            In = (new System.Random()).Next(8, 16);
                    } while (SolderesOnTable[In] == null);

                    this.InitiateForEveryKindThingHome(new AllDraw(ref THIS), SolderesOnTable[In].Row, SolderesOnTable[In].Column, a, Table, Order, false, In);

                    double Less = -2000000;

                    if (ADraw.Count > 0)
                    {
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + i.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + i.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                        Tab = Huristic(ADraw, a, i, ref Less, Order);
                    }
                    /*if(Tab!=null)
                       if ((new ChessRules(Ki, Tab, Order)).AchmazKingMove(Order,Tab))
                       {
                           A.RemoveAt(i);
                           i--;
                           continue;
                       }*/
                    if (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                    {
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nGenetic Algorithm Begin Dept " + i.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nGenetic Algirithm Begin Dept " + i.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                        ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                        Tab = R.GenerateTable(TableListAction, LoopHuristicIndex, Order);
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nGenetic Algorithm Finsished Dept " + i.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nGenetic Algirithm Finished Dept " + i.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                    }

                    if (Tab != null)
                    {
                        for (int iii = 0; iii < 8; iii++)
                            for (int jjj = 0; jjj < 8; jjj++)
                            {
                                TablInit[iii, jjj] = Tab[iii, jjj];
                            }
                        TableList.Add(TablInit);
                        ClList.Add(CL);
                        RWList.Add(RW);
                        KiList.Add(Ki);
                        // Order = Order * -1;
                        // ChessRules.CurrentOrder = Order;
                        Dept++;
                        //return;

                    }
                }


                Order = DummyOrder;
                ChessRules.CurrentOrder = Current;
                return;
            }
            else
            {
                TableList.Clear();
                int[,] Tab = null;
                int[,] TablInit = null;

                AllDraw.DeptiLevelMax = 2;
                if (THISDummy == null)
                    THISDummy = new FormRefrigtz(true);
                else
                {
                    THISDummy.accessDraw.ADraw.Clear();
                    THISDummy.accessDraw.TableList.Clear();
                }
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        THISDummy.Table[i, j] = Table[i, j];
                    }
                THISDummy.accessDraw.TableList.Add(THISDummy.Table);
                THISDummy.accessDraw.SetRowColumn(0);
                this.Clone(THISDummy.accessDraw);


                THISDummy.accessDraw.THIS = this.THIS;
                DeptIndexVlue = 0;
                ThinkingChess.NotSolvedKingDanger = false;
                LoopHuristicIndex = 0;
                if (CurrentTable == null)
                    CurrentTable = new int[8, 8];
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        CurrentTable[i, j] = Table[i, j];
                    }
                int Order1 = Order;
                Color color = a;
                //Found of Last Movments.(+)
                if (AllDraw.StoreADraw.Count > 0 && DynamicDeptFirstPrograming)
                {
                    //At First Level.(Second Call)(LevelDeptFirstDynamic=1)
                    //Current Movments at this level is StoreADraw[1].(+)
                    //Last Movments is StoreADraw[StoreAdraw.Count-1].(+)
                    //Begining Order Calculation from StoreADRaw[2].(+)
                    //At Second Level.(ThirdCall)(LevelDeptFirstDynamic=2)
                    //Current Movments at this level is StoreADraw[2]
                    //Last Movments is StoreADraw[StoreAdraw.Count-1].(+)
                    //Begining Ordr Calculation from StoreADraw[3].
                    for (int i = 1 + LevelDeptFirsDynamic; i < AllDraw.StoreADraw.Count; i++)
                    {
                        Order1 *= -1;
                        if (Order1 == 1)
                            color = Color.Gray;
                        else
                            color = Color.Brown;
                    }
                    //Calculation Last Table Huristic.(+)
                    //Some times Current Table become null. Breaking of 'Long Game'.
                    CurrentTable = HuristicCurrentTable(AllDraw.StoreADraw[AllDraw.StoreADraw.Count - 1], color, Order1);
                    //For Next of Last Table Huristic!(+)
                    Order = Order1 * -1;

                    Dept = AllDraw.StoreADraw.Count;
                    DeptiLevelMax = 2 + Dept;
                    ChessRules.CurrentOrder = Order;
                    LevelDeptFirsDynamic++;
                    if (Order == 1)
                        a = Color.Gray;
                    else
                        a = Color.Brown;
                }
                if (StoreADraw.Count == 0)
                    timer.SetDeptFirstTimer();
                //Construction of Last StoreADraw[StoreADraw.Count-1] at THISDummy.accessDraw.(+)
                if (AllDraw.StoreADraw.Count > 0 && DynamicDeptFirstPrograming && CurrentTable != null)
                {
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                        {
                            THISDummy.Table[i, j] = CurrentTable[i, j];
                        }
                    THISDummy.accessDraw.TableList.Clear();
                    THISDummy.accessDraw.TableList.Add(THISDummy.Table);
                    THISDummy.accessDraw.SetRowColumn(0);

                }
                else
                {
                    if (DynamicDeptFirstPrograming && CurrentTable == null)
                    {
                        AllDraw.StoreADraw.Clear();
                        LevelDeptFirsDynamic = 1;
                        AllDraw.DeptiLevelMax = 2;
                        if (THISDummy == null)
                            THISDummy = new FormRefrigtz(true);
                        else
                        {
                            THISDummy.accessDraw.ADraw.Clear();
                            THISDummy.accessDraw.TableList.Clear();
                        }
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                            {
                                THISDummy.Table[i, j] = Table[i, j];
                            }
                        THISDummy.accessDraw.TableList.Add(THISDummy.Table);
                        THISDummy.accessDraw.SetRowColumn(0);
                        this.Clone(THISDummy.accessDraw);
                        Dept = 0;
                        CurrentTable = new int[8, 8];
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                            {
                                CurrentTable[i, j] = Table[i, j];
                            }
                        Order = DummyOrder;
                        ChessRules.CurrentOrder = Current;
                        LastDynamicNotFound = true;


                    }
                }
                //Calculation of Remaining Items.(+)              
                THISDummy.accessDraw.InitiateDeptFirst(Dept, ii, jj, a, CurrentTable, Order, false, ref timer, ref TimerColor);

                double Less = -2000000;
                List<AllDraw> Ad = new List<AllDraw>();

                THISDummy.accessDraw.RecoonstructADraw(ref Ad);
                THISDummy.accessDraw.ADraw.Clear();
                //Copy Constructed Ad.(+)
                //Current Ad[0] is Next of Last StoreADraw[StoreADraw.Count-1].(+)
                for (int i = 0; i < Ad.Count; i++)
                    THISDummy.accessDraw.ADraw.Add(Ad[i]);
                //Adding Found to StoreDraw.(+)
                if (DynamicDeptFirstPrograming)
                {
                    for (int i = 0; i < THISDummy.accessDraw.ADraw.Count; i++)
                        AllDraw.StoreADraw.Add(THISDummy.accessDraw.ADraw[i]);
                }
                //Constructed Multiple ADraw.(+)
                if (AllDraw.StoreADraw.Count > 0 && DynamicDeptFirstPrograming)
                {
                    THISDummy.accessDraw.ADraw.Clear();//(At First Call LevelDeptFirsDynamic=1) Add Fromm StroeAllDraw[0]

                    //(At Second Call LevelDeptFirstDynamic=2) Add From StoreADraw[1].
                    //Copy Founded Items in order to find Huristic.(_)
                    for (int i = LevelDeptFirsDynamic - 1; i < AllDraw.StoreADraw.Count; i++)
                        THISDummy.accessDraw.ADraw.Add(AllDraw.StoreADraw[i]);
                    //Remove Last Movments of Current Table!
                    try
                    {
                        TableCurrent.RemoveAt(0);
                    }
                    catch (Exception t)
                    {
                        Log(t);
                    }

                }
                Order = DummyOrder;
                ChessRules.CurrentOrder = Current;
                if (Order == 1)
                    a = Color.Gray;
                else
                    a = Color.Brown;




                Tab = THISDummy.accessDraw.HuristicDeptSearch(THISDummy.accessDraw.ADraw, a, ref Less, Order, false);

                TableList.Clear();
                if (Tab != null)
                {
                    LastDynamicNotFound = false;
                    THISDummy.Dispose();
                    if (THISDummy.accessDraw.ADraw.Count > 0)
                    {
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + Dept.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + Dept.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                        TablInit = new int[8, 8];
                        Less = -2000000;



                        Order = DummyOrder;
                        ChessRules.CurrentOrder = Current;

                        if (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                        {
                            if (Order == 1)
                            {
                                THIS.SetBoxText("\r\nGenetic Algorithm Begin Dept 0 By Bob!");
                                THIS.RefreshBoxText();
                            }
                            else
                            {
                                THIS.SetBoxText("\r\nGenetic Algirithm Begin Dept 0 By Alice!");
                                THIS.RefreshBoxText();

                            }
                            ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                            Tab = R.GenerateTable(TableListAction, LoopHuristicIndex, Order);
                            if (Tab != null)
                                AllDraw.TableCurrent.Add(Tab);
                            if (Order == 1)
                            {
                                THIS.SetBoxText("\r\nGenetic Algorithm Finsished Dept 0 By Bob!");
                                THIS.RefreshBoxText();
                            }
                            else
                            {
                                THIS.SetBoxText("\r\nGenetic Algirithm Finished Dept 0 By Alice!");
                                THIS.RefreshBoxText();

                            }
                        }
                        if (Tab != null)
                        {
                            for (int iii = 0; iii < 8; iii++)
                                for (int jjj = 0; jjj < 8; jjj++)
                                {
                                    TablInit[iii, jjj] = Tab[iii, jjj];
                                }
                            TableList.Clear();
                            TableList.Add(TablInit);
                            Dept++;


                            Order = DummyOrder;
                            ChessRules.CurrentOrder = Current;
                            try
                            {
                                ChessRules.CurrentOrder = Current;
                                ChessGeneticAlgorithm RR = new ChessGeneticAlgorithm();
                                if (RR.FindGenToModified(AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Tab, AllDraw.TableListAction, 0, Order, true))
                                {
                                    bool HitVal = false;
                                    int Hit = AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRow, RR.CromosomColumn];
                                    if (Hit != 0)
                                        HitVal = true;
                                    bool Convert = false;
                                    if (Order == 1)
                                    {
                                        if (Tab[RR.CromosomRow, RR.CromosomColumn] == 1)
                                        {
                                            if (RR.CromosomColumn == 7)
                                                Convert = true;
                                        }
                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRowFirst, RR.CromosomColumnFirst], RR.CromosomColumn, RR.CromosomRow, HitVal, Hit, ChessRules.BridgeActGray, Convert);
                                    }
                                    else
                                    {
                                        if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRowFirst, RR.CromosomColumnFirst] == -1)
                                        {
                                            if (RR.CromosomColumn == 0)
                                                Convert = true;
                                        }
                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRowFirst, RR.CromosomColumnFirst], RR.CromosomColumn, RR.CromosomRow, HitVal, Hit, ChessRules.BridgeActBrown, Convert);
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException t)
                            {
                                Log(t);
                            }
                        }
                        else
                        {
                            AllDraw.StoreADraw.Clear();
                            LevelDeptFirsDynamic = 1;
                            TableCurrent.Clear();
                            Dept = 0;
                        }
                    }
                }
                else
                {
                    AllDraw.StoreADraw.Clear();
                    LevelDeptFirsDynamic = 1;
                    TableCurrent.Clear();
                    Dept = 0;
                }
                Order = DummyOrder;
                ChessRules.CurrentOrder = Current;

                return;
            }

        }
        public bool isEnemyThingsinStable(int[,] TableHuristic, int[,] TableAction, int Order)
        {
            int[,] Cromosom1 = TableHuristic;
            int[,] Cromosom2 = TableAction;
            bool and = true;
            /* if (!LastDynamicNotFound)
             {
                 for (int i = 0; i < 8; i++)
                     for (int j = 0; j < 8; j++)
                     {
                         if (Order == 1)
                         {
                             if (TableHuristic[i, j] > 0)
                             {
                                 if (TableHuristic[i, j] != TableAction[i, j])
                                     return false; ;
                             }




                         }
                         else
                             if (Order == -1)
                             {
                                 if (TableHuristic[i, j] < 0)
                                 {
                                     if (TableHuristic[i, j] != TableAction[i, j])
                                         return false; ;
                                 }

                             }
                     }
             }*/
            bool Find = false;
            bool Hit = false;
            int FindNumber = 0;
            int CromosomRowFirst = -1, CromosomColumnFirst = -1, CromosomRow = -1, CromosomColumn = -1;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (Order == 1)
                    {

                        if (and)
                        {
                            if (Cromosom1[i, j] < 0 && Cromosom2[i, j] < 0)
                                continue;
                        }
                        else
                        {
                            if (Cromosom1[i, j] < 0 || Cromosom2[i, j] < 0)
                                continue;
                        }
                    }
                    else
                    {
                        if (and)
                        {
                            if (Cromosom1[i, j] > 0 && Cromosom2[i, j] > 0)
                                continue;

                        }
                        else
                        {
                            if (Cromosom1[i, j] > 0 || Cromosom2[i, j] > 0)
                                continue;
                        }
                    }
                    if (Order == 1)
                    {
                        if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] > 0 && Cromosom2[i, j] == 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Gray, 1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] == 0 && Cromosom2[i, j] > 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(CromosomRow, CromosomColumn, i, j, Color.Gray, 1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] > 0 && Cromosom2[i, j] < 0))
                        {
                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Gray, 1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }
                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j])
                        {
                            CromosomRow = i;
                            CromosomColumn = j;
                            FindNumber++;
                        }
                    }
                    else
                    {
                        if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] < 0 && Cromosom2[i, j] == 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Brown, -1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] == 0 && Cromosom2[i, j] < 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(CromosomRow, CromosomColumn, i, j, Color.Brown, -1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        } else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] < 0 && Cromosom2[i, j] > 0))
                        {
                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Brown, -1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }
                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                FindNumber++;
                            }
                        }

                        else if (Cromosom1[i, j] != Cromosom2[i, j])
                        {
                            CromosomRow = i;
                            CromosomColumn = j;
                            FindNumber++;
                        }
                    }
                }
            }
            if (FindNumber == 1 && Find)
                return true;
            if (FindNumber == 2 && Find)
                return true;
            
            return false;

        }
    }
}

