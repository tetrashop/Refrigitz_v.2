﻿/*************************************************************************************************
 * Using Genetic Algorithm to produce new movment of repitativeloop conditions.*******************
 * *********************************************************************************************** 
 * Ramin Edjlal***********************************************************************************
 * The Loop Genetic Mechanism Stop Working********************************************************(+)
 * Table List Genetic Loop Huristic Stop Working**************************************************(+)
 * Program Stop Working***************************************************************************(+)
 * IndexOutOfBout Exeption************************************************************************(+)
 * Genetic Algorithm Order Misleading*************************************************************(+)
 * Genetic Order Misleading.**********************************************************************(+)
 * Genetic Algorithm Failed by Adding Some New Things*********************************************(+)
 * The Chess Sometimes Gone to Null Chromosome Row and Column*************************************(+)
 * Genetic Looping Algorithm**********************************************************************(+)
 * Genetic Algorithm Disabled Functions.**********************************************************(+)
 * Genetic Algorithm Misleading Movements By Alice.***********************************************(+)
 * Genetic Algorithm Misleading by Fault Movement By Alice.***************************************(+)
 * Genetic Algorithm could not find a Movements at Else of FindRowColumn Method By Bob.***********(+)
 * Genetic Algorithm Not Work. Infinity Loop Due to Order By Bob.*********************************(+)
 * Genetic Algorithm To Misleading Movements of Bob and Alice.************************************(+)
 * Genetic Algorithm is legal but misleading By Alice.********************************************(+)
 * Genetic Algorithm Order MalFunction.***********************************************************(+)
 * Genetic Algorithm Rules MalFunction.***********************************************************(+)
 * Malfunction of Brown Order (Alice).No Chess Rules Identification By Genetic Algorithm**********(+)
 * Genetic Algorithm MalFunction.*****************************************************************(+)
 * No Logical Reason For Malfunction of NonRulements of Genetic Algorithm.************************(+)
 * No Logical Reason for Malfunction of Bob Soldier Attack Movements to go non enemy.*************(+)
 * 1395/1/3***************************************************************************************(+:Sum(22))
 * Metric After Retrieve to Customer.*************************************************************
 * 530 Error To Attempt Convert Chess rules and Thinking Chess to dll.****************************
 * DRE=E/(E+D)=155[163]/(155[163]+530)=155[163]/685[693]=0.226[0.23]******************************
 * DRE2=E1/(E1+E2)=155[163]/(155[163]+4[6])=0.97[0.96]********************************************
 * DRE3=E2/(E2+E3)=6/(6+4)=0.6********************************************************************
 * DRE4=E2/(E2+E3)=[6]/(6+11)=[0.35]**************************************************************
 * DRE5=E3/(E3+E4)=[11]/(11+7)=[0.61](For Level 1 of Learning Autamat:E4)*************************
 * Is=[(S-Sw)/(Sb-Sw)]*100=[([2.75]-[0.23])/(0.97-[0.23])]*100=([2.52]/[0.74])*100=[340.5]********
 * S=DRE+DRE2+DRE3+DRE4+DRE5=2.816****************************************************************
 * Sb=0.97****************************************************************************************
 * Sw=[0.23]**************************************************************************************
 * The Level of Calculating are Successful state of Execution program results.********************
 * DRE6=E4/(E4+E5)=([7]/(7+5))=[0.58]*************************************************************
 * S2=S1+DRE6=[2.75]+[0.58]=[4.74]****************************************************************
 * Sb2=0.97***************************************************************************************
 * Sw2=[0.23]*************************************************************************************
 * Is2=[(S2-Sw2)/(Sb2-Sw2)]=[([4.74]-[0.23])/(0.97-[0.23])]*100=[4.51]/[0.74]=6.09*100=609********
 * Imp=[Is1-Is2]=340.5-609=-248.5*****************************************************************
 * DRE7=E5/(E5+E6)=5/(5+8)=0.38*******************************************************************
 * S3=S2+DRE7=4.74+0.38=5.12**********************************************************************
 * Is3=[(S3-Sw3)/(Sb3-Sw3)]*100=[(5.12-0.23)/(0.97-0.23)]*100=[4.89/0.74]*100=660.81**************
 * Sw3=0.23***************************************************************************************
 * Sb3=0.97***************************************************************************************
 * Imp2=[Is2-Is3]=[609-660.81]=-51.81************************************************************
 * DRE8=E6/(E6+E7)=8/(8+3)=0.72*******************************************************************
 * S4=S3+DRE8=5.12+0.72=5.84**********************************************************************
 * Is4=[(S4-Sw4)/(Sb4-Sw4)]*100=[(5.84-0.23)/(0.97-0.23)]*100=[5.61/0.74]*100=758.1***************
 * Ipm3=[Is3-Is4]=660-758.1=-98.1*****************************************************************
 * DRE9=E7/(E7+E8)=3/(3+2)=0.6********************************************************************
 * S5=S4+DRE9=5.84+0.6=6.44***********************************************************************
 * Is5=[(S5-Sw5)/(Sb5-Sw5)]*100=[(6.44-0.23)/(0.97-0.23)]*100=[6.21/0.74]*100=839.18**************
 * Imp4=[Is4-Is5]=[758-839.18]*100=-81.18*********************************************************
 * DRE10=E8/(E8+E9)=2/(2+4)=0.34******************************************************************
 * S6=S5+DRE10=6.44+0.34=6.78*********************************************************************
 * Is6=[(S6-Sw6)/(Sb6-Sw6)]*100=[(6.78-0.23)/(0.97-0.23)]*100=[6.55/0.74]*100=885.13**************
 * Imp5=[Is5-Is6]=839.18-885.13=-45.95************************************************************
 * DRE11=E9/(E9+E10)=4/(4+7)=0.36*****************************************************************
 * S7=S6+DRE11=6.78+0.44=7.14*********************************************************************
 * Is7=[(S7-Sw7)/(Sb7-Sw7)]*100=[(7.14-0.23)/(0.97-0.23]*100=[6.91/0.74]*100=933.78***************
 * Imp6=[Is6-Is7]=[885.13-933.78]=-48.65**********************************************************
 * DRE12=E10/(E10+E11)=7/(7+51)=0.12**************************************************************
 * S8=S7+DRE12=7.14+0.12=7.26*********************************************************************
 * Is8=[(S8-Sw8)/(Sb8-Sw8)]*100=[(7.26-0.12)/(0.97-0.12)]*100=[7.14/0.85]*100=840*****************
 * Sw8=0.12***************************************************************************************
 * Sb8=0.97***************************************************************************************
 * Imp7=[Is7-Is8]=[933.78-840]=93.78**************************************************************
 * DRE13=E11/(E11+E12))=51/(51+4)=0.92************************************************************
 * S9=S8+DRE13=7.26+0.92=8.18*********************************************************************
 * Is9=[(S9-Sw9)/(Sb9-Sw9)]*100=[(8.18-0.12)/(0.97-0.12]*100=[8.06/0.85]*100=948.23***************
 * Imp8=[Is8-Is9]=[840-948.23]=-107.77************************************************************
 * DRE14=E12+(E12+E13)=4/(4+4)=0.5****************************************************************
 * S10=S9+DRE14=8.18+0.5=8.68*********************************************************************
 * Is10=[S10-Sw10)/(Sb10-Sw10)]*100==[(8.86-0.12)/(0.97-0.12)]*100=[8.74/0.85]*100=1028.23********
 * Imp9=[Is9-Is10]=[948.23-1028.23]=-80***********************************************************
 * DRE15=E13/(E13+E14)=4/(4+10)=0.28**************************************************************
 * S11=S10+DRE15=8.86+0.28=9.14*******************************************************************
 * Is11=[(S11-Sw11)/(Sb11-Sw11)]*100=[(9.14-0.12)/(0.97-0.12)]*100=[9.02/0.85]*100=1061.17********
 * Imp10=[Is10-Is11]=[1028.23-1061.17]=-32.94*****************************************************
 * ***********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{

    class ChessGeneticAlgorithm
    {
        public static bool NoGameFounf = false;
        List<int[]> RowColumn = new List<int[]>();
        int Ki = 0;
        public int CromosomRow = -1, CromosomColumn = -1;
        public int CromosomRowFirst = -1, CromosomColumnFirst = -1;
        int Gen1 = 0, Gen2 = 0;
        int[,] GeneticTable = new int[8, 8];
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
        public ChessGeneticAlgorithm()
        {

            RowColumn.Clear();
        }
        public bool FindGenToModified(int[,] Cromosom1, int[,] Cromosom2, List<int[,]> List, int Index, int Order,bool and)
        {
            bool Find = false;
            int FindNumber = 0;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (Order == 1)
                    {

                        if (and)
                        {
                            if (Cromosom1[i, j] < 0 && Cromosom2[i, j] < 0)
                                continue;
                        }
                        else
                        {
                            if (Cromosom1[i, j] < 0 || Cromosom2[i, j] < 0)
                                continue;
                        }
                    }
                    else
                    {
                        if (and)
                        {
                            if (Cromosom1[i, j] > 0 && Cromosom2[i, j] > 0)
                                continue;

                        }
                        else
                        {
                            if (Cromosom1[i, j] > 0 || Cromosom2[i, j] > 0)
                                continue;
                        }
                    }
                    if (Cromosom1[i, j] != Cromosom2[i, j])
                    {
                        if (Cromosom2[i, j] == 0)
                        {
                            CromosomRowFirst = i;
                            CromosomColumnFirst = j;
                            continue;
                        }
                        else
                        {
                            if (and)
                            {
                                if (Cromosom1[i, j] == 0)
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                    Ki = List[Index][CromosomRow, CromosomColumn];
                                    continue;
                                }
                            }

                        }

                        CromosomRow = i;
                        CromosomColumn = j;
                        Find = true;
                        FindNumber++;
                        Ki = List[Index][CromosomRow, CromosomColumn];

                    }


                }
            }
            if (FindNumber == 1 && Find)
                return Find;
            return false;
        }
        public int[,] GenerateTable(List<int[,]> List, int Index, int Order)
        {
        Begine5:
            RowColumn.Clear();
            int Store = Index;
            int[,] Cromosom1 = null;
            int[,] Cromosom2 = null;
        FindFF:
            try
            {
                Cromosom1 = List[List.Count - 2];
                Cromosom2 = List[List.Count - 1];
            }
            catch (IndexOutOfRangeException t)
            {
                Log(t);
                return null;
            }

            Index = Store;

            if (!FindGenToModified(Cromosom1, Cromosom2, List, Index, Order,false))
                goto EndFindAThing;






        BeginFind:
            Color color = Color.Gray;
            if (Order == -1)
                color = Color.Brown;
            try
            {
                if (CromosomRow == -1 && CromosomColumn == -1)
                {
                    List.RemoveAt(List.Count - 1);
                    Index--;
                    goto Begine5;
                }
                Ki = List[List.Count-1][CromosomRow, CromosomColumn];

                GeneticTable = new int[8, 8];
                if (List[List.Count - 1][CromosomRow, CromosomColumn] == 0)
                {
                    return null;
                }
                else
                {
                    for (int ii = 0; ii < 8; ii++)
                        for (int jj = 0; jj < 8; jj++)
                            GeneticTable[ii, jj] = List[List.Count - 1][ii, jj]; ;
                }
                color = Color.Gray;
                if (Order == -1)
                    color = Color.Brown;
         
                for (Gen1 = 0; Gen1 < 8; Gen1++)
                    for (Gen2 = 0; Gen2 < 8; Gen2++)
                    {

                        if (Gen1 == CromosomRow && Gen2 == CromosomColumn)
                            continue;
                        if ((new ChessRules(GeneticTable[CromosomRow, CromosomColumn], GeneticTable, Order)).Rules(CromosomRow, CromosomColumn, Gen1,
                        Gen2, color, GeneticTable[CromosomRow, CromosomColumn]))
                        {
                            int[] A = new int[2];
                            A[0] = CromosomRow;
                            A[1] = CromosomColumn;
                            RowColumn.Add(A);
                            bool Hit = false;
                            if (GeneticTable[Gen1, Gen2] != 0)
                                Hit = true;
                            if (Order == 1)
                                AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(GeneticTable, FormRefrigtz.MovmentsNumber, GeneticTable[CromosomRow, CromosomColumn], Gen2, Gen1, Hit, GeneticTable[Gen1, Gen2], ChessRules.BridgeActBrown, false);
                            else
                                AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(GeneticTable, FormRefrigtz.MovmentsNumber, GeneticTable[CromosomRow, CromosomColumn], Gen2, Gen1, Hit, GeneticTable[Gen1, Gen2], ChessRules.BridgeActBrown, false);

                            GeneticTable[Gen1, Gen2] = GeneticTable[CromosomRow, CromosomColumn];
                            GeneticTable[CromosomRow, CromosomColumn] = 0;
                            if (ThinkingChess.ExistTableInList(GeneticTable, List, 0))
                            {
                                GeneticTable[CromosomRow, CromosomColumn] = GeneticTable[Gen1, Gen2];
                                GeneticTable[Gen1, Gen2] = 0;
                                continue;

                            }
                            else
                            {
                                if ((new ChessRules(GeneticTable[CromosomRow, CromosomRow], GeneticTable, Order)).Kish(GeneticTable, Order))
                                {
                                    GeneticTable[CromosomRow, CromosomColumn] = GeneticTable[Gen1, Gen2];
                                    GeneticTable[Gen1, Gen2] = 0;
                                    continue;
                                }

                                else
                                {


                                    return GeneticTable;
                                }

                            }
                        }


                    }
                GeneticTable = null;
                int a = GeneticTable[0, 0];
            }

            catch (NullReferenceException t)
            {
                Log(t);
                if (Order == 1)
                    Ki = (new Random()).Next(1, 7);
                else
                    Ki = (new Random()).Next(1, 7) * -1;
           
                if (Order == 1)
                {
                    int Count = 0;
                    do
                    {
                        if (Ki < 6)
                            Ki++;
                        else
                            Ki = 1;
                        Count++;
                    } while (Count < 6 && !(new ChessRules(Ki, List[List.Count - 1], Order)).FindAThing(List[List.Count - 1], ref CromosomRow, ref CromosomColumn, Ki, true, RowColumn));
                    if (Count >= 6)
                    {
                        NoGameFounf = true;
                        return null;
                    }


                }
                else
                {
                    int Count = 0;
                    do
                    {
                        if (Ki > -6)
                            Ki--;
                        else
                            Ki = -1;
                        Count++;
                    } while (Count < 6 && !(new ChessRules(Ki, List[List.Count - 1], Order)).FindAThing(List[List.Count - 1], ref CromosomRow, ref CromosomColumn, Ki, true, RowColumn));
                    if (Count >= 6)
                    {
                        NoGameFounf = true;
                        return null;
                    }

          




                }

                goto BeginFind;
            }

        EndFindAThing:
            if (Order == 1)
                Ki = (new Random()).Next(1, 7);
            else
                Ki = (new Random()).Next(1, 7) * -1;
            if (Order == 1)
            {
                int Count = 0;
                do
                {
                    if (Ki < 6)
                        Ki++;
                    else
                        Ki = 1;
                    Count++;
                } while (Count < 6 && !(new ChessRules(Ki, List[List.Count - 1], Order)).FindAThing(List[List.Count - 1], ref CromosomRow, ref CromosomColumn, Ki, true, RowColumn));
                if (Count >= 6)
                    return null;

            }
            else
            {
                int Count = 0;
                do
                {
                    if (Ki > -6)
                        Ki--;
                    else
                        Ki = -1;
                    Count++;
                } while (Count < 6 && !(new ChessRules(Ki, List[List.Count-1], Order)).FindAThing(List[List.Count-1], ref CromosomRow, ref CromosomColumn, Ki, true, RowColumn));
                if (Count >= 6)
                    return null;
            }

            goto BeginFind;


        }
    }

}
