﻿/***********************************************************************************
 * Every Ruls of objective condition of chess game.*********************************
 * Current Rules Have not Attack Movements******************************************(+)
 * Ramin Edjlal********************************************************************
 * Current Rules Have Not 'Kish' And 'Mate' ***************************************(+*)
 * Elephant Rules Hardly***********************************************************(+)
 * Horse Rules Hardly**************************************************************(+)
 * Minister Rules Hardly***********************************************************(+)
 * King Rules Hardly***************************************************************(+)
 * Bridges Rules Hardly************************************************************(+)
 * Restricted has been solved******************************************************(-)
 * No movements greater than one. Some Abnormal Movements**************************(++)
 * Abnormal Movements Correction***************************************************(-)
 * Clear Dirty Part****************************************************************(-)
 * Chess Rules Soldier Not Moved Jump From Enemy to 2******************************(+)
 * Chess Rules Abnormally Minister Gray Elephant to Right**************************(+)
 * Chess Rules Elephant Normally***************************************************(-)
 * Abnormally Recursive Method*****************************************************(+)
 * Chess Rule Kish Mate Doesn’t Work***********************************************(+)
 * Clicking 'Table' Content Has been Abnormally************************************(+)
 * The Mechanism of Kish Declared and Act 'Not' Logically**************************(+)
 * The Mechanism of Table Assignments and the Virtualization Misleading************(+)
 * The Movements of horse Brown 'Alice' Left Side Cause to Mislead*****************(+)
 * ExistInDestinationEnemy Thinking Misleading Operations**************************(+)
 * Null Thinking Exception Handling Should be Configured***************************(+)
 * Malfunction of Mouse 'Bob' Event Handling For Movements*************************(+)
 * Non 'Kish' Second Rules 'Alice' Move to 'Kish' State****************************(+)
 * 'Mate' Not Recognized By 'Alice'.***********************************************(+)
 * 'Kish' Recognized From 'Hard' Game. Mate Have Not Been Identified.**************(+*)
 * Chess Rules MalFunctional*******************************************************(+)
 * Unsatisfied Mate By 'Bob' With 'Alice'******************************************(+)
 * Removable 'Kish' by 'Bob' Was Not done by 'Alice' ******************************(+)
 * Unknown 'KishRemovable' and Unknown 'Kish' Mechanism****************************(+)
 * Table Content at 'Bob' 'Kish' of 'Alice', Malfunction with 'horse'**************(+)
 * Can Hit 'King'******************************************************************(+)
 * Gone to 'Kish' State Deterministic**********************************************(+)
 * King hitting. Gone to Achmaz State by 'Alice' and 'Bob'**********************(++)
 * King Hitting By 'Alice' and Gone to Achmaz Remaining*************************(+)
 * Hitting Kish Solved by Changing Strategy. Kish by 'Alice' Cannot Been Removed.**(-+)
 * Bridge King Mechanism Failed****************************************************(+)
 * Arguments IgonoreTowEnemy Between King and Attaker in Kish Achmaz Misleading*(+)
 * 'Kish' Ignore. Un Rulement 'Bob Movements***************************************(++)
 * Unidentified 'Bob' Minister Movements in Kish and Unrulements Movements*********(+)
 * Tow King Beside Them************************************************************(+)
 * King of 'Bob' Gone to Achmaz.************************************************(+)
 * Gone to Kish by 'Bob'***********************************************************(+)
 * Chess Order and Chess Kish by Bob Malfunctioned*********************************(+)
 * 'Mate' of 'Alice' Ended by Moving of 'Bob' King Unrulments**********************(+)
 * Movements of 'Alice' Soldier to Backward.***************************************(+)
 * BrigdeKing Movements in Large Bridge King Misleading****************************(_)
 * Syntax Statements Failed By Halting.********************************************(+)
 * Kish Of Bob Misleading no reason.***********************************************(+)
 * Syntax Error At Genetic Algorithm By Bob.***************************************(+)
 * 1394/12/20**********************************************************************(+:Sum(48)) (_ :Sum(1)) (-:Sum(5)) (*:Sum(2))
 * Chess Syntax MalFunction.*******************************************************[+]
 * Chess Rules Non Soldier Colud Not been Detected. For Dept Fist Algorithm.*******{+}
 * 'Kish' Released isolatly.'Kish' of Brown (Alice) No Matched Realesed.***********<+>
 * 'Kish' Not Detected By Bob.*****************************************************<+>
 * Bob Cloud not Remove 'Kish'.****************************************************<+>
 * Bob Colud not Move.No Kish asnd Mate.*******************************************<+>
 * Kings Have been Realeased Attacked.By Alice and Bob.****************************<+>
 * Achmaz kings Not work!**********************************************************<*>
 * Chess Rules of Movments Dept First caused to Databse MalFunction.***************(*)
 * Mal Function of Table.Table zero.!**********************************************(+)
 * Timer of Bob and Alice do not works!********************************************(*)
 * Not Right of Penalty Regard Mechansim.Misleading of Operations.*****************(+)
 * Reveal From Mate By Alice MalFunction.******************************************{+}
 * Mate Not Work On Statistic and More By Alice.***********************************{+}
 * Mate Operation By Alice is MalFunction.*****************************************(*)
 * 'Minister' Alice Have been Kish unreasonably.***********************************(*)
 * 'Alice' Supposed Wrongly KishAchmaz Means Kish.*********************************(*)
 * Illegal King Foundation in Rules Function No Reasonaly.*************************
 * Brown (Alice) King Dosn't exist.************************************************
 * ********************************************************************************(+:Sum(1)) 4:(+:Sum(5)) 5.(*:Sum(1)) 6.(+:Sum(2)) (*:Sum(2)) 7.(+:Sum(2)) 8.(*:Sum(3))
 * ********************************************************************************
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    class ChessRules
    {
        public static bool KingAttacker = false;
        public static bool SmallKingBridgeBrown = false;
        public static bool SmallKingBridgeGray = false;
        public static bool BigKingBridgeBrown = false;
        public static bool BigKingBridgeGray = false;
        public static bool KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporter = false;
        public static int KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber = 0;
        public static  bool KishAchmazIgnoreSelfThingBetweenTowEnemyKing = false;
        public static bool KishGrayAchmaz = false;
        public static bool KishBrownAchmaz = false;
        public static bool KishGrayAchmazFirstTimesOcured = false;
        public static bool KishBrownAchmazFirstTimesOcured = false;
     
        public static bool BridgeActGray = false;
        public static bool BridgeActBrown = false;
        public static int CurrentOrder = 1;
        public static bool KishGray = false;
        public static bool KishBrown = false;
        public static bool MateGray = false;
        public static bool MateBrown = false;
        public static bool KishGrayRemovable = true;
        public static bool KishBrownRemovable = true;
        public static int KishGrayRemovableValueRowi = 0;
        public static int KishGrayRemovableValueColumni = 0;
        public static int KishGrayRemovableValueRowii = 0;
        public static int KishGrayRemovableValueColumnjj = 0;
        public static int KishBrownRemovableValueRowi = 0;
        public static int KishBrownRemovableValueColumnj = 0;
        public static int KishBrownRemovableValueRowii = 0;
        public static int KishBrownRemovableValueColumnjj = 0;
        int Kind;
        int KindNA;

        
        
        
        
        int[,] Table = new int[8, 8];



        static int Order = 0;
        //static int CurrentOrder = -1;
        static public bool ExistInDestinationEnemy = false;




        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
        

        public ChessRules(int Ki, int[,] A, int Ord)
        {





            KindNA = Ki;
            Kind = System.Math.Abs(Ki);
            Table = A;
            Order = Ord;
        }

        public bool Rules(int RowFirst, //The First Click Row
            int ColumnFirst, //The First Click Column.
            int RowSecond, //The Destination Click Row
            int ColumnSecond, //The Destination Click Column
            Color color,//Color.  
            int Ki//Current Kind.
            )
        {
            KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporter = false;
            KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber = 0;
            if (Order != CurrentOrder)
                return false;
            int RowB=0, ColumnB=0;
            int RowG=0, ColumnG = 0;
            FindBrownKing(Table, ref RowB, ref ColumnB);
            FindGrayKing(Table, ref RowG, ref ColumnG);
            if (Order == 1)
            {
                //Illegal King Foundation.
                if (System.Math.Abs(RowB - RowG) <= 1 && System.Math.Abs(ColumnB - ColumnG) <= 1)
                        return false;
            }
            else
            {
                if (System.Math.Abs(RowB - RowG) <= 1 && System.Math.Abs(ColumnB - ColumnG) <= 1)
                        return false;

            }
            ExistInDestinationEnemy = false;
            if (Table[RowFirst, ColumnFirst] > 0 && Table[RowSecond, ColumnSecond] < 0 && color == Color.Gray)
                ExistInDestinationEnemy = true;
            else
                if (Table[RowFirst, ColumnFirst] < 0 && Table[RowSecond, ColumnSecond] > 0 && color == Color.Brown)
                    ExistInDestinationEnemy = true;

            if (System.Math.Abs(Kind) == 1)
            {
                if (ColumnFirst == 1 && color == Color.Gray)
                    return Rule(RowFirst, ColumnFirst, RowSecond, ColumnSecond, true, color, ExistInDestinationEnemy, Ki);
                else
                    if (ColumnFirst == 6 && color == Color.Brown)
                        return Rule(RowFirst, ColumnFirst, RowSecond, ColumnSecond, true, color, ExistInDestinationEnemy, Ki);
                    else
                        return Rule(RowFirst, ColumnFirst, RowSecond, ColumnSecond, false, color, ExistInDestinationEnemy, Ki);

            }
            else
                return Rule(RowFirst, ColumnFirst, RowSecond, ColumnSecond, false, color, ExistInDestinationEnemy, Ki);

        }
        public bool BridgeKing(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, int Ki)
        {

            if (Order == 1)
            {
                if (!BridgeActGray)
                {
                    if (ColumnFirst == 0 && ColumnSecond == 0)
                    {
                        if (RowFirst == RowSecond - 3)
                        {
                            if (Table[RowSecond - 3, ColumnSecond] == 6 && Table[RowSecond - 2, ColumnSecond] == 0 && Table[RowSecond - 1, ColumnSecond] == 0 && Table[RowSecond, ColumnSecond] == 4)
                            {
                                BridgeActGray = true;
                                SmallKingBridgeGray = true;
                                return true;
                            }

                        }
                        else
                            if (RowFirst == RowSecond + 4)
                            {
                                if (Table[RowSecond + 4, ColumnSecond] == 6 && Table[RowSecond + 3, ColumnSecond] == 0 && Table[RowSecond +2, ColumnSecond] == 0 && Table[RowSecond+ 1, ColumnSecond] == 0 && Table[RowSecond , ColumnSecond] == 4)
                                {
                                    BridgeActGray = true;
                                    BigKingBridgeGray = true;
                                    return true;
                                }

                            }
                    }
                }
            }
            else
            {
                if (!BridgeActBrown)
                {
                    if (ColumnFirst == 7 && ColumnSecond == 7)
                    {
                        if (RowFirst == RowSecond - 3)
                        {
                            if (Table[RowSecond - 3, ColumnSecond] == -6 && Table[RowSecond - 2, ColumnSecond] == 0 && Table[RowSecond - 1, ColumnSecond] == 0 && Table[RowSecond, ColumnSecond] == -4)
                            {
                                BridgeActBrown = true;
                                SmallKingBridgeBrown = true;
                                return true;
                            }

                        }
                        else
                            if (ColumnFirst == ColumnSecond + 4)
                            {
                                if (Table[RowSecond + 4, ColumnSecond] == -6 && Table[RowSecond + 3, ColumnSecond] == 0 && Table[RowSecond + 2, ColumnSecond] == 0 && Table[RowSecond + 1, ColumnSecond] == 0 && Table[RowSecond , ColumnSecond] == -4)
                                {
                                    BridgeActBrown = true;
                                    BigKingBridgeBrown = true;
                                    return true;
                                }

                            }
                    }
                }
            }
            return false;
        }
        public bool KishConstructor(Color color, int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, int Ki, int Order)
        {

            int[,] tab = new int[8, 8];
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    tab[i, j] = Table[i, j];
                }


            tab[RowSecond, ColumnSecond] = tab[RowFirst, ColumnFirst];
            tab[RowFirst, ColumnFirst] = 0;
            if (Kish(tab, Order))
            {
                if (color == Color.Gray)
                    if (KishGray)
                        return true;
                if (color == Color.Brown)
                    if (KishBrown)
                        return true;
            }

            return false;
        }
        private bool ExistSelfHome(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, int Ki)
        {
            bool NotExistInDestinationSelfHome = false;
            if (RowFirst != RowSecond || ColumnFirst != ColumnSecond)
            {
                if (Table[RowSecond, ColumnSecond] > 0 && Table[RowFirst, ColumnFirst] > 0)
                    NotExistInDestinationSelfHome = true;
                else
                    if (Table[RowSecond, ColumnSecond] < 0 && Table[RowFirst, ColumnFirst] < 0)
                        NotExistInDestinationSelfHome = true;
            }
            return NotExistInDestinationSelfHome;
        }
        public bool AchmazKingMove(int Order, int[,] Table, bool DoIgnore)
        {
            int[,] Tab = new int[8, 8];
            //Clone a Copy
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                    Tab[i, j] = Table[i, j];
            //Initiate Variables.
            KishGray = false;
            KishBrown = false;
             KishGrayAchmaz = false;
            KishBrownAchmaz = false;
            int RowG = 0, ColumnG = 0;
            int RowB = 0, ColumnB = 0;
            if (DoIgnore)
                ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = true;
            //Kish identification.
            Kish(Tab, Order);
            bool KishGrayDummy = KishGray;
            bool KishBrownDummy = KishBrown;
            if (KishBrown || KishGray)
            {
                //Kish meand achmaz.
                if (KishBrown)
                    KishBrownAchmaz = true;
                if (KishGray)
                    KishGrayAchmaz = true;
                return true;

            }
            //For Gray do
            //if (Order == 1 || !ThinkingChess.OnlySelf)
            {
                //Location of King Gary
                if (FindGrayKing(Tab, ref RowG, ref ColumnG))
                {
                    //For Every Enemy
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            if (i == RowG && j == ColumnG)
                                continue;

                            //if (Tab[i, j] < 0)
                            {
                                //Exaturation Condition.                                
                                if (Tab[i, j] == -1)
                                {
                                    //
                                    if (System.Math.Abs(i - RowG) == 1 && System.Math.Abs(j - ColumnG) == 1)
                                    {
                                        if (i > RowG)
                                        {
                                            KishGrayAchmaz = true;
                                            KishGrayAchmazFirstTimesOcured = true;
                                            ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = false;

                                        }
                                    }
                                }
                                int CDummy;
                                //Prevent of Going Achamaz
                                if ((new ChessRules(6, Tab, Order)).Rules(RowG, ColumnG, i, j, Color.Gray, Order))
                                {
                                    CDummy = ChessRules.CurrentOrder;
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                        {
                                            Tab[i, j] = 6;
                                            Tab[RowG, ColumnG] = 0;
                                            ChessRules.CurrentOrder = -1;
                                            if ((new ThinkingChess()).Attack(Tab, ii, jj, i, j, Color.Brown, -1))
                                            {
                                                KishGrayAchmazFirstTimesOcured = true;
                                                KishGrayAchmaz = true;
                                            }
                                            Tab[i, j] = 0;
                                            Tab[RowG, ColumnG] = 6;
                                            ChessRules.CurrentOrder = CDummy;
                                        }

                                }
                                CDummy = ChessRules.CurrentOrder;
                                ChessRules.CurrentOrder = -1;
                                //If Current Enemy is Attacked.Correction needing 
                                if ((new ThinkingChess()).Attack(Tab, i, j, RowG, ColumnG,
                                    //Color.Gray
                                    Color.Brown
                                    //, Order
                                    , -1) && Tab[i, j] < 0)
                                {

                                    //If Things Between is not needed.
                                    if (!DoIgnore)
                                    {
                                        KishGrayAchmazFirstTimesOcured = true;
                                        KishGrayAchmaz = true;
                                        //KishGrayAchmazFirstTimesOcured = true;

                                    }
                                    ChessRules.CurrentOrder = CDummy;
                                    //When King Gray is Movable.
                                    for (int iii = 0; iii < 8; iii++)
                                        for (int jjj = 0; jjj < 8; jjj++)
                                            if ((new ThinkingChess()).Movable(Tab, RowG, ColumnG, iii, jjj, Color.Gray, Order))
                                            {
                                                KishGrayAchmaz = false;
                                                KishGrayAchmazFirstTimesOcured = false;
                                                break;
                                            }
                                    //Action off Supporte and Attacker.
                                    int Supported = 0;
                                    int Attacked = 0;
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                        {
                                            if ((Tab[ii, jj] == 3 || Tab[ii, jj] == 4 || Tab[ii, jj] == 5) && (Tab[ii, jj] > 0) || (Tab[ii, jj] > 0 && System.Math.Abs(ii - RowG) < 4 && System.Math.Abs(jj - ColumnG) < 4))
                                            {
                                                if ((new ThinkingChess()).Support(Tab, ii, jj, RowG, ColumnG, Color.Gray, Order))
                                                    Supported++;
                                            }

                                        }
                                    //Cal Attacker
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                            for (int iii = 0; iii < 8; iii++)
                                                for (int jjj = 0; jjj < 8; jjj++)
                                                {

                                                    if (((Tab[ii, jj] == -3 || Tab[ii, jj] == -4 || Tab[ii, jj] == -5) && (Tab[ii, jj] < 0 && Tab[iii, jjj] > 0)) || (Tab[ii, jj] < 0 && Tab[iii, jjj] > 0 && System.Math.Abs(ii - RowG) < 4 && System.Math.Abs(iii - RowG) < 4 && System.Math.Abs(jj - ColumnG) < 4 && System.Math.Abs(jjj - ColumnG) < 4))
                                                    {
                                                        if ((new ThinkingChess()).Attack(Tab, ii, jj, iii, jjj, Color.Gray, Order))
                                                            Attacked++;
                                                    }
                                                }
                                    //Cal Supporter.
                                    bool SupportedAttacker = false;
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                        {
                                            if ((new ThinkingChess()).Attack(Tab, ii, jj, RowG, ColumnG, Color.Gray, Order))
                                            {

                                                for (int iii = 0; iii < 8; iii++)
                                                {
                                                    for (int jjj = 0; jjj < 8; jjj++)
                                                        if ((new ThinkingChess()).Support(Tab, iii, jjj, ii, jj, Color.Brown, Order * -1))
                                                        {
                                                            SupportedAttacker = true;
                                                            break;
                                                        }
                                                    if (SupportedAttacker)
                                                        break;
                                                }


                                            }

                                        }

                                    //When Supporter is less than Attacker.
                                    if (SupportedAttacker)
                                    {
                                        if (Supported < Attacked)
                                        {
                                            KishGrayAchmaz = true;
                                            KishGrayAchmazFirstTimesOcured = true;
                                        }

                                    }
                                    ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = false;

                                }
                                ChessRules.CurrentOrder = CDummy;
                            }


                        }
                    }
                }
            }
            //Do Same as Gray
           // if (Order == -1 || !ThinkingChess.OnlySelf)
            {
                if (FindBrownKing(Tab, ref RowB, ref ColumnB))
                {
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            if (i == RowB && j == ColumnB)
                                continue;
                            //if (Tab[i, j] > 0)
                            {
                                if (Tab[i, j] == 1)
                                {
                                    if (System.Math.Abs(i - RowB) == 1 && System.Math.Abs(j - ColumnB) == 1)
                                    {
                                        if (i < RowB)
                                        {

                                            KishBrownAchmaz = true;
                                            KishBrownAchmazFirstTimesOcured = true;
                                            ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = false;
                                        }
                                    }
                                }
                                int CDummy;
                                if ((new ChessRules(-6, Table, Order)).Rules(RowB, ColumnB, i, j, Color.Brown, Order))
                                {
                                    CDummy = ChessRules.CurrentOrder;
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                        {
                                            Tab[i, j] = -6;
                                            Tab[RowB, ColumnB] = 0;
                                            ChessRules.CurrentOrder = 1;
                                            if ((new ThinkingChess()).Attack(Tab, ii, jj, i, j, Color.Gray, 1))
                                            {
                                                KishBrownAchmazFirstTimesOcured = true;
                                                KishBrownAchmaz = true;
                                            }
                                            Tab[i, j] = 0;
                                            Tab[RowB, ColumnB] = -6;
                                            ChessRules.CurrentOrder = CDummy;

                                        }

                                }
                                CDummy = ChessRules.CurrentOrder;
                                ChessRules.CurrentOrder = 1;
                                if ((new ThinkingChess()).Attack(Tab, i, j, RowB, ColumnB
                                    //, Color.Brown
                                    , Color.Gray
                                    //, Order
                                , 1) && Tab[i, j] > 0)
                                {
                                    ChessRules.CurrentOrder = CDummy;
                                    if (!DoIgnore)
                                    {
                                        KishBrownAchmaz = true;
                                        // KishBrownAchmazFirstTimesOcured = true;

                                    }
                                    for (int iii = 0; iii < 8; iii++)
                                        for (int jjj = 0; jjj < 8; jjj++)
                                            if ((new ThinkingChess()).Movable(Tab, RowB, ColumnB, iii, jjj, Color.Brown, Order))
                                            {
                                                KishBrownAchmazFirstTimesOcured = false;
                                                KishBrownAchmaz = false;
                                                break;
                                            }
                                    int Supported = 0;
                                    int Attacked = 0;
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                        {
                                            if (((Tab[ii, jj] == -3 || Tab[ii, jj] == -4 || Tab[ii, jj] == -5) && (Tab[ii, jj] < 0) || (Tab[ii, jj] < 0 && System.Math.Abs(ii - RowB) < 4 && System.Math.Abs(jj - ColumnB) < 4)))
                                            {
                                                if ((new ThinkingChess()).Support(Tab, ii, jj, RowB, ColumnB, Color.Brown, Order))
                                                    Supported++;
                                            }



                                        }
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                            for (int iii = 0; iii < 8; iii++)
                                                for (int jjj = 0; jjj < 8; jjj++)
                                                {

                                                    if (((Tab[ii, jj] == 3 || Tab[ii, jj] == 4 || Tab[ii, jj] == 5) && (Tab[ii, jj] > 0 && Tab[iii, jjj] < 0)) || (Tab[ii, jj] > 0 && Tab[iii, jjj] < 0 && System.Math.Abs(ii - RowB) < 4 && System.Math.Abs(iii - RowB) < 4 && System.Math.Abs(jj - ColumnB) < 4 && System.Math.Abs(jjj - ColumnB) < 4))
                                                    {
                                                        if ((new ThinkingChess()).Attack(Tab, ii, jj, iii, jjj, Color.Brown, Order))
                                                            Attacked++;
                                                    }
                                                }
                                    bool SupportedAttacker = false;
                                    for (int ii = 0; ii < 8; ii++)
                                        for (int jj = 0; jj < 8; jj++)
                                        {
                                            if ((new ThinkingChess()).Attack(Tab, ii, jj, RowB, ColumnB, Color.Brown, Order))
                                            {

                                                for (int iii = 0; iii < 8; iii++)
                                                {
                                                    for (int jjj = 0; jjj < 8; jjj++)
                                                        if ((new ThinkingChess()).Support(Tab, iii, jjj, ii, jj, Color.Gray, Order * -1))
                                                        {
                                                            SupportedAttacker = true;
                                                            break;
                                                        }
                                                    if (SupportedAttacker)
                                                        break;
                                                }


                                            }

                                        }
                                    if (SupportedAttacker)
                                    {
                                        if (Supported < Attacked)
                                        {

                                            KishBrownAchmaz = true;
                                            KishBrownAchmazFirstTimesOcured = true;
                                        }

                                    }


                                    ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = false;


                                }
                                ChessRules.CurrentOrder = CDummy;

                            }
                        }
                    }
                }
            }
            ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = false;
            if (KishBrownAchmaz || KishGrayAchmaz)
            {
                KishGray = KishGrayDummy;
                KishBrown = KishBrownDummy;

                return true;
            }

            KishGray = KishGrayDummy;
            KishBrown = KishBrownDummy;
           
            return false;
        }

        bool FindGrayKing(int[,] Table, ref int Row, ref int Column)
        {
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    if (Table[i, j] == 6)
                    {
                        Row = i;
                        Column = j;
                        return true;
                    }
                }
            return false;
        }
        static String ThingsAlphabet(int i)
        {
            String A = "";
            if (i < 0)
                A = "Brown:";
            if (i > 0)
                A = "Gray:";
            if (System.Math.Abs(i) == 1)
                A += "(S)";
            if (System.Math.Abs(i) == 2)
                A += "(E)";
            if (System.Math.Abs(i) == 3)
                A += "(H)";
            if (System.Math.Abs(i) == 4)
                A += "(B)";
            if (System.Math.Abs(i) == 5)
                A += "(M)";
            if (System.Math.Abs(i) == 6)
                A += "(K)";
            return A;

        }
        
        static String RowAlphabet(int i)
        {
            String A = "";
            if (i == 0)
                A = "a";
            if (i == 1)
                A = "b";
            if (i == 2)
                A = "c";
            if (i == 3)
                A = "d";
            if (i == 4)
                A = "e";
            if (i == 5)
                A = "f";
            if (i == 6)
                A = "g";
            if (i == 7)
                A = "h";
            return A;

        }
        static public String CreateStatistic(int[,] Tab,int Movments,int SourceThings, int Column, int Row, bool Hit, int HitThings, bool BridgeKing, bool SodierConvert)
        {
            String S = Movments.ToString() + ".";

            //if (Movments == 52)
                (new ChessRules(1, Tab, 1)).Mate(Tab, 1);
            if (SodierConvert || BridgeKing)
            {
                if (BridgeKing)
                {
                    if (Row == 0 && Column == 0)
                    {
                        S += "Brown-BK-S";
                    }
                    if (Row == 0 && Column == 7)
                    {
                        S += "Brown-BK-G";
                    }
                    if (Row == 7 && Column == 0)
                    {
                        S += "Gray-BK-S";
                    }
                    if (Row == 7 && Column == 7)
                    {
                        S += "Gray-BK-G";
                    }
                }
                if (SodierConvert)
                {
                    S += ThingsAlphabet(SourceThings);
                    if (MateGray || MateBrown)
                    {
                        S += "xxx";
                    }
                    else if (KishBrown || KishGray)
                    {
                        S += "xx";
                    }
                    if (Hit)
                            S += "x";
                    S += Column.ToString();
                }
            }
            else
            {

                S += ThingsAlphabet(SourceThings);
                if (MateGray || MateBrown)
                {
                    S += "xxx";
                }
                else if (KishBrown || KishGray)
                {
                    S += "xx";
                }

                if (Hit)
                    S += "x";



                S += RowAlphabet(Row);
                S += Column.ToString();
            }
            S += "--";
            return S;
        }
        bool ArrayInList(List<int[]> List, int[] A)
        {
            bool Is = false;
            for (int i = 0; i < List.Count; i++)
            {
                if (A[0] == List[i][0] && A[1] == List[i][1])
                    Is = true;
            }
            return Is;
        }
        public bool FindAThing(int[,] Table, ref int Row, ref int Column, int Thing, bool BeMovable, List<int[]> List)
        {
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    int[] AA = new int[2];
                    AA[0] = i;
                    AA[1] = j;
                    if (Table[i, j] == Thing)
                    {

                        if (!BeMovable)
                        {
                            if (ArrayInList(List, AA))
                                continue;
                            Row = i;
                            Column = j;
                            return true;
                        }
                        else
                        {
                            Color A = Color.Gray;
                            if (Order == -1)
                                A = Color.Brown;
                            for (int ii = 0; ii < 8; ii++)
                                for (int jj = 0; jj < 8; jj++)
                                {

                                    if ((new ThinkingChess()).Movable(Table, i, j, ii, jj, A, Order))
                                    {
                                        if (ArrayInList(List, AA))
                                            continue;
                                        Row = i;
                                        Column = j;
                                        return true;
                                    }

                                }
                        }

                    }
                }
            return false;
        }

        bool FindBrownKing(int[,] Table, ref int Row, ref int Column)
        {
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    if (Table[i, j] == -6)
                    {
                        Row = i;
                        Column = j;
                        return true;
                    }
                }
            return false;
        }
        public bool KishRemovableByAttack(int[,] Table, int Order)
        {
            int[,] Tabl = new int[8, 8];
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                    Tabl[i, j] = Table[i, j];
           
            KishGrayRemovable = true;

            KishBrownRemovable = true;

            Kish(Tabl, Order);
            //if (Order == -1)
            {
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        for (int ii = 0; ii < 8; ii++)
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                if (Table[i, j] < 0)
                                {
                                    if (Table[ii, jj] > 0)
                                    {

                                        int[,] Tab = new int[8, 8];
                                        for (int iii = 0; iii < 8; iii++)
                                            for (int jjj = 0; jjj < 8; jjj++)
                                            {
                                                Tab[iii, jjj] = Table[iii, jjj];
                                            }
                                        if ((new ThinkingChess().Movable(Tab, i, j, ii, jj, Color.Brown, -1)))
                                        {
                                             for (int iii = 0; iii < 8; iii++)
                                                for (int jjj = 0; jjj < 8; jjj++)
                                                {
                                                    Tab[iii, jjj] = Table[iii, jjj];
                                                }

                                            if (KishBrown)
                                            {
                                                Tab[ii, jj] = Tab[i, j];
                                                Tab[i, j] = 0;
                                                if (!Kish(Tab, Order))
                                                {
                                                    if (!KishBrown)
                                                    {

                                                        Tab[i, j] = Table[ii, jj];
                                                        Tab[ii, jj] = 0;
                                                        KishBrownRemovableValueRowi = i;
                                                        KishGrayRemovableValueColumni = j;
                                                        KishGrayRemovableValueRowii = ii;
                                                        KishGrayRemovableValueColumnjj = jj;
                                                        KishGrayRemovable = true;
                                                                                                            }
                                                }
                                                Tab[i, j] = Table[ii, jj];
                                                Tab[ii, jj] = 0;
                                            }


                                        }
                                    }
                                }
                            }
            }
            //else
            {

                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        for (int ii = 0; ii < 8; ii++)
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                if (Table[i, j] > 0)
                                {
                                    if (Table[ii, jj] < 0)
                                    {
                                        int[,] Tab = new int[8, 8];
                                        for (int iii = 0; iii < 8; iii++)
                                            for (int jjj = 0; jjj < 8; jjj++)
                                            {
                                                Tab[iii, jjj] = Table[iii, jjj];
                                            }
                                        if ((new ThinkingChess().Movable(Tab, i, j, ii, jj, Color.Gray, 1)))
                                        {
                                             for (int iii = 0; iii < 8; iii++)
                                                for (int jjj = 0; jjj < 8; jjj++)
                                                {
                                                    Tab[iii, jjj] = Table[iii, jjj];
                                                }

                                            if (KishGray)
                                            {
                                                Tab[ii, jj] = Tab[i, j];
                                                Tab[i, j] = 0;
                                                if (!Kish(Tab, Order))
                                                {
                                                    if (!KishGray)
                                                    {
                                                        Tab[i, j] = Table[ii, jj];
                                                        Tab[ii, jj] = 0;
                                                        KishBrownRemovableValueRowi = i;
                                                        KishBrownRemovableValueColumnj = j;
                                                        KishBrownRemovableValueRowii = ii;
                                                        KishBrownRemovableValueColumnjj = jj;
                                                        KishBrownRemovable = true;
                                                        
                                                    }
                                                }
                                                Tab[i, j] = Table[ii, jj];
                                                Tab[ii, jj] = 0;
                                            }


                                        }
                                    }
                                }
                            }
            }
            if (KishBrownRemovable || KishGrayRemovable)
                return true;
            return false;
        }

        public bool Kish(int[,] Table, int Order)
        {
            bool Store = ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing;
            ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = false;
            KishGray = false;
            KishBrown = false;
            int[,] Tab = new int[8, 8];
            for (int ii = 0; ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                    Tab[ii, jj] = Table[ii, jj];
            int RowG = 0, ColumnG = 0;
            int RowB = 0, ColumnB = 0;
            //if (Order == 1 || !ThinkingChess.OnlySelf)
            {
                if (FindGrayKing(Tab, ref RowG, ref ColumnG))
                {
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                        {
                            if (i == RowG && j == ColumnG)
                                continue;
                             if (Tab[i, j] < 0)
                            {
                                int Dummt = ChessRules.CurrentOrder;
                                ChessRules.CurrentOrder = -1;

                                for (int ii = 0; ii < 8; ii++)
                                    for (int jj = 0; jj < 8; jj++)
                                        Tab[ii, jj] = Table[ii, jj];
                                if ((new ThinkingChess()).Attack(Tab, i, j, RowG, ColumnG, Color.Brown, -1))
                                {
                                    KishGray = true;
                                    ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = Store;
                                    
                                }
                                ChessRules.CurrentOrder = Dummt;
                            }


                        }
                }
            }
             //if (Order == -1 || !ThinkingChess.OnlySelf)
            {
                if (FindBrownKing(Tab, ref RowB, ref ColumnB))
                {
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                        
                        {
                            if (i == RowB && j == ColumnB)
                                continue;
                            if (Tab[i, j] > 0)
                            {
                                int Dummt = ChessRules.CurrentOrder;
                                ChessRules.CurrentOrder = 1;
                                for (int ii = 0; ii < 8; ii++)
                                    for (int jj = 0; jj < 8; jj++)
                                        Tab[ii, jj] = Table[ii, jj];
                                if ((new ThinkingChess()).Attack(Tab, i, j, RowB, ColumnB, Color.Gray, 1))
                                {
                                    ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = Store;
                                    KishBrown = true;
                                    
                                }
                                ChessRules.CurrentOrder = Dummt;
                            }
                        }
                }
            }
            ChessRules.KishAchmazIgnoreSelfThingBetweenTowEnemyKing = Store;
            if (KishBrown || KishGray)
                return true;
            return false;
        }

        public bool Mate(int[,] Tab, int Order)
        {
            int[,] Table = new int[8, 8];
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                    Table[i, j] = Tab[i, j];
            KishGray = false;
            KishBrown = false;
            MateBrown = false;
            MateGray = false;
            bool ActMove = true;
            int RowG = 0, ColumnG = 0;
            int RowB = 0, ColumnB = 0;
            /*if (KishRemovableByAttack(Table, Order))
            {
                if (ChessRules.KishGrayRemovable && ChessRules.KishBrownRemovable)
                    return false;
            }*/
            int Dumny = ChessRules.CurrentOrder;
            Kish(Table, Order);
            bool KishGrayDummy = KishGray;
            bool KishBrownDummy = KishBrown;
            //if (Order == 1 || !ThinkingChess.OnlySelf)
            {
                ActMove = false;
               
                if (FindGrayKing(Table, ref RowG, ref ColumnG))
                {
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            KishGray = KishGrayDummy;
                            KishBrown = KishBrownDummy;
                            for (int ii = 0; ii < 8; ii++)
                                for (int jj = 0; jj < 8; jj++)
                                    Table[ii, jj] = Tab[ii, jj];
                       
                            if (KishGray)
                            {
                                ChessRules.CurrentOrder = 1;
                                if ((new ThinkingChess()).Movable(Table, RowG, ColumnG, i, j, Color.Gray, 1))
                                {
                                    ActMove = false;
                                    int Store = Table[i, j];
                                    //For Another Methods
                                    Table[i, j] = Table[RowG, ColumnG];
                                    Table[RowG, ColumnG] = 0;
                                    if (Kish(Table, 1))
                                    {
                                        Table[RowG, ColumnG] = Table[i, j];
                                        Table[i, j] = Store;
                                        if (KishGray)
                                        {
                                            ActMove = true;
                                            Table[RowG, ColumnG] = Table[i, j];
                                            Table[i, j] = Store;
                                            continue;
                                        }
                                        else
                                        {
                                            Table[RowG, ColumnG] = Table[i, j];
                                            Table[i, j] = Store;
                                            ActMove = false;
                                            break;
                                        }

                                    }
                                    Table[RowG, ColumnG] = Table[i, j];
                                    Table[i, j] = Store;
                                    ActMove = false;
                                    break;

                                }
                            }
                        }
                        if (!ActMove)
                            break;
                    }
                    KishGray = KishGrayDummy;
                    KishBrown = KishBrownDummy;
                    if (KishGray && ActMove)
                        MateGray = true;
                }
            }
            // else
            //if (Order == -1 || !ThinkingChess.OnlySelf)
            {
                ActMove = true;
                if (FindBrownKing(Table, ref RowB, ref ColumnB))
                {

                    for (int i = 0; i < 8; i++)
                    {

                        for (int j = 0; j < 8; j++)
                        {
                            KishGray = KishGrayDummy;
                            KishBrown = KishBrownDummy;
                            for (int ii = 0; ii < 8; ii++)
                                for (int jj = 0; jj < 8; jj++)
                                    Table[ii, jj] = Tab[ii, jj];
                            if (KishBrown)
                            {
                                ChessRules.CurrentOrder = -1;
                                if ((new ThinkingChess()).Movable(Table, RowB, ColumnB, i, j, Color.Brown, -1))

                                {
                                    ActMove = false;
                                    //For Another Methods
                                    int Store = Table[i, j];
                                    Table[i, j] = Table[RowB, ColumnB];
                                    Table[RowB, ColumnB] = 0;
                                    if (Kish(Table, -1))
                                    {
                                        Table[RowB, ColumnB] = Table[i, j];
                                        Table[i, j] = Store;
                                        if (KishBrown)
                                        {
                                            ActMove = true;
                                            Table[RowB, ColumnB] = Table[i, j];
                                            Table[i, j] = Store;
                                            continue;
                                        }
                                        else
                                        {
                                            ActMove = false;
                                            Table[RowB, ColumnB] = Table[i, j];
                                            Table[i, j] = Store;
                                            break;
                                        }




                                    }
                                    Table[RowB, ColumnB] = Table[i, j];
                                    Table[i, j] = Store;
                                    ActMove = false;

                                }
                            }
                        }
                        if (!ActMove)
                            break;
                        
                    }
                    KishGray = KishGrayDummy;
                    KishBrown = KishBrownDummy;
                    if (KishBrown && ActMove)
                        MateBrown = true;
                
                }
            }
            ChessRules.CurrentOrder = Dumny;
            if (MateGray || MateBrown)
            {
                KishGray = KishGrayDummy;
                KishBrown = KishBrownDummy;
                FormRefrigtz.EndOfGame = true;
                return true;
            }
            KishGray = KishGrayDummy;
            KishBrown = KishBrownDummy;
         
            return false;
        }
        private bool Rule(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, bool ExistInDestinationEnemy, int Ki)
        
        {
            if (Kind != 7)
            {
                if (ExistSelfHome(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, Ki))
                    return false;
            }
            if (!KingAttacker)
            {
                //Coluld not hit King In Destination Enemy.
                if (Order == 1 && Table[RowSecond, ColumnSecond] == -6)
                    return false;
                if (Order == -1 && Table[RowSecond, ColumnSecond] == 6)
                    return false;
            }
            if (RowFirst == RowSecond && ColumnFirst == ColumnSecond)
                return false;
            KingAttacker = false;
            //Kish(Table);
            // Mate(Table);

            // bool RuleR = false;
            if (Kind == 1)

                return SoldierRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy);

            else
                if (Kind == 4)
                    return BridgeRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy, Ki);

                else
                    if (Kind == 3)

                        return HourseRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy);


                    else
                        if (Kind == 2)

                            return ElefantRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy, Ki);

                        else
                            if (Kind == 5)

                                return MinisterRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy, Ki);

                            else
                                if (Kind == 6)

                                    return KingRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy, Ki);
                                else
                                    if (Kind == 7)
                                        return BridgeKing(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, Ki);



            return false;
        }
        public bool KingRules(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, bool ExistInDestinationEnemy, int Ki)
        {
            if (MinisterRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy, Ki) && (System.Math.Abs(RowFirst - RowSecond) <= 1 && System.Math.Abs(ColumnFirst - ColumnSecond) <= 1))
            {
                int[,] Tab = new int[8, 8];
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        Tab[i, j] = Table[i, j];
                    }
                int Store = Tab[RowSecond, ColumnSecond];
                Tab[RowSecond, ColumnSecond] = Tab[RowFirst, ColumnFirst];
                Tab[RowFirst, ColumnFirst] = 0;

                if (Kish(Tab, Order))
                {
                    if (Order == 1 && ChessRules.KishGray)
                        return false;
                    else
                        if (Order == -1 && ChessRules.KishBrown)
                            return false;
                }
                if (Order == 1 && Table[RowFirst, ColumnFirst] == 6)
                {
                    try
                    {
                        if (Table[RowSecond + 1, ColumnSecond] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond, ColumnSecond + 1] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond + 1, ColumnSecond + 1] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond - 1, ColumnSecond] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond, ColumnSecond - 1] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond - 1, ColumnSecond - 1] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond + 1, ColumnSecond - 1] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond - 1, ColumnSecond + 1] == -6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }


                }
                else if (Order == -1 && Table[RowFirst, ColumnFirst] == -6)
                {
                    try
                    {
                        if (Table[RowSecond + 1, ColumnSecond] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond, ColumnSecond + 1] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond + 1, ColumnSecond + 1] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond - 1, ColumnSecond] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond, ColumnSecond - 1] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond - 1, ColumnSecond - 1] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond + 1, ColumnSecond - 1] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }
                    try
                    {
                        if (Table[RowSecond - 1, ColumnSecond + 1] == 6)
                            return false;
                    }
                    catch (Exception t) { Log(t); }

                }
                return true;
            }
            return false;
        }
        public bool MinisterRules(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, bool ExistInDestinationEnemy, int Ki)
        {
            if (BridgeRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy, Ki))
            {
                // if (ExistInDestinationEnemy)
                //    Table[RowSecond, ColumnSecond] = 0;
                return true;
            }
            if (ElefantRules(RowFirst, ColumnFirst, RowSecond, ColumnSecond, NotMoved, color, ExistInDestinationEnemy, Ki))
            {
                // if (ExistInDestinationEnemy)
                //     Table[RowSecond, ColumnSecond] = 0;               
                return true;
            }

            return false;
        }
        public bool BridgeRules(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, bool ExistInDestinationEnemy, int Ki)
        {

            if (System.Math.Abs(ColumnFirst - ColumnSecond) == 0 && System.Math.Abs(RowFirst - RowSecond) != 0)
            {
                int RowU = RowSecond, RowD = RowFirst;
                int ColD = ColumnFirst, ColU = ColumnSecond;
                int Rowf = 1, Colf = 1;
                if (RowU < RowD)
                    Rowf = -1;
                if (ColU < ColD)
                    Colf = -1;
                int incf = 0, incR = 0;
                if (Rowf < 0)
                    incf = -1;
                if (Colf < 0)
                    incR = -1;
                int F = 0, G = 0;
                int A = 0, B = 0;
                if (incf < 0)
                {
                    F = RowU;
                    G = RowD;
                }
                else
                {
                    F = RowD;
                    G = RowU;

                }
                if (incR < 0)
                {
                    A = ColU;
                    B = ColD;
                }
                else
                {
                    A = ColD;
                    B = ColU;

                }
                {
                    for (int i = F; i <= G; i++)
                    {
                        if (i != RowFirst)
                        {
                            if (Table[i, ColumnFirst] > 0 && Table[RowFirst, ColumnFirst] > 0)
                                return false;
                            if (Table[i, ColumnFirst] < 0 && Table[RowFirst, ColumnFirst] < 0)
                                return false;
                            if (i != RowSecond && !KishAchmazIgnoreSelfThingBetweenTowEnemyKing)
                            {
                               if (Table[i, ColumnFirst] < 0 && Table[RowFirst, ColumnFirst] > 0)
                                    return false;
                                if (Table[i, ColumnFirst] > 0 && Table[RowFirst, ColumnFirst] < 0)
                                    return false;
                            }
                          /*  else
                                if (i != RowSecond && KishAchmazIgnoreSelfThingBetweenTowEnemyKing)
                                {
                                    if (Table[i, ColumnFirst] < 0 && Table[RowFirst, ColumnFirst] < 0)
                                        KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber++;
                                    if (Table[i, ColumnFirst] > 0 && Table[RowFirst, ColumnFirst] > 0)
                                        KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber++;

                                }*/
                        }

                    }
                }
                /*if (Order == 1)
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == -6)
                            return false;
                }
                else
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == 6)
                            return false;

                }*/
                return true;
            }
            if (System.Math.Abs(ColumnFirst - ColumnSecond) != 0 && System.Math.Abs(RowFirst - RowSecond) == 0)
            {

                int RowU = RowSecond, RowD = RowFirst;
                int ColD = ColumnFirst, ColU = ColumnSecond;
                int Rowf = 1, Colf = 1;
                if (RowU < RowD)
                    Rowf = -1;
                if (ColU < ColD)
                    Colf = -1;
                int incf = 0, incR = 0;
                if (Rowf < 0)
                    incf = -1;
                if (Colf < 0)
                    incR = -1;
                int F = 0, G = 0;
                int A = 0, B = 0;
                if (incf < 0)
                {
                    F = RowU;
                    G = RowD;
                }
                else
                {
                    F = RowD;
                    G = RowU;

                }
                if (incR < 0)
                {
                    A = ColU;
                    B = ColD;
                }
                else
                {
                    A = ColD;
                    B = ColU;

                }


                for (int j = A; j <= B; j++)
                {
                    if (j != ColumnFirst)
                    {
                        if (Table[RowFirst, j] > 0 && Table[RowFirst, ColumnFirst] > 0)
                            return false;
                        if (Table[RowFirst, j] < 0 && Table[RowFirst, ColumnFirst] < 0)
                            return false;
                       if (j != ColumnSecond && !KishAchmazIgnoreSelfThingBetweenTowEnemyKing)
                        {
                            if (Table[RowFirst, j] < 0 && Table[RowFirst, ColumnFirst] > 0)
                                return false;
                            if (Table[RowFirst, j] > 0 && Table[RowFirst, ColumnFirst] < 0)
                                return false;
                        }/*
                        else
                            if (j != ColumnSecond && KishAchmazIgnoreSelfThingBetweenTowEnemyKing)
                            {
                                if (Table[RowFirst, j] < 0 && Table[RowFirst, ColumnFirst] < 0)
                                    KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber++;
                                if (Table[RowFirst, j] > 0 && Table[RowFirst, ColumnFirst] > 0)
                                    KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber++;

                            }
                       */
                    }


                }
       /*         if (Order == 1)
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == -6)
                            return false;
                }
                else
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == 6)
                            return false;

                }*/
              //  if (KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber >= 2)
               //     return false;
                return true;
            }


            return false;

        }
        public bool ElefantRules(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, bool ExistInDestinationEnemy, int Ki)
        {

            if (System.Math.Abs(ColumnFirst - ColumnSecond) == System.Math.Abs(RowFirst - RowSecond))
            {
                int RowU = RowSecond, RowD = RowFirst;
                int ColD = ColumnFirst, ColU = ColumnSecond;
                int Rowf = 1, Colf = 1;
                if (RowU < RowD)
                    Rowf = -1;
                if (ColU < ColD)
                    Colf = -1;
                int incf = 0, incR = 0;
                if (Rowf < 0)
                    incf = -1;
                if (Colf < 0)
                    incR = -1;
                int F = 0, G = 0;
                int A = 0, B = 0;
                if (incf < 0)
                {
                    F = RowU;
                    G = RowD;
                }
                else
                {
                    F = RowD;
                    G = RowU;

                }
                if (incR < 0)
                {
                    A = ColU;
                    B = ColD;
                }
                else
                {
                    A = ColD;
                    B = ColU;

                }
                for (int i = F; i <= G; i++)
                    for (int j = A; j <= B; j++)
                    {
                        if (System.Math.Abs(i - RowFirst) != System.Math.Abs(j - ColumnFirst))
                            continue;

                        if (i != RowFirst && j != ColumnFirst)
                        {
                            // if (i != RowSecond && j != ColumnSecond && !KishAchmazIgnoreSelfThingBetweenTowEnemyKing)
                            {
                                if (Table[i, j] > 0 && Table[RowFirst, ColumnFirst] > 0)
                                    return false;
                                if (Table[i, j] < 0 && Table[RowFirst, ColumnFirst] < 0)
                                    return false;
                                if (i != RowSecond && j != ColumnSecond)
                                {
                                    if (Table[i, j] < 0 && Table[RowFirst, ColumnFirst] > 0)
                                        return false;
                                    if (Table[i, j] > 0 && Table[RowFirst, ColumnFirst] < 0)
                                        return false;
                                }
                            }
                            /*  else
                                  if (i != RowSecond && j != ColumnSecond && KishAchmazIgnoreSelfThingBetweenTowEnemyKing)
                                  {                                  
                                          if (Table[i, j] > 0 && Table[RowFirst, ColumnFirst] < 0)
                                              KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber++;
                                          if (Table[i, j] < 0 && Table[RowFirst, ColumnFirst] > 0)
                                              KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber++;
                                  
                                   

                                  }
                              */
                        }

                    }
 /*               if (Order == 1)
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == -6)
                            return false;
                }
                else
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == 6)
                            return false;

                }
  */
                //if (KishAchmazIgnoreSelfThingBetweenTowEnemyKingHaveSupporterNumber >= 2)
                //    return false;
                return true;
            }
            return false;
        }
        public bool HourseRules(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, bool ExistInDestinationEnemy)
        {

            if (System.Math.Abs(ColumnFirst - ColumnSecond) == 2 && System.Math.Abs(RowFirst - RowSecond) == 1)
            {
                if (Order == 1)
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == -6)
                            return false;
                }
                else
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == 6)
                            return false;

                }
                return true;
            }
            if (System.Math.Abs(ColumnFirst - ColumnSecond) == 1 && System.Math.Abs(RowFirst - RowSecond) == 2)
            {
                if (Order == 1)
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == -6)
                            return false;
                }
                else
                {
                    if (ExistInDestinationEnemy)
                        if (Table[RowSecond, ColumnSecond] == 6)
                            return false;

                }
                return true;
            }

            return false;
        }
        public bool SoldierRules(int RowFirst, int ColumnFirst, int RowSecond, int ColumnSecond, bool NotMoved, Color color, bool ExistInDestinationEnemy)
        {
            if (color == Color.Gray)
            {
                if (ColumnFirst > ColumnSecond)
                    return false;
            }
            else
                if (color == Color.Brown)
                {
                    if (ColumnFirst < ColumnSecond)
                        return false;
                }
            //When Soldier Not Moved in Original Location do
            if (NotMoved)
            {
                if (color == Color.Gray && Order == 1)
                {
                    //Depend on First Move do For Land Of Islam
                    if ((RowFirst == RowSecond) && (ColumnSecond == ColumnFirst + 2 || ColumnSecond == ColumnFirst + 1) && Table[RowFirst, ColumnFirst + 1] == 0)
                        {
                            if (Table[RowSecond, ColumnSecond] == 0)
                                return true;
                            else
                                return false;
                        }
                        else
                            if (ColumnSecond == ColumnFirst + 1)
                            {
                                if ((RowFirst == RowSecond - 1 || RowFirst == RowSecond + 1) && ExistInDestinationEnemy)
                                {
                                       // if (ExistInDestinationEnemy)
                                       //     if (Table[RowSecond, ColumnSecond] == -6)
                                        //        return false;                                    
                                    return true;
                                }

                            }
                }
                else
                    if (Order == -1)
                    {
                        //Depend Of First Move do For Positivism
                        if ((RowFirst == RowSecond)&&(ColumnFirst == ColumnSecond + 2 || ColumnFirst == ColumnSecond + 1) && Table[RowSecond, ColumnSecond + 1] == 0)
                             {
                                if (Table[RowSecond, ColumnSecond] == 0)
                                    return true;
                                else
                                    return false;
                            }
                            else
                                if (ColumnFirst == ColumnSecond + 1)
                                {
                                    if ((RowFirst == RowSecond - 1 || RowFirst == RowSecond + 1) && ExistInDestinationEnemy)
                                    {                                      
                                           // if (ExistInDestinationEnemy)
                                            //    if (Table[RowSecond, ColumnSecond] == 6)
                                             //       return false;

                                         return true;
                                    }

                                }

                    }
            }
            else
            {
                if (color == Color.Gray && Order == 1)
                {
                    //Depend on Second Move do For Land Of Islam
                    if ((RowFirst == RowSecond) && (ColumnSecond == ColumnFirst + 1))
                       {
                            if (Table[RowSecond, ColumnSecond] == 0)
                                return true;
                            else
                                return false;
                        }
                        else
                            if (ColumnSecond == ColumnFirst + 1)
                            {
                                if ((RowFirst == RowSecond - 1 || RowFirst == RowSecond + 1) && ExistInDestinationEnemy)
                                {
                                    
                                     
                                    return true;
                                }

                            }
                }
                else
                    if (Order == -1)
                    {
                        //Depend Of Second Move do For Positivism Land
                        if ((RowSecond == RowFirst) && (ColumnFirst == ColumnSecond + 1))                           
                            {
                                if (Table[RowSecond, ColumnSecond] == 0)
                                    return true;
                                else
                                    return false;
                            }
                            else
                                if (ColumnFirst == ColumnSecond + 1)
                                {
                                    if ((RowFirst == RowSecond - 1 || RowFirst == RowSecond + 1) && ExistInDestinationEnemy)
                                    {
                                        
                                          //  if (ExistInDestinationEnemy)
                                           //     if (Table[RowSecond, ColumnSecond] == -6)
                                           //         return false;
                                        
                                        return true;
                                    }

                                }

                    }
            }
            return false;
        }
    }
}
