﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawSoldier : ThingsConverter
    {
        public int Row, Column;
        public Color color;
        public ThinkingChess[] SoldierThinking = new ThinkingChess[AllDraw.SodierMovments];
        public int[,] Table = null;
        public int Order = 0;
        public int Current = 0;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
       
        public DrawSoldier() { }
        public DrawSoldier(int i, int j, Color a, int[,] Tab, int Ord, bool TB, int Cur) :
            base(i, j, a, Tab, Ord, TB, Cur)
        {
            Table = Tab;
            for (int ii = 0; ii < AllDraw.SodierMovments; ii++)

                SoldierThinking[ii] = new ThinkingChess(i, j, a, Tab, 4, Ord, TB, Cur, 16);
            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;
        }
        public void Clone(ref DrawSoldier AA)
        {
            AA = new DrawSoldier(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.SodierMovments; i++)
            {
                try
                {
                    AA.SoldierThinking[i] = new ThinkingChess();
                    this.SoldierThinking[i].Clone(ref AA.SoldierThinking[i]);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.SoldierThinking[i] = null;
                }
            }
        }
        public void DrawSoldierOnTable(ref Graphics g, int CellW, int CellH)
        {
            if (!ConvertOperation(Row, Column, color, Table, Order, false, Current))
            {

                try
                {
                    if (color == Color.Gray)
                    {
                        g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "SG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                    }
                    else
                    {
                        g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "SB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                    }
                }
                catch (Exception t) { Log(t); }

            }
            else
                if (ConvertedToMinister)
                {
                    try
                    {
                        if (color == Color.Gray)
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }
                        else
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }
                    }
                    catch (Exception t) { Log(t); }
                }
                else if (ConvertedToBridge)
                {
                    try
                    {
                        if (color == Color.Gray)
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "BrG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }
                        else
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "BrB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }
                    }
                    catch (Exception t) { Log(t); }
                }
                else if (ConvertedToHourse)
                {

                    try
                    {
                        if (color == Color.Gray)
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "HG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }
                        else
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "HB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }
                    }
                    catch (Exception t) { Log(t); }

                }
                else if (ConvertedToElefant)
                {
                    try
                    {
                        if (color == Color.Gray)
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "EG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }
                        else
                        {
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "EB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                        }

                    }
                    catch (Exception t) { Log(t); }
                }
        }
    }

}
