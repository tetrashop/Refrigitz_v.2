﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawElefant
    {
        public int Row, Column;
        public ThinkingChess[] ElefantThinking = new ThinkingChess[AllDraw.ElefantMovments];
        public int[,] Table = null;
        public Color color;
        public int Current = 0;
        public int Order;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
       

        public DrawElefant() { }
            public DrawElefant(int i, int j, Color a, int[,] Tab, int Ord, bool TB,int Cur)
        {
            Table = Tab;
            for (int ii = 0; ii < AllDraw.ElefantMovments; ii++)
                ElefantThinking[ii] = new ThinkingChess(i, j, a, Tab, 16, Ord, TB,Cur,4);

            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;
    
        }
        public void Clone(ref DrawElefant AA)
        {
            AA = new DrawElefant(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.ElefantMovments; i++)
            {
                try
                {
                    AA.ElefantThinking[i] = new ThinkingChess();
                    this.ElefantThinking[i].Clone(ref AA.ElefantThinking[i]);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.ElefantThinking[i]=null;
                }
            }
             }
        public void DrawElefantOnTable(ref Graphics g, int CellW, int CellH)
        {
            try
            {
                if (color == Color.Gray)
                {
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot+"EG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }
                else
                {
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot+"EB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }
            }
            catch (Exception t)
            {
                Log(t);
            }
        }

    }
}
