﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawSoldier : ThingsConverter
    {
        //Iniatate Global Variables.
        public float RowS, ColumnS;
        public Color color;
        public ThinkingChess[] SoldierThinking = new ThinkingChess[AllDraw.SodierMovments];
        public int[,] Table = null;
        public int Order = 0;
        public int Current = 0;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { Log(t); }
        }
       //Constructor 1.
        public DrawSoldier() { }
        //Constructor 2.
        public DrawSoldier(float i, float j, Color a, int[,] Tab, int Ord, bool TB, int Cur) :
            base((int)i, (int)j, a, Tab, Ord, TB, Cur)
        {
            //Initiate Global Variables.  
            Table = Tab;
            for (int ii = 0; ii < AllDraw.SodierMovments; ii++)

                SoldierThinking[ii] = new ThinkingChess((int)i, (int)j, a, Tab, 4, Ord, TB, Cur, 16);
            RowS = i;
            ColumnS = j;
            color = a;
            Order = Ord;
            Current = Cur;
        }
        //Clone a Copy Method.
        public void Clone(ref DrawSoldier AA,ref FormRefrigtz THIS)
        {
            //Initiate a Object and Assignemt of a Clone to Construction of a Copy.
            AA = new DrawSoldier(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
           
            for (int i = 0; i < AllDraw.SodierMovments; i++)
            {
                try
                {
                    AA.SoldierThinking[i] = new ThinkingChess();
                    this.SoldierThinking[i].Clone(ref AA.SoldierThinking[i],ref THIS);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.SoldierThinking[i] = null;
                }
            }
        }
        //Drawing Soldiers On the Table Method..
        public void DrawSoldierOnTable(ref Graphics g, int CellW, int CellH)
        {
            //When Conversion Solders Not Occured.
            if (!ConvertOperation((int)Row, (int)Column, color, Table, Order, false, Current))
            {

                try
                {
                    //If Order is Gray.
                    if (color == Color.Gray)
                    {
                        //Draw an Instant from File of Gray Soldeirs.
                        g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "SG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                    }
                    else
                    {
                        //Draw an Instatnt of Brown Soldier File On the Table.
                        g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "SB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                    }
                }
                catch (Exception t) { Log(t); }

            }
            else//If Minsister Conversion Occured.
                if (ConvertedToMinister)
                {
                    try
                    {
                        //Color of Gray.
                        if (color == Color.Gray)
                        {
                            //Draw of Gray Minsister Image File By an Instant.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                        }
                        else
                        {
                            //Draw a Image File on the Table Form n Instatnt One.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                        }
                    }
                    catch (Exception t) { Log(t); }
                }
                else if (ConvertedToBridge)//When Bridged Converted.
                {
                    try
                    {
                        //Color of Gray.
                        if (color == Color.Gray)
                        {
                            //Create on the Inststant of Gray Bridges Images.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "BrG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                        }
                        else
                        {
                            //Creat of an Instant of Brown Image Bridges.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "BrB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                        }
                    }
                    catch (Exception t) { Log(t); }
                }
                else if (ConvertedToHourse)//When Hourse Conversion Occured.
                {

                    try
                    {
                        //Color of Gray.
                        if (color == Color.Gray)
                        {
                            //Draw an Instatnt of Gray Hourse Image File.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "HG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (int)CellH), CellW, CellH));
                        }
                        else
                        {
                            //Creat of an Instatnt Hourse Image File.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "HB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                        }
                    }
                    catch (Exception t) { Log(t); }

                }
                else if (ConvertedToElefant)//When Elephant Conversion.
                {
                    try
                    {
                        //Color of Gray.
                        if (color == Color.Gray)
                        {
                            //Draw an Instatnt Image of Gray Elephant.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "EG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                        }
                        else
                        {
                            //Draw of Instant Image of Brwon Elephant.
                            g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "EB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                        }

                    }
                    catch (Exception t) { Log(t); }
                }
        }
    }

}
//End of Documentation.