﻿/****************************************************************************
 * Thinking Operation class.*************************************************
 * Ramin Edjlal**************************************************************
 * Drived Classess of Autamata Cellular Quantum Thinking Kernel**************
 * 1394/12/19****************************************************************
 * Crashed with Stack Overflow Exception*************************************(+)
 * Drives Caused Memory lack*************************************************(+)
 * New Version Cased Stack Overflow******************************************(+)
 * Scanning Four Dimension Homes of Thing Existences Taking A lot Of Time****(+)
 * All Data in This Scope From AllDraw Become Clear When Scope Changes*******(+)
 * Heuristic Work but the Movements And Attack Method Doesn’t work***********(+)
 * Probability Heuristic constant Table return*******************************(+)
 * Heuristic Working Not Constant Immunity***********************************(+)
 * Heuristic Constant Result Mechanism***************************************(+)
 * Things Order and Virtualization Error*************************************(+)
 * Misleading Things Order movement******************************************(+)
 * Multi Movements (3 ) In Chess Thinking************************************(+)
 * Location of Horse 'Bob' (Gray) After Hitting Un logically Unsupported*****(+)
 * Kish Thinking 'Alice' Malfunction*****************************************(+)
 * 'Mate' By 'Bob' Have Not Been Recognized.*********************************(+)
 * 'Kish' By 'Bob' Not Recognized.*******************************************(+)
 * 'Kish' 'Alice' Detected. No Action Was Done.******************************(+)
 * 'Kish' Mechanism Failure.*************************************************(+)
 * Strategy By 'Alice' Changed. 'Kish' Not Recognized By 'Alice'.************(+)
 * Heuristic Loop************************************************************(+)
 * 'Kish' Mechanism For Penalty Regard Is Malfunction************************(*)
 * Things Location Failure. Row and Column of this Objects class Malfunction*(+)
 * Malfunction Of Operating Lists in this class.*****************************(+)
 * Some Movements of All Possible Movements is not Identified****************(+)
 * Malfunction Clone Data To be Copied. List Will be erased******************(+)
 * King Cannot Hit Unsupported Enemy Things at Kish.*************************(+)
 * Thinking Time Taking al lot of time.**************************************(+)
 * There is No Reason For Mal Function of Thinking.**************************[+]
 * Huristic Supported at horse huristic cal at table content malfunction.****[+]
 * No Reason for malfunctioning of table content at huristic supported.******[+]
 * Thinking Finished Misleading.bool Variable of Think Finished Not Work on.*(+) 
 * A non Identified King Table List Alice is in List and Unhabitly ignored.**(+)
 * The Location of Penalty Regard Mechansim is Misleading.*******************(+)
 * Penalty Reagrd List is Empty.No Misleading List of Penalty Regard Mec.****(+)
 * No Ilegal Non Achmaz and Kish By 'Alice' at Current Game in PR Mech.******(+)
 * **************************************************************************(+:Sum(26)) (*:Sum(1)) 5:(+:Sum(3)) 6.(+:Sum(+))
 * **************************************************************************
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading;
using LearningMachine;
using System.IO;
namespace Refrigtz
{
    public class ThinkingChess
    {
        //Initiate Global Variables.
        public static bool UsePenaltyRegardMechnisam = false;
        public static bool BestMovments = true;
        public static bool PredictHuristic = false;
        public static bool OnlySelf = false;
        public static bool DeptHuristic = false;
        public List<int> HitNumber = new List<int>();
        public static bool NotSolvedKingDanger = false;
        /// public LearningKrinskyAtamata Current = null;
        public static bool ThinkingRun = false;
        int ThingsNumber = 0;
        //bool Init = false;
        int CurrentArray = 0;
        //static bool ExistEnemy = false;
        public double HuristicValue = 0;
        public double HuristicValueMovement = 0;
        public double HuristicValueSupported = 0;
        public double HuristicValueAchmazKishMate = 0;
        public bool ThinkingBegin = false;
        public bool ThinkingFinished = false;
        public int IndexSoldier = 0;
        public int IndexElefant = 0;
        public int IndexHourse = 0;
        public int IndexBridge = 0;
        public int IndexMinister = 0;
        public int IndexKing = 0;
        static public int Index = 0;

        static public int[,] RowColumn;
        public List<int[]> RowColumnSoldier;
        public List<int[]> RowColumnElefant;
        public List<int[]> RowColumnHourse;
        public List<int[]> RowColumnBridge;
        public List<int[]> RowColumnMinister;
        public List<int[]> RowColumnKing;
        public int[,] Table;
        public List<int> HitNumberSoldier;
        public List<int> HitNumberElefant;
        public List<int> HitNumberHourse;
        public List<int> HitNumberBridge;
        public List<int> HitNumberMinister;
        public List<int> HitNumberKing;

        public int[,] TableConst;
        public List<int[,]> TableListSolder = new List<int[,]>();
        public List<int[,]> TableListElefant = new List<int[,]>();
        public List<int[,]> TableListHourse = new List<int[,]>();
        public List<int[,]> TableListBridge = new List<int[,]>();
        public List<int[,]> TableListMinister = new List<int[,]>();
        public List<int[,]> TableListKing = new List<int[,]>();

        public List<double[]> HuristicListSolder = new List<double[]>();
        public List<double[]> HuristicListElefant = new List<double[]>();
        public List<double[]> HuristicListHourse = new List<double[]>();
        public List<double[]> HuristicListBridge = new List<double[]>();
        public List<double[]> HuristicListMinister = new List<double[]>();
        public List<double[]> HuristicListKing = new List<double[]>();

        public List<QuantumAtamata> PenaltyRegardListSolder = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListElefant = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListHourse = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListBridge = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListMinister = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListKing = new List<QuantumAtamata>();
        public int Max;
        public int Row, Column;
        Color color;
        int Order;
        public Thread t = null;
        public List<AllDraw> Dept = null;
        ///Log of Errors.
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); /// path of file where stack trace will be stored.
            }
            catch (Exception t) { Log(t); }
        }
        public ThinkingChess()
        {
            //Clear Dearty Part.
            Dept = new List<AllDraw>();
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            RowColumnSoldier = new List<int[]>();
            RowColumnElefant = new List<int[]>();
            RowColumnHourse = new List<int[]>();
            RowColumnBridge = new List<int[]>();
            RowColumnMinister = new List<int[]>();
            RowColumnKing = new List<int[]>();
            RowColumn = new int[32 * 64, 2];
            HitNumberSoldier = new List<int>();
            HitNumberElefant = new List<int>();
            HitNumberHourse = new List<int>();
            HitNumberBridge = new List<int>();
            HitNumberMinister = new List<int>();
            HitNumberKing = new List<int>();

            PenaltyRegardListSolder = new List<QuantumAtamata>();
            PenaltyRegardListElefant = new List<QuantumAtamata>();
            PenaltyRegardListHourse = new List<QuantumAtamata>();
            PenaltyRegardListBridge = new List<QuantumAtamata>();
            PenaltyRegardListMinister = new List<QuantumAtamata>();
            PenaltyRegardListKing = new List<QuantumAtamata>();

        }
        ///Constructor
        public ThinkingChess(int i, int j, Color a, int[,] Tab, int Ma, int Ord, bool ThinkingBeg, int CurA, int ThingN)
        {
            Dept = new List<AllDraw>();
            ThingsNumber = ThingN;
            CurrentArray = CurA;
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            RowColumnSoldier = new List<int[]>();
            RowColumnElefant = new List<int[]>();
            RowColumnHourse = new List<int[]>();
            RowColumnBridge = new List<int[]>();
            RowColumnMinister = new List<int[]>();
            RowColumnKing = new List<int[]>();
            RowColumn = new int[1000000, 2];
            HitNumberSoldier = new List<int>();
            HitNumberElefant = new List<int>();
            HitNumberHourse = new List<int>();
            HitNumberBridge = new List<int>();
            HitNumberMinister = new List<int>();
            HitNumberKing = new List<int>();

            PenaltyRegardListSolder = new List<QuantumAtamata>();
            PenaltyRegardListElefant = new List<QuantumAtamata>();
            PenaltyRegardListHourse = new List<QuantumAtamata>();
            PenaltyRegardListBridge = new List<QuantumAtamata>();
            PenaltyRegardListMinister = new List<QuantumAtamata>();
            PenaltyRegardListKing = new List<QuantumAtamata>();

            Row = i;
            Column = j;
            color = a;
            Max = Ma;
            Table = Tab;
            Index = 0;
            IndexSoldier = 0;
            IndexElefant = 0;
            IndexHourse = 0;
            IndexBridge = 0;
            IndexMinister = 0;
            IndexKing = 0;
            TableConst = new int[8, 8];
            for (int ii = 0;
                ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    TableConst[ii, jj] = Table[ii, jj];
                }
            Order = Ord;
            ThinkingBegin = ThinkingBeg;

        }
        ///Clone a Copy.
        public void Clone(ref ThinkingChess AA,ref FormRefrigtz THIS)
        {
            //Assignment Contert to New Content Object.
            AA = new ThinkingChess();
            AA.color = color;
            AA.Column = Column;
            AA.HuristicValue = HuristicValue;
            AA.HuristicValueMovement = HuristicValueMovement;
            AA.HuristicValueAchmazKishMate = HuristicValueAchmazKishMate;
            AA.HuristicValueSupported = HuristicValueSupported;
            AA.HitNumber = HitNumber;
            AA.HitNumberBridge = HitNumberBridge;
            AA.HitNumberElefant = HitNumberElefant;
            AA.HitNumberHourse = HitNumberHourse;
            AA.HitNumberKing = HitNumberKing;
            AA.HitNumberMinister = HitNumberMinister;
            AA.HitNumberSoldier = HitNumberSoldier;
            AA.IndexBridge = IndexBridge;
            AA.IndexElefant = IndexElefant;
            AA.IndexHourse = IndexHourse;
            AA.IndexKing = IndexKing;
            AA.IndexMinister = IndexMinister;
            AA.IndexSoldier = IndexSoldier;
            AA.Max = Max;
            AA.Order = Order;
            AA.Row = Row;
            AA.Dept = new List<AllDraw>();
            if (Dept.Count != 0)
            {
                for (int i = 0; i < Dept.Count; i++)
                    AA.Dept.Add(Dept[i]);
            }

            for (int j = 0; j < RowColumnSoldier.Count; j++)
                AA.RowColumnSoldier.Add(RowColumnSoldier[j]);

            for (int j = 0; j < RowColumnBridge.Count; j++)
                AA.RowColumnBridge.Add(RowColumnBridge[j]);


            for (int j = 0; j < RowColumnElefant.Count; j++)
                AA.RowColumnElefant.Add(RowColumnElefant[j]);
           
            for (int j = 0; j < RowColumnHourse.Count; j++)
                     AA.RowColumnHourse.Add(RowColumnHourse[j]);

            for (int j = 0; j < RowColumnKing.Count; j++)
                AA.RowColumnKing.Add(RowColumnKing[j]);

            for (int j = 0; j < RowColumnMinister.Count; j++)
                AA.RowColumnMinister.Add(RowColumnMinister[j]);

            AA.t = t;
            AA.Table = new int[8, 8];
            AA.TableConst = new int[8, 8];
            if (Table != null)
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        AA.Table[i, j] = Table[i, j];
            if (TableConst != null)
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        AA.TableConst[i, j] = TableConst[i, j];
            for (int i = 0; i < TableListBridge.Count; i++)
                AA.TableListBridge.Add(TableListBridge[i]);

            for (int i = 0; i < TableListElefant.Count; i++)
                AA.TableListElefant.Add(TableListElefant[i]);

            for (int i = 0; i < TableListHourse.Count; i++)
                AA.TableListHourse.Add(TableListHourse[i]);

            for (int i = 0; i < TableListKing.Count; i++)
                AA.TableListKing.Add(TableListKing[i]);

            for (int i = 0; i < TableListMinister.Count; i++)
                AA.TableListMinister.Add(TableListMinister[i]);

            for (int i = 0; i < TableListSolder.Count; i++)
                AA.TableListSolder.Add(TableListSolder[i]);


            for (int i = 0; i < HuristicListSolder.Count; i++)
                AA.HuristicListSolder.Add(HuristicListSolder[i]);


            for (int i = 0; i < HuristicListElefant.Count; i++)
                AA.HuristicListElefant.Add(HuristicListElefant[i]);

            for (int i = 0; i < HuristicListHourse.Count; i++)
                AA.HuristicListHourse.Add(HuristicListHourse[i]);


            for (int i = 0; i < HuristicListBridge.Count; i++)
                AA.HuristicListBridge.Add(HuristicListBridge[i]);

            for (int i = 0; i < HuristicListMinister.Count; i++)
                AA.HuristicListMinister.Add(HuristicListMinister[i]);

            for (int i = 0; i < HuristicListKing.Count; i++)
                AA.HuristicListKing.Add(HuristicListKing[i]);

         

            for (int i = 0; i < PenaltyRegardListSolder.Count; i++)
                AA.PenaltyRegardListSolder.Add(PenaltyRegardListSolder[i]);


            for (int i = 0; i < PenaltyRegardListElefant.Count; i++)
                AA.PenaltyRegardListElefant.Add(PenaltyRegardListElefant[i]);

            for (int i = 0; i < PenaltyRegardListHourse.Count; i++)
                AA.PenaltyRegardListHourse.Add(PenaltyRegardListHourse[i]);


            for (int i = 0; i < PenaltyRegardListBridge.Count; i++)
                AA.PenaltyRegardListBridge.Add(PenaltyRegardListBridge[i]);

            for (int i = 0; i < PenaltyRegardListMinister.Count; i++)
                AA.PenaltyRegardListMinister.Add(PenaltyRegardListMinister[i]);

            for (int i = 0; i < PenaltyRegardListKing.Count; i++)
                AA.PenaltyRegardListKing.Add(PenaltyRegardListKing[i]);

            AA.ThinkingBegin = ThinkingBegin;
            AA.ThinkingFinished = ThinkingFinished;
          
        }
        ///Determine of Chossing Max Hitting Value in Hit State.
        int MaxOrderEnemyAndSelf(int[,] Tab, int i, int j, int ii, int jj, int Order)
        {
            //Initiate Local Variable.
            int MaxOrder = 0;
            //When is Gray Order.
            if (Order == 1)
            {
                //For Gray Things.
                if (Tab[i, j] > 0)
                {
                    //Find Maximum Hitting Movments.
                    int Store = Tab[ii, jj];
                    Tab[ii, jj] = 0;
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                            if (!Attack(Tab, iii, jjj, i, j, Color.Brown, Order))
                            {
                                if (System.Math.Abs(Tab[i, j]) < System.Math.Abs(Tab[ii, jj]))
                                    MaxOrder = Tab[ii, jj];
                                else
                                    MaxOrder = Tab[i, j];
                            }
                    Tab[ii, jj] = Store;

                }

            }
            //For Brown Order.
            if (Order == -1)
            {
                //For Brown Objects.
                if (Tab[i, j] < 0)
                {
                    //Find Maximum Brown Hitting Movments.
                    int Store = Tab[ii, jj];
                    Tab[ii, jj] = 0;
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                            if (!Attack(Tab, iii, jjj, i, j, Color.Brown, Order))
                            {
                                if (System.Math.Abs(Tab[i, j]) < System.Math.Abs(Tab[ii, jj]))
                                    MaxOrder = Tab[ii, jj];
                                else
                                    MaxOrder = Tab[i, j];
                            }
                    Tab[ii, jj] = Store;
                }

            }
            //return Maximum Hitting.
            return MaxOrder;

        }
        ///Huristic of Attacker.
        float HuristicAttack(int[,] Table, int Order, Color a)
        {
            int HA = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            ///When Dept Huristic is Not Assigned.
            if (!DeptHuristic)
            {
                ///For Every Objects.
                int i = Row, j = Column;
                ///For All Movments.
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        if (i == ii && j == jj)
                            continue;
                        int Sign = 1;
                        Order = DummyOrder;
                        ///When Attack is true. means [ii,jj] is in Attacked  [i,j].
                        ///What is Attack!
                        ///Ans:When [ii,jj] is Attacked [i,j] return true when enemy is located in [ii,jj].
                        if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                        {
                            Order = 1;
                            Sign = -1;
                            ChessRules.CurrentOrder = 1;
                            a = Color.Gray;
                        }
                        else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                        {
                            Order = -1;
                            Sign = -1;
                            ChessRules.CurrentOrder = -1;
                            a = Color.Brown;
                        }
                        else
                            if (Table[ii, jj] < 0 && DummyOrder == -1 && Table[i, j] > 0)
                            {
                                Order = -1;
                                Sign = -1;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Gray;
                            }
                            else if (Table[ii, jj] > 0 && DummyOrder == 1 && Table[i, j] < 0)
                            {
                                Order = 1;
                                Sign = -1;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Brown;
                            }
                            else
                                continue;
                        //For Attack Movments.
                        if (Attack(Table, ii, jj, i, j, a, Order))
                        {
                            //Finf Huristic Value Of Current and Add to Sumation.
                          //  if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                          //      HA += MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                           // else
                            {
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    HA += AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    HA += AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    HA += AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    HA += AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    HA += AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    HA += AllDraw.KingValue * Sign;
                            }



                        }





                    }
                }

            }
                //For All Table Homes find Attack Huristic.
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                Order = DummyOrder;
                                int Sign = 1;
                                ///When Attack is true. means [ii,jj] is in Attacked  [i,j].
                                ///What is Attack!
                                ///Ans:When [ii,jj] is Attacked [i,j] return true when enemy is located in [ii,jj].
                                if (Table[ii, jj] > 0 && Order == -1 && Table[i, j] < 0)
                                {
                                    Order = 1;
                                    Sign = -1;
                                    ChessRules.CurrentOrder = 1;
                                    a = Color.Gray;
                                }
                                else if (Table[ii, jj] < 0 && Order == 1 && Table[i, j] > 0)
                                {
                                    Order = -1;
                                    Sign = -1;
                                    ChessRules.CurrentOrder = -1;
                                    a = Color.Brown;
                                }
                                else
                                    if (Table[ii, jj] < 0 && Order == -1 && Table[i, j] > 0)
                                    {
                                        Order = -1;
                                        Sign = -1;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Gray;
                                    }
                                    else if (Table[ii, jj] > 0 && Order == 1 && Table[i, j] < 0)
                                    {
                                        Order = 1;
                                        Sign = -1;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Brown;
                                    }
                                    else
                                        continue;
                               //For Attack Movments.
                                if (Attack(Table, ii, jj, i, j, a, Order))
                                {
                                    //Find Huristic Movments Attack.
                              //      if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                              //          HA += MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                              //      else
                                    {
                                        if (System.Math.Abs(Table[i, j]) == 1)
                                            HA += AllDraw.SodierValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 2)
                                            HA += AllDraw.ElefantValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 3)
                                            HA += AllDraw.HourseValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 4)
                                            HA += AllDraw.BridgeValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 5)
                                            HA += AllDraw.MinisterValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 6)
                                            HA += AllDraw.KingValue * Sign;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //Initiate to Begin Call Orders.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //Add Local Huristic to Global One.
            HuristicValue += HA;
            return HA;
        }
        ///Huristic of Achmaz.
        float HuristicAchmaz(int[,] Table, int Order, Color a)
        {
            int HA = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            ///When There is no DeptHuristic
            if (!DeptHuristic)
            {
                ///For Every Object.
                int i = Row, j = Column;
                ///For All Object in Current Table.
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        if (i == ii && j == jj)
                            continue;
                        Order = DummyOrder;
                        int Sign = 1;
                        ///When Achmaz is true. means [ii,jj] is in Achmaz by [i,j].
                        ///What is Achmaz!
                        ///Ans:When [i,j] is Attacked [ii,jj] return true when enemy is located in [ii,jj].
                        if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                        {
                            Order = 1;
                            Sign = -1;
                            ChessRules.CurrentOrder = 1;
                            a = Color.Gray;
                        }
                        else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                        {
                            Order = 1;
                            Sign = -1;
                            ChessRules.CurrentOrder = 1;
                            a = Color.Brown;
                        }
                        else
                            if (Table[ii, jj] < 0 && DummyOrder == -1 && Table[i, j] > 0)
                            {
                                Order = -1;
                                Sign = -1;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Gray;
                            }
                            else if (Table[ii, jj] > 0 && DummyOrder == 1 && Table[i, j] < 0)
                            {
                                Order = 1;
                                Sign = -1;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Brown;
                            }
                            else
                                continue;
                        //For Achmaz Movments.
                        if (Achmaz(Table, ii, jj, i, j, a, Order))
                        {
                            //Find Local Sumation of Achmaz Huristic.
                        //    if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                         //       HA += MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                        //    else
                            {
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    HA += AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    HA += AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    HA += AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    HA += AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    HA += AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    HA += AllDraw.KingValue * Sign;
                            }



                        }





                    }
                }

            }
                //For All Table Home Find Achmaz Huristic
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                int Sign = 1;
                                ///When Achmaz is true. means [ii,jj] is in Achmaz by [i,j].
                                ///What is Achmaz!
                                ///Ans:When [i,j] is Attacked [ii,jj] return true when enemy is located in [ii,jj].
                                if (Table[ii, jj] > 0 && Order == -1 && Table[i, j] < 0)
                                {
                                    Order = 1;
                                    Sign = -1;
                                    ChessRules.CurrentOrder = 1;
                                    a = Color.Gray;
                                }
                                else if (Table[ii, jj] < 0 && Order == 1 && Table[i, j] > 0)
                                {
                                    Order = -1;
                                    Sign = -1;
                                    ChessRules.CurrentOrder = -1;
                                    a = Color.Brown;
                                }
                                else
                                    if (Table[ii, jj] < 0 && Order == -1 && Table[i, j] > 0)
                                    {
                                        Order = -1;
                                        Sign = -1;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Gray;
                                    }
                                    else if (Table[ii, jj] > 0 && Order == 1 && Table[i, j] < 0)
                                    {
                                        Order = 1;
                                        Sign = -1;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Brown;
                                    }
                                    else
                                        continue;
                                //For Current Movments of legal Movments.
                                if (Achmaz(Table, ii, jj, i, j, a, Order))
                                {
                                    //Find Achmaz Huristic Locals.
                            //        if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                           //             HA += MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                           //         else
                                    {
                                        if (System.Math.Abs(Table[i, j]) == 1)
                                            HA += AllDraw.SodierValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 2)
                                            HA += AllDraw.ElefantValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 3)
                                            HA += AllDraw.HourseValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 4)
                                            HA += AllDraw.BridgeValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 5)
                                            HA += AllDraw.MinisterValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 6)
                                            HA += AllDraw.KingValue * Sign;

                                    }

                                }





                            }
                        }
                    }
                }
            }
            //Initiate Orders to Call Begining.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //Assignments of Global Huristic with Local One.
            HuristicValueAchmazKishMate += HA;
            //return Local Huristic.
            return HA;
        }
        void HuristicHitting(int[,] Tab, int ii, int jj, int Order, Color a, bool Hit)
        {
            //Defualt is Gray Order.
            int Sign = 1;
            //For Brown One.
            if (Tab[ii, jj] < 0)
                Sign = -1;
            //If Hitting Occured Find Positive Hitting Huristic.
            if (Hit)
                HuristicValue += (float)(Tab[ii, jj] * Sign);
        }
        ///Huristic of Suportation.
        float HuristicSupported(int[,] Tab, int Order, Color a)
        {
            //Initiate Local Vrariables.
            int HA = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            //If There is Not Dept Huristic Boolean Value.
            if (!DeptHuristic)
            {
                //For Current Object Lcation.
                int i = Row, j = Column;
                //In All Homes of Table.
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        //Ignore Current Unnessery Home.
                        if (i == ii && j == jj)
                            continue;
                        //Default Is Gray One.
                        int Sign = 1;
                        Order = DummyOrder;
                        ///When Supporte is true. means [ii,jj] is in Supportes [i,j].
                        ///What is Supporte!
                        ///Ans:When [i,j] is Supporte [ii,jj] return true when Self is located in [ii,jj].
                        if (Table[ii, jj] < 0 && DummyOrder == -1 && Table[i, j] < 0)
                        {
                            Order = -1;
                            Sign = 1;
                            ChessRules.CurrentOrder = -1;
                            a = Color.Gray;
                        }
                        else if (Table[ii, jj] > 0 && DummyOrder == 1 && Table[i, j] > 0)
                        {
                            Order = 1;
                            Sign = 1;
                            ChessRules.CurrentOrder = 1;
                            a = Color.Brown;
                        }
                        else
                            if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] > 0)
                            {
                                Order = 1;
                                Sign = 1;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Gray;
                            }
                            else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] < 0)
                            {
                                Order = -1;
                                Sign = -1;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Brown;
                            }
                            else
                                continue;
                        //For Support Movments.
                        if (Support(Tab, ii, jj, i, j, a, Order))
                        {
                            //Calculate Local Support Huristic.
                          //  if (System.Math.Abs(Tab[i, j]) < MaxOrderEnemyAndSelf(Tab, i, j, ii, jj, Order))
                            //    HA += MaxOrderEnemyAndSelf(Tab, i, j, ii, jj, Order) * Sign;
                           // else
                            {
                                if (System.Math.Abs(Tab[i, j]) == 1)
                                    HA += AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 2)
                                    HA += AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 3)
                                    HA += AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 4)
                                    HA += AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 5)
                                    HA += AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Tab[i, j]) == 6)
                                    HA += AllDraw.KingValue * Sign;
                            }
                        }


                    }
                }

            }
                //For All Homes Table.
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                //Ignore Current Home.
                                if (i == ii && j == jj)
                                    continue;
                                //Initiate Local Variables.
                                int Sign = 1;
                                Order = DummyOrder;
                                ///When Supporte is true. means [ii,jj] is in Supported.by [i,j].
                                ///What is Supporte!
                                ///Ans:When [i,j] is Supporte [ii,jj] return true when Self is located in [ii,jj].
                                if (Table[ii, jj] < 0 && Order == -1 && Table[i, j] < 0)
                                {
                                    Order = -1;
                                    Sign = 1;
                                    ChessRules.CurrentOrder = -1;
                                    a = Color.Gray;
                                }
                                else if (Table[ii, jj] > 0 && Order == 1 && Table[i, j] > 0)
                                {
                                    Order = 1;
                                    Sign = 1;
                                    ChessRules.CurrentOrder = 1;
                                    a = Color.Brown;
                                }
                                else
                                    if (Table[ii, jj] > 0 && Order == -1 && Table[i, j] > 0)
                                    {
                                        Order = 1;
                                        Sign = -1;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Gray;
                                    }
                                    else if (Table[ii, jj] < 0 && Order == 1 && Table[i, j] < 0)
                                    {
                                        Order = -1;
                                        Sign = -1;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Brown;
                                    }
                                    else
                                        continue;
                                //For Support Movments.
                                if (Support(Table, ii, jj, i, j, a, Order))
                                {
                                //    if (System.Math.Abs(Tab[i, j]) < MaxOrderEnemyAndSelf(Tab, i, j, ii, jj, Order))
                                //        HA += MaxOrderEnemyAndSelf(Tab, i, j, ii, jj, Order) * Sign;
                                //    else
                                    {
                                        if (System.Math.Abs(Tab[i, j]) == 1)
                                            HA += AllDraw.SodierValue * Sign;
                                        else if (System.Math.Abs(Tab[i, j]) == 2)
                                            HA += AllDraw.ElefantValue * Sign;
                                        else if (System.Math.Abs(Tab[i, j]) == 3)
                                            HA += AllDraw.HourseValue * Sign;
                                        else if (System.Math.Abs(Tab[i, j]) == 4)
                                            HA += AllDraw.BridgeValue * Sign;
                                        else if (System.Math.Abs(Tab[i, j]) == 5)
                                            HA += AllDraw.MinisterValue * Sign;
                                        else if (System.Math.Abs(Tab[i, j]) == 6)
                                            HA += AllDraw.KingValue * Sign;
                                    }


                                }
                            }
                        }
                    }
                }
            }
            //Reassignments of Global Orders with Local Begining One.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            HuristicValueSupported += HA;
            return HA;
        }
        ///Identification of Equality
        static bool TableEqual(int[,] Tab1, int[,] Tab2)
        {
            try
            {
                //For All Home
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        //When there is different values in same location of tow Table return non equality.
                        if (Tab1[i, j] != Tab2[i, j])
                            return false;
                    }
                //Else return equlity.
                return true;
            }
            catch (Exception t)
            {
                Log(t);
                return false;
            }
        }
        ///Deterimination of Existance of Table in List.
        static public bool ExistTableInList(int[,] Tab, List<int[,]> List, int Index)
        {
            //Initiate Local Variables.
            bool Exist = false;
            //For All Tables of Table List.
            for (int i = Index; i < List.Count; i++)
            {
                //Strore Equality Value.
                bool Eq = TableEqual(Tab, List[i]);
                //When is Equality is Occurred.
                if (Eq)
                {
                    //Store Equality Local Value in a Global static value.
                    AllDraw.LoopHuristicIndex = i;
                    return Eq;
                }
                Exist |= Eq;
            }
            //return Equality Local value of all lists.
            return Exist;
        }
        ///Thinking of Mate
        public bool ThinkMate(int i, int j)
        {
            //If Current Location is Kings.
            if (System.Math.Abs(Table[Row, Column]) == 6)
            {
                //When King is Moveble to Parameter Location is not mate.
                if ((new ChessRules(Table[Row, Column], Table, Order)).Rules(Row, Column, i, j, color, 1))
                {
                    Table[i, j] = Table[Row, Column];
                    Table[i, j] = 0;
                    return false;
                }
            }
            //return Mate.
            return true;
        }
        ///Move Determination.
        public bool Movable(int[,] Table, int i, int j, int ii, int jj, Color a, int Order)
        {
            //Initiate Local Variables.
            int Store = Table[ii, jj];
            ///Table[ii, jj] = 0;
            //Menen Parameter is Moveble to Second Parameters Location returm Movable.
            if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Order))
            {
                //Initiate Movments.
                Table[ii, jj] = 0;
                Table[ii, jj] = Table[i, j];
                //Default Order Assignments.
                int Ord = 1;
                //Brown Order Consideration.
                if (Table[ii, jj] < 0)
                    Ord = -1;
                //Store of Local Order Assignments in Global Assignments.
                int Dummy = ChessRules.CurrentOrder;
                ChessRules.CurrentOrder = Ord;
                //Consider Global Kish Variables.
                (new ChessRules(Table[ii, jj], Table, Ord)).Kish(Table, Ord);
                //Reaasignment of Premitive Variables.
                ChessRules.CurrentOrder = Dummy;
                //Reassignments of Table Content and Consider Mate Specific Order.
                Table[i, j] = Table[ii, jj];

                if (Table[i, j] > 0)
                {
                    Table[ii, jj] = Store;
                    if (ChessRules.MateGray)
                        return false;


                    return true;
                }


                if (Table[i, j] < 0)
                {
                    Table[ii, jj] = Store;
                    if (ChessRules.MateBrown)
                        return false;
                    return true;
                }


            }

            Table[ii, jj] = Store;
            return false;
        }
        ///Huristic of Kish and Mate.
        public void HuristicKishAndMate(int[,] Table, Color a)
        {
            if (DeptHuristic)
            {
                //Consider Global Kish Mate Achmaz Variables Orderly.
                (new ChessRules(1, Table, Order)).Mate(Table, Order);
                (new ChessRules(1, Table, Order)).AchmazKingMove(Order, Table, false);
                {
                    //Consider Value to More Valuable Positive and Negative Kish Mate Achmaz 
                    if (ChessRules.MateGray || ChessRules.MateBrown)
                    {
                        if (Order == 1 && ChessRules.MateBrown)
                        {
                            HuristicValueAchmazKishMate += 100000;
                        }
                        if (Order == -1 && ChessRules.MateGray)
                        {
                            HuristicValueAchmazKishMate += 100000;
                        }
                    }

                    if (ChessRules.KishGray || ChessRules.KishBrown)
                    {

                        if (Order == 1 && ChessRules.KishBrown)
                        {
                            HuristicValueAchmazKishMate += 50000;
                        }
                        if (Order == -1 && ChessRules.KishGray)
                        {
                            HuristicValueAchmazKishMate += 50000;
                        }
                    }

                    if (ChessRules.KishGrayAchmaz || ChessRules.KishBrownAchmaz)
                    {

                        if (Order == 1 && ChessRules.KishBrownAchmaz)
                        {
                            HuristicValueAchmazKishMate += 30000;
                        }
                        if (Order == -1 && ChessRules.KishGrayAchmaz)
                        {
                            HuristicValueAchmazKishMate += 30000;
                        }
                    }
                    if (ChessRules.MateGray || ChessRules.MateBrown)
                    {

                        if (Order == 1 && ChessRules.MateGray)
                        {
                            HuristicValueAchmazKishMate -= 100000;
                        }
                        if (Order == -1 && ChessRules.MateBrown)
                        {
                            HuristicValueAchmazKishMate -= 100000;
                        }
                    }

                    if (ChessRules.KishGray || ChessRules.KishBrown)
                    {

                        if (Order == 1 && ChessRules.KishGray)
                        {
                            HuristicValueAchmazKishMate -= 50000;
                        }
                        if (Order == -1 && ChessRules.KishBrown)
                        {
                            HuristicValueAchmazKishMate -= 50000;
                        }
                    }
                    if (ChessRules.KishBrownAchmaz || ChessRules.KishGrayAchmaz)
                    {

                        if (Order == 1 && ChessRules.KishGrayAchmaz)
                        {
                            HuristicValueAchmazKishMate -= 30000;
                        }
                        if (Order == -1 && ChessRules.KishBrownAchmaz)
                        {
                            HuristicValueAchmazKishMate -= 30000;
                        }
                    }

                }
            }
        }
        ///Huristic of Movments.
        public float HuristicMovment(int[,] Table, Color a)
        {
            //Initiate Local Variable.
            int HA = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            ///When Dept Huristic is Not Assigned.
            if (!DeptHuristic)
            {
                ///For Current Objects.
                int i = Row, j = Column;
                for (int ii = 0; ii < 8; ii++)
                {
                    for (int jj = 0; jj < 8; jj++)
                    {
                        if (i == ii && j == jj)
                            continue;
                        Order = DummyOrder;
                        int Sign = 1;
                        ///When Moveble is true. means [i,j] is in Movmebale to [ii,jj].
                        ///What is Moveable!
                        ///Ans:When [i,j] is Movebale to [ii,jj] return true when Empty or Enemy is located in [ii,jj].
                        if (Table[ii, jj] >= 0 && DummyOrder == -1 && Table[i, j] < 0)
                        {
                            Order = -1;
                            Sign = 1;
                            ChessRules.CurrentOrder = -1;
                            a = Color.Gray;
                        }
                        else if (Table[ii, jj] <= 0 && DummyOrder == 1 && Table[i, j] > 0)
                        {
                            Order = 1;
                            Sign = 1;
                            ChessRules.CurrentOrder = 1;
                            a = Color.Brown;
                        }
                        else
                            continue;
                        //When is Movable Movement inCurrent.
                        if (Movable(Table, i, j, ii, jj, a, Order))
                        {
                            //Calculate Local Huristic Sumation.
                        //    if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                         //       HA += MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                         //   else
                            {
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    HA += AllDraw.SodierValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    HA += AllDraw.ElefantValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    HA += AllDraw.HourseValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    HA += AllDraw.BridgeValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    HA += AllDraw.MinisterValue * Sign;
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    HA += AllDraw.KingValue * Sign;
                            }
                        }

                    }
                }

            }
                //For All Homes Table.
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        for (int ii = 0; ii < 8; ii++)
                        {
                            for (int jj = 0; jj < 8; jj++)
                            {
                                if (i == ii && j == jj)
                                    continue;
                                int Sign = 1;
                                Order = DummyOrder;
                                ///When Moveble is true. means [i,j] is in Movmebale to [ii,jj].
                                ///What is Moveable!
                                ///Ans:When [i,j] is Movebale to [ii,jj] return true when Empty or Enemy is located in [ii,jj].
                                if (Table[ii, jj] >= 0 && Order == -1 && Table[i, j] < 0)
                                {
                                    Order = -1;
                                    Sign = 1;
                                    ChessRules.CurrentOrder = -1;
                                    a = Color.Gray;
                                }
                                else if (Table[ii, jj] <= 0 && Order == 1 && Table[i, j] > 0)
                                {
                                    Order = 1;
                                    Sign = 1;
                                    ChessRules.CurrentOrder = 1;
                                    a = Color.Brown;
                                }
                               else

                                    continue;
                                //If Current Home is Moveble.
                                if (Movable(Table, i, j, ii, jj, a, Order))
                                {
                                    //Caculate Local Huristic.
                           //         if (System.Math.Abs(Table[i, j]) < MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order))
                            //            HA += MaxOrderEnemyAndSelf(Table, i, j, ii, jj, Order) * Sign;
                           //         else
                                    {
                                        if (System.Math.Abs(Table[i, j]) == 1)
                                            HA += AllDraw.SodierValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 2)
                                            HA += AllDraw.ElefantValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 3)
                                            HA += AllDraw.HourseValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 4)
                                            HA += AllDraw.BridgeValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 5)
                                            HA += AllDraw.MinisterValue * Sign;
                                        else if (System.Math.Abs(Table[i, j]) == 6)
                                            HA += AllDraw.KingValue * Sign;
                                    }
                                }

                            }
                        }
                    }
                }
            }
            //Reassignments of Begin Call Global Orders.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //Store Local Huristic in Global One.
            HuristicValueMovement += HA;
            //Return Local Huristic.
            return HA;

        }
        ///Exist Row and Column in Array.
        public bool ExistRowClolumnInArray(int ii, int jj)
        {
            //A non Used Unusful Method Content.
            for (int j = 0; j < Index; j++)
            {
                ///    if (RowColumn[0, j] == ii && RowColumn[1, j] == jj)
                ///        return true;
            }
            return false;
        }
        ///Attack Determination.
        public bool Attack(int[,] Table, int i, int j, int ii, int jj, Color a, int Order)
        {
            //Initiate Global static  Variable.
            ChessRules.KingAttacker = true;
            //when there is a Movment from Parameter One to Second Parameter return Attacke..
            if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Order) && Table[ii, jj] != 0)
            {
                return true;
            }

            return false;
        }
        ///Achmaz Determination.
        public bool Achmaz(int[,] Tab, int i, int j, int ii, int jj, Color a, int Order)
        {
            //Initiate Local Varibales.
            int[,] Table = new int[8, 8];
            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                {
                    Table[iii, jjj] = Tab[iii, jjj];
                }
            Table[ii, jj] = 0;
            ///When [i,j] is Attacked [ii,jj] reterun true when enemy is located in [ii,jj].
            if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Order))
            {
                //Initiate Local Variables.
                for (int iii = 0; iii < 8; iii++)
                    for (int jjj = 0; jjj < 8; jjj++)
                    {
                        Table[iii, jjj] = Tab[iii, jjj];
                    }
                //Take Movments.
                Table[ii, jj] = Table[i, j];
                Table[i, j] = 0;
                //Consider Kish.
                if ((new ChessRules(Table[ii, jj], Table, Order).Kish(Table, Order)))
                    //Return Achmaz.
                    return true;


            }
            //return Non Achmaz.
             return false;
        }
        ///Supportation Determination.
        public bool Support(int[,] Tab, int i, int j, int ii, int jj, Color a, int Order)
        {
            //Initiate Local Variables.
            int[,] Table = new int[8, 8];

            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                    Table[iii, jjj] = Tab[iii, jjj];
            ///When All Tables is Gray.
            if (Table[i, j] > 0 && Table[ii, jj] > 0)
            {
                int Store = Table[ii, jj];
                Table[ii, jj] = 0;
                ///When [i,j] Supporte [ii,jj].
                if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Order))
                {
                    Table[ii, jj] = Store;
                    return true;
                }
                Table[ii, jj] = Store;
            }

            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                    Table[iii, jjj] = Tab[iii, jjj];
            ///When All is Brown.
            if (Table[i, j] < 0 && Table[ii, jj] < 0)
            {
                int Store = Table[ii, jj];
                Table[ii, jj] = 0;
                ///When [i,j] Supporetd [ii,jj].
                if ((new ChessRules(Table[i, j], Table, Order)).Rules(i, j, ii, jj, a, Table[i, j]))
                {
                    Table[ii, jj] = Store;
                    return true;
                }
                Table[ii, jj] = Store;
            }

            return false;
        }

        ///Kernel of Thinking
        public void Thinking()
        {
            ///Initiate Locallly Global Variables. 
            //ExistEnemy = true;
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            HuristicListBridge.Clear();
            HuristicListElefant.Clear();
            HuristicListHourse.Clear();
            HuristicListKing.Clear();
            HuristicListMinister.Clear();
            HuristicListSolder.Clear();
            RowColumnSoldier.Clear();
            RowColumnElefant.Clear();
            RowColumnHourse.Clear();
            RowColumnBridge.Clear();
            RowColumnMinister.Clear();
            RowColumnKing.Clear();
            HitNumberSoldier.Clear();
            HitNumberElefant.Clear();
            HitNumberHourse.Clear();
            HitNumberBridge.Clear();
            HitNumberMinister.Clear();
            HitNumberKing.Clear();


            IndexSoldier = 0;
            IndexElefant = 0;
            IndexHourse = 0;
            IndexBridge = 0;
            IndexMinister = 0;
            IndexKing = 0;

            ///if (ThinkingBegin)
            {
                ///For Stored Location of Objects.
                int ii = Row;
                int jj = Column;
                ///for (int ii = 0; ii < 8; ii++)
                {
                    ///for (int jj = 0; jj < 8; jj++)
                    {
                        ///For Every Tables Home.
                        for (int i = 0; i < 8; i++)
                        {
                            for (int j = 0; j < 8; j++)
                            {
                                ///Current is Ignored for Increased of Performance.
                                if (ii == i && jj == j)
                                    continue;
                                ///Initiate a Local Variables.
                                int[,] TableS = new int[8, 8];
                                ///"Inizialization of This New Class (Current is Dynamic class Object) is MalFunction (Constant Variable Count).
                                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                                ///Most Dot Net FrameWork Hot Path
                                ///Create A Clone of Current Table Constant in ThinkingChess Object Tasble.
                                for (int iii = 0; iii < 8; iii++)
                                    for (int jjj = 0; jjj < 8; jjj++)
                                    {
                                        TableS[iii, jjj] = TableConst[iii, jjj];
                                    }
                                ///Deterimine Current Table Order and Color.
                                if (TableS[ii, jj] > 0 && CurrentArray < ThingsNumber / 2 && Order == 1)
                                    color = Color.Gray;
                                else
                                    if (TableS[ii, jj] < 0 && CurrentArray >= ThingsNumber / 2 && Order == -1)
                                        color = Color.Brown;
                                    else
                                    {
                                        if (!ThinkingBegin)
                                        {
                                            ThinkingFinished = true;
                                            ThinkingRun = false;
                                            return;
                                        }
                                        continue;
                                    }

                                ///Ignore of Additinal Non Profit Objects and Empty Home. 
                                if (Order == 1 && TableS[i, j] > 0)
                                    continue;
                                if (Order == -1 && TableS[i, j] < 0)
                                    continue;
                                if (Order == 1 && TableS[ii, jj] < 0)
                                    continue;
                                if (Order == -1 && TableS[ii, jj] > 0)
                                    continue;
                                ///Deterimine for Bridge King Wrongly Desision.
                                bool Bridge = false;
                                ChessRules.ExistInDestinationEnemy = false;
                                ///Calculate Bridges of Gray King.
                                if (!ChessRules.BridgeActGray && Order == 1 && TableS[ii, jj] == 6)
                                {
                                    //When is Bridges Gray King.
                                    if ((new ChessRules(7, TableS, Order)).Rules(ii, jj, i, j, color, 7))
                                    {
                                        //Predict Huristic Caluculatio Before Movments.
                                        ThinkingRun = true;
                                        HuristicAttack(TableS, Order, color);
                                        HuristicMovment(TableS, color);
                                        HuristicSupported(TableS, Order, color);
                                        HuristicKishAndMate(TableS, color);
                                        HuristicAchmaz(TableS, Order, color);
                                        HuristicAchmaz(TableS, Order, color);
                                       //Act Movments.
                                        if (i < ii)
                                        {
                                            TableS[ii - 1, j] = 4;
                                            TableS[ii - 2, j] = 6;

                                        }

                                        else
                                        {
                                            TableS[ii + 1, j] = 4;
                                            TableS[ii + 2, j] = 6;
                                        }
                                        TableS[ii, jj] = 0;
                                        TableS[i, j] = 0;

                                        //Store Movments Items.
                                        int[] AS = new int[2];
                                        AS[0] = i;
                                        AS[1] = j;
                                        RowColumnKing.Add(AS);
                                        RowColumn[Index, 0] = i;
                                        RowColumn[Index, 1] = j;

                                        Index++;
                                        TableListKing.Add(TableS);
                                        IndexKing++;
                                        Row = i;
                                        Column = j;
                                        //Calculate Movment Huristic After Movments.
                                        if (PredictHuristic)
                                        {
                                            HuristicAttack(TableS, Order, color);
                                            HuristicMovment(TableS, color);
                                            HuristicSupported(TableS, Order, color);
                                            HuristicKishAndMate(TableS, color);
                                            HuristicAchmaz(TableS, Order, color);
                                        }
                                        //Calculate Huristic Sumaton and Stor Specificcaly.
                                        double[] Hu = new double[4];
                                        Hu[0] = HuristicValue;
                                        Hu[1] = HuristicValueMovement;
                                        Hu[2] = HuristicValueSupported;
                                        Hu[3] = HuristicValueAchmazKishMate;
                                        HuristicListKing.Add(Hu);
                                        ChessRules.BridgeActGray = true;

                                        Bridge = true;
                                    }
                                }
                                
                                ///Calculate of Bridges of Brown.
                                    if (!ChessRules.BridgeActBrown && Order == -1 && TableS[ii, jj] == -6)
                                    {
                                        //When is Brown Bridges King.
                                        if ((new ChessRules(-7, TableS, Order)).Rules(ii, jj, i, j, color, -7))
                                        {
                                            //Calcuilate Huristic Before Movment.
                                            ThinkingRun = true;
                                            HuristicAttack(TableS, Order, color);
                                            HuristicMovment(TableS, color);
                                            HuristicSupported(TableS, Order, color);
                                            HuristicKishAndMate(TableS, color);
                                            HuristicAchmaz(TableS, Order, color);
                                            //Act Movment.
                                            if (i < ii)
                                            {
                                                TableS[ii - 1, j] = -4;
                                                TableS[ii - 2, j] = -6;

                                            }

                                            else
                                            {
                                                TableS[ii + 1, j] = -4;
                                                TableS[ii + 2, j] = -6;
                                            }
                                            TableS[ii, jj] = 0;
                                            TableS[i, j] = 0;


                                            //Store Movments Items. 
                                            int[] AS = new int[2];
                                            AS[0] = i;
                                            AS[1] = j;
                                            RowColumnKing.Add(AS);
                                            RowColumn[Index, 0] = i;
                                            RowColumn[Index, 1] = j;
                                            Index++;
                                            TableListKing.Add(TableS);
                                            IndexKing++;
                                            Row = i;
                                            Column = j;
                                            //Calculatre Huristic After Movments.
                                            if (PredictHuristic)
                                            {
                                                HuristicAttack(TableS, Order, color);
                                                HuristicMovment(TableS, color);
                                                HuristicSupported(TableS, Order, color);
                                                HuristicKishAndMate(TableS, color);
                                                HuristicAchmaz(TableS, Order, color);
                                            }
                                            //Calculate Huristic Sumation and Store in Specific List.
                                            double[] Hu = new double[4];
                                            Hu[0] = HuristicValue;
                                            Hu[1] = HuristicValueMovement;
                                            Hu[2] = HuristicValueSupported;
                                            Hu[3] = HuristicValueAchmazKishMate;
                                            HuristicListKing.Add(Hu);
                                            ChessRules.BridgeActBrown = true;
                                            Bridge = true;
                                        }

                                    }
                                ///When Bridges acts Continue.
                                    if (Bridge)
                                        continue;
                                ///For Soldier Thinking
                                        if (System.Math.Abs(TableS[ii, jj]) == 1)
                                        {
                                            ///When There is Movments.
                                            if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                            {
                                                ///Calculate Hit Occured and Value of Object.
                                                bool Hit = false;
                                                int HitNumber = TableS[i, j];
                                                if (System.Math.Abs(TableS[i, j]) > 0)
                                                    Hit = true;
                                                ///Add Table to List of Private.
                                                HitNumberSoldier.Add(TableS[i, j]);
                                                ThinkingRun = true;
                                                ///Predict Huristic.
                                                HuristicAttack(TableS, Order, color);
                                                HuristicMovment(TableS, color);
                                                HuristicSupported(TableS, Order, color);
                                                HuristicKishAndMate(TableS, color);
                                                HuristicAchmaz(TableS, Order, color);
                                                HuristicHitting(TableS, ii, jj, Order, color, Hit);
                                                ///Action of Movements.
                                                TableS[i, j] = TableS[ii, jj];
                                                TableS[ii, jj] = 0;
                                                ///Consideration of Itterative Movments to ignore.
                                                if (ThinkingChess.ExistTableInList(TableS, TableListSolder, 0))
                                                {
                                                    ///Set Predict Huristic and Movments Backward.
                                                    TableS[ii, jj] = TableS[i, j];
                                                    TableS[i, j] = 0;
                                                    HuristicValue = 0;
                                                    HuristicValueMovement = 0;
                                                    HuristicValueSupported = 0;
                                                    HuristicValueAchmazKishMate = 0;

                                                    continue;
                                                }
                                                ///Operation of Penalty Regard Mechanisam on Kish and mate speciffically.
                                                if (UsePenaltyRegardMechnisam)
                                                {
                                                    ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                    if (A.AchmazKingMove(Order, TableS, false))
                                                    {
                                                        if (Order == 1 && (ChessRules.KishGray))
                                                            Current.LearningAlgorithmPenalty();
                                                        else
                                                            if (Order == -1 && (ChessRules.KishBrown))
                                                                Current.LearningAlgorithmPenalty();
                                                        PenaltyRegardListSolder.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListSolder.Add(Current);
                                                }
                                                else
                                                    PenaltyRegardListSolder.Add(Current);
                                                ///Store of Indexes Changes and Table in specific List.
                                                int[] AS = new int[2];
                                                AS[0] = i;
                                                AS[1] = j;
                                                RowColumnSoldier.Add(AS);
                                                RowColumn[Index, 0] = i;
                                                RowColumn[Index, 1] = j;
                                                Index++;
                                                TableListSolder.Add(TableS);
                                                IndexSoldier++;
                                                Row = i;
                                                Column = j;
                                                ///Wehn Predict of Operation Do operate a Predict of this movments.
                                                if (PredictHuristic)
                                                {
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                }
                                                ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                                                double[] Hu = new double[4];
                                                Hu[0] = HuristicValue;
                                                Hu[1] = HuristicValueMovement;
                                                Hu[2] = HuristicValueSupported;
                                                Hu[3] = HuristicValueAchmazKishMate;
                                                HuristicListSolder.Add(Hu);
                                                if (Order == 1)
                                                    AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 1, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                else
                                                    AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -1, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();

                                            }
                                        }
                                        else
                                            ///Else for Elephant Thinking.
                                            if (System.Math.Abs(TableS[ii, jj]) == 2)
                                            {
                                                ///When There is Movments.
                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    ///Calculate Hit Occured and Value of Object.
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;
                                                    ///Add Table to List of Private.
                                                    HitNumberElefant.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    ///Predict Huristic.
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    HuristicHitting(TableS, ii, jj, Order, color, Hit);
                                                    ///Action of Movements.
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    ///Consideration of Itterative Movments to ignore.
                                                    if (ThinkingChess.ExistTableInList(TableS, TableListElefant, 0))
                                                    {
                                                        ///Set Predict Huristic and Movments Backward.
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmazKishMate = 0;

                                                        continue;
                                                    }
                                                    ///Operation of Penalty Regard Mechanisam on Kish and mate speciffically.
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListElefant.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListElefant.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListElefant.Add(Current);
                                                    ///Store of Indexes Changes and Table in specific List.
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnElefant.Add(AS);

                                                    RowColumn[Index, 0] = i;
                                                    RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListElefant.Add(TableS);
                                                    IndexElefant++;
                                                    Row = i;
                                                    Column = j;
                                                    ///Wehn Predict of Operation Do operate a Predict of this movments.
                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);
                                                    }
                                                    ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmazKishMate;
                                                    HuristicListElefant.Add(Hu);
                                                    ///ThinkingFinished = true;
                                                    ///break;
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 2, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -2, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                                ///Else for Hourse Thinking.
                                            else if (System.Math.Abs(TableS[ii, jj]) == 3)
                                            {
                                                ///When There is Movments.
                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    ///Calculate Hit Occured and Value of Object.
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;
                                                    ///Add Table to List of Private.
                                                    HitNumberHourse.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    ///Predict Huristic.
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    HuristicHitting(TableS, ii, jj, Order, color, Hit);
                                                    ///Action of Movements.
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    ///Consideration of Itterative Movments to ignore.
                                                    if (ThinkingChess.ExistTableInList(TableS, TableListHourse, 0))
                                                    {
                                                        ///Set Predict Huristic and Movments Backward.
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmazKishMate = 0;

                                                        continue;
                                                    }
                                                    ///Operation of Penalty Regard Mechanisam on Kish and mate speciffically.
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListHourse.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListHourse.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListHourse.Add(Current);
                                                    ///Store of Indexes Changes and Table in specific List.
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnHourse.Add(AS);

                                                    ThinkingChess.RowColumn[Index, 0] = i;
                                                    ThinkingChess.RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListHourse.Add(TableS);
                                                    IndexHourse++;
                                                    Row = i;
                                                    Column = j;
                                                    ///Wehn Predict of Operation Do operate a Predict of this movments.
                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);
                                                    }
                                                    //Calculate Huristic and Add to List and Cal Syntax.
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmazKishMate;
                                                    HuristicListHourse.Add(Hu);
                                                    ///ThinkingFinished = true;
                                                    ///break;
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 3, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -3, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                                ///Else For Bridges Thinking.
                                            else if (System.Math.Abs(TableS[ii, jj]) == 4)
                                            {
                                                ///When There is Movments.
                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    ///Calculate Hit Occured and Value of Object.
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;
                                                    ///Add Table to List of Private.
                                                    HitNumberBridge.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    ///Predict Huristic.
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    HuristicHitting(TableS, ii, jj, Order, color, Hit);
                                                    ///Action of Movements.
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    ///Consideration of Itterative Movments to ignore.
                                                    if (ExistTableInList(TableS, TableListBridge, 0))
                                                    {
                                                        ///Set Predict Huristic and Movments Backward.
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmazKishMate = 0;

                                                        continue;
                                                    }
                                                    ///Operation of Penalty Regard Mechanisam on Kish and mate speciffically.
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListBridge.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListBridge.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListBridge.Add(Current);
                                                    ///Store of Indexes Changes and Table in specific List.
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnBridge.Add(AS);
                                                    ThinkingChess.RowColumn[Index, 0] = i;
                                                    ThinkingChess.RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListBridge.Add(TableS);
                                                    IndexBridge++;
                                                    Row = i;
                                                    Column = j;
                                                    ///Wehn Predict of Operation Do operate a Predict of this movments.
                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);

                                                    }
                                                    ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmazKishMate;
                                                    HuristicListBridge.Add(Hu);
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 4, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -4, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                                ///Else for Minister Thinkings.
                                            else if (System.Math.Abs(TableS[ii, jj]) == 5)
                                            {
                                                ///When There is Movments.
                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    ///Calculate Hit Occured and Value of Object.
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;
                                                    ///Add Table to List of Private.
                                                    HitNumberMinister.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    ///Predict Huristic.
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    HuristicHitting(TableS, ii, jj, Order, color, Hit);
                                                    ///Action of Movements.
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    ///Consideration of Itterative Movments to ignore.
                                                    if (ExistTableInList(TableS, TableListMinister, 0))
                                                    {
                                                        ///Set Predict Huristic and Movments Backward.
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmazKishMate = 0;

                                                        continue;
                                                    }
                                                    ///Operation of Penalty Regard Mechanisam on Kish and mate speciffically.
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListMinister.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListMinister.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListMinister.Add(Current);
                                                    ///Store of Indexes Changes and Table in specific List.
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnMinister.Add(AS);
                                                    RowColumn[Index, 0] = i;
                                                    RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListMinister.Add(TableS);
                                                    IndexMinister++;
                                                    Row = i;
                                                    Column = j;
                                                    ///Wehn Predict of Operation Do operate a Predict of this movments.
                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);
                                                    }
                                                    ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmazKishMate;
                                                    HuristicListMinister.Add(Hu);
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 5, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -5, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();
                                                }
                                            }
                                                ///Else For Kings Thinkings.
                                            else if (System.Math.Abs(TableS[ii, jj]) == 6)
                                            {
                                                ///When There is Movments.
                                                if ((new ChessRules(TableS[ii, jj], TableS, Order)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
                                                {
                                                    ///Calculate Hit Occured and Value of Object.
                                                    bool Hit = false;
                                                    int HitNumber = TableS[i, j];
                                                    if (System.Math.Abs(TableS[i, j]) > 0)
                                                        Hit = true;
                                                    ///Add Table to List of Private.
                                                    HitNumberKing.Add(TableS[i, j]);
                                                    ThinkingRun = true;
                                                    ///Predict Huristic.
                                                    HuristicAttack(TableS, Order, color);
                                                    HuristicMovment(TableS, color);
                                                    HuristicSupported(TableS, Order, color);
                                                    HuristicKishAndMate(TableS, color);
                                                    HuristicAchmaz(TableS, Order, color);
                                                    HuristicHitting(TableS, ii, jj, Order, color, Hit);
                                                    ///Action of Movements.
                                                    TableS[i, j] = TableS[ii, jj];
                                                    TableS[ii, jj] = 0;
                                                    ///Consideration of Itterative Movments to ignore.
                                                    if (ExistTableInList(TableS, TableListKing, 0))
                                                    {
                                                        ///Set Predict Huristic and Movments Backward.
                                                        TableS[ii, jj] = TableS[i, j];
                                                        TableS[i, j] = 0;
                                                        HuristicValue = 0;
                                                        HuristicValueMovement = 0;
                                                        HuristicValueSupported = 0;
                                                        HuristicValueAchmazKishMate = 0;

                                                        continue;
                                                    }
                                                    ///Operation of Penalty Regard Mechanisam on Kish and mate speciffically.
                                                    if (UsePenaltyRegardMechnisam)
                                                    {
                                                        ChessRules A = new ChessRules(TableS[ii, jj], TableS, Order);
                                                        if (A.AchmazKingMove(Order, TableS, false))
                                                        {
                                                            if (Order == 1 && (ChessRules.KishGray))
                                                                Current.LearningAlgorithmPenalty();
                                                            else
                                                                if (Order == -1 && (ChessRules.KishBrown))
                                                                    Current.LearningAlgorithmPenalty();
                                                            PenaltyRegardListKing.Add(Current);
                                                        }
                                                        else
                                                            PenaltyRegardListKing.Add(Current);
                                                    }
                                                    else
                                                        PenaltyRegardListKing.Add(Current);
                                                    ///Store of Indexes Changes and Table in specific List.
                                                    int[] AS = new int[2];
                                                    AS[0] = i;
                                                    AS[1] = j;
                                                    RowColumnKing.Add(AS);
                                                    RowColumn[Index, 0] = i;
                                                    RowColumn[Index, 1] = j;
                                                    Index++;
                                                    TableListKing.Add(TableS);
                                                    IndexKing++;
                                                    Row = i;
                                                    Column = j;
                                                    ///Wehn Predict of Operation Do operate a Predict of this movments.
                                                    if (PredictHuristic)
                                                    {
                                                        HuristicAttack(TableS, Order, color);
                                                        HuristicMovment(TableS, color);
                                                        HuristicSupported(TableS, Order, color);
                                                        HuristicKishAndMate(TableS, color);
                                                        HuristicAchmaz(TableS, Order, color);

                                                    }
                                                    ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                                                    double[] Hu = new double[4];
                                                    Hu[0] = HuristicValue;
                                                    Hu[1] = HuristicValueMovement;
                                                    Hu[2] = HuristicValueSupported;
                                                    Hu[3] = HuristicValueAchmazKishMate;
                                                    HuristicListKing.Add(Hu);
                                                    if (Order == 1)
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, 6, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    else
                                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableS, FormRefrigtz.MovmentsNumber, -6, j, i, Hit, HitNumber, ChessRules.BridgeActBrown, false);
                                                    AllDraw.SyntaxToWrite += "Huristic :" + (Hu[0] + Hu[1] + Hu[2] + Hu[3]).ToString();

                                                }
                                            }

                            }
                            ///Wehn Thinkings finished by Movments found breaks.
                            if (ThinkingFinished)
                                break;

                        }

                    }
                }
                ///Initiate Global Varibales at END.
                ThinkingBegin = false;
                ///This Variable Not Work! 
                ThinkingFinished = true;

            }
            ///Return at End.
            return;
        }

    }
}
//End of Documentation.