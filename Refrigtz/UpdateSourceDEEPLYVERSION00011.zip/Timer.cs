﻿/**************************************************************************
 * Ramin Edjlal.***********************************************************
 * Timer is Working Reversly***********************************************
 * Timer Order Decrising Not Work!*****************************************
 * Timer Not Worked.*******************************************************
 * Timer Scheduling For Regard and Set Point MalFunctions.*****************
 * Timer Set Point of Text MalFuncational.*********************************
 * Thinking Finshed Begin At New Time Text Box.****************************
 * Timer Changing Start Stop Function Failed.******************************
 * Timer MalFunction.******************************************************
 * Visual Studio Timer and Visualization du to Internet Access MalFunction* 
 * Dynamic Timer Dept First Increament or Decreament MalFunction.**********
 * No Logically Idea For Managments of Dynamic Dept First Max Dept.********
 * Timer MalFunction When Leave ForGround The Programm.********************
 * ************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Refrigtz
{

    public class Timer
    {
        long ConstTimer = 0;
        double DeptFirstMidleTimer = 0;
        long DeptFirstLastTime = 0;
        public static bool Text = false;
        public long Times = 5 * 60 * 1000;
        long TimesBegin = 0;
        public bool EndTime = false;
        Thread t;
        public bool Paused = true;
        public bool TextChanged = true;
        public int Sign = -1;
        bool Infinity = false;
        public Timer(bool SignPositive)
        {
            if (SignPositive)
            {
                Times = 0;
                Sign = 1;
                Infinity = true;
            }
        }
        public void TimerInitiate()
        {
            t = new Thread(new ThreadStart(timerThread));
            t.Start();
        }
        void timerThread()
        {


            do
            {

                while (Paused)
                {
                    System.Threading.Thread.Sleep(500);
                };

                long t1 = DateTime.Now.Hour * 3600000 + DateTime.Now.Minute * 60000
                    + DateTime.Now.Second * 1000 + DateTime.Now.Millisecond;


                do
                {

                }
                while (DateTime.Now.Hour * 3600000 + DateTime.Now.Minute * 60000
                   + DateTime.Now.Second * 1000 + DateTime.Now.Millisecond - t1 < 1000);
                Times = Times + 1000 * Sign;



                TextChanged = true;


            } while (Times > 0 || Infinity);


            EndTime = true;
        }
        public long TimesAccess
        {
            get { return Times; }
            set { Times = value; }


        }
        public int DeptiLevelMaxInitiate(Timer TimerColor, int Depti)
        {
            int Increase = 0;
            if ((System.Math.Pow(AllDraw.DeptiLevelMax * DeptFirstMidleTimer, 4) + System.Math.Pow(TimerColor.TimesAccess, 4) > System.Math.Pow(AllDraw.DeptiLevelMax * DeptFirstMidleTimer, 4)+System.Math.Pow(Depti * DeptFirstMidleTimer, 4)))
            {
                Increase = 1;

            }
            else
            {
                if ((System.Math.Pow(AllDraw.DeptiLevelMax * DeptFirstMidleTimer, 4) + System.Math.Pow(TimerColor.TimesAccess, 4) < System.Math.Pow(AllDraw.DeptiLevelMax * DeptFirstMidleTimer, 4) + System.Math.Pow(Depti * DeptFirstMidleTimer, 4)))
                {
                    Increase = -1;
                }
            }
            return Increase;
        }
        public void SetDeptFirstTimer()
        {
            DeptFirstLastTime = Times;
            DeptFirstMidleTimer = 0;
        }
        public void MidleDeptFirstTimer(int Depti)
        {
            DeptFirstMidleTimer = (DeptFirstLastTime * Depti + (Times - DeptFirstLastTime)) / (Depti + 1);
            DeptFirstLastTime = Times - DeptFirstLastTime;
        }
        public void StartTime()
        {
            t = new Thread(new ThreadStart(timerThread));
            t.Start();

            if (TimesBegin == 0)
                TimesBegin = DateTime.Now.Hour * 3600000 + DateTime.Now.Minute * 60000
                            + DateTime.Now.Second * 1000 + DateTime.Now.Millisecond;

            Paused = false;

        }


        public void StopTime()
        {
            
            t.Abort();
            if (!AllDraw.DeptFirstSearch)
            {
                if ((DateTime.Now.Hour * 3600000 + DateTime.Now.Minute * 60000
                        + DateTime.Now.Second * 1000 + DateTime.Now.Millisecond - TimesBegin) < 5000)
                    Times = 5 * 60 * 1000 + 60000;
                else
                    Times = 5 * 60 * 1000;
                ConstTimer = 5 * 60 * 1000;
            }
            else
            {
                if ((DateTime.Now.Hour * 3600000 + DateTime.Now.Minute * 60000
                  + DateTime.Now.Second * 1000 + DateTime.Now.Millisecond - TimesBegin) < 10000)
                    Times = 10 * 60 * 1000 + 60000;
                else
                    Times = 10 * 60 * 1000;
                ConstTimer = 10 * 60 * 1000;
            }
            TimesBegin = 0;
            Paused = true;
        }
        public String ReturnTime()
        {
            String Minute = (Times / 60000).ToString();
            String Second = ((Times - System.Convert.ToInt64(Times / 60000) * 60000) / 1000).ToString();

            return Minute + ":" + Second;
        }
    }
}
