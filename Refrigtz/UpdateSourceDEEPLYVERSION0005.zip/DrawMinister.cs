﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawMinister//:DrawKing
    {
        //Initiate Global Variable.
        public int Row, Column;
        public Color color;
        public int[,] Table = null;
        public int Current = 0;
        public int Order;
        public ThinkingChess[] MinisterThinking = new ThinkingChess[AllDraw.MinisterMovments];
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
       //constructor 1.
        public DrawMinister() { }
        //Constructor 2.
        public DrawMinister(int i, int j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            //Initiate Global Variables.
            Table = Tab;
            for (int ii = 0; ii < AllDraw.MinisterMovments; ii++)
                MinisterThinking[ii] = new ThinkingChess(i, j, a, Tab, 32, Ord, TB, Cur, 2);

            Row = i;
            Column = j;
            color = a;
            Current = Cur;
            Order = Ord;

        }
        //Clone a Copy.
        public void Clone(ref DrawMinister AA,ref FormRefrigtz THIS)
        {
            //Initiate an Object and Clone a Construction Objectve.
            AA = new DrawMinister(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.MinisterMovments; i++)
            {
                try
                {
                    AA.MinisterThinking[i] = new ThinkingChess();
                    this.MinisterThinking[i].Clone(ref AA.MinisterThinking[i],ref THIS);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.MinisterThinking[i] = null;
                }

            }
        }
        //Draw an Mnister on the Table.
        public void DrawMinisterOnTable(ref Graphics g, int CellW, int CellH)
        {
            try
            {
                //Gray Order.
                if (color == Color.Gray)
                {
                    //Draw a Gray Instatnt Minister Image on the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }
                else
                {
                    //Draw a Brwon Instatnt Minister Image on the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "MB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }

            }
            catch (Exception t) { Log(t); }
        }
    }
}
//End of Documentation.