﻿/***********************************************************************************************
 * Main class of Form Inherited of Form Main in the C#.*****************************************
 * Ramin Edjlal*********************************************************************************(+)
 * Mouse Event Handling Error*******************************************************************(+)
 * Some Soldiers Loos Location  And Virutuallization at Click***********************************(+)
 * Some Codes Lines Frizes**********************************************************************(+)
 * Hit things Abnormal behaviour****************************************************************(+)
 * Virtualization Things Error******************************************************************(+)
 * No Reason Logically For Equality of 'SoldierP' and 'Soldier'*********************************(+)
 * Problem of Sameness of Hit Enemys Solved.No Reason For Equality of 'Soldier' and 'SoldierP'**(-+)
 * No Problem For Hiting************************************************************************(+)
 * Bridges of Gray Color Conversion to Kings Brown**********************************************(*)
 * Bridges Conversion To King Brown Abnormally no Reasonably************************************(*)
 * Color Conversion In Virtualization Hit Enemy*************************************************(+)
 * Need To Find Enemy Detection on Current OrderPlate************************************************(+)
 * Mate an Kish Dosn't Work*********************************************************************(*)
 * No Movments By Computer**********************************************************************(+)
 * Illegal Virtualization. The Thinking By 'Alice' (My Computer) ChessRules Misleading**********(+)
 * permutative Constant Huristic Results********************************************************(+)
 * In Existence of Adding Suported Huristic Constant Huristic Result Detection******************(+)
 * OrderPlate Not Configured*************************************************************************(+)
 * Non Color Hourse Hit Assignment Misleading(Abnormal)*****************************************(+)
 * Undetected Error Table Content Malfunction***************************************************(+)
 * MalFunction Movments Greate than 5 by 'Alice'.***********************************************(+)
 * 'Kish' Second Time 'Alice' MalFanction*******************************************************(+)
 * 'Kish' 'Alice' Mechnisam Failure*************************************************************(+)
 '* Mate' of Unsatisfied in 'Alice'*************************************************************(*)
 * Mate Dosn't Recognized.**********************************************************************(_)
 * Virtualization Filed (Not Responding) at Indpencdency State**********************************(+)
 * Unable To Draw Timer  Content at Tow Picture Box*********************************************(+)
 * Timer Working Hardly.************************************************************************(+)
 * Dead Lock In Drawing Images.*****************************************************************(+)
 * Misleading Thread OrderPlate And Time Sharing*****************************************************(+)
 * Thinkings Taking a lot of Time.**************************************************************(+)
 * AntiVirus Protextion and Existance Caused to Reduce Speed of Thinking and lead to Lose.******(+)
 * No Programatically Reason For Speed Reduction.***********************************************(+) 
 * Mybe Windows Filrewall Has no been correctly Arranges to reduce speed.***********************(+)
 * Method on Leave not Work.********************************************************************(*)
 * OrderPlate Reader Table MalFunction.**************************************************************(+)
 * Wrong Sysntax To Read.***********************************************************************(*)
 * Some Tables of Hitting Tow Person Are Missing.***********************************************(_)
 * Some Syntaxes at Table Read Are Missing.*****************************************************(_)
 * Chess Refregitz Sometimes Not Responding due to Cpu Power Non Ability.***********************(*)
 * Chess Refregitz Sometimes stop working.******************************************************(*)
 * 1395/1/16************************************************************************************(*)
 * OrderPlate MalFunction.**********************************************************************{+}
 * Virtualization Error.No Reason For MalFunctionla Operation of Program at Sysntax and Orde.***{*}
 * Cause Sensitive Problems of 'Kish' And 'Mate By 'Alice' is borring at StateCP.***************{*}
 * Table Content Misleading.********************************************************************(*)
 * Documentation Faulting On Removing Detials.**************************************************(*)
 * *********************************************************************************************
 * *********************************************************************************************
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Data.OleDb;
using System.Media;
using System.IO;
namespace Refrigtz
{
    //Constructor
    public partial class FormRefrigtz : Form
    {
        //Initiate Global Variable.
        public FormSelect Sec = new FormSelect();
        bool AllDrawLoad = false;
        Thread AllOperate = null;
        static bool Paused = false;
        static bool UpdateConfigurationTableVal = false;
        static bool NewTable = false;
        OleDbConnection bookConn;
        OleDbCommand oleDbCmd = new OleDbCommand();

        private OleDbConnection bookConnUser;
        private OleDbCommand oleDbCmdUser = new OleDbCommand();

        Image TimerImage = null;
        Graphics g1 = null;
        Image TimerImage1 = null;
        Graphics g2 = null;
        Graphics g = null;
        Image ChessTable = null;


        public static int LastRow = -1;
        public static int LastColumn = -1;
        Thread t1 = null;
        Thread t2 = null;
        Thread t3 = null;
        Thread t4 = null;
        Thread TTimerSet;
        public static bool LoadedTable = false;
        bool GrayWinner = false;
        bool BrownWiner = false;
        Timer TimerText = null;
        Timer GrayTimer = null;
        Timer BrownTimer = null;
        public static int MovmentsNumber = 0;
        public static bool EndOfGame = false;
        bool Maximize = false;
        static int RowP = 0, ColP = 0, RowS = 0, ColS = 0;
        bool BobSection = true;
        bool AliceSection = false;
        public static bool Person = true;
        static int CurrentKind = 0;
        bool Scan = true;
        AllDraw DummyConst = null;
        public static bool StateCC = false;//Computer With Computer
        public static bool StateCP = false;//Person With Computer
        public static bool StateGe = false;//For Genetic Games.
        int Index = 0;
        AllDraw Draw;
        public static int OrderPlate = 1;
        // int AllDraw.MouseClick;
        int Soldier;
        int Elefant;
        int Hourse;
        int Bridge;
        int Minister;
        int King;
        float RowClickP = -1, ColumnClickP = -1;
        int RowClick = -1, ColumnClick = -1;
        float RowRealesedP = -1, ColumnRealeasedP = -1;
        float RowRealesed = -1, ColumnRealeased = -1;
        public int[,] Table = new int[8, 8];
        //bool TimerTickByGray = true;

        FormRefrigtz THIs = null;
        //Error Handling.
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
        //Constructor No2
        public FormRefrigtz(bool AllDra)
        {

            AllDrawLoad = AllDra;
            InitializeComponent();

            if (!AllDrawLoad)
            {
                this.pictureBoxRefrigtz.Size = new Size((this.pictureBoxRefrigtz.Width / 8) * 8, (this.pictureBoxRefrigtz.Height / 8) * 8);

                t1 = new Thread(new ThreadStart(AliceWithPerson));
                t2 = new Thread(new ThreadStart(BobAction));
                t3 = new Thread(new ThreadStart(AliceAction));
                t4 = new Thread(new ThreadStart(GeneticAction));

            }


            THIs = this;
            Draw = new AllDraw(ref THIs);

            if (!AllDrawLoad)
            {
                BrownTimer = new Timer(false);
                GrayTimer = new Timer(false);
                TimerText = new Timer(true);

                BrownTimer.TimerInitiate();
                GrayTimer.TimerInitiate();
                TTimerSet = new Thread(new ThreadStart(SetTimer));
                TTimerSet.Start();

                TimerText.TimerInitiate();

                TimerText.StartTime();
            }
            ChessRules.KishBrown = false;
            ChessRules.KishGray = false;
            ChessRules.MateBrown = false;
            ChessRules.MateGray = false;


            if (!AllDrawLoad)
            {
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        Table[i, j] = 0;
                    }

                for (int i = 0; i < 8; i++)
                    Table[i, 1] = 1;

                for (int i = 8; i < 16; i++)
                    Table[i - 8, 6] = -1;
                Table[2, 0] = 2;
                Table[5, 0] = 2;
                Table[2, 7] = -2;
                Table[5, 7] = -2;

                Table[1, 0] = 3;
                Table[6, 0] = 3;
                Table[1, 7] = -3;
                Table[6, 7] = -3;

                Table[0, 0] = 4;
                Table[7, 0] = 4;
                Table[0, 7] = -4;
                Table[7, 7] = -4;

                Table[3, 0] = 5;
                Table[3, 7] = -5;

                Table[4, 0] = 6;
                Table[4, 7] = -6;
            }
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    AllDraw.TableVeryfy[i, j] = Table[i, j];
                    AllDraw.TableVeryfyConst[i, j] = Table[i, j];
                }
            if (!AllDrawLoad)
            {
                AllDraw.TableListAction.Add(Table);
            }
            for (int i = 0; i < 8; i++)
            {
                Draw.SolderesOnTable[i] = new DrawSoldier(i, 1, Color.Gray, Table, 1, false, i);
            }
            for (int i = 8; i < 16; i++)
            {
                Draw.SolderesOnTable[i] = new DrawSoldier(i - 8, 6, Color.Brown, Table, -1, false, i);
            }
            Draw.ElephantOnTable[0] = new DrawElefant(2, 0, Color.Gray, Table, 1, false, 0);
            Draw.ElephantOnTable[1] = new DrawElefant(5, 0, Color.Gray, Table, 1, false, 1);
            Draw.ElephantOnTable[2] = new DrawElefant(2, 7, Color.Brown, Table, -1, false, 2);
            Draw.ElephantOnTable[3] = new DrawElefant(5, 7, Color.Brown, Table, -1, false, 3);

            Draw.HoursesOnTable[0] = new DrawHourse(1, 0, Color.Gray, Table, 1, false, 0);
            Draw.HoursesOnTable[1] = new DrawHourse(6, 0, Color.Gray, Table, 1, false, 1);
            Draw.HoursesOnTable[2] = new DrawHourse(1, 7, Color.Brown, Table, -1, false, 2);
            Draw.HoursesOnTable[3] = new DrawHourse(6, 7, Color.Brown, Table, -1, false, 3);

            Draw.BridgesOnTable[0] = new DrawBridge(0, 0, Color.Gray, Table, 1, false, 0);
            Draw.BridgesOnTable[1] = new DrawBridge(7, 0, Color.Gray, Table, 1, false, 1);
            Draw.BridgesOnTable[2] = new DrawBridge(0, 7, Color.Brown, Table, -1, false, 2);
            Draw.BridgesOnTable[3] = new DrawBridge(7, 7, Color.Brown, Table, -1, false, 3);

            Draw.MinisterOnTable[0] = new DrawMinister(3, 0, Color.Gray, Table, 1, false, 0);
            Draw.MinisterOnTable[1] = new DrawMinister(3, 7, Color.Brown, Table, -1, false, 1);

            Draw.KingOnTable[0] = new DrawKing(4, 0, Color.Gray, Table, 1, false, 0);
            Draw.KingOnTable[1] = new DrawKing(4, 7, Color.Brown, Table, -1, false, 1);


            AllDraw.TableListAction.Add(Table);
        }
        //Acccess Point
        public AllDraw accessDraw
        {
            get { return Draw; }
            set { Draw = value; }

        }
        //Syncronization Between Class Dlls.
        private void SetTimer()
        {
            do
            {
                //while (!StateCC && !StateCP && !StateGe)
                Thread.Sleep(50);
                Timer.DeptFirstSearch = AllDraw.DeptFirstSearch;
                Timer.DeptiLevelMax = AllDraw.DeptiLevelMax;
                Timer.UseDoubleTime = AllDraw.UseDoubleTime;
                Timer.StoreAllDrawCount = AllDraw.StoreADraw.Count;
            }
            while (true);

        }
        //Load Besm.
        void LoadBesm()
        {





        }
        //Boolean Setting of Illustration at Slected Object Rules.
        bool[,] VeryFye(int [,] Table,int Order,Color a)
        {
            bool[,] Tab = new bool[8, 8];
            for(int i=0;i<8;i++)
                for (int j = 0; j < 8; j++)
                {
                    if ((new ChessRules(Table[(int)RowClickP, (int)ColumnClickP], Table, Order)).Rules((int)RowClickP, (int)ColumnClickP, i, j, a, Table[(int)RowClickP, (int)ColumnClickP])) 
                    {
                        Tab[i, j] = true;
                    }
                }
            return Tab;
        }
        //Load Refregitz Form.
        private void Form1_Load(object sender, EventArgs e)
        {
            if (Sec.radioButtonGrayOrder.Checked)
            {
                ChessRules.CurrentOrder = 1;
                OrderPlate = 1;
            }
            else
                if (Sec.radioButtonBrownOrder.Checked)
                {
                    ChessRules.CurrentOrder = -1;
                    OrderPlate = -1;
                }

            List<Process> a = new List<Process>();
            a.AddRange(Process.GetProcessesByName("Refrigtz"));
            if (a.Count > 1)
            {

                if (System.Windows.Forms.MessageBox.Show(null, "New Instant Of Refregitz!", "New Instant", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    for (int i = 0; i < a.Count; i++)
                    {
                        try
                        {

                            a[i].Kill();
                            exitToolStripMenuItem_Click(sender, e);
                        }
                        catch (Exception t) { Log(t); Application.ExitThread(); }

                    }

                }
            }
            if (!Directory.Exists("DataBase"))
            {
                if (!Directory.Exists("DataBase\\MainBank"))
                {
                    Directory.CreateDirectory("DataBase\\MainBank");
                    File.Move("ChessBank.accdb", "DataBase\\MainBank\\ChessBank.accdb");
                }
            }
            if (!Directory.Exists("Images"))
            {
                if (!Directory.Exists("Images\\Original"))
                {
                    Directory.CreateDirectory("Images\\Original");
                }
            }
            try
            {
                File.Move("OBrB.png", "Images\\Original\\BrB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OBrG.png", "Images\\Original\\BrG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OEB.png", "Images\\Original\\EB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OEG.png", "Images\\Original\\EG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OHB.png", "Images\\Original\\HB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OHG.png", "Images\\Original\\HG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OKB.png", "Images\\Original\\KB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OKG.png", "Images\\Original\\KG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OMB.png", "Images\\Original\\MB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OMG.png", "Images\\Original\\MG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OSB.png", "Images\\Original\\SB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("OSG.png", "Images\\Original\\SG.png");
            }
            catch (Exception t) { Log(t); }

            if (!Directory.Exists("Fit\\Small\\"))
            {
                Directory.CreateDirectory("Images\\Fit\\Small");
            }
            try
            {
                File.Move("FSBrB.png", "Images\\Fit\\Small\\BrB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSBrG.png", "Images\\Fit\\Small\\BrG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSEB.png", "Images\\Fit\\Small\\EB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSEG.png", "Images\\Fit\\Small\\EG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSHB.png", "Images\\Fit\\Small\\HB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSHG.png", "Images\\Fit\\Small\\HG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSKB.png", "Images\\Fit\\Small\\KB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSKG.png", "Images\\Fit\\Small\\KG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSMB.png", "Images\\Fit\\Small\\MB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSMG.png", "Images\\Fit\\Small\\MG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSSB.png", "Images\\Fit\\Small\\SB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FSSG.png", "Images\\Fit\\Small\\SG.png");
            }
            catch (Exception t) { Log(t); }

            if (!Directory.Exists("Images\\Fit\\Big"))
            {
                Directory.CreateDirectory("Images\\Fit\\Big");
            }
            try
            {
                File.Move("FBBrB.png", "Images\\Fit\\Big\\BrB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBBrG.png", "Images\\Fit\\Big\\BrG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBEB.png", "Images\\Fit\\Big\\EB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBEG.png", "Images\\Fit\\Big\\EG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBHB.png", "Images\\Fit\\Big\\HB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBHG.png", "Images\\Fit\\Big\\HG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBKB.png", "Images\\Fit\\Big\\KB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBKG.png", "Images\\Fit\\Big\\KG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBMB.png", "Images\\Fit\\Big\\MB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBMG.png", "Images\\Fit\\Big\\MG.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBSB.png", "Images\\Fit\\Big\\SB.png");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("FBSG.png", "Images\\Fit\\Big\\SG.png");
            }
            catch (Exception t) { Log(t); }

            if (!Directory.Exists("Images\\Program"))
            {
                Directory.CreateDirectory("Images\\Program");
            }

            try
            {
                File.Move("Black.jpg", "Images\\Program\\Black.jpg");
            }
            catch (Exception t) { Log(t); }
            try
            {
                File.Move("White.jpg", "Images\\Program\\White.jpg");
            }
            catch (Exception t) { Log(t); }


            if (!Directory.Exists("Music"))
            {
                Directory.CreateDirectory("Music");
            }
            try
            {
                File.Move("Click6.wav", "Music\\Click6.wav");
            }
            catch (Exception t) { Log(t); }

            if (!AllDrawLoad)
            {
                if (!System.IO.File.Exists("Database\\CurrentBank.accdb"))
                {
                    System.IO.File.Copy("Database\\MainBank\\ChessBank.accdb", "Database\\CurrentBank.accdb");
                    InsertTableAtDataBase(Table);
                    CreateConfigurationTable();
                }
                else
                {
                    if (!NewTable)
                    {
                        ChessRules.CurrentOrder = 1;
                        OrderPlate = 1;
                        //Read Last Table and Set MovementNumber
                        Table = ReadTable(0, ref MovmentsNumber);
                        //Clear Table List.
                        Draw.TableList.Clear();
                        //Add Table List.
                        Draw.TableList.Add(Table);
                        //Construction of Draw Things and Thinkings.

                        Draw.SetRowColumn(0);
                        //When Configuration is Allowed Read Configuration.
                        if (!UpdateConfigurationTableVal)
                            ReadConfigurationTable();
                        //Set Configuration To True for some unknown reason!.
                        UpdateConfigurationTableVal = true;

                    }
                    else
                    {
                        int iii = 0;
                        do { iii++; } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + iii.ToString() + ".accdb"));
                        System.IO.File.Copy("Database\\CurrentBank.accdb", "Database\\Games\\CurrentBank" + iii.ToString() + ".accdb");
                        System.IO.File.Delete("Database\\CurrentBank.accdb");
                        System.IO.File.Copy("Database\\MainBank\\ChessBank.accdb", "Database\\CurrentBank.accdb");
                        InsertTableAtDataBase(Table);
                        CreateConfigurationTable();

                    }
                }




                AllOperate = new Thread(new ThreadStart(AllOperations));
                AllOperate.Start();
                if (OrderPlate == 1)
                {
                    BrownTimer.StopTime();
                    GrayTimer.StartTime();
                }
                else
                {
                    GrayTimer.StopTime();
                    BrownTimer.StartTime();
                }
            }
            else
            {
                if (t1 != null)
                    t1.Abort();
                if (t2 != null)
                    t2.Abort();
                if (t3 != null)
                    t3.Abort();
                if (t4 != null)
                    t4.Abort();
            }

        }
        //Reading Table Database.
        int[,] ReadTable(int Movment, ref int MoveNumber)
        {
            int[,] Tab = Table;
            int Move = 0;
            AllDraw.TableListAction.Clear();
            do
            {
                try
                {
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";
                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    String TableName = Move.ToString();
                    String Zero = "Table";
                    for (int i = 0; i < 8 - TableName.Length; i++)
                        Zero += "0";
                    TableName = Zero + TableName;

                    oleDbCmd.CommandText = "Select * From " + TableName;
                    OleDbDataReader dr = null;
                    dr = oleDbCmd.ExecuteReader();
                    int ii = 0;
                    while (dr.Read())
                    {
                        Tab[0, ii] = System.Convert.ToInt32(dr["a"]);
                        Tab[1, ii] = System.Convert.ToInt32(dr["b"]);
                        Tab[2, ii] = System.Convert.ToInt32(dr["c"]);
                        Tab[3, ii] = System.Convert.ToInt32(dr["d"]);
                        Tab[4, ii] = System.Convert.ToInt32(dr["e"]);
                        Tab[5, ii] = System.Convert.ToInt32(dr["f"]);
                        Tab[6, ii] = System.Convert.ToInt32(dr["g"]);
                        Tab[7, ii] = System.Convert.ToInt32(dr["h"]);
                        ii++;
                    }
                    int[,] TableA = new int[8, 8];
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                            TableA[i, j] = Tab[i, j];
                    Draw.TableList.Clear();
                    Draw.TableList.Add(TableA);
                    Draw.SetRowColumn(0);
                    AllDraw.TableListAction.Add(TableA);
                    if (AllDraw.TableListAction.Count > 1)
                    {
                        ChessGeneticAlgorithm R = new ChessGeneticAlgorithm();
                        if (R.FindGenToModified(AllDraw.TableListAction[AllDraw.TableListAction.Count - 2], AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], AllDraw.TableListAction, 0, OrderPlate, true))
                        {
                            bool HitVal = false;
                            int Hit = AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRow, R.CromosomColumn];
                            if (Hit != 0)
                                HitVal = true;
                            bool Convert = false;
                            if (OrderPlate == 1)
                            {
                                if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][R.CromosomRow, R.CromosomColumn] == 1)
                                {
                                    if (R.CromosomColumn == 7)
                                        Convert = true;
                                }
                                AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MoveNumber + 1, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActGray, Convert);
                            }
                            else
                            {
                                if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][R.CromosomRowFirst, R.CromosomColumnFirst] == -1)
                                {
                                    if (R.CromosomColumn == 0)
                                        Convert = true;
                                }
                                AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MoveNumber + 1, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActBrown, Convert);
                            }
                            SetBoxStatistic(AllDraw.SyntaxToWrite);
                            RefreshBoxStatistic();
                        }
                    }


                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    Move++;
                    if (Move > 1)
                        MoveNumber++;
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                            TableA[i, j] = Tab[i, j];


                    if ((new ChessRules(1, TableA, OrderPlate).Mate(TableA, OrderPlate)))
                    {
                        int iii = 0;
                        do { iii++; } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + iii.ToString() + ".accdb"));
                        System.IO.File.Copy("Database\\CurrentBank.accdb", "Database\\Games\\CurrentBank" + iii.ToString() + ".accdb");
                        System.IO.File.Delete("Database\\CurrentBank.accdb");
                        break;

                    }
                }
                catch (Exception t)
                {
                    Log(t);
                    try
                    {
                        bookConn.Close();
                        oleDbCmd.Dispose();
                        bookConn.Dispose();

                        Move++;

                        String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";
                        bookConn = new OleDbConnection(connParam);
                        bookConn.Open();
                        oleDbCmd.Connection = bookConn;
                        String TableName = (Move).ToString();
                        String Zero = "Table";
                        for (int i = 0; i < 8 - TableName.Length; i++)
                            Zero += "0";
                        TableName = Zero + TableName;

                        oleDbCmd.CommandText = "Select * From " + TableName;
                        OleDbDataReader dr = null;
                        dr = oleDbCmd.ExecuteReader();
                        int ii = 0;
                        while (dr.Read())
                        {
                            Tab[0, ii] = System.Convert.ToInt32(dr["a"]);
                            Tab[1, ii] = System.Convert.ToInt32(dr["b"]);
                            Tab[2, ii] = System.Convert.ToInt32(dr["c"]);
                            Tab[3, ii] = System.Convert.ToInt32(dr["d"]);
                            Tab[4, ii] = System.Convert.ToInt32(dr["e"]);
                            Tab[5, ii] = System.Convert.ToInt32(dr["f"]);
                            Tab[6, ii] = System.Convert.ToInt32(dr["g"]);
                            Tab[7, ii] = System.Convert.ToInt32(dr["h"]);
                            ii++;
                        }
                        int[,] TableA = new int[8, 8];
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                                TableA[i, j] = Tab[i, j];

                        Draw.TableList.Clear();
                        Draw.TableList.Add(TableA);
                        Draw.SetRowColumn(0);
                        AllDraw.TableListAction.Add(TableA);
                        if (AllDraw.TableListAction.Count > 1)
                        {
                            ChessGeneticAlgorithm R = new ChessGeneticAlgorithm();
                            if (R.FindGenToModified(AllDraw.TableListAction[AllDraw.TableListAction.Count - 2], AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], AllDraw.TableListAction, 0, OrderPlate, true))
                            {
                                bool HitVal = false;
                                int Hit = AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRow, R.CromosomColumn];
                                if (Hit != 0)
                                    HitVal = true;
                                bool Convert = false;
                                if (OrderPlate == 1)
                                {
                                    if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][R.CromosomRow, R.CromosomColumn] == 1)
                                    {
                                        if (R.CromosomColumn == 7)
                                            Convert = true;
                                    }
                                    AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MoveNumber + 1, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActGray, Convert);
                                }
                                else
                                {
                                    if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst] == -1)
                                    {
                                        if (R.CromosomColumn == 0)
                                            Convert = true;
                                    }
                                    AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MoveNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActBrown, Convert);
                                }
                                SetBoxStatistic(AllDraw.SyntaxToWrite);
                                RefreshBoxStatistic();
                            }
                        }

                        bookConn.Close();
                        oleDbCmd.Dispose();
                        bookConn.Dispose();
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                                TableA[i, j] = Tab[i, j];


                        if ((new ChessRules(1, TableA, OrderPlate).Mate(TableA, OrderPlate)))
                        {
                            int iii = 0;
                            do { iii++; } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + iii.ToString() + ".accdb"));
                            System.IO.File.Copy("Database\\CurrentBank.accdb", "Database\\Games\\CurrentBank" + iii.ToString() + ".accdb");
                            System.IO.File.Delete("Database\\CurrentBank.accdb");
                            break;

                        }

                    }
                    catch (Exception tt)
                    {
                        Log(tt);
                        bookConn.Close();
                        oleDbCmd.Dispose();
                        bookConn.Dispose();
                        break;
                    }
                }
                if (Move > 1)
                {
                    OrderPlate *= -1;
                    ChessRules.CurrentOrder = OrderPlate;
                }


            } while (true);
            return Tab;


        }
        //Verify Accuarance of Table Games Methos.
        bool VerifyTable(String FileName, int Movment, ref int MoveNumber)
        {
            int[,] Tab = Table;
            int Move = 1;
            int Order = 1;
            //AllDraw.TableListAction.Clear();
            do
            {
                if (Move > 5000)
                    break;
                try
                {
                    if (Move % 2 == 1)
                        Order = 1;
                    else
                        Order = -1;
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileName + ";Persist Security Info=true;Jet OLEDB:Database Password=''";
                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    String TableName = Move.ToString();
                    String Zero = "Table";
                    for (int i = 0; i < 8 - TableName.Length; i++)
                        Zero += "0";
                    TableName = Zero + TableName;

                    oleDbCmd.CommandText = "Select * From " + TableName;
                    OleDbDataReader dr = null;
                    try
                    {
                        dr = oleDbCmd.ExecuteReader();
                    }
                    catch (Exception t)
                    {
                        Log(t);
                        Move++;
                        break;
                    }
                    int ii = 0;
                    while (dr.Read())
                    {
                        Tab[0, ii] = System.Convert.ToInt32(dr["a"]);
                        Tab[1, ii] = System.Convert.ToInt32(dr["b"]);
                        Tab[2, ii] = System.Convert.ToInt32(dr["c"]);
                        Tab[3, ii] = System.Convert.ToInt32(dr["d"]);
                        Tab[4, ii] = System.Convert.ToInt32(dr["e"]);
                        Tab[5, ii] = System.Convert.ToInt32(dr["f"]);
                        Tab[6, ii] = System.Convert.ToInt32(dr["g"]);
                        Tab[7, ii] = System.Convert.ToInt32(dr["h"]);
                        ii++;
                    }
                    int[,] TableA = new int[8, 8];
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                            TableA[i, j] = Tab[i, j];
                    Draw.TableList.Clear();
                    Draw.TableList.Add(TableA);
                    Draw.SetRowColumn(0);
                    if (!Draw.isEnemyThingsinStable(TableA, AllDraw.TableVeryfy, Order))
                    {
                        Tab = null;
                        Tab[0, 0] = -1;
                    }
                    else
                    {
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                                AllDraw.TableVeryfy[i, j] = Tab[i, j];
         
                    }
            

                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    Move++;
                    if (Move > 1)
                        MoveNumber++;
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                            TableA[i, j] = Tab[i, j];


                    if ((new ChessRules(1, TableA, OrderPlate).Mate(TableA, OrderPlate)))
                    {
                        int iii = 0;
                        do { iii++; } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + iii.ToString() + ".accdb"));
                        System.IO.File.Copy("Database\\CurrentBank.accdb", "Database\\Games\\CurrentBank" + iii.ToString() + ".accdb");
                        System.IO.File.Delete("Database\\CurrentBank.accdb");
                        break;

                    }
                }
                catch (Exception t)
                {
                End:
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();

                    do
                    {
                        Log(t);
                        try
                        {

                            Move++;

                            String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileName + ";Persist Security Info=true;Jet OLEDB:Database Password=''";
                            bookConn = new OleDbConnection(connParam);
                            bookConn.Open();
                            oleDbCmd.Connection = bookConn;
                            String TableName = (Move).ToString();
                            String Zero = "Table";
                            for (int i = 0; i < 8 - TableName.Length; i++)
                                Zero += "0";
                            TableName = Zero + TableName;

                            oleDbCmd.CommandText = "Drop Table " + TableName;
                            OleDbDataReader dr = null;
                            dr = oleDbCmd.ExecuteReader();
                            bookConn.Close();
                            oleDbCmd.Dispose();
                            bookConn.Dispose();

                        }
                        catch (Exception tt)
                        {
                            Log(tt);
                            bookConn.Close();
                            oleDbCmd.Dispose();
                            bookConn.Dispose();
                            return false;
                        }
                    } while (true);
                }
                if (Move > 1)
                {
                    OrderPlate *= -1;
                    ChessRules.CurrentOrder = OrderPlate;
                }


            } while (true);
            return true;


        }
        //Read Specific Table Number.
        int[,] ReadTableMovmentNumber()
        {
            int[,] Tab = Table;
            int Move = MovmentsNumber;
            AllDraw.TableListAction.Clear();

            try
            {
                if (Move > 1)
                {
                    if (MovmentsNumber % 2 == 0)
                        OrderPlate = 1;
                    else
                        OrderPlate = -1;
                    ChessRules.CurrentOrder = OrderPlate;
                }
                String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";
                bookConn = new OleDbConnection(connParam);
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                String TableName = Move.ToString();
                String Zero = "Table";
                for (int i = 0; i < 8 - TableName.Length; i++)
                    Zero += "0";
                TableName = Zero + TableName;

                oleDbCmd.CommandText = "Select * From " + TableName;
                OleDbDataReader dr = null;
                dr = oleDbCmd.ExecuteReader();
                int ii = 0;
                while (dr.Read())
                {
                    Tab[0, ii] = System.Convert.ToInt32(dr["a"]);
                    Tab[1, ii] = System.Convert.ToInt32(dr["b"]);
                    Tab[2, ii] = System.Convert.ToInt32(dr["c"]);
                    Tab[3, ii] = System.Convert.ToInt32(dr["d"]);
                    Tab[4, ii] = System.Convert.ToInt32(dr["e"]);
                    Tab[5, ii] = System.Convert.ToInt32(dr["f"]);
                    Tab[6, ii] = System.Convert.ToInt32(dr["g"]);
                    Tab[7, ii] = System.Convert.ToInt32(dr["h"]);
                    ii++;
                }
                int[,] TableA = new int[8, 8];
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        TableA[i, j] = Tab[i, j];

                AllDraw.TableListAction.Add(TableA);
                if (AllDraw.TableListAction.Count > 1)
                {
                    ChessGeneticAlgorithm R = new ChessGeneticAlgorithm();
                    if (R.FindGenToModified(AllDraw.TableListAction[AllDraw.TableListAction.Count - 2], AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], AllDraw.TableListAction, 0, OrderPlate, true))
                    {
                        bool HitVal = false;
                        int Hit = AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRow, R.CromosomColumn];
                        if (Hit != 0)
                            HitVal = true;
                        bool Convert = false;
                        if (OrderPlate == 1)
                        {
                            if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][R.CromosomRow, R.CromosomColumn] == 1)
                            {
                                if (R.CromosomColumn == 7)
                                    Convert = true;
                            }
                            AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActGray, Convert);
                        }
                        else
                        {
                            if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][R.CromosomRowFirst, R.CromosomColumnFirst] == -1)
                            {
                                if (R.CromosomColumn == 0)
                                    Convert = true;
                            }
                            AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActBrown, Convert);
                        }
                        SetBoxStatistic(AllDraw.SyntaxToWrite);
                        RefreshBoxStatistic();
                    }
                }


                bookConn.Close();
                oleDbCmd.Dispose();
                bookConn.Dispose();
                Move++;

                if ((new ChessRules(1, Tab, OrderPlate).Mate(Tab, OrderPlate)))
                {
                    int iii = 0;
                    do { iii++; } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + iii.ToString() + ".accdb"));
                    System.IO.File.Copy("Database\\CurrentBank.accdb", "Database\\Games\\CurrentBank" + iii.ToString() + ".accdb");
                    System.IO.File.Delete("Database\\CurrentBank.accdb");
                    return TableA;

                }
            }
            catch (Exception t)
            {
                Log(t);
                try
                {
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();

                    Move++;

                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";
                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    String TableName = (Move).ToString();
                    String Zero = "Table";
                    for (int i = 0; i < 8 - TableName.Length; i++)
                        Zero += "0";
                    TableName = Zero + TableName;

                    oleDbCmd.CommandText = "Select * From " + TableName;
                    OleDbDataReader dr = null;
                    dr = oleDbCmd.ExecuteReader();
                    int ii = 0;
                    while (dr.Read())
                    {
                        Tab[0, ii] = System.Convert.ToInt32(dr["a"]);
                        Tab[1, ii] = System.Convert.ToInt32(dr["b"]);
                        Tab[2, ii] = System.Convert.ToInt32(dr["c"]);
                        Tab[3, ii] = System.Convert.ToInt32(dr["d"]);
                        Tab[4, ii] = System.Convert.ToInt32(dr["e"]);
                        Tab[5, ii] = System.Convert.ToInt32(dr["f"]);
                        Tab[6, ii] = System.Convert.ToInt32(dr["g"]);
                        Tab[7, ii] = System.Convert.ToInt32(dr["h"]);
                        ii++;
                    }
                    int[,] TableA = new int[8, 8];
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                            TableA[i, j] = Tab[i, j];

                    AllDraw.TableListAction.Add(TableA);
                    if (AllDraw.TableListAction.Count > 1)
                    {
                        ChessGeneticAlgorithm R = new ChessGeneticAlgorithm();
                        if (R.FindGenToModified(AllDraw.TableListAction[AllDraw.TableListAction.Count - 2], AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], AllDraw.TableListAction, 0, OrderPlate, true))
                        {
                            bool HitVal = false;
                            int Hit = AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRow, R.CromosomColumn];
                            if (Hit != 0)
                                HitVal = true;
                            bool Convert = false;
                            if (OrderPlate == 1)
                            {
                                if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][R.CromosomRow, R.CromosomColumn] == 1)
                                {
                                    if (R.CromosomColumn == 7)
                                        Convert = true;
                                }
                                AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActGray, Convert);
                            }
                            else
                            {
                                if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst] == -1)
                                {
                                    if (R.CromosomColumn == 0)
                                        Convert = true;
                                }
                                AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(TableA, MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 2][R.CromosomRowFirst, R.CromosomColumnFirst], R.CromosomColumn, R.CromosomRow, HitVal, Hit, ChessRules.BridgeActBrown, Convert);
                            }
                            SetBoxStatistic(AllDraw.SyntaxToWrite);
                            RefreshBoxStatistic();
                        }
                    }

                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    if ((new ChessRules(1, Tab, OrderPlate).Mate(Tab, OrderPlate)))
                    {
                        int iii = 0;
                        do { iii++; } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + iii.ToString() + ".accdb"));
                        System.IO.File.Copy("Database\\CurrentBank.accdb", "Database\\Games\\CurrentBank" + iii.ToString() + ".accdb");
                        System.IO.File.Delete("Database\\CurrentBank.accdb");
                        return TableA; ;

                    }

                }
                catch (Exception tt)
                {
                    Log(tt);
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    return null;
                }
            }



            return Tab;


        }
        //Creation of New Tables at DatabaseMethod.
        String CreatTable()
        {
        Begin12:
            try
            {
                String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                bookConn = new OleDbConnection(connParam);
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                String TableName = MovmentsNumber.ToString();
                String Zero = "Table";
                for (int i = 0; i < 8 - TableName.Length; i++)
                    Zero += "0";
                TableName = Zero + TableName;

                oleDbCmd.CommandText = "Create Table " + TableName + " (a Number NOT NULL,b Number NOT NULL,c Number NOT NULL,d Number NOT NULL,e Number NOT NULL,f Number NOT NULL,g Number NOT NULL,h Number NOT NULL)";
                int temp = 0;
                temp = oleDbCmd.ExecuteNonQuery();
                bookConn.Close();
                oleDbCmd.Dispose();
                bookConn.Dispose();
                return TableName;
            }
            catch (Exception t)
            {
                Log(t);
                String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                bookConn = new OleDbConnection(connParam);
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                String TableName = MovmentsNumber.ToString();
                String Zero = "Table";
                for (int i = 0; i < 8 - TableName.Length; i++)
                    Zero += "0";
                TableName = Zero + TableName;

                oleDbCmd.CommandText = "Drop Table " + TableName;
                int temp = 0;
                temp = oleDbCmd.ExecuteNonQuery();
                bookConn.Close();
                oleDbCmd.Dispose();
                bookConn.Dispose();
                goto Begin12;

            }
        }
        //Creatiopn of Configuration Table
        void CreateConfigurationTable()
        {
            if (!AllDrawLoad)
            {
            Begin12:
                try
                {
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;

                    oleDbCmd.CommandText = "Create Table Configuration (checkBoxDeptHuristic Number NOT NULL,checkBoxPredictHuristci Number NOT NULL,checkBoxDeptFirstSearch Number NOT NULL,checkBoxBestMovments Number NOT NULL,checkBoxOnlySelf Number NOT NULL,radioButtonOriginalImages Number NOT NULL,radioButtonBigFittingImages Number NOT NULL,radioButtonSmallFittingImages Number NOT NULL,checkBoxDeptMovement Number NOT NULL,checkBoxUseDoubleTime Number NOT NULL,checkBoxUsePenaltyRegradMechnisam Number NOT NULL,checkBoxDynamicProgrammingDeptFirst Number NOT NULL)";
                    int temp = 0;
                    temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;

                    oleDbCmd.CommandText = "Insert into Configuration (checkBoxDeptHuristic,checkBoxPredictHuristci,checkBoxDeptFirstSearch,checkBoxBestMovments,checkBoxOnlySelf,radioButtonOriginalImages,radioButtonBigFittingImages,radioButtonSmallFittingImages,checkBoxDeptMovement,checkBoxUseDoubleTime,checkBoxUsePenaltyRegradMechnisam,checkBoxDynamicProgrammingDeptFirst) values(" + System.Convert.ToInt32(checkBoxDeptHuristic.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxPredictHuristci.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxDeptFirstSearch.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxBestMovments.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxOnlySelf.Checked).ToString() + "," + System.Convert.ToInt32(radioButtonOriginalImages.Checked).ToString() + "," + System.Convert.ToInt32(radioButtonBigFittingImages.Checked).ToString() + "," + System.Convert.ToInt32(radioButtonSmallFittingImages.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxBestMovments.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxUseDoubleTime.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxUsePenaltyRegradMechnisam.Checked).ToString() + "," + System.Convert.ToInt32(checkBoxDynamicProgrammingDeptFirst.Checked).ToString() + ")";

                    temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();

                }
                catch (Exception t)
                {
                    Log(t);
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    oleDbCmd.CommandText = "Drop Table Configuration";
                    int temp = 0;
                    temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    goto Begin12;

                }
            }
        }
        //Reading of Configuration Table Method.
        void ReadConfigurationTable()
        {
            if (!AllDrawLoad)
            {
            Begin12:
                try
                {
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;

                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;

                    oleDbCmd.CommandText = "Select * from Configuration";
                    OleDbDataReader dr = null;
                    dr = oleDbCmd.ExecuteReader();
                    if (dr.Read())
                    {
                        checkBoxDeptHuristic.Checked = System.Convert.ToBoolean(dr["checkBoxDeptHuristic"]);
                        checkBoxPredictHuristci.Checked = System.Convert.ToBoolean(dr["checkBoxPredictHuristci"]);
                        checkBoxDeptFirstSearch.Checked = System.Convert.ToBoolean(dr["checkBoxDeptFirstSearch"]);
                        checkBoxBestMovments.Checked = System.Convert.ToBoolean(dr["checkBoxBestMovments"]);
                        checkBoxOnlySelf.Checked = System.Convert.ToBoolean(dr["checkBoxOnlySelf"]);
                        radioButtonOriginalImages.Checked = System.Convert.ToBoolean(dr["radioButtonOriginalImages"]);
                        radioButtonBigFittingImages.Checked = System.Convert.ToBoolean(dr["radioButtonBigFittingImages"]);
                        radioButtonSmallFittingImages.Checked = System.Convert.ToBoolean(dr["radioButtonSmallFittingImages"]);
                        checkBoxDeptMovement.Checked = System.Convert.ToBoolean(dr["checkBoxDeptMovement"]);
                        checkBoxUseDoubleTime.Checked = System.Convert.ToBoolean(dr["checkBoxUseDoubleTime"]);
                        checkBoxUsePenaltyRegradMechnisam.Checked = System.Convert.ToBoolean(dr["checkBoxUsePenaltyRegradMechnisam"]);
                        checkBoxDynamicProgrammingDeptFirst.Checked = System.Convert.ToBoolean(dr["checkBoxDynamicProgrammingDeptFirst"]);

                    }
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();

                }
                catch (Exception t)
                {
                    Log(t);
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    oleDbCmd.CommandText = "Drop Table Configuration";
                    int temp = 0;
                    temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    goto Begin12;

                }
            }
        }
        //Updating of Configuration Method.
        void UpdateConfigurationTable()
        {
            if (UpdateConfigurationTableVal)
            {
            Begin12:
                try
                {
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;

                    oleDbCmd.CommandText = "Update Configuration Set checkBoxDeptHuristic=" + System.Convert.ToInt32(checkBoxDeptHuristic.Checked).ToString() + ",checkBoxPredictHuristci=" + System.Convert.ToInt32(checkBoxPredictHuristci.Checked).ToString() + ",checkBoxDeptFirstSearch=" + System.Convert.ToInt32(checkBoxDeptFirstSearch.Checked).ToString() + ",checkBoxBestMovments=" + System.Convert.ToInt32(checkBoxBestMovments.Checked).ToString() + ",checkBoxOnlySelf=" + System.Convert.ToInt32(checkBoxOnlySelf.Checked).ToString() + ",radioButtonOriginalImages=" + System.Convert.ToInt32(radioButtonOriginalImages.Checked).ToString() + ",radioButtonBigFittingImages=" + System.Convert.ToInt32(radioButtonBigFittingImages.Checked).ToString() + ",radioButtonSmallFittingImages=" + System.Convert.ToInt32(radioButtonSmallFittingImages.Checked).ToString() + ",checkBoxDeptMovement=" + System.Convert.ToInt32(checkBoxDeptMovement.Checked).ToString() + ",checkBoxUseDoubleTime=" + System.Convert.ToInt32(checkBoxUseDoubleTime.Checked).ToString() + ",checkBoxUsePenaltyRegradMechnisam=" + System.Convert.ToInt32(checkBoxUsePenaltyRegradMechnisam.Checked).ToString() + ",checkBoxDynamicProgrammingDeptFirst=" + System.Convert.ToInt32(checkBoxDynamicProgrammingDeptFirst.Checked).ToString();

                    int temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();

                }
                catch (Exception t)
                {
                    Log(t);
                    String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

                    bookConn = new OleDbConnection(connParam);
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    oleDbCmd.CommandText = "Drop Table Configuration";
                    int temp = 0;
                    temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();
                    oleDbCmd.Dispose();
                    bookConn.Dispose();
                    goto Begin12;

                }
            }
        }
        //Inserting of New Tabler at Database.
        void InsertTableAtDataBase(int[,] Tab)
        {
            String TableName = CreatTable();
            String connParam = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]) + "\\" + "Database\\CurrentBank.accdb;Persist Security Info=true;Jet OLEDB:Database Password=''";

            bookConn = new OleDbConnection(connParam);
            bookConn.Open();
            oleDbCmd.Connection = bookConn;
            for (int i = 0; i < 8; i++)
            {
                oleDbCmd.CommandText = "insert into " + TableName + "(a,b,c,d,e,f,g,h)  values (" + Tab[0, i].ToString() + "," + Tab[1, i].ToString() + "," + Tab[2, i].ToString() + "," + Tab[3, i].ToString() + "," + Tab[4, i].ToString() + "," + Tab[5, i].ToString() + "," + Tab[6, i].ToString() + "," + Tab[7, i].ToString() + ")";
                int temp = 0;
                temp = oleDbCmd.ExecuteNonQuery();

            }
            bookConn.Close();
            oleDbCmd.Dispose();
            bookConn.Dispose();

        }
        //Painting of Form Refregitz PictureBox and Tow Timer Pictue Box on Time.
        private void pictureBoxRefrigtz_Paint(object sender, PaintEventArgs e)
        {


            //if (!Person) { AllDraw.RedrawTable = true; }

            if (AllDraw.TableListAction.Count > 3)
                toolStripMenuItemRandomGeneticGames.Enabled = true;
            else
                toolStripMenuItemRandomGeneticGames.Enabled = false;
            if (!GrayTimer.Paused)
            try
            {
                TimerImage = (Image)new Bitmap(pictureBoxTimerGray.Width, pictureBoxTimerGray.Height);
                g1 = Graphics.FromImage(TimerImage);
                g1.FillRectangle(new SolidBrush(Color.Gray), new Rectangle(new Point(0, 0), new Size(pictureBoxTimerGray.Width, pictureBoxTimerGray.Height)));
                g1.DrawString(GrayTimer.ReturnTime(), new Font("Times New Roman", 30), new SolidBrush(Color.Black), new PointF(5, 5));
                pictureBoxTimerGray.Image = TimerImage;
                g1.Dispose();
                GrayTimer.TextChanged = false;
            }
            catch (Exception t)
            {
                pictureBoxTimerGray.Update();
                pictureBoxTimerGray.Invalidate();
                RunInFront();
                Log(t);
            }



            if (!BrownTimer.Paused)
            try
            {
                TimerImage1 = (Image)new Bitmap(pictureBoxTimerBrown.Width, pictureBoxTimerBrown.Height);
                g2 = Graphics.FromImage(TimerImage1);
                g2.FillRectangle(new SolidBrush(Color.Brown), new Rectangle(new Point(0, 0), new Size(pictureBoxTimerBrown.Width, pictureBoxTimerBrown.Height)));
                g2.DrawString(BrownTimer.ReturnTime(), new Font("Times New Roman", 30), new SolidBrush(Color.Black), new PointF(5, 5));
                pictureBoxTimerBrown.Image = TimerImage1;
                g2.Dispose();
                BrownTimer.TextChanged = false;
            }
            catch (Exception t)
            {
                Log(t);
                pictureBoxTimerBrown.Update();
                pictureBoxTimerBrown.Invalidate();
                RunInFront();
            }

            if (GrayTimer.EndTime)
                BrownWiner = true;
            if (BrownTimer.EndTime)
                GrayWinner = true;
            if (GrayWinner || BrownWiner)
            {
                if (t1 != null)
                    t1.Abort();
                if (t2 != null)
                    t2.Abort();
                if (t3 != null)
                    t3.Abort();
                if (GrayWinner)
                    SetBoxText("\r\nGray Winees!");
                if (BrownWiner)
                    SetBoxText("\r\nBrown Winees!");

                return;
            }
            //if (AllDraw.RedrawTable)
            try
            {

                //ReconstructTable();
                pictureBoxRefrigtz.Image = (Image)new Bitmap(pictureBoxRefrigtz.Width, pictureBoxRefrigtz.Height);
                ChessTable = (Image)new Bitmap(pictureBoxRefrigtz.Image.Width, pictureBoxRefrigtz.Image.Height);
                g = Graphics.FromImage(ChessTable);
                g.FillRectangle(new SolidBrush(Color.Yellow), new Rectangle(0, 0, pictureBoxRefrigtz.Width, pictureBoxRefrigtz.Height));
                Color a = Color.Gray;
                if (OrderPlate == -1)
                    a = Color.Brown;
                bool[,] Tab=null;
                if (RowClickP != -1 && ColumnClickP != -1)
                    Tab = VeryFye(Table, OrderPlate, a);
                for (int i = 0; i < pictureBoxRefrigtz.Image.Width; i += pictureBoxRefrigtz.Image.Width / 8)
                    for (int j = 0; j < pictureBoxRefrigtz.Image.Height; j += pictureBoxRefrigtz.Image.Height / 8)
                    {
                        //if ((i + j) % 2 == 0)
                        //     g.FillRectangle(new SolidBrush(Color.Black), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                        // else
                        //    g.FillRectangle(new SolidBrush(Color.White), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                        try
                        {
                            if ((i + j) % 2 == 0)
                                g.DrawImage(Image.FromFile("Images\\Program\\Black.jpg"), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                            else
                                g.DrawImage(Image.FromFile("Images\\Program\\White.jpg"), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                            if (Tab[i / (pictureBoxRefrigtz.Image.Width / 8), j / (pictureBoxRefrigtz.Image.Height / 8)])
                            {
                                g.DrawString("*",new Font("Times New Roman",50),new SolidBrush(Color.Red), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                            }

                        }
                        catch (Exception t) { Log(t); }
                    }

                for (int i = 0; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        Draw.SolderesOnTable[i].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                    }
                    catch (Exception t)
                    {
                        Log(t);
                    }
                }
                for (int i = 0; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {
                        Draw.ElephantOnTable[i].DrawElefantOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                    }
                    catch (Exception t)
                    {
                        Log(t);
                    }
                }
                for (int i = 0; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        Draw.HoursesOnTable[i].DrawHourseOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                    }
                    catch (Exception t)
                    {
                        Log(t);
                    }
                }
                for (int i = 0; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {
                        Draw.BridgesOnTable[i].DrawBridgeOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                    }
                    catch (Exception t)
                    {
                        Log(t);
                    }

                }


                for (int i = 0; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {
                        Draw.MinisterOnTable[i].DrawMinisterOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                    }
                    catch (Exception t)
                    {
                        Log(t);
                    }
                }

                for (int i = 0; i < AllDraw.KingHigh; i++)
                {
                    try
                    {
                        Draw.KingOnTable[i].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                    }
                    catch (Exception t)
                    {
                        Log(t);
                    }
                }


                pictureBoxRefrigtz.Image = ChessTable;
                g.Dispose();

                LoadedTable = true;
            }
            catch (Exception t)
            {
                Log(t);
                pictureBoxRefrigtz.Update();
                pictureBoxRefrigtz.Invalidate();
                RunInFront();
            }
            System.Threading.Thread.Sleep(5);
        }
        //All Operation of Thinking Handling.
        void AllOperations()
        {
            do
            {
                AllDraw.SyntaxToWrite = "";
                Thread.Sleep(50);
                try
                {


                    if (ChessGeneticAlgorithm.NoGameFounf)
                    {
                        SetBoxText("No Game Could be continued!");
                        RefreshBoxText();

                    }

                    if ((new ChessRules(1, Table, OrderPlate)).Mate(Table, OrderPlate))
                    {
                        if (ChessRules.MateGray || ChessRules.MateBrown || EndOfGame)
                        {
                            StateCC = false;
                            StateCP = false;
                            Person = false;
                            SetBoxText("\r\nMate!");
                            RefreshBoxText();
                            AllOperate.Suspend();




                        }
                        else
                        {


                            if (ChessRules.MateGray && OrderPlate == 1)


                                if (ChessRules.KishGray || ChessRules.KishBrown)
                                {
                                    if (OrderPlate == 1)

                                        SetBoxText("\r\nGray OrderPlate!Kish!");
                                    else
                                        SetBoxText("\r\nBrown OrderPlate!Kish!");


                                }
                        }
                    }


                    /* if (AllDraw.MouseClick == 2)
                      {
                          Color color = Color.Gray; ;
                          if (Table[(int)RowClickP, (int)ColumnClickP] > 0)
                              color = Color.Gray;
                          else
                              if (Table[(int)RowClickP, (int)ColumnClickP] < 0)
                                  color = Color.Brown;
                          A = (new ChessRules(Table[(int)RowClickP, (int)ColumnClickP], Table, OrderPlate));
                          if (A.Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, color, Table[(int)RowRealesed, (int)ColumnRealeased]))
                          {
                              if (A.KishConstructor(color, RowClickP, ColumnClickP, RowRealesed, ColumnRealeased, Table[(int)RowClickP, (int)ColumnClickP], OrderPlate))
                              {
                                  //return;
                              }
                              if (A.KishRemovableByAttack(Table, OrderPlate))
                              {
                                  if (ChessRules.KishGray)
                                  {
                                  }
                                  if (ChessRules.KishBrown)
                                  {
                                  }
                              }



                          }



                      }
                      try
                      {
                          if (OrderPlate == 1)
                              A = (new ChessRules(6, Table, OrderPlate));
                          else
                              A = (new ChessRules(-6, Table, OrderPlate));               
                      }
                      catch (Exception t)
                      {
                      }
                      */
                    if (!ChessRules.MateBrown && !ChessRules.MateGray)
                    {
                        if (AllDraw.MouseClick > 0 && ((!StateCC || StateCP) || Person))
                        {


                            try
                            {
                                Color a = Color.Gray;
                                if (OrderPlate == -1)
                                    a = Color.Brown;
                                bool[,] Tab = null;
                                if (RowClickP != -1 && ColumnClickP != -1)
                                    Tab = VeryFye(Table, OrderPlate, a);
                                if ((RowRealesed + ColumnRealeased) % 2 == 0)
                                    g.DrawImage(Image.FromFile("Images\\Program\\Black.jpg"), new Rectangle((int)RowRealesed, (int)ColumnRealeased, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                                else
                                    g.DrawImage(Image.FromFile("Images\\Program\\White.jpg"), new Rectangle((int)RowRealesed, (int)ColumnRealeased, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                                
                            }
                            catch (Exception t) { RunInFront(); Log(t); }

                            if ((!StateCC && StateCP) || Person)
                            {
                                if (Sec.radioButtonGrayOrder.Checked)
                                {
                                    if (ColumnClickP == ColumnRealeased && System.Math.Abs(RowClickP - RowRealesed) > 1 && Table[(int)RowClickP, (int)ColumnClickP] == 6)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, King);

                                            Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -6;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(7, Table, 1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Gray, 7))
                                                {
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = 7;
                                                    Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, King);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = 6;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 6, (int)ColumnClickP, (int)RowClickP, false, 5, true, false));
                                                    if (RowClickP > RowRealesed)
                                                    {
                                                        Table[(int)RowRealesed - 1, (int)ColumnRealeased] = 4;
                                                        for (int i = 0; i < 4; i++)
                                                        {
                                                            if (Draw.BridgesOnTable[i].Row == RowRealesed && Draw.BridgesOnTable[i].Column == ColumnRealeased)
                                                            {
                                                                Draw.BridgesOnTable[i] = new DrawBridge(RowRealesed + 1, ColumnRealeased, Color.Gray, Table, OrderPlate, false, King);
                                                                break;

                                                            }

                                                        }

                                                    }
                                                    else
                                                    {
                                                        Table[(int)RowRealesed + 1, (int)ColumnRealeased] = 4;
                                                        for (int i = 0; i < 4; i++)
                                                        {
                                                            if (Draw.BridgesOnTable[i].Row == RowRealesed && Draw.BridgesOnTable[i].Column == ColumnRealeased)
                                                            {
                                                                Draw.BridgesOnTable[i] = new DrawBridge(RowRealesed - 1, ColumnRealeased, Color.Gray, Table, OrderPlate, false, King);
                                                                break;

                                                            }

                                                        }
                                                    }


                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);



                                                    GrayTimer.StopTime();
                                                    BrownTimer.StartTime();

                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    AllDraw.TableListAction.Add(Table);
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                        AllDraw.StoreADraw.Add(Draw);
                                                }

                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = -6;
                                                    Draw.KingOnTable[King] = new DrawKing(RowClickP, ColumnClickP, Color.Gray, Table, OrderPlate, false, King);
                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                                    MovmentsNumber++;
                                                }


                                            }

                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == 1)
                                    {
                                        if (AllDraw.MouseClick == 1)
                                        {

                                            Draw.SolderesOnTable[Soldier] = new DrawSoldier(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Soldier);
                                            Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = 1;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {

                                                if ((new ChessRules(1, Table, 1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Gray, 1))
                                                {
                                                    ThingsConverter.ActOfClickEqualTow = true;
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = 1;
                                                    Draw.SolderesOnTable[Soldier].ConvertOperation((int)RowRealesed, (int)ColumnRealeased, Color.Gray, Table, OrderPlate, false, Soldier);
                                                    if (Draw.SolderesOnTable[Soldier].Convert)
                                                    {
                                                        int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                        bool HitVal = false;
                                                        if (Hit != 0)
                                                            HitVal = true;
                                                        SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 1, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, true));

                                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                        if (Draw.SolderesOnTable[Soldier].ConvertedToMinister)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = 5;
                                                        else if (Draw.SolderesOnTable[Soldier].ConvertedToBridge)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = 4;
                                                        else if (Draw.SolderesOnTable[Soldier].ConvertedToHourse)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = 3;
                                                        else if (Draw.SolderesOnTable[Soldier].ConvertedToElefant)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = 2;

                                                        Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                                    }
                                                    else
                                                    {
                                                        int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                        bool HitVal = false;
                                                        if (Hit != 0)
                                                            HitVal = true;
                                                        SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 1, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));

                                                        Draw.SolderesOnTable[Soldier] = new DrawSoldier(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Soldier);
                                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                        Table[(int)RowRealesed, (int)ColumnRealeased] = 1;
                                                        Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                                    }


                                                    Person = false;
                                                    AllDraw.TableListAction.Add(Table);
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    GrayTimer.StopTime();
                                                    BrownTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Draw.SolderesOnTable[Soldier] = new DrawSoldier(RowClickP, ColumnClickP, Color.Gray, Table, OrderPlate, false, Soldier);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 1;
                                                    Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }


                                            }


                                    }

                                    if (Table[(int)RowClickP, (int)ColumnClickP] == 2)
                                    {
                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.ElephantOnTable[Elefant] = new DrawElefant(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Elefant);
                                            Draw.ElephantOnTable[Elefant].DrawElefantOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = 2;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(2, Table, 1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Gray, 2))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 2, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = 2;
                                                    Draw.ElephantOnTable[Elefant] = new DrawElefant(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Elefant);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = 2;
                                                    Draw.ElephantOnTable[Elefant].DrawElefantOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    Person = false;
                                                    AllDraw.TableListAction.Add(Table);
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    GrayTimer.StopTime();
                                                    BrownTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = 2;
                                                    Draw.ElephantOnTable[Elefant] = new DrawElefant(RowClickP, ColumnClickP, Color.Gray, Table, OrderPlate, false, Elefant);
                                                    Draw.ElephantOnTable[Elefant].DrawElefantOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                                }
                                            }


                                    }

                                    if (Table[(int)RowClickP, (int)ColumnClickP] == 3)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.HoursesOnTable[Hourse] = new DrawHourse(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Hourse);
                                            Draw.HoursesOnTable[Hourse].DrawHourseOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = 3;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(3, Table, 1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Gray, 3))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 3, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = 3;
                                                    Draw.HoursesOnTable[Hourse] = new DrawHourse(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Hourse);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = 3;
                                                    Draw.HoursesOnTable[Hourse].DrawHourseOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    GrayTimer.StopTime();
                                                    BrownTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = 3;
                                                    Draw.HoursesOnTable[Hourse] = new DrawHourse(RowClickP, ColumnClickP, Color.Gray, Table, OrderPlate, false, Hourse);
                                                    Draw.HoursesOnTable[Hourse].DrawHourseOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }


                                            }


                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == 4)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.BridgesOnTable[Bridge] = new DrawBridge(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Bridge);
                                            Draw.BridgesOnTable[Bridge].DrawBridgeOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = 4;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(4, Table, 1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Gray, 4))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 4, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = 4;
                                                    Draw.BridgesOnTable[Bridge] = new DrawBridge(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Bridge);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = 4;
                                                    Draw.BridgesOnTable[Bridge].DrawBridgeOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    GrayTimer.StopTime();
                                                    BrownTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = 4;
                                                    Draw.BridgesOnTable[Bridge] = new DrawBridge(RowClickP, ColumnClickP, Color.Gray, Table, OrderPlate, false, Bridge);
                                                    Draw.BridgesOnTable[Bridge].DrawBridgeOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }
                                            }


                                    }


                                    if (Table[(int)RowClickP, (int)ColumnClickP] == 5)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.MinisterOnTable[Minister] = new DrawMinister(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Minister);

                                            Draw.MinisterOnTable[Minister].DrawMinisterOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = 5;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {

                                                if ((new ChessRules(5, Table, 1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Gray, 5))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 5, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = 5;
                                                    Draw.MinisterOnTable[Minister] = new DrawMinister(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, Minister);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = 5;
                                                    Draw.MinisterOnTable[Minister].DrawMinisterOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    GrayTimer.StopTime();
                                                    BrownTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = 5;
                                                    Draw.MinisterOnTable[Minister] = new DrawMinister(RowClickP, ColumnClickP, Color.Gray, Table, OrderPlate, false, Minister);
                                                    Draw.MinisterOnTable[Minister].DrawMinisterOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }

                                            }


                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == 6)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, King);

                                            Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] =0;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(6, Table, 1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Gray, 6))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, 6, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = 6;
                                                    Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Gray, Table, OrderPlate, false, King);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = 6;
                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    GrayTimer.StopTime();
                                                    BrownTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }

                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = 6;
                                                    Draw.KingOnTable[King] = new DrawKing(RowClickP, ColumnClickP, Color.Gray, Table, OrderPlate, false, King);
                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }

                                            }


                                    }
                                }


                                if (Sec.radioButtonBrownOrder.Checked)
                                {
                                    if (ColumnRealeased == ColumnClickP && System.Math.Abs(RowClickP - RowClickP) > 1 && Table[(int)RowClickP, (int)ColumnClickP] == -6)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, King);

                                            Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -6;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(-7, Table, -1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Brown, -7))
                                                {
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = -7;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -6, (int)ColumnClickP, (int)RowClickP, false, 5, true, false));
                                                    Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, King);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = -6;
                                                    if (RowClickP > RowRealesed)
                                                    {
                                                        Table[(int)RowRealesed - 1, (int)ColumnRealeased] = 4;
                                                        for (int i = 0; i < 4; i++)
                                                        {
                                                            if (Draw.BridgesOnTable[i].Row == RowRealesed && Draw.BridgesOnTable[i].Column == ColumnRealeased)
                                                            {
                                                                Draw.BridgesOnTable[i] = new DrawBridge(RowRealesed + 1, ColumnRealeased, Color.Brown, Table, OrderPlate, false, King);
                                                                break;

                                                            }

                                                        }
                                                    }

                                                    else
                                                    {
                                                        Table[(int)RowRealesed + 1, (int)ColumnRealeased] = 4;
                                                        for (int i = 0; i < 4; i++)
                                                        {
                                                            if (Draw.BridgesOnTable[i].Row == RowRealesed && Draw.BridgesOnTable[i].Column == ColumnRealeased)
                                                            {
                                                                Draw.BridgesOnTable[i] = new DrawBridge(RowRealesed - 1, ColumnRealeased, Color.Brown, Table, OrderPlate, false, King);
                                                                break;

                                                            }

                                                        }
                                                    }


                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);


                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    BrownTimer.StopTime();
                                                    GrayTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }

                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = -6;
                                                    Draw.KingOnTable[King] = new DrawKing(RowClickP, ColumnClickP, Color.Brown, Table, OrderPlate, false, King);
                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }


                                            }


                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == -1)
                                    {

                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.SolderesOnTable[Soldier] = new DrawSoldier(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Soldier);

                                            Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -1;

                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(-1, Table, -1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Brown, -1))
                                                {
                                                    ThingsConverter.ActOfClickEqualTow = true;
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = -1;
                                                    Draw.SolderesOnTable[Soldier].ConvertOperation((int)RowRealesed, (int)ColumnRealeased, Color.Gray, Table, OrderPlate, false, Soldier);
                                                    if (Draw.SolderesOnTable[Soldier].Convert)
                                                    {
                                                        int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                        bool HitVal = false;
                                                        if (Hit != 0)
                                                            HitVal = true;
                                                        SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -1,(int)ColumnRealeased, (int)ColumnRealeased, HitVal, Hit, false, true));

                                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                        if (Draw.SolderesOnTable[Soldier].ConvertedToMinister)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = -5;
                                                        else if (Draw.SolderesOnTable[Soldier].ConvertedToBridge)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = -4;
                                                        else if (Draw.SolderesOnTable[Soldier].ConvertedToHourse)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = -3;
                                                        else if (Draw.SolderesOnTable[Soldier].ConvertedToElefant)
                                                            Table[(int)RowRealesed, (int)ColumnRealeased] = -2;
                                                        Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    }
                                                    else
                                                    {
                                                        int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                        bool HitVal = false;
                                                        if (Hit != 0)
                                                            HitVal = true;
                                                        SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -1, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));

                                                        Draw.SolderesOnTable[Soldier] = new DrawSoldier(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Soldier);
                                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                        Table[(int)RowRealesed, (int)ColumnRealeased] = -1;
                                                    }
                                                    Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    BrownTimer.StopTime();
                                                    GrayTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = -1;
                                                    Draw.SolderesOnTable[Soldier] = new DrawSoldier(RowClickP, ColumnClickP, Color.Brown, Table, OrderPlate, false, Soldier);
                                                    Draw.SolderesOnTable[Soldier].DrawSoldierOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }

                                            }


                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == -2)
                                    {
                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.ElephantOnTable[Elefant] = new DrawElefant(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Elefant);
                                            Draw.ElephantOnTable[Elefant].DrawElefantOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -2;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(-2, Table, -1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Brown, -2))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -2, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = -2;
                                                    Draw.ElephantOnTable[Elefant] = new DrawElefant(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Elefant);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = -2;
                                                    Draw.ElephantOnTable[Elefant].DrawElefantOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    BrownTimer.StopTime();
                                                    GrayTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = -2;
                                                    Draw.ElephantOnTable[Elefant] = new DrawElefant(RowClickP, ColumnClickP, Color.Brown, Table, OrderPlate, false, Elefant);
                                                    Draw.ElephantOnTable[Elefant].DrawElefantOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }

                                            }


                                    }

                                    if (Table[(int)RowClickP, (int)ColumnClickP] == -3)
                                    {

                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.HoursesOnTable[Hourse] = new DrawHourse(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Hourse);

                                            Draw.HoursesOnTable[Hourse].DrawHourseOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -3;

                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(-3, Table, -1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Brown, -3))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -3, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = -3;
                                                    Draw.HoursesOnTable[Hourse] = new DrawHourse(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Hourse);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = -3;
                                                    Draw.HoursesOnTable[Hourse].DrawHourseOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    BrownTimer.StopTime();
                                                    GrayTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = -3;
                                                    Draw.HoursesOnTable[Hourse] = new DrawHourse(RowClickP, ColumnClickP, Color.Brown, Table, OrderPlate, false, Hourse);
                                                    Draw.HoursesOnTable[Hourse].DrawHourseOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }
                                            }


                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == -4)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.BridgesOnTable[Bridge] = new DrawBridge(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Bridge);

                                            Draw.BridgesOnTable[Bridge].DrawBridgeOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -4;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(-4, Table, -1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Brown, -4))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -4, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = -4;
                                                    Draw.BridgesOnTable[Bridge] = new DrawBridge(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Bridge);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = -4;
                                                    Draw.BridgesOnTable[Bridge].DrawBridgeOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    BrownTimer.StopTime();
                                                    GrayTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = -4;
                                                    Draw.BridgesOnTable[Bridge] = new DrawBridge(RowClickP, ColumnClickP, Color.Brown, Table, OrderPlate, false, Bridge);
                                                    Draw.BridgesOnTable[Bridge].DrawBridgeOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }

                                            }


                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == -5)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.MinisterOnTable[Minister] = new DrawMinister(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Minister);

                                            Draw.MinisterOnTable[Minister].DrawMinisterOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -5;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(-5, Table, -1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Brown, -5))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -5, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = -5;
                                                    Draw.MinisterOnTable[Minister] = new DrawMinister(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, Minister);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = -5;
                                                    Draw.MinisterOnTable[Minister].DrawMinisterOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;
                                                    BrownTimer.StopTime();
                                                    GrayTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }
                                                else
                                                {
                                                    Table[(int)RowClickP, (int)ColumnClickP] = -5;
                                                    Draw.MinisterOnTable[Minister] = new DrawMinister(RowClickP, ColumnClickP, Color.Brown, Table, OrderPlate, false, Minister);

                                                    Draw.MinisterOnTable[Minister].DrawMinisterOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }



                                            }


                                    }
                                    if (Table[(int)RowClickP, (int)ColumnClickP] == -6)
                                    {


                                        if (AllDraw.MouseClick == 1)
                                        {
                                            Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, King);

                                            Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);
                                            //Table[(int)RowClickP, (int)ColumnClickP] = -6;
                                        }
                                        else
                                            if (AllDraw.MouseClick == 2)
                                            {
                                                if ((new ChessRules(-6, Table, -1)).Rules((int)RowClickP, (int)ColumnClickP, (int)RowRealesed, (int)ColumnRealeased, Color.Brown, -6))
                                                {
                                                    int Hit = Table[(int)RowRealesed, (int)ColumnRealeased];
                                                    bool HitVal = false;
                                                    if (Hit != 0)
                                                        HitVal = true;
                                                    SetBoxStatistic(ChessRules.CreateStatistic(Table, MovmentsNumber, -6, (int)ColumnRealeased, (int)RowRealesed, HitVal, Hit, false, false));
                                                    LastRow = (int)RowRealesed;
                                                    LastColumn = (int)ColumnClickP;
                                                    CurrentKind = -6;
                                                    Draw.KingOnTable[King] = new DrawKing(RowRealesed, ColumnRealeased, Color.Brown, Table, OrderPlate, false, King);
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    Table[(int)RowRealesed, (int)ColumnRealeased] = -6;
                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);


                                                    AllDraw.TableListAction.Add(Table);
                                                    Person = false;
                                                    OrderPlate = OrderPlate * -1;
                                                    ChessRules.CurrentOrder = OrderPlate;
                                                    MovmentsNumber++;

                                                    BrownTimer.StopTime();
                                                    GrayTimer.StartTime();
                                                    InsertTableAtDataBase(Table);
                                                    if (AllDraw.DeptFirstSearch)
                                                    {
                                                        AllDraw.StoreADraw.RemoveAt(0);
                                                        AllDraw.StoreADraw[0].TableList.Clear();
                                                        AllDraw.StoreADraw[0].TableList.Add(Table);
                                                        AllDraw.StoreADraw[0].SetRowColumn(0);
                                                    }
                                                }

                                                else
                                                {

                                                    Table[(int)RowClickP, (int)ColumnClickP] = -6;
                                                    Draw.KingOnTable[King] = new DrawKing(RowClickP, ColumnClickP, Color.Brown, Table, OrderPlate, false, King);
                                                    Draw.KingOnTable[King].DrawKingOnTable(ref g, pictureBoxRefrigtz.Image.Width / 8, pictureBoxRefrigtz.Image.Height / 8);

                                                }


                                            }


                                    }

                                }
                            }

                        }
                        else
                        {
                            if (StateCP && !Person)
                            {
                                if (Sec.radioButtonGrayOrder.Checked && OrderPlate == -1)
                                {
                                    Person = true;
                                    if (t1.IsAlive && t1.IsBackground)
                                        t1.Resume();
                                    else if (!t1.IsAlive)
                                    {
                                        t1 = new Thread(new ThreadStart(AliceWithPerson));
                                        t1.Start();
                                    }
                                }
                                else if (Sec.radioButtonBrownOrder.Checked && OrderPlate == 1)
                                {
                                    Person = true;
                                    if (t1.IsAlive && t1.IsBackground)
                                        t1.Resume();
                                    else if (!t1.IsAlive)
                                    {
                                        if (t1 != null)
                                            t1.Abort();
                                        t1 = new Thread(new ThreadStart(BobWithPerson));
                                        t1.Start();
                                    }

                                }
                            }
                            else
                                if (StateCC)
                                {
                                    if (BobSection)
                                    {
                                        if (t3.IsAlive) t3.Suspend();
                                        BobSection = false;
                                        if (t2.IsAlive && t2.IsBackground)
                                            t2.Resume();
                                        else if (!t2.IsAlive)
                                        {
                                            if (t2 != null)
                                                t2.Abort();
                                            t2 = new Thread(new ThreadStart(BobAction));

                                            t2.Start();
                                        }
                                    }
                                    else
                                    {
                                        if (AliceSection)
                                        {
                                            if (t2.IsAlive) t2.Suspend();
                                            AliceSection = false;
                                            if (t3.IsAlive && t3.IsBackground)
                                                t3.Resume();
                                            else if (!t3.IsAlive)
                                            {
                                                if (t3 != null)
                                                    t3.Abort();
                                                t3 = new Thread(new ThreadStart(AliceAction));
                                                t3.Start();
                                            }
                                        }
                                    }
                                }
                                else
                                    if (StateGe)
                                    {
                                        if (t4.IsAlive && t4.IsBackground)
                                            t4.Resume();
                                        else if (!t4.IsAlive)
                                        {
                                            if (t4 != null)
                                                t4.Abort();
                                            t4 = new Thread(new ThreadStart(GeneticAction));
                                            t4.Start();
                                        }
                                    }


                        }
                        while (!StateCP && !StateCC && !StateGe)
                            Thread.Sleep(10);
                    }
                    //if (AllDraw.RedrawTable)
                    {


                        if (AllDraw.MouseClick == 0 && RowClickP != -1)
                        {

                            HitRecustruct();
                            ChessRules.CurrentOrder = OrderPlate;
                            ChessRules.ExistInDestinationEnemy = false;
                            RowClick = -1;
                            ColumnClick = -1;
                            RowClickP = -1;
                            ColumnClickP = -1;
                            RowRealesed = -1;
                            ColumnRealeased = -1;
                            RowRealesedP = -1;
                            ColumnClickP = -1;

                        }
                        else
                        {
                            if (AllDraw.MouseClick >= 2)
                            {

                                using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
                                {
                                    soundClick.Play();
                                    soundClick.Dispose();
                                }

                                AllDraw.MouseClick = 0;
                                SetBoxText("\r\nObject Realeased.");
                                RefreshBoxText();
                                this.SetBoxStatistic(AllDraw.SyntaxToWrite);
                                this.RefreshBoxStatistic();


                            }
                        }


                        AllDraw.RedrawTable = false;
                    }
                    if (AllDraw.MouseClick == 1)
                    {
                        SetBoxText("\r\nObject Selected.");
                        RefreshBoxText();
                    }
                }
                catch (Exception t)
                {
                    Log(t);
                }
            } while (true);

        }
        //Deligation of Control Threading.
        delegate void SetTextBoxTextCallback(String state);

        public void SetBoxText(String state)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.InvokeRequired)
            {
                try
                {
                    String A = TimerText.ReturnTime();
                    if (OrderPlate == -1)
                        A = TimerText.ReturnTime();

                    SetTextBoxTextCallback d = new SetTextBoxTextCallback(SetBoxText);
                    this.Invoke(new Action(() => textBoxText.AppendText(state + " At Time " + A)));
                }
                catch (Exception t) { Log(t); }
            }
            else
            {
                try
                {
                    String A = GrayTimer.ReturnTime();
                    if (OrderPlate == -1)
                        A = BrownTimer.ReturnTime();

                    textBoxText.AppendText(state + " At Time " + A);
                }
                catch (Exception t) { Log(t); }
            }
            this.RefreshBoxText();
        }
        delegate void RefreshhTextBoxTextCallback();

        public void RefreshBoxText()
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.InvokeRequired)
            {
                try
                {
                    RefreshhTextBoxTextCallback d = new RefreshhTextBoxTextCallback(RefreshBoxText);
                    this.Invoke(new Action(() => textBoxText.Refresh()));
                }
                catch (Exception t) { Log(t); }
            }
            else
            {
                try
                {
                    textBoxStatistic.Refresh();
                }
                catch (Exception t) { Log(t); }
            }

        }
        delegate void SetTextBoxStatisticCallback(String state);

        public void SetBoxStatistic(String state)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.InvokeRequired)
            {
                try
                {
                    SetTextBoxStatisticCallback d = new SetTextBoxStatisticCallback(SetBoxStatistic);
                    this.Invoke(new Action(() => textBoxStatistic.AppendText(state)));
                }
                catch (Exception t) { Log(t); }
            }
            else
            {
                try
                {

                    textBoxStatistic.AppendText(state);
                }
                catch (Exception t) { Log(t); }
            }
            this.RefreshBoxStatistic();
        }
        delegate void RefreshhTextBoxStatisticCallback();

        public void RefreshBoxStatistic()
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.InvokeRequired)
            {
                RefreshhTextBoxStatisticCallback d = new RefreshhTextBoxStatisticCallback(RefreshBoxStatistic);
                this.Invoke(new Action(() => textBoxStatistic.Refresh()));
            }
            else
            {
                textBoxStatistic.Refresh();
            }

        }
        //The State of Alice with Person Thinking.
        void AliceWithPerson()
        {

            try
            {
                bool StoreStateCC = StateCC;
                bool StoreStateCP = StateCP;
                bool StoreStateGe = StateGe;
                StateCC = false;
                StateCP = false;
                StateGe = false;

                MovmentsNumber++;

                SetBoxText("\r\n Movments Number " + MovmentsNumber.ToString() + " is Brown OrderPlate!");
                RefreshBoxText();
            Begin1:
                SetBoxText("\r\nThinking Begin!");
                RefreshBoxText();
                Color a = Color.Gray;
                if (OrderPlate == -1)
                    a = Color.Brown;
                Draw.Initiate(1, 4, a, Table, OrderPlate, false, ref TimerText, ref BrownTimer);
                //StateCP = false;
                this.SetBoxText("\r\nThinking Finished!");
                try
                {
                    Table = Draw.TableList[0];
                }
                catch (Exception t)
                {
                    Log(t);
                    goto Begin1;
                }

                OrderPlate = OrderPlate * -1;
                Draw.SetRowColumn(0);
                ChessRules.CurrentOrder = OrderPlate;
                AllDraw.TableListAction.Add(Table);
                this.SetBoxStatistic(AllDraw.SyntaxToWrite);
                this.RefreshBoxStatistic();


                BrownTimer.StopTime();
                GrayTimer.StartTime();

                using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
                {
                    soundClick.Play();
                    soundClick.Dispose();
                }

                InsertTableAtDataBase(Table);
                Person = true;
                StateCC = StoreStateCC;
                StateCP = StoreStateCP;
                StateGe = StoreStateGe;


            }
            catch (Exception t)
            {
                Log(t);
                this.SetBoxText("\r\nError!");
            }
        }
        //The State of Bob with Person Thinking.
        void BobWithPerson()
        {

            try
            {
                bool StoreStateCC = StateCC;
                bool StoreStateCP = StateCP;
                bool StoreStateGe = StateGe;
                StateCC = false;
                StateCP = false;
                StateGe = false;

                MovmentsNumber++;

                SetBoxText("\r\n Movments Number " + MovmentsNumber.ToString() + " is Gray OrderPlate!");
                RefreshBoxText();
            Begin1:
                SetBoxText("\r\nThinking Begin!");
                RefreshBoxText();
                Color a = Color.Gray;
                if (OrderPlate == -1)
                    a = Color.Brown;
                Draw.Initiate(1, 4, a, Table, OrderPlate, false, ref TimerText, ref GrayTimer);
                //StateCP = false;
                this.SetBoxText("\r\nThinking Finished!");
                try
                {
                    Table = Draw.TableList[0];
                }
                catch (Exception t)
                {
                    Log(t);
                    goto Begin1;
                }

                OrderPlate = OrderPlate * -1;
                Draw.SetRowColumn(0);
                ChessRules.CurrentOrder = OrderPlate;
                AllDraw.TableListAction.Add(Table);
                this.SetBoxStatistic(AllDraw.SyntaxToWrite);
                this.RefreshBoxStatistic();


                GrayTimer.StartTime();
                BrownTimer.StopTime();
              
                using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
                {
                    soundClick.Play();
                    soundClick.Dispose();
                }

                InsertTableAtDataBase(Table);
                Person = true;
                StateCC = StoreStateCC;
                StateCP = StoreStateCP;
                StateGe = StoreStateGe;


            }
            catch (Exception t)
            {
                Log(t);
                this.SetBoxText("\r\nError!");
            }
        }
       //Alice Section of Computer by Computer Thinking.
        void AliceAction()
        {
            bool StoreStateCC = StateCC;
            bool StoreStateCP = StateCP;
            bool StoreStateGe = StateGe;
            StateCC = false;
            StateCP = false;
            StateGe = false;

            MovmentsNumber++;


            SetBoxText("\r\n Movments Number " + MovmentsNumber.ToString() + " is Brown OrderPlate!");
            RefreshBoxText();
        Begin4:
            SetBoxText("\r\nThinking Begin By Alice!");
            RefreshBoxText();
            RefreshBoxText();
            Color a = Color.Gray;
            if (OrderPlate == -1)
                a = Color.Brown;

            Draw.Initiate(1, 4, a, Table, OrderPlate, false, ref TimerText, ref BrownTimer);
            //StateCP = false;
            try
            {
                Table = Draw.TableList[0];
            }
            catch (Exception t)
            {
                Log(t);
                goto Begin4;
            }
            // Person = true;
            AllDraw.TableListAction.Add(Table);
            OrderPlate = OrderPlate * -1;
            Draw.SetRowColumn(0);
            ChessRules.CurrentOrder = OrderPlate;

            this.SetBoxText("\r\nThinking Finished By Alice!");
            RefreshBoxText();
            this.SetBoxStatistic(AllDraw.SyntaxToWrite);
            this.RefreshBoxStatistic();
            BrownTimer.StopTime();
            GrayTimer.StartTime();

            using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
            {
                soundClick.Play();
                soundClick.Dispose();
            }

            InsertTableAtDataBase(Table);
            BobSection = true;
            StateCC = StoreStateCC;
            StateCP = StoreStateCP;
            StateGe = StoreStateGe;


        }
        void GeneticAction()
        {

            StateGe = false;
            MovmentsNumber++;


            if (OrderPlate == 1)

                SetBoxText("\r\n Movments Number " + MovmentsNumber.ToString() + " is Gray OrderPlate!");
            else
                SetBoxText("\r\n Movments Number " + MovmentsNumber.ToString() + " is Brown OrderPlate!");
            RefreshBoxText();
        Begin4:
            if (OrderPlate == 1)
                SetBoxText("\r\nThinking Begin By Bob!");
            else
                SetBoxText("\r\nThinking Begin By Alice!");
            RefreshBoxText();
            Color a = Color.Gray;
            if (OrderPlate == -1)
                a = Color.Brown;
            Draw.InitiateGenetic(1, 4, a, Table, OrderPlate, false);
            //StateCP = false;

            try
            {
                Table = Draw.TableList[0];
            }
            catch (Exception t)
            {
                Log(t);
                goto Begin4;
            }

            // Person = true;
            AllDraw.TableListAction.Add(Table);
            OrderPlate = OrderPlate * -1;
            Draw.SetRowColumn(0);

            ChessRules.CurrentOrder = OrderPlate;

            this.SetBoxText("\r\nThinking Finished By Alice!");
            RefreshBoxText();
            this.SetBoxStatistic(AllDraw.SyntaxToWrite);
            this.RefreshBoxStatistic();
            if (OrderPlate == 1)
            {
                BrownTimer.StopTime();
                GrayTimer.StartTime();
            }
            else
            {
                GrayTimer.StopTime();
                BrownTimer.StartTime();

            }

            using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
            {
                soundClick.Play();
                soundClick.Dispose();
            }

            StateGe = true;
            InsertTableAtDataBase(Table);
            if (t4.IsAlive)
                t4.Suspend();
        }
        //Bob Section of Computer By Computer Thinking.
        void BobAction()
        {
            bool StoreStateCC = StateCC;
            bool StoreStateCP = StateCP;
            bool StoreStateGe = StateGe;
            StateCC = false;
            StateCP = false;
            StateGe = false;


            MovmentsNumber++;
            if (OrderPlate == 1)

                SetBoxText("\r\n Movments Number " + MovmentsNumber.ToString() + " is Gray OrderPlate!");
            else
                SetBoxText("\r\n Movments Number " + MovmentsNumber.ToString() + " is Brown OrderPlate!");
            RefreshBoxText();
        Begin2:
            SetBoxText("\r\nThinking Begin By Bob!");
            RefreshBoxText();
            Color a = Color.Gray;
            if (OrderPlate == -1)
                a = Color.Brown;
            Draw.Initiate(1, 4, a, Table, OrderPlate, false, ref TimerText, ref GrayTimer);



            //StateCP = false;

            try
            {
                Table = Draw.TableList[0];
            }
            catch (Exception t)
            {
                Log(t);
                goto Begin2;
            }
            // Person = true;
            AllDraw.TableListAction.Add(Table);
            OrderPlate = OrderPlate * -1;
            Draw.SetRowColumn(0);
            ChessRules.CurrentOrder = OrderPlate;

            AllDraw.TableListAction.Add(Table);
            this.SetBoxText("\r\nThinking Finished by Bob!");
            RefreshBoxText();

            this.SetBoxStatistic(AllDraw.SyntaxToWrite);
            this.RefreshBoxStatistic();

            GrayTimer.StopTime();
            BrownTimer.StartTime();
            using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
            {
                soundClick.Play();
                soundClick.Dispose();
            }

            InsertTableAtDataBase(Table);
            AliceSection = true;
            StateCC = StoreStateCC;
            StateCP = StoreStateCP;
            StateGe = StoreStateGe;

        }
        //Recostruction of Table Faulting.
        private void ReconstructTable()
        {
            if (AllDraw.MouseClick == 0)
            {
                if (RowClickP != -1 && ColumnClickP != 1)
                {
                    //  if (Table[(int)RowClickP, (int)ColumnClickP] != 1)
                    for (int i = 0; i < 8; i++)
                    {
                        try
                        {
                            Table[(int)Draw.SolderesOnTable[i].Row, (int)Draw.SolderesOnTable[i].Column] = 1;
                        }
                        catch (Exception t)
                        {

                            Log(t);
                        }
                    }

                    // if (Table[(int)RowClickP, (int)ColumnClickP] != -1)
                    for (int i = 8; i < 16; i++)
                    {
                        try
                        {
                            Table[(int)Draw.SolderesOnTable[i].Row, (int)Draw.SolderesOnTable[i].Column] = -1;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }

                    // if (Table[(int)RowClickP, (int)ColumnClickP] != 2)
                    for (int i = 0; i < 2; i++)
                    {
                        try
                        {
                            Table[(int)Draw.ElephantOnTable[i].Row, (int)Draw.ElephantOnTable[i].Column] = 2;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }


                    //  if (Table[(int)RowClickP, (int)ColumnClickP] != -2)
                    for (int i = 2; i < 4; i++)
                    {
                        try
                        {
                            Table[(int)Draw.ElephantOnTable[i].Row, (int)Draw.ElephantOnTable[i].Column] = -2;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }

                    // if (Table[(int)RowClickP, (int)ColumnClickP] != 3)
                    for (int i = 0; i < 2; i++)
                    {
                        try
                        {
                            Table[(int)Draw.HoursesOnTable[i].Row, (int)Draw.HoursesOnTable[i].Column] = 3;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }


                    // if (Table[(int)RowClickP, (int)ColumnClickP] != -3)
                    for (int i = 2; i < 4; i++)
                    {
                        try
                        {
                            Table[(int)Draw.HoursesOnTable[i].Row, (int)Draw.HoursesOnTable[i].Column] = -3;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }

                    // if (Table[(int)RowClickP, (int)ColumnClickP] != 4)
                    for (int i = 0; i < 2; i++)
                    {
                        try
                        {
                            Table[(int)Draw.BridgesOnTable[i].Row, (int)Draw.BridgesOnTable[i].Column] = 4;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }

                    // if (Table[(int)RowClickP, (int)ColumnClickP] != -4)
                    for (int i = 2; i < 4; i++)
                    {
                        try
                        {
                            Table[(int)Draw.BridgesOnTable[i].Row, (int)Draw.BridgesOnTable[i].Column] = -4;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    // if (Table[(int)RowClickP, (int)ColumnClickP] != 5)
                    for (int i = 0; i < 1; i++)
                    {
                        try
                        {
                            Table[(int)Draw.BridgesOnTable[i].Row, (int)Draw.BridgesOnTable[i].Column] = 5;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    // if (Table[(int)RowClickP, (int)ColumnClickP] != -5)
                    for (int i = 1; i < 2; i++)
                    {
                        try
                        {
                            Table[(int)Draw.BridgesOnTable[i].Row, (int)Draw.BridgesOnTable[i].Column] = -5;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }

                    // if (Table[(int)RowClickP, (int)ColumnClickP] != 6)
                    for (int i = 0; i < 1; i++)
                    {
                        try
                        {
                            Table[(int)Draw.BridgesOnTable[i].Row, (int)Draw.BridgesOnTable[i].Column] = 6;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    //if (Table[(int)RowClickP, (int)ColumnClickP] != -6)
                    for (int i = 1; i < 2; i++)
                    {
                        try
                        {
                            Table[(int)Draw.BridgesOnTable[i].Row, (int)Draw.BridgesOnTable[i].Column] = -6;
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }


                }
            }

        }
        //Hit Reconstruction of Table.
        void HitRecustruct()
        {
            if (ChessRules.ExistInDestinationEnemy)
            {
                if (System.Math.Abs(CurrentKind) == 1)
                {
                    for (int i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                    {
                        try
                        {
                            if (Draw.SolderesOnTable[Soldier].Row == Draw.SolderesOnTable[i].Row && Draw.SolderesOnTable[Soldier].Column == Draw.SolderesOnTable[i].Column)
                            {
                                Draw.SolderesOnTable[i] = null;
                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                return;
                            }
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    for (int i = 0; i < AllDraw.ElefantHigh; i++)
                    {
                        try
                        {
                            if (Draw.SolderesOnTable[Soldier].Row == Draw.ElephantOnTable[i].Row && Draw.SolderesOnTable[Soldier].Column == Draw.ElephantOnTable[i].Column)
                            {
                                Draw.ElephantOnTable[i] = null;
                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                return;
                            }
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    for (int i = 0; i < AllDraw.HourseHight; i++)
                    {
                        try
                        {
                            if (Draw.SolderesOnTable[Soldier].Row == Draw.HoursesOnTable[i].Row && Draw.SolderesOnTable[Soldier].Column == Draw.HoursesOnTable[i].Column)
                            {
                                Draw.HoursesOnTable[i] = null;
                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                return;
                            }
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    for (int i = 0; i < AllDraw.BridgeHigh; i++)
                    {
                        try
                        {
                            if (Draw.SolderesOnTable[Soldier].Row == Draw.BridgesOnTable[i].Row && Draw.SolderesOnTable[Soldier].Column == Draw.BridgesOnTable[i].Column)
                            {
                                Draw.BridgesOnTable[i] = null;
                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                return;
                            }
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    for (int i = 0; i < AllDraw.MinisterHigh; i++)
                    {
                        try
                        {
                            if (Draw.SolderesOnTable[Soldier].Row == Draw.MinisterOnTable[i].Row && Draw.SolderesOnTable[Soldier].Column == Draw.MinisterOnTable[i].Column)
                            {
                                Draw.MinisterOnTable[i] = null;
                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                return;
                            }
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                    for (int i = 0; i < AllDraw.KingHigh; i++)
                    {
                        try
                        {
                            if (Draw.SolderesOnTable[Soldier].Row == Draw.KingOnTable[i].Row && Draw.SolderesOnTable[Soldier].Column == Draw.KingOnTable[i].Column)
                            {
                                Draw.KingOnTable[i] = null;
                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                return;
                            }
                        }
                        catch (Exception t)
                        {
                            Log(t);
                        }
                    }
                }
                else
                    if (System.Math.Abs(CurrentKind) == 2)
                    {

                        for (int i = 0; i < AllDraw.SodierHigh; i++)
                        {
                            try
                            {
                                if (Draw.ElephantOnTable[Elefant].Row == Draw.SolderesOnTable[i].Row && Draw.ElephantOnTable[Elefant].Column == Draw.SolderesOnTable[i].Column)
                                {
                                    Draw.SolderesOnTable[i] = null;
                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                    return;
                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }
                        for (int i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                        {
                            try
                            {
                                if (Draw.ElephantOnTable[Elefant].Row == Draw.ElephantOnTable[i].Row && Draw.ElephantOnTable[Elefant].Column == Draw.ElephantOnTable[i].Column)
                                {
                                    Draw.ElephantOnTable[i] = null;
                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                    return;
                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }
                        for (int i = 0; i < AllDraw.HourseHight; i++)
                        {
                            try
                            {
                                if (Draw.ElephantOnTable[Elefant].Row == Draw.HoursesOnTable[i].Row && Draw.ElephantOnTable[Elefant].Column == Draw.HoursesOnTable[i].Column)
                                {
                                    Draw.HoursesOnTable[i] = null;
                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                    return;
                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }
                        for (int i = 0; i < AllDraw.BridgeHigh; i++)
                        {
                            try
                            {

                                if (Draw.ElephantOnTable[Elefant].Row == Draw.BridgesOnTable[i].Row && Draw.ElephantOnTable[Elefant].Column == Draw.BridgesOnTable[i].Column)
                                {
                                    Draw.BridgesOnTable[i] = null;
                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                    return;
                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }
                        for (int i = 0; i < AllDraw.MinisterHigh; i++)
                        {
                            try
                            {
                                if (Draw.ElephantOnTable[Elefant].Row == Draw.MinisterOnTable[i].Row && Draw.ElephantOnTable[Elefant].Column == Draw.MinisterOnTable[i].Column)
                                {
                                    Draw.MinisterOnTable[i] = null;
                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                    return;
                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }
                        for (int i = 0; i < AllDraw.KingHigh; i++)
                        {
                            try
                            {
                                if (Draw.ElephantOnTable[Elefant].Row == Draw.KingOnTable[i].Row && Draw.ElephantOnTable[Elefant].Column == Draw.KingOnTable[i].Column)
                                {
                                    Draw.KingOnTable[i] = null;
                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                    return;
                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                    }
                    else
                        if (System.Math.Abs(CurrentKind) == 3)
                        {

                            for (int i = 0; i < AllDraw.SodierHigh; i++)
                            {
                                try
                                {
                                    if (Draw.HoursesOnTable[Hourse].Row == Draw.SolderesOnTable[i].Row && Draw.HoursesOnTable[Hourse].Column == Draw.SolderesOnTable[i].Column)
                                    {
                                        Draw.SolderesOnTable[i] = null;
                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }
                            for (int i = 0; i < AllDraw.ElefantHigh; i++)
                            {
                                try
                                {
                                    if (Draw.HoursesOnTable[Hourse].Row == Draw.ElephantOnTable[i].Row && Draw.HoursesOnTable[Hourse].Column == Draw.ElephantOnTable[i].Column)
                                    {
                                        Draw.ElephantOnTable[i] = null;
                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }
                            for (int i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                            {
                                try
                                {
                                    if (Draw.HoursesOnTable[Hourse].Row == Draw.HoursesOnTable[i].Row && Draw.HoursesOnTable[Hourse].Column == Draw.HoursesOnTable[i].Column)
                                    {
                                        Draw.HoursesOnTable[i] = null;
                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }
                            for (int i = 0; i < AllDraw.BridgeHigh; i++)
                            {
                                try
                                {
                                    if (Draw.HoursesOnTable[Hourse].Row == Draw.BridgesOnTable[i].Row && Draw.HoursesOnTable[Hourse].Column == Draw.BridgesOnTable[i].Column)
                                    {
                                        Draw.BridgesOnTable[i] = null;
                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }

                            for (int i = 0; i < AllDraw.MinisterHigh; i++)
                            {
                                try
                                {
                                    if (Draw.HoursesOnTable[Hourse].Row == Draw.MinisterOnTable[i].Row && Draw.HoursesOnTable[Hourse].Column == Draw.MinisterOnTable[i].Column)
                                    {
                                        Draw.MinisterOnTable[i] = null;
                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }
                            for (int i = 0; i < AllDraw.KingHigh; i++)
                            {
                                try
                                {
                                    if (Draw.HoursesOnTable[Hourse].Row == Draw.KingOnTable[i].Row && Draw.HoursesOnTable[Hourse].Column == Draw.KingOnTable[i].Column)
                                    {
                                        Draw.KingOnTable[i] = null;
                                        Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }

                        }
                        else
                            if (System.Math.Abs(CurrentKind) == 4)
                            {

                                for (int i = 0; i < AllDraw.SodierHigh; i++)
                                {
                                    try
                                    {
                                        if (Draw.BridgesOnTable[Bridge].Row == Draw.SolderesOnTable[i].Row && Draw.BridgesOnTable[Bridge].Column == Draw.SolderesOnTable[i].Column)
                                        {
                                            Draw.SolderesOnTable[i] = null;
                                            Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                            return;
                                        }
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                                for (int i = 0; i < AllDraw.ElefantHigh; i++)
                                {
                                    try
                                    {
                                        if (Draw.BridgesOnTable[Bridge].Row == Draw.ElephantOnTable[i].Row && Draw.BridgesOnTable[Bridge].Column == Draw.ElephantOnTable[i].Column)
                                        {
                                            Draw.ElephantOnTable[i] = null;
                                            Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                            return;
                                        }
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }

                                for (int i = 0; i < AllDraw.HourseHight; i++)
                                {
                                    try
                                    {
                                        if (Draw.BridgesOnTable[Bridge].Row == Draw.HoursesOnTable[i].Row && Draw.BridgesOnTable[Bridge].Column == Draw.HoursesOnTable[i].Column)
                                        {
                                            Draw.HoursesOnTable[i] = null;
                                            Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                            return;
                                        }
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                                for (int i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                                {
                                    try
                                    {
                                        if (Draw.BridgesOnTable[Bridge].Row == Draw.BridgesOnTable[i].Row && Draw.BridgesOnTable[Bridge].Column == Draw.BridgesOnTable[i].Column)
                                        {
                                            Draw.BridgesOnTable[i] = null;
                                            Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                            return;
                                        }
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                                for (int i = 0; i < AllDraw.MinisterHigh; i++)
                                {
                                    try
                                    {
                                        if (Draw.BridgesOnTable[Bridge].Row == Draw.MinisterOnTable[i].Row && Draw.BridgesOnTable[Bridge].Column == Draw.MinisterOnTable[i].Column)
                                        {
                                            Draw.MinisterOnTable[i] = null;
                                            Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                            return;
                                        }
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                                for (int i = 0; i < AllDraw.KingHigh; i++)
                                {
                                    try
                                    {
                                        if (Draw.BridgesOnTable[Bridge].Row == Draw.KingOnTable[i].Row && Draw.BridgesOnTable[Bridge].Column == Draw.KingOnTable[i].Column)
                                        {
                                            Draw.KingOnTable[i] = null;
                                            Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                            return;
                                        }
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                            }
                            else
                                if (System.Math.Abs(CurrentKind) == 5)
                                {

                                    for (int i = 0; i < AllDraw.SodierHigh; i++)
                                    {
                                        try
                                        {
                                            if (Draw.MinisterOnTable[Minister].Row == Draw.SolderesOnTable[i].Row && Draw.MinisterOnTable[Minister].Column == Draw.SolderesOnTable[i].Column)
                                            {
                                                Draw.SolderesOnTable[i] = null;
                                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                return;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                    for (int i = 0; i < AllDraw.ElefantHigh; i++)
                                    {
                                        try
                                        {
                                            if (Draw.MinisterOnTable[Minister].Row == Draw.ElephantOnTable[i].Row && Draw.MinisterOnTable[Minister].Column == Draw.ElephantOnTable[i].Column)
                                            {
                                                Draw.ElephantOnTable[i] = null;
                                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                return;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }

                                    for (int i = 0; i < AllDraw.HourseHight; i++)
                                    {
                                        try
                                        {
                                            if (Draw.MinisterOnTable[Minister].Row == Draw.HoursesOnTable[i].Row && Draw.MinisterOnTable[Minister].Column == Draw.HoursesOnTable[i].Column)
                                            {
                                                Draw.HoursesOnTable[i] = null;
                                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                return;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }

                                    for (int i = 0; i < AllDraw.BridgeHigh; i++)
                                    {
                                        try
                                        {
                                            if (Draw.MinisterOnTable[Minister].Row == Draw.BridgesOnTable[i].Row && Draw.MinisterOnTable[Minister].Column == Draw.BridgesOnTable[i].Column)
                                            {
                                                Draw.BridgesOnTable[i] = null;
                                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                return;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                    for (int i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                                    {
                                        try
                                        {
                                            if (Draw.MinisterOnTable[Minister].Row == Draw.MinisterOnTable[i].Row && Draw.MinisterOnTable[Minister].Column == Draw.MinisterOnTable[i].Column)
                                            {
                                                Draw.MinisterOnTable[i] = null;
                                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                return;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                    for (int i = 0; i < AllDraw.KingHigh; i++)
                                    {
                                        try
                                        {
                                            if (Draw.MinisterOnTable[Minister].Row == Draw.KingOnTable[i].Row && Draw.MinisterOnTable[Minister].Column == Draw.KingOnTable[i].Column)
                                            {
                                                Draw.KingOnTable[i] = null;
                                                Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                return;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                else
                                    if (System.Math.Abs(CurrentKind) == 6)
                                    {

                                        for (int i = 0; i < AllDraw.SodierHigh; i++)
                                        {
                                            try
                                            {
                                                if (Draw.KingOnTable[King].Row == Draw.SolderesOnTable[i].Row && Draw.KingOnTable[King].Column == Draw.SolderesOnTable[i].Column)
                                                {
                                                    Draw.SolderesOnTable[i] = null;
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    return;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        for (int i = 0; i < AllDraw.ElefantHigh; i++)
                                        {
                                            try
                                            {
                                                if (Draw.KingOnTable[King].Row == Draw.ElephantOnTable[i].Row && Draw.KingOnTable[King].Column == Draw.ElephantOnTable[i].Column)
                                                {
                                                    Draw.ElephantOnTable[i] = null;
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    return;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        for (int i = 0; i < AllDraw.HourseHight; i++)
                                        {
                                            try
                                            {
                                                if (Draw.KingOnTable[King].Row == Draw.HoursesOnTable[i].Row && Draw.KingOnTable[King].Column == Draw.HoursesOnTable[i].Column)
                                                {
                                                    Draw.HoursesOnTable[i] = null;
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    return;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        for (int i = 0; i < AllDraw.BridgeHigh; i++)
                                        {
                                            try
                                            {
                                                if (Draw.KingOnTable[King].Row == Draw.BridgesOnTable[i].Row && Draw.KingOnTable[King].Column == Draw.BridgesOnTable[i].Column)
                                                {
                                                    Draw.BridgesOnTable[i] = null;
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    return;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        for (int i = 0; i < AllDraw.MinisterHigh; i++)
                                        {
                                            try
                                            {
                                                if (Draw.KingOnTable[King].Row == Draw.MinisterOnTable[i].Row && Draw.KingOnTable[King].Column == Draw.MinisterOnTable[i].Column)
                                                {
                                                    Draw.MinisterOnTable[i] = null;
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    return;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        for (int i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                                        {
                                            try
                                            {
                                                if (Draw.KingOnTable[King].Row == Draw.KingOnTable[i].Row && Draw.KingOnTable[King].Column == Draw.KingOnTable[i].Column)
                                                {
                                                    Draw.KingOnTable[i] = null;
                                                    Table[(int)RowClickP, (int)ColumnClickP] = 0;
                                                    return;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                    }
            }
        }
        //About Tool Strip Calling.
        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AboutBoxChessRefrigitz ChessRefrigitz = new AboutBoxChessRefrigitz();
            ChessRefrigitz.ShowDialog();
        }
        //Mouse Click Form Refregitz pictureBox Event Handling.
        private void pictureBoxRefrigtz_MouseClick(object sender, MouseEventArgs e)
        {
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    if (System.Math.Abs(e.X - i * (pictureBoxRefrigtz.Image.Width / 8)) < pictureBoxRefrigtz.Image.Width / 8 && System.Math.Abs(e.Y - j * (pictureBoxRefrigtz.Image.Height / 8)) < pictureBoxRefrigtz.Image.Height / 8)
                    {
                        if (AllDraw.MouseClick < 1)
                        {
                            RowClickP = i;
                            ColumnClickP = j;

                        }

                        RowRealesed = i;
                        ColumnRealeased = j;

                        RowClick = i;
                        ColumnClick = j;
                        if (RowClickP == -1 && ColumnClickP == -1)
                        {
                            RowClickP = RowClick;
                            ColumnClickP = ColumnClick;
                        }
                        if (AllDraw.MouseClick == 0)
                        {
                            for (int ii = 0; ii < AllDraw.SodierHigh; ii++)
                            {
                                try
                                {
                                    if ((Draw.SolderesOnTable[ii].Row == i & Draw.SolderesOnTable[ii].Column == j) && System.Math.Abs(Table[i, j]) == 1)
                                    {
                                        Soldier = ii;
                                        AllDraw.MouseClick++;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                            }
                            for (int ii = 0; ii < AllDraw.ElefantHigh; ii++)
                            {
                                try
                                {
                                    if ((Draw.ElephantOnTable[ii].Row == i & Draw.ElephantOnTable[ii].Column == j) && System.Math.Abs(Table[i, j]) == 2)
                                    {
                                        Elefant = ii;
                                        AllDraw.MouseClick++;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                            }
                            for (int ii = 0; ii < AllDraw.HourseHight; ii++)
                            {
                                try
                                {
                                    if ((Draw.HoursesOnTable[ii].Row == i & Draw.HoursesOnTable[ii].Column == j) && System.Math.Abs(Table[i, j]) == 3)
                                    {
                                        Hourse = ii;
                                        AllDraw.MouseClick++;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }
                            for (int ii = 0; ii < AllDraw.BridgeHigh; ii++)
                            {
                                try
                                {
                                    if ((Draw.BridgesOnTable[ii].Row == i & Draw.BridgesOnTable[ii].Column == j) && System.Math.Abs(Table[i, j]) == 4)
                                    {
                                        Bridge = ii;
                                        AllDraw.MouseClick++;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }

                            for (int ii = 0; ii < AllDraw.MinisterHigh; ii++)
                            {
                                try
                                {
                                    if ((Draw.MinisterOnTable[ii].Row == i & Draw.MinisterOnTable[ii].Column == j) && System.Math.Abs(Table[i, j]) == 5)
                                    {
                                        Minister = ii;
                                        AllDraw.MouseClick++;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                            }

                            for (int ii = 0; ii < AllDraw.KingHigh; ii++)
                            {
                                try
                                {
                                    if ((Draw.KingOnTable[ii].Row == i & Draw.KingOnTable[ii].Column == j) && System.Math.Abs(Table[i, j]) == 6)
                                    {
                                        King = ii;
                                        AllDraw.MouseClick++;
                                        return;
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                            }
                        }

                        AllDraw.MouseClick++;
                        return;
                    }
                }

        }
        //Mouse Leave Blank Event Handling.
        private void pictureBoxRefrigtz_MouseLeave(object sender, EventArgs e)
        {
        }
        //Mouse Movments of FormRefregitz PictureBox Event Handling.
        private void pictureBoxRefrigtz_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {

                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        if (System.Math.Abs(e.X - i * (pictureBoxRefrigtz.Image.Width / 8)) < pictureBoxRefrigtz.Image.Width / 8 && System.Math.Abs(e.Y - j * (pictureBoxRefrigtz.Image.Height / 8)) < pictureBoxRefrigtz.Image.Height / 8)
                        {
                            if (AllDraw.MouseClick == 1)
                            {

                                for (int ii = 0; ii < pictureBoxRefrigtz.Image.Width; ii += pictureBoxRefrigtz.Image.Width / 8)
                                    for (int jj = 0; jj < pictureBoxRefrigtz.Image.Height; jj += pictureBoxRefrigtz.Image.Height / 8)
                                    {
                                        try
                                        {  //if ((i + j) % 2 == 0)
                                            //     g.FillRectangle(new SolidBrush(Color.Black), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                                            // else
                                            //    g.FillRectangle(new SolidBrush(Color.White), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                                            Color a = Color.Gray;
                                            if (OrderPlate == -1)
                                                a = Color.Brown;
                                            bool[,] Tab = null;
                                            if (RowClickP != -1 && ColumnClickP != -1)
                                                Tab = VeryFye(Table, OrderPlate, a);
                                            if ((ii + jj) % 2 == 0)
                                                g.DrawImage(Image.FromFile("Images\\Program\\Black.jpg"), new Rectangle(ii, jj, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                                            else
                                                g.DrawImage(Image.FromFile("Images\\Program\\White.jpg"), new Rectangle(ii, jj, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                                            if (Tab[i / (pictureBoxRefrigtz.Image.Width / 8), j / (pictureBoxRefrigtz.Image.Height / 8)])
                                            {
                                                g.DrawString("*", new Font("Times New Roman", 50), new SolidBrush(Color.Red), new Rectangle(i, j, this.pictureBoxRefrigtz.Width / 8, this.pictureBoxRefrigtz.Height / 8));
                                            }
                                        }
                                        catch (Exception t) { Log(t); }
                                    }


                                if (RowRealesed == -1 && ColumnRealeased == -1 & RowRealesedP == -1 && ColumnRealeasedP == -1)
                                {
                                    RowRealesed = i;
                                    ColumnRealeased = j;
                                    RowRealesedP = i;
                                    ColumnRealeasedP = j;
                                }



                            }
                            RowRealesedP = RowRealesed;
                            ColumnRealeasedP = ColumnRealeased;
                            RowRealesed = i;
                            ColumnRealeased = j;
                            return;
                        }
                    }
            }
            catch (Exception t)
            {
                Log(t);
            }
        }
        //FromRefregitz PictureBox Blanck Click Handling.
        private void pictureBoxRefrigtz_Click(object sender, EventArgs e)
        {
        }
        //A Tool Strip Blanck Click Event Handling.
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }
        //Computer By Computer tool Strip Menu Item Event Handlimng.
        private void computerWithComputerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StateCC = true;
            if (OrderPlate == 1)
            {
                BobSection = true;
                AliceSection = false;
                GrayTimer.StartTime();
            }
            else
            {
                BobSection = false;
                AliceSection = true;
                BrownTimer.StartTime();
            }
        }
        //Computer by Person Illegal name tool Strip Evnt Handling.
        private void computerWithComputerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StateCC = true;
            BobSection = false;
            AliceSection = false;
            StateCC = false;
            StateGe = false;
            if (OrderPlate == 1 && Sec.radioButtonGrayOrder.Checked)
            {
                Person = true;
                StateCP = true;
                GrayTimer.StartTime();
            }
            else if (Sec.radioButtonBrownOrder.Checked && OrderPlate == -1)
            {
                Person = false;
                StateCP = true;
                BrownTimer.StartTime();
            }
            else
            {
                StateCP = true;
                Person = false;
            }





        }
        //Button Next Game Analysis Click Event Handling.
        private void buttonNext_Click(object sender, EventArgs e)
        {
            try
            {
                //Increased a movments.
                MovmentsNumber++;
                //Read Increased Movments.
                Table = ReadTableMovmentNumber();
                //Clear Table List of Draw.
                Draw.TableList.Clear();
                //Add Table to Table List.
                Draw.TableList.Add(Table);
                //Constructed a Draw All.
                Draw.SetRowColumn(0);
                //OutPut.
                SetBoxText("\r\nMovments Number " + MovmentsNumber.ToString() + " Fronted.");
                //Refresh TextBox.
                RefreshBoxText();
                //Sound a Music.
                using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
                {
                    soundClick.Play();
                    soundClick.Dispose();
                }

            }
            catch (Exception t) { Log(t); }

        }
        //Previous Game Analysis Click Event Handling
        private void buttonPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                //Read Current Table List
                Table = ReadTableMovmentNumber();
                //Clear Current TableList.
                Draw.TableList.Clear();
                //Add Table To Table List
                Draw.TableList.Add(Table);
                //Construction of All Things and Thinkings.
                Draw.SetRowColumn(0);
                //Out Put
                SetBoxText("\r\nMovments Number " + MovmentsNumber.ToString() + " Backed.");
                //Refresh TextBox.
                RefreshBoxText();
                //Sound a Music.
                using (SoundPlayer soundClick = new SoundPlayer("Music\\Click6.wav"))
                {
                    soundClick.Play();
                    soundClick.Dispose();
                }
                //Decreased a Movments.
                MovmentsNumber--;
            }
            catch (Exception t) { Log(t); }

        }
        //Mouse Double Click pictureBoxRefregitz Click Event Handlimng.
        private void pictureBoxRefrigtz_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (!Maximize)
            {
                RowP = pictureBoxRefrigtz.Width;
                ColP = pictureBoxRefrigtz.Height;
                RowS = this.Width;
                ColS = this.Height;
                this.MaximumSize = new Size(1000, 700);
                pictureBoxRefrigtz.MaximumSize = new Size(900, 600);

                Maximize = true;
            }
            else
            {
                this.MaximumSize = new Size(RowS, ColS);
                pictureBoxRefrigtz.MaximumSize = new Size(RowP, ColP);

                RowP = pictureBoxRefrigtz.Width;
                ColP = pictureBoxRefrigtz.Height;
                RowS = this.Width;
                ColS = this.Height;

                Maximize = false;
            }
        }
        //New Game tool Strip Event Handling. 
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            NewTable = true;
            this.Hide();
            StateCC = false;
            BobSection = false;
            AliceSection = false;
            StateCP = false;
            Person = false;

            (new FormRefrigtz(false)).Show();
        }
        //Leave FormRefregitz Event Handling. 
        private void FormRefrigtz_Leave(object sender, EventArgs e)
        {

        }
        //Exit ToolStrip Event Handling.
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (LoadedTable)
            {
                if (TTimerSet != null)
                    TTimerSet.Abort();
                if (AllOperate != null)
                    AllOperate.Abort();
                if (t1 != null)
                    t1.Abort();
                if (t2 != null)
                    t2.Abort();
                if (t3 != null)
                    t3.Abort();
                if (t4 != null)
                    t4.Abort();
                GrayTimer.StopTime();
                BrownTimer.StopTime();
                TimerText.StopTime();

                StateCC = false;
                StateCP = false;
                StateGe = false;
                Person = false;
                if (!Directory.Exists("DataBase\\Games"))
                    Directory.CreateDirectory("DataBase\\Games");
                int i = 0;
                do { i++; } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + i.ToString() + ".accdb"));
                System.IO.File.Copy("Database\\CurrentBank.accdb", "Database\\Games\\CurrentBank" + i.ToString() + ".accdb");
                System.IO.File.Delete("Database\\CurrentBank.accdb");
                Application.Exit();
                return;
            }

        }

        //An Broken Paint PictureBox Event Handling.
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            try
            {

            }
            catch (Exception t) { Log(t); }



        }
        //A Broken Timer Brown Event Handling.
        private void pictureBoxTimerBrown_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                //this.InvokePaint(pictureBoxRefrigtz, new PaintEventArgs(pictureBoxRefrigtz.CreateGraphics(), new Rectangle(0, 0, pictureBoxRefrigtz.Width, pictureBoxRefrigtz.Height)));

            }
            catch (Exception t) { Log(t); }


        }
        //A Broken Frorm Refregitz Paint Event Handling.
        private void FormRefrigtz_Paint(object sender, PaintEventArgs e)
        {
            //this.Update();
            //this.Invalidate();

        }
        //A Broken Blanck Text Changes Event Handling.
        private void textBoxText_TextChanged(object sender, EventArgs e)
        {

        }
        //A Gray Timer Broken Paint Picture Box Event Handling.
        private void pictureBoxTimerGray_Paint(object sender, PaintEventArgs e)
        {

        }
        //A Broken Blanck PictureBox Paint Event Handling.
        private void pictureBoxTimerBrown_Paint_1(object sender, PaintEventArgs e)
        {

        }
        //Dept Huristic Checkbox Checked Event Handling.
        private void checkBoxDeptHuristic_CheckedChanged(object sender, EventArgs e)
        {
            RunInBackGround();
            if (checkBoxDeptHuristic.Checked)
                ThinkingChess.DeptHuristic = true;
            else
                ThinkingChess.DeptHuristic = false;
            UpdateConfigurationTable();
            RunInFront();
        }
        //Only Self Hidden UnUsed Broken Code Checked CheckBox Event Handling.
        private void checkBoxOnlySelf_CheckedChanged(object sender, EventArgs e)
        {
            /*RunInBackGround();
            if (checkBoxOnlySelf.Checked)
                ThinkingChess.OnlySelf = true;
            else
                ThinkingChess.OnlySelf = false;
            UpdateConfigurationTable();
            RunInFront();*/
        }
        //Predict Huristic Check Box Checkeed Event Handling.
        private void checkBoxPredictHuristci_CheckedChanged(object sender, EventArgs e)
        {
            RunInBackGround();
            if (checkBoxPredictHuristci.Checked)
                ThinkingChess.PredictHuristic = true;
            else
                ThinkingChess.PredictHuristic = false;
            UpdateConfigurationTable();
            RunInFront();
        }
        //Best Movments Stared Hidden Checked Box Event Handling.
        private void checkBoxBestMovments_CheckedChanged(object sender, EventArgs e)
        {
            /*try
            {
                RunInBackGround();
                if (checkBoxBestMovments.Checked)
                    ThinkingChess.BestMovments = true;
                else
                    ThinkingChess.BestMovments = false;
                UpdateConfigurationTable();
                RunInFront();
            }
            catch (Exception t) { RunInFront(); Log(t); }*/
        }
        //radio Button Checked Box Checked Event Handling.
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {

                RunInBackGround();
                if (radioButtonOriginalImages.Checked)
                    AllDraw.ImagesSubRoot = AllDraw.ImageRoot + "\\Original\\";
                UpdateConfigurationTable();
                RunInFront();
            }
            catch (Exception t) { RunInFront(); Log(t); }
        }
        //Big Fitting Checked Box Checked Event Handling.
        private void radioButtonBigFittingImages_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                RunInBackGround();
                if (radioButtonBigFittingImages.Checked)
                    AllDraw.ImagesSubRoot = AllDraw.ImageRoot + "\\Fit\\Big\\";
                UpdateConfigurationTable();
                RunInFront();
            }
            catch (Exception t) { RunInFront(); Log(t); }
        }
        //Samll Fitting Radio Button Checked Event Handling.
        private void radioButtonSmallFittingImages_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                RunInBackGround();
                if (radioButtonSmallFittingImages.Checked)
                    AllDraw.ImagesSubRoot = AllDraw.ImageRoot + "\\Fit\\Small\\";
                UpdateConfigurationTable();
                RunInFront();
            }
            catch (Exception t) { RunInFront(); Log(t); }
        }
        //Genetic Algorithm Game tool Strip Event Handling. 
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            StateGe = true;
        }
        //Stop Button Click Event Handling.
        private void buttonStop_Click(object sender, EventArgs e)
        {
            if (t1.IsAlive)
                t1.Resume();
            if (t2.IsAlive)
                t2.Resume();
            if (t3.IsAlive)
                t3.Resume();
            if (t4.IsAlive)
                t4.Resume();
            StateCC = false;
            StateCP = false;
            StateGe = false;
            Person = false;
            SetBoxText("\r\nAll Stop!.");

        }
        //Dept First Search Checked BOX Checked Event Handling.
        private void checkBoxDeptFirstSearch_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                AllDraw.DeptFirstSearch = true;
                if (checkBoxDeptFirstSearch.Checked)
                    checkBoxUseDoubleTime.Visible = true;
                else checkBoxUseDoubleTime.Visible = false;
            }
            catch (Exception t) { RunInFront(); Log(t); }



        }
        //Hardes Games tool Strip Event Handling.
        private void hardestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            checkBoxDeptHuristic.Checked = true;
            checkBoxPredictHuristci.Checked = true;
            checkBoxDeptFirstSearch.Checked = true;
            checkBoxBestMovments.Checked = false;
            checkBoxOnlySelf.Checked = false;
            UpdateConfigurationTable();
        }
        //Medum Game tool Strip Event Handling .
        private void medumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            checkBoxDeptHuristic.Checked = true;
            checkBoxPredictHuristci.Checked = true;
            checkBoxDeptFirstSearch.Checked = false;
            checkBoxBestMovments.Checked = false;
            checkBoxOnlySelf.Checked = false;
            UpdateConfigurationTable();

        }
        //Easest tool Strip Event Handling .
        private void easestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            checkBoxDeptHuristic.Checked = false;

            checkBoxPredictHuristci.Checked = false;
            checkBoxDeptFirstSearch.Checked = false;
            AllDraw.DeptFirstSearch = false;
            checkBoxBestMovments.Checked = false;
            checkBoxOnlySelf.Checked = true;
            UpdateConfigurationTable();

        }
        //Maximum Size Form Refregitz Evemnt Handling Operation.
        private void FormRefrigtz_MaximumSizeChanged(object sender, EventArgs e)
        {


            if (t1.IsAlive)
                t1.Suspend();
            if (t2.IsAlive)
                t2.Suspend();
            if (t3.IsAlive)
                t3.Suspend();
            if (t4.IsAlive)
                t4.Suspend();





            pictureBoxRefrigtz.Update();
            pictureBoxRefrigtz.Invalidate();

            System.Threading.Thread.Sleep(1000);

            if (t1.IsBackground)
                t1.Resume();
            if (t2.IsBackground)
                t2.Resume();
            if (t3.IsBackground)
                t3.Resume();
            if (t4.IsBackground)
                t4.Resume();
        }
        //Enetr of Form Refregitsz Broken Event Handling.
        private void FormRefrigtz_Enter(object sender, EventArgs e)
        {

            //  pictureBoxRefrigtz.Update();
            //  pictureBoxRefrigtz.Invalidate();

        }
        //A Broken Balnck Menu tool Strip Enbet Handling.
        private void menuStripChessRefrigitz_Enter(object sender, EventArgs e)
        {



        }
        //Leave toll Strips Event Handling Operation.
        private void menuStripChessRefrigitz_Leave(object sender, EventArgs e)
        {
            if (t1 != null)
                t1.Abort();
            if (t2 != null)
                t2.Abort();
            if (t3 != null)
                t3.Abort();
            if (t4 != null)
                t4.Abort();
            

        }
        //Puased Click Event Handling
        private void buttonPause_Click(object sender, EventArgs e)
        {
            if (Paused)
            {
                try
                {
                    Paused = true;


                    buttonPauseStart.Text = "Start";
                }
                catch (Exception t) { Log(t); }
            }
            else
            {
                try
                {

                    if (t1.IsBackground)
                        t1.Resume();
                    if (t2.IsBackground)
                        t2.Resume();
                    if (t3.IsBackground)
                        t3.Resume();
                    if (t4.IsBackground)
                        t4.Resume();
                    Paused = false;
                    buttonPauseStart.Text = "Stop";
                }
                catch (Exception t) { Log(t); }
            }
        }
        //Run In Backgroud Thread Handling Method.
        void RunInBackGround()
        {

            if (t1.IsAlive)
                t1.Suspend();
            if (t2.IsAlive)
                t2.Suspend();
            if (t3.IsAlive)
                t3.Suspend();
            if (t4.IsAlive)
                t4.Suspend();

        }
        //Run In Front Thread Handling Method.
        void RunInFront()
        {
            if (StateCC && AliceSection && t3.IsBackground)
                t3.Resume();
            if (StateCC && BobSection && t2.IsBackground)
                t2.Resume();
            if (StateCP && !Person && t1.IsBackground)
                t1.Resume();

            if (t1.IsAlive && t1.IsBackground)
                t1.Resume();
            if (t2.IsAlive && t2.IsBackground)
                t2.Resume();
            if (t3.IsAlive && t3.IsBackground)
                t3.Resume();
            if (t4.IsAlive && t4.IsBackground)
                t4.Resume();

        }
        //Dept Movements Chkeched Box Checked Stared Event Handling. 
        private void checkBoxDeptMovement_CheckedChanged(object sender, EventArgs e)
        {/*
            try
            {
                RunInBackGround();
                if (checkBoxDeptMovement.Checked)
                {
                    AllDraw.SodierMovments = 4;
                    AllDraw.ElefantMovments = 16;
                    AllDraw.HourseMovments = 8;
                    AllDraw.BridgeMovments = 16;
                    AllDraw.MinisterMovments = 32;
                    AllDraw.KingMovments = 8;

                }
                else
                {
                    AllDraw.SodierMovments = 1;
                    AllDraw.ElefantMovments = 1;
                    AllDraw.HourseMovments = 1;
                    AllDraw.BridgeMovments = 1;
                    AllDraw.MinisterMovments = 1;
                    AllDraw.KingMovments = 1;
                }
                RunInFront();
            }
            catch (Exception t) { RunInFront(); Log(t); }*/
        }
        //A Broken Blanck tool Strip Event Handling.
        private void checkBoxDeptFirstSearch_Enter(object sender, EventArgs e)
        {

        }
        //A Broken Best Movments Blanck Checked Box Event Handling. 
        private void checkBoxBestMovments_Enter(object sender, EventArgs e)
        {

        }
        //Predict Huristic checked Box Event Handling .
        private void checkBoxPredictHuristci_Enter(object sender, EventArgs e)
        {

        }
        //A Broken Blanck checked Box Hidden Event Handling.
        private void checkBoxOnlySelf_Enter(object sender, EventArgs e)
        {

        }
        //A Broken Dept Hurist Black checked Box Event Handling.
        private void checkBoxDeptHuristic_Enter(object sender, EventArgs e)
        {

        }
        //Dept Movments Event Handl;ing Operations Method.
        private void checkBoxDeptMovement_Enter(object sender, EventArgs e)
        {
            if (checkBoxDeptMovement.Checked)
            {
                AllDraw.SodierMovments = 4;
                AllDraw.ElefantMovments = 16;
                AllDraw.HourseMovments = 8;
                AllDraw.BridgeMovments = 16;
                AllDraw.MinisterMovments = 32;
                AllDraw.KingMovments = 8;

            }
            else
            {
                AllDraw.SodierMovments = 1;
                AllDraw.ElefantMovments = 1;
                AllDraw.HourseMovments = 1;
                AllDraw.BridgeMovments = 1;
                AllDraw.MinisterMovments = 1;
                AllDraw.KingMovments = 1;
            }

        }
        //Double Time Checked Box Checked Event Handling.
        private void checkBoxUseDoubleTime_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                RunInBackGround();
                if (AllDraw.DeptFirstSearch)
                {
                    checkBoxUseDoubleTime.Visible = true;

                    if (checkBoxUseDoubleTime.Checked)
                    {
                        AllDraw.UseDoubleTime = true;
                    }
                }
                else
                {
                    checkBoxUseDoubleTime.Visible = false;
                    AllDraw.UseDoubleTime = false;
                }

                UpdateConfigurationTable();
                RunInFront();
            }
            catch (Exception t) { RunInFront(); Log(t); }

        }
        //A Broken Unkwon Blanckedtool Strip event Hndling.
        private void menuStripChessRefrigitz_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        //Penalty Regrad Mechansiam Checed Box Event Handling Operation Method.
        private void checkBoxUsePenaltyRegradMechnisam_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                RunInBackGround();
                if (checkBoxUsePenaltyRegradMechnisam.Checked)
                    ThinkingChess.UsePenaltyRegardMechnisam = true;
                else
                    ThinkingChess.UsePenaltyRegardMechnisam = false;
                UpdateConfigurationTable();
                RunInFront();
            }
            catch (Exception t) { Log(t); }
        }
        //Dynamic Programming Dept First checked Event Handling.
        private void checkBoxDynamicProgrammingDeptFirst_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                RunInBackGround();
                if (checkBoxDynamicProgrammingDeptFirst.Checked)
                    AllDraw.DynamicDeptFirstPrograming = true;
                else
                    AllDraw.DynamicDeptFirstPrograming = false;
                UpdateConfigurationTable();
                RunInFront();
            }
            catch (Exception t) { Log(t); }
        }
        //Help Event Handling Show Method.
        private void toolStripMenuItem3_Click_1(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "Help.chm");

        }
        //Verify tool Srtip Games Folder Databases Event Handling Operation.
        private void verifyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int Max = 0;
            do
            {
                Max++;
            } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + Max.ToString() + ".accdb"));
            int iii = 0;
            do
            {
                progressBarVerify.Value = (int)(((double)iii / (double)Max) * 100.0);
                iii++;
                String FileName = "Database\\Games\\CurrentBank" + iii.ToString() + ".accdb";
                //Read Last Table and Set MovementNumber
                MovmentsNumber = 0;
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        AllDraw.TableVeryfy[i, j] = AllDraw.TableVeryfyConst[i, j];
                    }
  
                VerifyTable(FileName, 0, ref MovmentsNumber);
                //Clear Table List.
                Draw.TableList.Clear();
                //Add Table List.
                Draw.TableList.Add(Table);
                //Construction of Draw Things and Thinkings.

                Draw.SetRowColumn(0);
                //When Configuration is Allowed Read Configuration.
                if (!UpdateConfigurationTableVal)
                    ReadConfigurationTable();
                //Set Configuration To True for some unknown reason!.
                UpdateConfigurationTableVal = true;

            } while (System.IO.File.Exists("Database\\Games\\CurrentBank" + iii.ToString() + ".accdb"));
            MovmentsNumber = 0;
        }
    }

}
//End of Documentation.




