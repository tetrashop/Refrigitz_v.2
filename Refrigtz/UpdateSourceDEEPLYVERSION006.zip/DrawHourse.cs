﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;

namespace Refrigtz
{
    public class DrawHourse
    {
        //Iniatite Global Variables.
        public float Row, Column;
        public Color color;
        public int[,] Table = null;
        public ThinkingChess[] HourseThinking = new ThinkingChess[AllDraw.HourseMovments];
        public int Current = 0;
        public int Order;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
       //Constructor 1.
        public DrawHourse() { }
        //Constructpor 2.
        public DrawHourse(float i, float j, Color a, int[,] Tab, int Ord, bool TB, int Cur)
        {
            //Initiate Global Variable By Local Paramenters.
            Table = Tab;
            for (int ii = 0; ii < AllDraw.HourseMovments; ii++)
                HourseThinking[ii] = new ThinkingChess((int)i, (int)j, a, Tab, 8, Ord, TB, Cur, 4);

            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;

        }
        //Cloen a Copy.
        public void Clone(ref DrawHourse AA,ref FormRefrigtz THIS)
        {
            //Create a Construction Ojects and Initiate a Clone Copy.
            AA = new DrawHourse(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.HourseMovments; i++)
            {
                try
                {
                    AA.HourseThinking[i] = new ThinkingChess();
                    this.HourseThinking[i].Clone(ref AA.HourseThinking[i],ref THIS);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.HourseThinking[i] = null;
                }
            }
        }
        //Draw a Instatnt Hourse on the Table Method.
        public void DrawHourseOnTable(ref Graphics g, int CellW, int CellH)
        {
            try
            {
                //Gray Order.
                if (color == Color.Gray)
                {
                    //Draw an Instatnt Gray Hourse on the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "HG.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                }
                else
                {
                    //Draw an Instatnt Brown Hourse on the Table.
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot + "HB.png"), new Rectangle((int)(Row * (float)CellW), (int)(Column * (float)CellH), CellW, CellH));
                }
            }
            catch (Exception t) { Log(t); }
        }
    }
}

//End of Documentation.