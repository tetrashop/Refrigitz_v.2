﻿/*******************************************************************************************
 * Initiate and Decision making class.******************************************************
 * Ramin Edjlal*****************************************************************************
 * Call Of Constructor From Constructor*****************************************************(+)
 * The Storing AllDraw Object in Self Constructor Caused Stack Overflow*********************(+)
 * Link List Of Storing String Caused A Stack Over Flow*************************************(+)
 * Wait For Finished Current Dept Caused To Long Time***************************************(+)
 * Need To Heuristic (Arvin) Function(s) to Manage Cell in Form1****************************(+)
 * First Scanning Movements of Things Anomaly***********************************************(+)
 * In Current Version of Heuristic Table Doesn’t Reached(Zero)******************************(+)
 * In Current Version InitiateForEveryThisngsHome Dosn't Work*******************************(+)
 * In This Version Thinking Taking A LotofTime(DeptFirst Array Tree)************************(+)
 * Heuristic Work In Depts. But Scanning Dosen’t Works**************************************(+)
 * Adding Clone Caused To Stack Overflow****************************************************(+)
 * Clone Caused To StackOverFlow************************************************************(+)
 * Row And Column Become Zero in Virtualization*********************************************(+)
 * Initiate Error***************************************************************************(+)
 * Seems To Be Logical Drawing *************************************************************(+)
 * Color Suddenly Changing******************************************************************(+)
 * AllDraw Object Sub Objects List When Return from local Scope Become Zero*****************(+)
 * Huristic Dosn't Work*********************************************************************(+)
 * Color Order Of Visualization Changed Suddenly********************************************(+)
 * Color Changes with no movement***********************************************************(+)
 * Table Not Gate (Inversion of Table List) Doesn’t help to do Normally*********************(+)
 * Literally Errors Correction**************************************************************(+)
 * From Arrangements of Things Reaches Suddenly Things Location Occurs**********************(+)
 * The Arrangements is Logical**************************************************************(+)
 * The Color changes and the arrangements changes are not clearly obvious*******************(+)
 * Color Changes Solved. no movements*******************************************************(-+)
 * Things movements Anomally****************************************************************(+)
 * Chess Rules Anomally*********************************************************************(+)
 * Heuristic Function Not Work**************************************************************(+)
 * Heuristic Work But the Table is Empty****************************************************(+)
 * Table is Not Empty But the Movement is Not Logical***************************************(+)
 * Clear Dirty Part.************************************************************************(*)
 * Need to Restricted Approval. Taking a lot of time Thinking Computation*******************(+)
 * No movements In Virtualization***********************************************************(+)
 * Chess Rules Abnormal thinking movements. No movement greater than 2**********************(+)
 * Problem For Drawing of Thinking Things***************************************************(+)
 * Heuristic Constant Result****************************************************************(+)
 * One movements Right .Heuristic Remaining Constant Results********************************(+)
 * Constant Heuristic Result****************************************************************(+)
 * Need To Add A Heuristic Useful Another***************************************************(+)
 * Heuristic Function Does’ Work Allis suddenly Become Zero that Previously Working*********(+)
 * No Movement Greater than one order in Computer 'Alice'***********************************(+)
 * Tow movements in Computer 'Alice' Of two Different Order Color***************************(+)
 * Heuristic Not Work Greater than 3 Length Count of A**************************************(+)
 * 'They Don't Really Take care about us'. Misleading in Heuristic King Supported***********(+)
 * Non Order Movments***********************************************************************(+)
 * Misleading at Stage three. no illegal movement greater than three************************(+)
 * Thinking Order Misleading****************************************************************(+)
 * Hit Mechanism Malfunctional**************************************************************(+)
 * Tow movements At One 'Alice' Order time**************************************************(+)
 * Heuristic Computer By Computer 'Alice' by 'Bob' Caused to Loop Heuristic*****************(+)
 * Learning Automata of Quantum also leads to re loop heuristic*****************************(*)
 * Heuristic Learning Automata 'Alice' By 'Bob' Leads to Re loop****************************(+)
 * Heuristic Things Loop 'Alice' By 'Bob'***************************************************(+)
 * Self 'Kish' Detection Failure By 'Alice'*************************************************(+)
 * 'Penalty' Value Of All Become zero althouth the one should be non Penalty****************(*)
 * Clone Dosn't Copy All Content of AllDraw Dummy*******************************************(+)
 * KishRemovable By Self King Solved.Penalty Action Misleading******************************(-*)
 * 'Kish' Detection Failure*****************************************************************(+)
 * Mechanisam Of Order in Predict Failed.***************************************************(+)
 * 'Alice' King Virtualization or Table Content of King Misleading**************************(+)
 * With The All Things Huristic Signing Mechnisam Some Movments become null Table.**********(+)
 * Dept First Search Not Working. Misleading MalFunction Virtualization.********************(+)
 * Dept First Table is Null at Bob Order.***************************************************(+)
 * Dept First SetVirtualization and Table Misleading By Alice.******************************(+)
 * No Reason Logically For MalFunction  Timer Dept First Dynamic Timer.*********************(+)
 * DeptFirst Thinking Taking a lot of time.*************************************************[+]
 * Dept First Not Work.*********************************************************************[+]
 * Dept First Not Work.Timer Stop At Greater than 2,3,4,5,6,7 Movments.*********************[+]
 * No Reason For MalFunction of DeptFirstNotFoundHuristicDeptFirst.*****************
 * ********[+]
 * Problem Solved.No Reason to NullExeption of DeptFirstHuristic Algorithm.*****************[-*]
 * Function Evaluation Disabled .At Initiate DeptFirstGenetic Found Sysntax.****************[*]
 * Index Was Out Of Range Exeption Was Not Handled.Colud Not Be Handle.*********************{+}
 * No Logical Mechanism To Reconstructe Current AllDraw Objects.****************************{+}
 * Dept First Sysntax is legal and The table is constant table.*****************************{+}
 * Table Content Empty. No Syntax Exist.****************************************************{+}
 * Game Begin From First When the Soldiers Move Ordinary Complete in Dept First*************{*}
 * New Instatnt Of Program Cuase to Begin Fron First.***************************************<+>
 * No Logically Reason For New Game Of Program. New Instatnt Not Detected.******************<+>
 * Internal New Instatnt Of FormeRefregitz is MalFunction.**********************************<+>
 * Dept First CC Changes to CC Normal Game.*************************************************<+>
 * Game CC UnContoroled.********************************************************************<+>
 * MalFunction of Syntax and Movments.By Alice and Bob.*************************************<+>
 * Threading Solved! The OutOfRangeIndex Not Work.******************************************[-+]
 * Vituallization error!No Best Matches between Truth of table content and irtualization****[+]
 * Dynamic Programming for Stroring ADraw THISDummy Adraw Value MalFunction.****************(+)
 * Order is Constant in Dynamic Programming.************************************************(+)
 * Table MalFunction at Dynamic Programming.At Step 3.**************************************(+)
 * Some Movments are MalFuncational at Dynamic Programming.*********************************(+)
 * Huristic Overlay Tow Part of ADraw and StoreADraw Sections at Different levels Tab Cal.**(+)
 * Not to be needing again calculation. MalFunction is depend of tow part.******************(+)
 * BackWard Loos of Things AllDraw Mechnisam.***********************************************(*)
 * Some Dynamic Programming MalFunction Movments.*******************************************(*)
 * Syntax and Forward and Backward Movments Syntax is MalFunction.**************************<+>
 * Database and Virtualization Forward and Backward MalFunction*****************************<+>
 * Reproduction of Thinfs Missleading.******************************************************<*>
 * Reproduction of Some Things are MalFunction Movments.************************************{+}
 * Dept Count of Dynamic Programming Misleadig.Dept Operation Count Mal Function.***********(*)
 * Huristic By Alice is MalFunction.********************************************************(+)
 * Achmaz Identification By Alice is MalFunction.*******************************************(+)
 * Kish Identification By Alice is MalFunction.*********************************************(+)
 * Kish Recognized But Mate Not Recognized!*************************************************(_+)
 * Penalty Regard Mechanism Misleading.*****************************************************{+}
 * Inhereted LearningAtamata Caused to Shared Parent Allocated Variable.********************{+}
 * 'Kish' By 'Alice' Not Removed Unreasonably.**********************************************{*}
 * DeptFirst Huristic Found MalFunction at Kish Alice.**************************************{+}
 * Sortments of ADRAW and Construction is MalFunction at Dept Dynamic Programming.**********{+}
 * Huristic Dept First were Worked Out Unreasonably such Situation(Golden Sword Magic).*****{*}
 * Converted 'King' of 'Alice' to 'Elephant' UnReasonably.**********************************(+)
 * 'Long Game' ; But MalFunction of Game.***************************************************(+)
 * 'Always' in Current game is 'Bob'.*******************************************************(+)
 * Current Table of ADRAW is Correct Table But the Game is MalFunction.*********************(+)
 * Move of Current Table Dept First Huristic found ;found an ovelay in 'Bob' and 'Alice'****(+)
 * Current Table in High Level Become Null and prevent of 'LongGame' Strategy.**************(+)
 * 'LongGame' Become short Undetectably Unreasonably;Clear Store Non Detectably.************(*)
 * All Draw Dept First section some movments have not been accurred considerably.***********(*)
 * 'Long Game' Breaks Suddendly without Monitor Caused.*************************************{+}
 * Overlay Some Movments of 'Long Game' Breaked.Caused Probability to break.****************{+}
 * SomeTimes All Situation of Current Games Become Cleared and No Table Founded.************{+}
 * Gray Soldeir is Only Movmnets and Converts in Huristic and No Move are detectable.*******{+}
 * DEEPLY Recursive Tree of Second Version Become in Some Null At Hurristic Finsished.****** 
 * *****************************************************************************************(+:Sum(63)) 
 * 1394/12/19*******************************************************************************(*:Sum(4))
 * *****************************************************************************************(-:sum(2)) (_:Sum(0)):2:(+:Sum(3)) (-:Sum(1)) (*:Sum(2)) 3: (+:Sum(4)) (*:Sum(1)) 4:(+:Sum(6))  5:(+:Sum(2)) (-:Sum(1)) 6:(+:Sum(6)) (*:Sum(2)) 7.(+:Sum(2)) (*:Sum(1)) 8.(+:Sum(1)) 9.(+:Sum(4)) (*:Sum(1)) (-:Sum(1)) 10.(+:Sum(4)) (*:Sum(2)) 11.(+:Sum(4)) 12.(+:Sum(2)) (*:Sum(2)) 13.(+:Sum(4))
 */


using System;
using System.Collections.Generic;

using System.Text;
using System.Drawing;
using System.Threading;
using System.IO;
namespace Refrigtz
{
    public class AllDraw
    {
        //Initiate Variables.
        public static int[,] TableVeryfy = new int[8, 8];
        static int MaxDept = 3;
        public static int[,] TableVeryfyConst = new int[8, 8];
        static int[,] TableHuristic = new int[8, 8];

        public static List<int[,]> TableCurrent = new List<int[,]>();
        static bool NoTableFound = false;
        bool LastDynamicNotFound = false;
        public static bool DynamicDeptFirstPrograming = false;
        public static List<AllDraw> StoreADraw = new List<AllDraw>();
        public static List<int> StoreADrawDept = new List<int>();
        static int LevelDeptFirsDynamic = 1;
        public static bool UseDoubleTime = false;
        public static int DeptiLevelMax = 2;
        public static bool DeptFirstSearch = false;
        public static String ImageRoot = "Images";
        public static String ImagesSubRoot = AllDraw.ImageRoot + "\\Fit\\Small\\";
        public static bool RedrawTable = true;
        public static String SyntaxToWrite = "";
        public static bool SodierConversionOcuured = false;
        public static int SodierMovments = 1;
        public static int ElefantMovments = 1;
        public static int HourseMovments = 1;
        public static int BridgeMovments = 1;
        public static int MinisterMovments = 1;
        public static int KingMovments = 1;

        public static int SodierMidle = 8;
        public static int SodierHigh = 16;
        public static int ElefantMidle = 2;
        public static int ElefantHigh = 4;
        public static int HourseMidle = 2;
        public static int HourseHight = 4;
        public static int BridgeMidle = 2;
        public static int BridgeHigh = 4;
        public static int MinisterMidle = 1;
        public static int MinisterHigh = 2;
        public static int KingMidle = 1;
        public static int KingHigh = 2;

        ChessPerdict APredict = null;

        bool KishG = false, KishB = false;
        public static int SodierValue = 1;
        public static int ElefantValue = 2;
        public static int HourseValue = 3;
        public static int BridgeValue = 5;
        public static int MinisterValue = 8;
        public static int KingValue = 10;
        int RW = 0;
        int CL = 0;
        int Ki = 0;
        int RW1 = 0;
        int CL1 = 0;
        int Ki1 = 0;
        int RW2 = 0;
        int CL2 = 0;
        int Ki2 = 0;
        int RW3 = 0;
        int CL3 = 0;
        int Ki3 = 0;
        int RW4 = 0;
        int CL4 = 0;
        int Ki4 = 0;
        int RW5 = 0;
        int CL5 = 0;
        int Ki5 = 0;
        int RW6 = 0;
        int CL6 = 0;
        int Ki6 = 0;
        public static int LoopHuristicIndex = 0;
        static List<int> RWList = new List<int>();
        static List<int> ClList = new List<int>();
        static List<int> KiList = new List<int>();
        static public List<int[,]> TableListAction = new List<int[,]>();
        public int Move = 0;
        static public int MouseClick = 0;
        int[] DeptIndex = new int[20];
        int DeptIndexVlue = 0;
        public int[,] CurrentTable = new int[8, 8];
        public List<AllDraw> ADraw = null;
        public List<int[,]> TableList = new List<int[,]>();

        public int Dept = 0;
        public DrawSoldier[] SolderesOnTable = null;
        public DrawElefant[] ElephantOnTable = null;
        public DrawHourse[] HoursesOnTable = null;
        public DrawBridge[] BridgesOnTable = null;
        public DrawMinister[] MinisterOnTable = null;
        public DrawKing[] KingOnTable = null;
        FormRefrigtz THIS;
        //Error Handling
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
        //Constructor
        public AllDraw(ref FormRefrigtz th)
        {
            THIS = th;
            APredict = new ChessPerdict(ref th);
            ADraw = new List<AllDraw>();
            SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
            for (int i = 0; i < AllDraw.SodierHigh; i++)
                SolderesOnTable[i] = new DrawSoldier();
            ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
            for (int i = 0; i < AllDraw.ElefantHigh; i++)
                ElephantOnTable[i] = new DrawElefant();
            HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
            for (int i = 0; i < AllDraw.HourseHight; i++)
                HoursesOnTable[i] = new DrawHourse();
            BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
            for (int i = 0; i < AllDraw.BridgeHigh; i++)
                BridgesOnTable[i] = new DrawBridge();
            MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
            for (int i = 0; i < AllDraw.MinisterHigh; i++)
                MinisterOnTable[i] = new DrawMinister();
            KingOnTable = new DrawKing[AllDraw.KingHigh];
            for (int i = 0; i < AllDraw.KingHigh; i++)
                KingOnTable[i] = new DrawKing();


        }
        //Clone Copy Method
        public void Clone(AllDraw AA)
        {

            AA.SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
            for (int i = 0; i < AllDraw.SodierHigh; i++)
            {
                try
                {
                    this.SolderesOnTable[i].Clone(ref AA.SolderesOnTable[i], ref THIS);
                }
                catch (Exception t) { Log(t); }
            }
            AA.ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
            for (int i = 0; i < AllDraw.ElefantHigh; i++)
            {
                try
                {
                    this.ElephantOnTable[i].Clone(ref AA.ElephantOnTable[i], ref THIS);

                }
                catch (Exception t) { Log(t); }
            }
            AA.HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
            for (int i = 0; i < AllDraw.HourseHight; i++)
            {
                try
                {
                    this.HoursesOnTable[i].Clone(ref AA.HoursesOnTable[i], ref THIS);

                }
                catch (Exception t) { Log(t); }
            }
            AA.BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
            for (int i = 0; i < AllDraw.BridgeHigh; i++)
            {
                try
                {
                    this.BridgesOnTable[i].Clone(ref AA.BridgesOnTable[i], ref THIS);

                }
                catch (Exception t) { Log(t); }
            }
            AA.MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
            for (int i = 0; i < AllDraw.MinisterHigh; i++)
            {
                try
                {
                    this.MinisterOnTable[i].Clone(ref AA.MinisterOnTable[i], ref THIS);

                }
                catch (Exception t) { Log(t); }
            }
            AA.KingOnTable = new DrawKing[AllDraw.KingHigh];
            for (int i = 0; i < AllDraw.KingHigh; i++)
            {
                try
                {
                    this.KingOnTable[i].Clone(ref AA.KingOnTable[i], ref THIS);

                }
                catch (Exception t) { Log(t); }
            }
            AA.ADraw = new List<AllDraw>();
            AA.Dept = this.Dept;
            for (int i = 0; i < this.ADraw.Count; i++)
            {

                AA.ADraw.Add(this.ADraw[i]);
            }
            for (int i = 0; i < this.TableList.Count; i++)
                AA.TableList.Add(this.TableList[i]);

        }
        //aBlanck Constructor
        public AllDraw(AllDraw THi)
        {
        }
        //Check For Thinking Of Current Item Movments Finished.
        public bool AllCurrentDeptThinkingFinished(AllDraw Dum, int i, int j, int Kind)
        {
            bool Finished = false;
            {
                if (Kind == 1)
                {
                    if (Dum.SolderesOnTable[i].SoldierThinking[0].ThinkingFinished)
                        return true;
                }
                else if (Kind == 2)
                {
                    if (Dum.ElephantOnTable[i].ElefantThinking[0].ThinkingFinished)
                        return true;
                }
                else if (Kind == 3)
                {
                    if (Dum.HoursesOnTable[i].HourseThinking[0].ThinkingFinished)
                        return true;
                }
                else if (Kind == 4)
                {
                    if (Dum.BridgesOnTable[i].BridgeThinking[0].ThinkingFinished)
                        return true;
                }
                else if (Kind == 5)
                {
                    if (Dum.MinisterOnTable[i].MinisterThinking[0].ThinkingFinished)
                        return true;
                }
                else if (Kind == 6)
                {
                    if (Dum.KingOnTable[i].KingThinking[0].ThinkingFinished)
                        return true;
                }
            }
            return Finished;

        }
        //Wait For Thinking Of Current Item Finished.
        void Wait(AllDraw Dum, int i, int j, int k, int Kind, bool Dept)
        {
            do
            {
                Thread.Sleep(10);
            } while (!AllCurrentDeptThinkingFinished(Dum, i, j, Kind));


        }
        //(Non Dept First ) Huristic Non Coplement Search Method.
        public void InitiateForEveryKindThingHome(AllDraw DummyHA, int ii, int jj, Color a, int[,] Table, int Order, bool TB, int IN)
        {

            int i = 0, j = 0;
            AllDraw Dummy = new AllDraw(ref THIS);
            if (Order == 1)
            {
                for (i = 0; i < AllDraw.SodierMidle; i++)
                {
                    try
                    {
                        if (SolderesOnTable[i] == null)
                            continue;
                        ii = SolderesOnTable[i].Row;
                        jj = SolderesOnTable[i].Column;
                        Table = SolderesOnTable[i].Table;
                        Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                        {
                            for (j = 0; j < AllDraw.SodierMovments; j++)
                            {
                                Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingBegin = true;
                                Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingFinished = false;
                                Dummy.SolderesOnTable[i].SoldierThinking[0].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[0].Thinking));
                                Dummy.SolderesOnTable[i].SoldierThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 1, false);

                            }
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.SolderesOnTable[i] = null;
                        Log(t);
                    }
                }
                for (i = 0; i < AllDraw.ElefantMidle; i++)
                {
                    try
                    {
                        if (ElephantOnTable[i] == null)
                            continue;
                        ii = ElephantOnTable[i].Row;
                        jj = ElephantOnTable[i].Column;
                        Table = ElephantOnTable[i].Table;
                        Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                        {
                            for (j = 0; j < AllDraw.ElefantMovments; j++)
                            {
                                Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingBegin = true;
                                Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingFinished = false;
                                Dummy.ElephantOnTable[i].ElefantThinking[0].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[0].Thinking));
                                Dummy.ElephantOnTable[i].ElefantThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 2, false);
                            }
                        }
                    }

                    catch (Exception t)
                    {
                        Dummy.ElephantOnTable[i] = null;
                        Log(t);
                    }
                }



                for (i = 0; i < AllDraw.HourseMidle; i++)
                {
                    try
                    {
                        if (HoursesOnTable[i] == null)
                            continue;
                        ii = HoursesOnTable[i].Row;
                        jj = HoursesOnTable[i].Column;
                        Table = HoursesOnTable[i].Table;
                        Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);


                        {
                            for (j = 0; j < AllDraw.HourseMovments; j++)
                            {
                                Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingBegin = true;
                                Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingFinished = false;
                                Dummy.HoursesOnTable[i].HourseThinking[0].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[0].Thinking));
                                Dummy.HoursesOnTable[i].HourseThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 3, false);
                            }

                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.HoursesOnTable[i] = null;
                        Log(t);
                    }
                }




                for (i = 0; i < AllDraw.BridgeMidle; i++)
                {
                    try
                    {
                        if (BridgesOnTable[i] == null)
                            continue;
                        ii = BridgesOnTable[i].Row;
                        jj = BridgesOnTable[i].Column;
                        Table = BridgesOnTable[i].Table;
                        Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                        {
                            for (j = 0; j < AllDraw.BridgeMovments; j++)
                            {
                                Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingBegin = true;
                                Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingFinished = false;
                                Dummy.BridgesOnTable[i].BridgeThinking[0].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[0].Thinking));
                                Dummy.BridgesOnTable[i].BridgeThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 4, false);
                            }

                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.BridgesOnTable[i] = null;
                        Log(t);
                    }
                }
                for (i = 0; i < AllDraw.MinisterMidle; i++)
                {
                    try
                    {
                        if (MinisterOnTable[i] == null)
                            continue;
                        ii = MinisterOnTable[i].Row;
                        jj = MinisterOnTable[i].Column;
                        Table = MinisterOnTable[i].Table;
                        Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);


                        {
                            for (j = 0; j < AllDraw.MinisterMovments; j++)
                            {
                                Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingBegin = true;
                                Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingFinished = false;
                                Dummy.MinisterOnTable[i].MinisterThinking[0].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[0].Thinking));
                                Dummy.MinisterOnTable[i].MinisterThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 5, false);
                            }

                        }

                    }
                    catch (Exception t)
                    {
                        Dummy.MinisterOnTable[i] = null;
                        Log(t);
                    }
                }


                for (i = 0; i < AllDraw.KingMidle; i++)
                {
                    try
                    {
                        if (KingOnTable[i] == null)
                            continue;
                        ii = KingOnTable[i].Row;
                        jj = KingOnTable[i].Column;
                        Table = KingOnTable[i].Table;
                        Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);


                        {
                            for (j = 0; j < AllDraw.KingMovments; j++)
                            {
                                Dummy.KingOnTable[i].KingThinking[0].ThinkingBegin = true;
                                Dummy.KingOnTable[i].KingThinking[0].ThinkingFinished = false;
                                Dummy.KingOnTable[i].KingThinking[0].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[0].Thinking));
                                Dummy.KingOnTable[i].KingThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 6, false);
                            }

                        }
                    }
                    catch (Exception t)
                    {
                        Log(t);
                        Dummy.KingOnTable[i] = null;
                    }
                }
            }
            else
            {
                for (i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        if (SolderesOnTable[i] == null)
                            continue;
                        ii = SolderesOnTable[i].Row;
                        jj = SolderesOnTable[i].Column;
                        Table = SolderesOnTable[i].Table;
                        Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);

                        {
                            for (j = 0; j < AllDraw.SodierMovments; j++)
                            {
                                Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingBegin = true;
                                Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingFinished = false;
                                Dummy.SolderesOnTable[i].SoldierThinking[0].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[0].Thinking));
                                Dummy.SolderesOnTable[i].SoldierThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 1, false);

                            }
                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.SolderesOnTable[i] = null;
                        Log(t);
                    }
                }
                for (i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {
                        if (ElephantOnTable[i] == null)
                            continue;
                        ii = ElephantOnTable[i].Row;
                        jj = ElephantOnTable[i].Column;
                        Table = ElephantOnTable[i].Table;
                        Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);

                        {
                            for (j = 0; j < AllDraw.ElefantMovments; j++)
                            {
                                Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingBegin = true;
                                Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingFinished = false;
                                Dummy.ElephantOnTable[i].ElefantThinking[0].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[0].Thinking));
                                Dummy.ElephantOnTable[i].ElefantThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 2, false);
                            }
                        }
                    }

                    catch (Exception t)
                    {
                        Dummy.ElephantOnTable[i] = null;
                        Log(t);
                    }
                }


                for (i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        if (HoursesOnTable[i] == null)
                            continue;
                        ii = HoursesOnTable[i].Row;
                        jj = HoursesOnTable[i].Column;
                        Table = HoursesOnTable[i].Table;
                        Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                        {
                            for (j = 0; j < AllDraw.HourseMovments; j++)
                            {
                                Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingBegin = true;
                                Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingFinished = false;
                                Dummy.HoursesOnTable[i].HourseThinking[0].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[0].Thinking));
                                Dummy.HoursesOnTable[i].HourseThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 3, false);
                            }

                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.HoursesOnTable[i] = null;
                        Log(t);
                    }
                }

                for (i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {
                        if (BridgesOnTable[i] == null)
                            continue;
                        ii = BridgesOnTable[i].Row;
                        jj = BridgesOnTable[i].Column;
                        Table = BridgesOnTable[i].Table;
                        Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                        {
                            for (j = 0; j < AllDraw.BridgeMovments; j++)
                            {
                                Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingBegin = true;
                                Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingFinished = false;
                                Dummy.BridgesOnTable[i].BridgeThinking[0].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[0].Thinking));
                                Dummy.BridgesOnTable[i].BridgeThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 4, false);
                            }

                        }
                    }
                    catch (Exception t)
                    {
                        Dummy.BridgesOnTable[i] = null;
                        Log(t);
                    }
                }


                for (i = MinisterMidle; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {
                        if (MinisterOnTable[i] == null)
                            continue;
                        ii = MinisterOnTable[i].Row;
                        jj = MinisterOnTable[i].Column;
                        Table = MinisterOnTable[i].Table;
                        Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);


                        {
                            for (j = 0; j < AllDraw.MinisterMovments; j++)
                            {
                                Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingBegin = true;
                                Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingFinished = false;
                                Dummy.MinisterOnTable[i].MinisterThinking[0].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[0].Thinking));
                                Dummy.MinisterOnTable[i].MinisterThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 5, false);
                            }

                        }

                    }
                    catch (Exception t)
                    {
                        Dummy.MinisterOnTable[i] = null;
                        Log(t);
                    }
                }

                for (i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                {
                    try
                    {
                        if (KingOnTable[i] == null)
                            continue;
                        ii = KingOnTable[i].Row;
                        jj = KingOnTable[i].Column;
                        Table = KingOnTable[i].Table;
                        Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                        {
                            for (j = 0; j < AllDraw.KingMovments; j++)
                            {
                                Dummy.KingOnTable[i].KingThinking[0].ThinkingBegin = true;
                                Dummy.KingOnTable[i].KingThinking[0].ThinkingFinished = false;
                                Dummy.KingOnTable[i].KingThinking[0].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[0].Thinking));
                                Dummy.KingOnTable[i].KingThinking[0].t.Start();
                                Wait(Dummy, i, j, 0, 6, false);
                            }

                        }
                    }
                    catch (Exception t)
                    {
                        Log(t);
                        Dummy.KingOnTable[i] = null;
                    }
                }

            }

            if (AllDraw.DeptFirstSearch)
            {
                AllDraw AdumnmyConstructed = Dummy.CopyRemeiningItems(this, Order * -1);
                if (ADraw != null)
                    this.ADraw.Clear();
                else
                    this.ADraw = new List<AllDraw>();
                this.ADraw.Add(Dummy);
            }
            else
            {
                if (ADraw != null)
                    this.ADraw = new List<AllDraw>();
                else
                    this.ADraw.Clear();
                this.ADraw.Add(Dummy);
            }

        }
        //Rearrange AllDraw Object Content.
        public void SetRowColumn(int index)
        {
            try
            {
                Move = 0;
                //Intiate Dummy Variables.
                int So1 = 0;
                int So2 = AllDraw.SodierMidle;
                int El1 = 0;
                int El2 = AllDraw.ElefantMidle;
                int Ho1 = 0;
                int Ho2 = AllDraw.HourseMidle;
                int Br1 = 0;
                int Br2 = AllDraw.BridgeMidle;
                int Mi1 = 0;
                int Mi2 = AllDraw.MinisterMidle;
                int Ki1 = 0;
                int Ki2 = AllDraw.KingMidle;
                //Wen Conversion Occured.
                //if (AllDraw.SodierConversionOcuured)
                {
                    //A = new List<AllDraw>();
                    SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
                    for (int i = 0; i < AllDraw.SodierHigh; i++)
                        SolderesOnTable[i] = new DrawSoldier();
                    ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
                    for (int i = 0; i < AllDraw.ElefantHigh; i++)
                        ElephantOnTable[i] = new DrawElefant();
                    HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
                    for (int i = 0; i < AllDraw.HourseHight; i++)
                        HoursesOnTable[i] = new DrawHourse();
                    BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
                    for (int i = 0; i < AllDraw.BridgeHigh; i++)
                        BridgesOnTable[i] = new DrawBridge();
                    MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
                    for (int i = 0; i < AllDraw.MinisterHigh; i++)
                        MinisterOnTable[i] = new DrawMinister();
                    KingOnTable = new DrawKing[AllDraw.KingHigh];
                    for (int i = 0; i < AllDraw.KingHigh; i++)
                        KingOnTable[i] = new DrawKing();
                    AllDraw.SodierConversionOcuured = false;

                }
                //When Table Exist.
                if (TableList.Count > 0)
                {
                    //For Every Table Things.
                    for (int Column = 0; Column < 8; Column++)
                        for (int Row = 0; Row < 8; Row++)
                        {
                            //When Things are Soldiers.
                            if (System.Math.Abs(this.TableList[index][Row, Column]) == 1)
                            {
                                //Determine Color
                                Color a;

                                if (this.TableList[index][Row, Column] > 0)
                                    a = Color.Gray;
                                else
                                    a = Color.Brown;
                                //When Color is Gray. 
                                if (a == Color.Gray)
                                {
                                    try
                                    {
                                        //When Solders ate current location differs add move.
                                        try
                                        {
                                            if (SolderesOnTable[So1].Row != Row || SolderesOnTable[So1].Column != Column)
                                                Move++;
                                        }
                                        catch (Exception t) { Log(t); }
                                        //Construct Soder Gray.
                                        SolderesOnTable[So1] = new DrawSoldier(Row, Column, a, this.TableList[index], 1, false, So1);
                                        //Increase So1.
                                        So1++;
                                        if (So1 > SodierMidle)
                                        {
                                            SodierMidle++;
                                            SodierHigh++;
                                        }

                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                                //When Color is Brown
                                else
                                {
                                    try
                                    {
                                        //When Solders ate current location differs add move.
                                        try
                                        {
                                            if (SolderesOnTable[So2].Row != Row ||
                                            SolderesOnTable[So2].Column != Column)
                                                Move++;
                                        }
                                        catch (Exception t) { Log(t); }
                                        //Construct Soldeir Brown.
                                        SolderesOnTable[So2] = new DrawSoldier(Row, Column, a, this.TableList[index], -1, false, So2);
                                        //Increase So2.
                                        So2++;
                                        if (So2 > SodierHigh)
                                            SodierHigh++;
                                    }
                                    catch (Exception t)
                                    {
                                        Log(t);
                                    }
                                }
                            }
                            else //Reamaining are the same and correct.
                                if (System.Math.Abs(this.TableList[index][Row, Column]) == 2)
                                {
                                    Color a;

                                    if (this.TableList[index][Row, Column] > 0)
                                        a = Color.Gray;
                                    else
                                        a = Color.Brown;
                                    if (a == Color.Gray)
                                    {
                                        try
                                        {
                                            try
                                            {
                                                if (ElephantOnTable[El1].Row != Row ||
                                                    ElephantOnTable[El1].Column != Column)
                                                    Move++;
                                            }
                                            catch (Exception t) { Log(t); }
                                            ElephantOnTable[El1] = new DrawElefant(Row, Column, a, this.TableList[index], 1, false, El1);
                                            El1++;
                                            if (El1 > ElefantMidle)
                                            {
                                                ElefantMidle++;
                                                ElefantHigh++;
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                    else
                                    {
                                        try
                                        {
                                            try
                                            {
                                                if (ElephantOnTable[El2].Row != Row ||
                                                    ElephantOnTable[El2].Column != Column)
                                                    Move++;
                                            }
                                            catch (Exception t) { Log(t); }
                                            ElephantOnTable[El2] = new DrawElefant(Row, Column, a, this.TableList[index], -1, false, El2);
                                            El2++;
                                            if (El2 > ElefantHigh)
                                                ElefantHigh++;

                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }

                                    }
                                }
                                else
                                    if (System.Math.Abs(this.TableList[index][Row, Column]) == 3)
                                    {
                                        Color a;

                                        if (this.TableList[index][Row, Column] > 0)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        if (a == Color.Gray)
                                        {

                                            try
                                            {
                                                try
                                                {
                                                    if (HoursesOnTable[Ho1].Row != Row ||
                                                        HoursesOnTable[Ho1].Column != Column)
                                                        Move++;
                                                }
                                                catch (Exception t) { Log(t); }
                                                HoursesOnTable[Ho1] = new DrawHourse(Row, Column, a, this.TableList[index], 1, false, Ho1);
                                                Ho1++;
                                                if (Ho1 > HourseMidle)
                                                {
                                                    HourseMidle++;
                                                    HourseHight++;
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        else
                                        {
                                            try
                                            {
                                                try
                                                {
                                                    if (HoursesOnTable[Ho2].Row != Row |
                                                        HoursesOnTable[Ho2].Column != Column)
                                                        Move++;
                                                }
                                                catch (Exception t) { Log(t); }
                                                HoursesOnTable[Ho2] = new DrawHourse(Row, Column, a, this.TableList[index], -1, false, Ho2);
                                                Ho2++;
                                                if (Ho2 > HourseHight)
                                                    HourseHight++;
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                    }
                                    else
                                        if (System.Math.Abs(this.TableList[index][Row, Column]) == 4)
                                        {
                                            Color a;

                                            if (this.TableList[index][Row, Column] > 0)
                                                a = Color.Gray;
                                            else
                                                a = Color.Brown;
                                            if (a == Color.Gray)
                                            {

                                                try
                                                {
                                                    try
                                                    {
                                                        if (BridgesOnTable[Br1].Row != Row ||
                                                            BridgesOnTable[Br1].Column != Column)
                                                            Move++;
                                                    }
                                                    catch (Exception t) { Log(t); }
                                                    BridgesOnTable[Br1] = new DrawBridge(Row, Column, a, this.TableList[index], 1, false, Br1);
                                                    Br1++;
                                                    if (Br1 > BridgeMidle)
                                                    {
                                                        BridgeMidle++;
                                                        BridgeHigh++;
                                                    }

                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    try
                                                    {
                                                        if (BridgesOnTable[Br2].Row != Row ||
                                                            BridgesOnTable[Br2].Column != Column)
                                                            Move++;
                                                    }
                                                    catch (Exception t) { Log(t); } BridgesOnTable[Br2] = new DrawBridge(Row, Column, a, this.TableList[index], -1, false, Br2);
                                                    Br2++;
                                                    if (Br2 > BridgeHigh)
                                                        BridgeHigh++;

                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        else
                                            if (System.Math.Abs(this.TableList[index][Row, Column]) == 5)
                                            {
                                                Color a;

                                                if (this.TableList[index][Row, Column] > 0)
                                                    a = Color.Gray;
                                                else
                                                    a = Color.Brown;
                                                if (a == Color.Gray)
                                                {

                                                    try
                                                    {
                                                        try
                                                        {
                                                            if (MinisterOnTable[Mi1].Row != Row ||
                                                                MinisterOnTable[Mi1].Column != Column)
                                                                Move++;
                                                        }
                                                        catch (Exception t) { Log(t); } MinisterOnTable[Mi1] = new DrawMinister(Row, Column, a, this.TableList[index], 1, false, Mi1);
                                                        Mi1++;
                                                        if (Mi1 > MinisterMidle)
                                                        {
                                                            MinisterMidle++;
                                                            MinisterHigh++;
                                                        }
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }

                                                }
                                                else
                                                {
                                                    try
                                                    {
                                                        try
                                                        {
                                                            if (MinisterOnTable[Mi2].Row != Row ||
                                                                MinisterOnTable[Mi2].Column != Column)
                                                                Move++;
                                                        }
                                                        catch (Exception t) { Log(t); } MinisterOnTable[Mi2] = new DrawMinister(Row, Column, a, this.TableList[index], -1, false, Mi2);
                                                        Mi2++;
                                                        if (Mi2 > MinisterHigh)
                                                            MinisterHigh++;

                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }
                                                }
                                            }
                                            else
                                                if (System.Math.Abs(this.TableList[index][Row, Column]) == 6)
                                                {
                                                    Color a;

                                                    if (this.TableList[index][Row, Column] > 0)
                                                        a = Color.Gray;
                                                    else
                                                        a = Color.Brown;
                                                    if (a == Color.Gray)
                                                    {

                                                        try
                                                        {
                                                            try
                                                            {
                                                                if (KingOnTable[Ki1].Row != Row ||
                                                                    KingOnTable[Ki1].Column != Column)
                                                                    Move++;

                                                            }
                                                            catch (Exception t) { Log(t); } KingOnTable[Ki1] = new DrawKing(Row, Column, a, this.TableList[index], 1, false, Ki1);
                                                            Ki1++;
                                                            if (Ki1 > KingMidle)
                                                            {
                                                                KingMidle++;
                                                                KingHigh++;

                                                            }

                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        try
                                                        {
                                                            try
                                                            {
                                                                if (KingOnTable[Ki2].Row != Row ||
                                                                    KingOnTable[Ki2].Column != Column)
                                                                    Move++;
                                                            }
                                                            catch (Exception t) { Log(t); } KingOnTable[Ki2] = new DrawKing(Row, Column, a, this.TableList[index], -1, false, Ki2);
                                                            Ki2++;
                                                            if (Ki2 > KingHigh)
                                                                KingHigh++;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                        }
                                                    }

                                                }
                        }
                    for (int i = So1; i < AllDraw.SodierMidle; i++)
                        SolderesOnTable[i] = null;

                    for (int i = So2; i < AllDraw.SodierHigh; i++)
                        SolderesOnTable[i] = null;

                    for (int i = El1; i < AllDraw.ElefantMidle; i++)
                        ElephantOnTable[i] = null;

                    for (int i = El2; i < AllDraw.ElefantHigh; i++)
                        ElephantOnTable[i] = null;

                    for (int i = Ho1; i < AllDraw.HourseMidle; i++)
                        HoursesOnTable[i] = null;

                    for (int i = Ho2; i < AllDraw.HourseHight; i++)
                        HoursesOnTable[i] = null;

                    for (int i = Br1; i < AllDraw.BridgeMidle; i++)
                        BridgesOnTable[i] = null;

                    for (int i = Br2; i < AllDraw.BridgeHigh; i++)
                        BridgesOnTable[i] = null;

                    for (int i = Mi1; i < AllDraw.MinisterMidle; i++)
                        MinisterOnTable[i] = null;

                    for (int i = Mi2; i < AllDraw.MinisterHigh; i++)
                        MinisterOnTable[i] = null;

                    for (int i = Ki1; i < AllDraw.KingMidle; i++)
                        KingOnTable[i] = null;

                    for (int i = Ki2; i < AllDraw.KingHigh; i++)
                        KingOnTable[i] = null;

                }
                /*  AllDraw.RedrawTable = true;
                  AllDraw.SodierMidle = So1;
                  AllDraw.SodierHigh = So2;
                  AllDraw.ElefantMidle = El1;
                  AllDraw.ElefantHigh = El2;
                  AllDraw.HourseMidle = Ho1;
                  AllDraw.HourseHight = Ho2;
                  AllDraw.BridgeMidle = Br1;
                  AllDraw.BridgeHigh = Br2;
                  AllDraw.MinisterMidle = Mi1;
                  AllDraw.MinisterHigh = Mi2;
                  AllDraw.KingMidle = Ki1;
                  AllDraw.KingHigh = Ki2;*/

            }
            catch (Exception t)
            {
                Log(t);
            }
        }
        //Dept First Huristic Method.
        public int[,] HuristicDeptSearch(int Depti, List<AllDraw> A, Color a, ref double Less, int Order, bool CurrentTableHuristic)
        {
            if (Depti > MaxDept)
                return TableHuristic;
            Depti++;
            int i = 0, j = 0;
            bool Act = false;
            //When There is Some A.Count
            //if (A.Count > 0)
            {
                //FormatException Every BridgeMovments.
                //for (int ii = 0; ii < A.Count; ii++)
                {
                    if (Order == 1)
                    {
                        //For Every Soldeir
                        for (i = 0; i < AllDraw.SodierMidle; i++)
                        {


                            //For Every Soldier Movments Dept.
                            for (int k = 0; k < AllDraw.SodierMovments; k++)
                                //When There is an Movment in such situation.
                                try
                                {
                                    for (j = 0; SolderesOnTable[i] != null && SolderesOnTable[i] != null && SolderesOnTable[i].SoldierThinking[k] != null && SolderesOnTable[i].SoldierThinking[k] != null && j < SolderesOnTable[i].SoldierThinking[k].TableListSolder.Count; j++)
                                    {
                                        //if (Dept == 0)
                                        {
                                            try
                                            {
                                                //For Penalty Reagrad Mechanisam of Current Kish Mate Current Movments.

                                                if (FormRefrigtz.OrderPlate == Order)
                                                    if (SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0)
                                                    {
                                                        Less = -200000000;
                                                        continue;
                                                    }

                                                //When There is No Movments in Such Order Enemy continue.
                                                if (Order != FormRefrigtz.OrderPlate)
                                                    if (SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                                        continue;
                                                //When There is greater Huristic Movments.
                                                if (SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                                {
                                                    //if (KishG || KishB)
                                                    //{
                                                    //retrive table of current huristic.
                                                    int[,] TableS = SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                                    int[,] TableSS = SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];

                                                    //checked for Legal Movments ArgumentOutOfRangeException curnt game.
                                                    if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                    {
                                                        try
                                                        {
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;

                                                        }

                                                    }
                                                    //When there is not Penalty regard mechanism.
                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        //If there iss kish or kshachamaz Order.
                                                        if ((new ChessRules(1, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            //When Orderis Gray.
                                                            if (Order == 1)
                                                            {
                                                                //Continue When is kish KishAchmaz and DeptFirstSearch .
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                //Continue when KishBrown and DeptFirstSearch. 
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        // }
                                                        else
                                                        {

                                                        }
                                                        //When Order is gray.
                                                        if (Order == 1)
                                                        {
                                                            //When KishGrayAchmaz and There is not DeptFirst search.
                                                            if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                            {
                                                                //Predic Search.
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;
                                                                else
                                                                {
                                                                    Act = true;
                                                                    Less = SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];

                                                                    continue;


                                                                }

                                                            }
                                                        }
                                                        else
                                                        {
                                                            //When Order is Bromn and there is not DeptFirstSearch.
                                                            if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                            {
                                                                //Prdedict Kish.
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;

                                                            }
                                                        }
                                                    }
                                                    RW1 = i;
                                                    CL1 = k;
                                                    Ki1 = j;

                                                    if (Depti == 1)
                                                    {
                                                        //Set Table and Huristic Value and Syntax.
                                                        Act = true;
                                                        FormRefrigtz.LastRow = SolderesOnTable[i].SoldierThinking[k].Row;
                                                        FormRefrigtz.LastColumn = SolderesOnTable[i].SoldierThinking[k].Column;

                                                        Less = SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];


                                                        TableHuristic = SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                                        bool Hit = false;
                                                        if (SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);


                                                        ThingsConverter.ActOfClickEqualTow = true;
                                                        SolderesOnTable[i].ConvertOperation(SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], a, SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, false, i);
                                                        int Sign = 1;
                                                        if (a == Color.Brown)
                                                            Sign = -1;
                                                        //If there is Soldier Convert.
                                                        if (SolderesOnTable[i].Convert)
                                                        {
                                                            Hit = false;
                                                            if (SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                                Hit = true;
                                                            if (Order == 1)
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);
                                                            else
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);

                                                            if (SolderesOnTable[i].ConvertedToMinister)
                                                                TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 5 * Sign;
                                                            else if (SolderesOnTable[i].ConvertedToBridge)
                                                                TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 4 * Sign;
                                                            else if (SolderesOnTable[i].ConvertedToHourse)
                                                                TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 3 * Sign;
                                                            else if (SolderesOnTable[i].ConvertedToElefant)
                                                                TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 2 * Sign;
                                                            TableList.Clear();
                                                            TableList.Add(TableHuristic);
                                                            if (A.Count > 1)
                                                                SetRowColumn(0);
                                                            TableList.Clear();

                                                        }
                                                    }


                                                }
                                                else
                                                {
                                                    //Set Table and Huristic Value and Syntax.
                                                    try
                                                    {
                                                        if (Depti == 1)
                                                        {
                                                            Act = true;
                                                            FormRefrigtz.LastRow = SolderesOnTable[RW1].SoldierThinking[CL1].Row;
                                                            FormRefrigtz.LastColumn = SolderesOnTable[RW1].SoldierThinking[CL1].Column;

                                                            Less = SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][0] + SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][1] + SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][2] + SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][3];


                                                            TableHuristic = SolderesOnTable[RW1].SoldierThinking[CL1].TableListSolder[Ki1];
                                                            bool Hit = false;
                                                            if (SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1] > 0)
                                                                Hit = true;
                                                            if (Order == 1)
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, false);
                                                            else
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, false);


                                                            ThingsConverter.ActOfClickEqualTow = true;
                                                            SolderesOnTable[RW1].ConvertOperation(SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], a, SolderesOnTable[RW1].SoldierThinking[CL1].TableListSolder[Ki1], Order, false, i);
                                                            int Sign = 1;
                                                            if (a == Color.Brown)
                                                                Sign = -1;
                                                            //If there is Soldier Convert.
                                                            if (SolderesOnTable[RW1].Convert)
                                                            {
                                                                Hit = false;
                                                                if (SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1] > 0)
                                                                    Hit = true;
                                                                if (Order == 1)
                                                                    SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, true);
                                                                else
                                                                    SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, true);

                                                                if (SolderesOnTable[RW1].ConvertedToMinister)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 5 * Sign;
                                                                else if (SolderesOnTable[RW1].ConvertedToBridge)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 4 * Sign;
                                                                else if (SolderesOnTable[RW1].ConvertedToHourse)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 3 * Sign;
                                                                else if (SolderesOnTable[RW1].ConvertedToElefant)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 2 * Sign;
                                                                TableList.Clear();
                                                                TableList.Add(TableHuristic);
                                                                if (A.Count > 1)
                                                                    SetRowColumn(0);
                                                                TableList.Clear();

                                                            }
                                                        }
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }
                                                }

                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        //else
                                        {
                                            try
                                            {
                                                for (int p = 0; p < SolderesOnTable[i].SoldierThinking[0].Dept.Count; p++)
                                                    SolderesOnTable[i].SoldierThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);

                                            }

                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                    }

                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }
                        //Do For Remaining Objects same as Soldeir Documentation.
                        for (i = 0; i < AllDraw.ElefantMidle; i++)
                        {
                            for (int k = 0; k < AllDraw.ElefantMovments; k++)
                                try
                                {
                                    for (j = 0; ElephantOnTable[i] != null && ElephantOnTable[i] != null && ElephantOnTable[i].ElefantThinking[k] != null && ElephantOnTable[i].ElefantThinking[k] != null && j < ElephantOnTable[i].ElefantThinking[k].TableListElefant.Count; j++)
                                    {
                                        //if (Depti == 1)
                                        {
                                            try
                                            {

                                                if (FormRefrigtz.OrderPlate == Order)
                                                    if (ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0)
                                                    {
                                                        Less = -200000000;
                                                        continue;
                                                    }

                                                if (Order != FormRefrigtz.OrderPlate)
                                                    if (ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                                        continue;
                                                if (ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                                {
                                                    //if (KishG || KishB)
                                                    //{

                                                    int[,] TableS = ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                                    int[,] TableSS = ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                                    if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                    {
                                                        try
                                                        {
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;

                                                        }


                                                    }
                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        if ((new ChessRules(2, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            if (Order == 1)
                                                            {
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        else
                                                        {

                                                        }

                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;
                                                                else
                                                                {
                                                                    Act = true;
                                                                    Less = ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];

                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;


                                                            }
                                                        }

                                                    }
                                                    RW2 = i;
                                                    CL2 = k;
                                                    Ki2 = j;

                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 2, ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -2, ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = ElephantOnTable[i].ElefantThinking[k].Row;
                                                        FormRefrigtz.LastColumn = ElephantOnTable[i].ElefantThinking[k].Column;

                                                        Act = true;
                                                        Less = ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];
                                                        TableHuristic = ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                                    }
                                                }
                                                else
                                                {

                                                    try
                                                    {
                                                        if (Depti == 1)
                                                        {
                                                            bool Hit = false;
                                                            if (ElephantOnTable[RW2].ElefantThinking[CL2].HitNumberElefant[Ki2] > 0)
                                                                Hit = true;
                                                            if (Order == 1)
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 2, ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][1], ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][0], Hit, ElephantOnTable[RW2].ElefantThinking[CL2].HitNumberElefant[Ki2], ChessRules.BridgeActBrown, false);
                                                            else
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -2, ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][1], ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][0], Hit, ElephantOnTable[RW2].ElefantThinking[CL2].HitNumberElefant[Ki2], ChessRules.BridgeActBrown, false);

                                                            FormRefrigtz.LastRow = ElephantOnTable[RW2].ElefantThinking[CL2].Row;
                                                            FormRefrigtz.LastColumn = ElephantOnTable[RW2].ElefantThinking[CL2].Column;

                                                            Act = true;
                                                            Less = ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][0] + ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][1] + ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][2] + ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][3];
                                                            TableHuristic = ElephantOnTable[RW2].ElefantThinking[CL2].TableListElefant[Ki2];
                                                        }
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }
                                                }

                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        //else
                                        {
                                            try
                                            {
                                                for (int p = 0; p < ElephantOnTable[i].ElefantThinking[0].Dept.Count; p++)
                                                    ElephantOnTable[i].ElefantThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);

                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                        for (i = 0; i < AllDraw.HourseHight; i++)
                        {

                            for (int k = 0; k < AllDraw.HourseMovments; k++)
                                try
                                {
                                    for (j = 0; HoursesOnTable[i] != null && HoursesOnTable[i] != null && HoursesOnTable[i].HourseThinking[k] != null && HoursesOnTable[i].HourseThinking[k] != null && j < HoursesOnTable[i].HourseThinking[k].TableListHourse.Count; j++)
                                    {
                                        //if (Depti == 1)
                                        {
                                            try
                                            {

                                                if (FormRefrigtz.OrderPlate == Order)
                                                    if (HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0)
                                                    {
                                                        Less = -200000000;
                                                        continue;
                                                    }

                                                if (Order != FormRefrigtz.OrderPlate)
                                                    if (HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)
                                                        continue;
                                                if (HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)
                                                {
                                                    int[,] TableS = HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                                    int[,] TableSS = HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                                    {
                                                        if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                        {
                                                            try
                                                            {
                                                                if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                    continue;
                                                            }
                                                            catch (Exception t)
                                                            {
                                                                Log(t);
                                                                if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                    continue;

                                                            }

                                                        }
                                                        if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                        {
                                                            if ((new ChessRules(3, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                            {
                                                                if (Order == 1)
                                                                {
                                                                    if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                        continue;
                                                                }
                                                                else
                                                                {
                                                                    if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                        continue;
                                                                }
                                                            }
                                                            else
                                                            {

                                                            }
                                                        }


                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;

                                                            }
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;
                                                                else
                                                                {
                                                                    Act = true;
                                                                    Less = HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                                    continue;
                                                                }

                                                            }
                                                        }
                                                    }
                                                    RW3 = i;
                                                    CL3 = k;
                                                    Ki3 = j;

                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 3, HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -3, HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                                        FormRefrigtz.LastRow = HoursesOnTable[i].HourseThinking[k].Row;
                                                        FormRefrigtz.LastColumn = HoursesOnTable[i].HourseThinking[k].Column;

                                                        Act = true;
                                                        Less = HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                        TableHuristic = HoursesOnTable[i].HourseThinking[k].TableListHourse[j];

                                                    }

                                                }
                                                else
                                                {
                                                    try
                                                    {
                                                        if (Depti == 1)
                                                        {
                                                            bool Hit = false;
                                                            if (HoursesOnTable[RW3].HourseThinking[CL3].HitNumberHourse[Ki3] > 0)
                                                                Hit = true;
                                                            if (Order == 1)
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 3, HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][1], HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][0], Hit, HoursesOnTable[RW3].HourseThinking[CL3].HitNumberHourse[Ki3], ChessRules.BridgeActBrown, false);
                                                            else
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -3, HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][1], HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][0], Hit, HoursesOnTable[RW3].HourseThinking[CL3].HitNumberHourse[Ki3], ChessRules.BridgeActBrown, false);
                                                            FormRefrigtz.LastRow = HoursesOnTable[RW3].HourseThinking[CL3].Row;
                                                            FormRefrigtz.LastColumn = HoursesOnTable[RW3].HourseThinking[CL3].Column;

                                                            Act = true;
                                                            Less = HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][0] + HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][1] + HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][2] + HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][3];
                                                            TableHuristic = HoursesOnTable[RW3].HourseThinking[CL3].TableListHourse[Ki3];
                                                        }
                                                    }
                                                    catch (Exception t)
                                                    { Log(t); }
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        // else
                                        {
                                            try
                                            {
                                                for (int p = 0; p < HoursesOnTable[i].HourseThinking[0].Dept.Count; p++)
                                                    HoursesOnTable[i].HourseThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);

                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }


                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }

                        for (i = 0; i < AllDraw.BridgeMidle; i++)
                        {
                            for (int k = 0; k < AllDraw.BridgeMovments; k++)
                                try
                                {
                                    for (j = 0; BridgesOnTable[i] != null && BridgesOnTable[i] != null && BridgesOnTable[i].BridgeThinking[k] != null && BridgesOnTable[i].BridgeThinking[k] != null && j < BridgesOnTable[i].BridgeThinking[k].TableListBridge.Count; j++)
                                    {
                                        //if (Depti == 1)
                                        {
                                            try
                                            {

                                                if (FormRefrigtz.OrderPlate == Order)
                                                    if (BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0)
                                                    {
                                                        Less = -200000000;
                                                        continue;
                                                    }
                                                if (Order != FormRefrigtz.OrderPlate)
                                                    if (BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                                        continue;
                                                if (BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                                {
                                                    int[,] TableS = BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                                    int[,] TableSS = BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                                    if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                    {
                                                        try
                                                        {
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;

                                                        }


                                                    }
                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        if ((new ChessRules(4, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            if (Order == 1)
                                                            {
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        else
                                                        {

                                                        }

                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.BridgesOnTable[i].Row, APredict.BridgesOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;

                                                            }
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(BridgesOnTable[i].Row, BridgesOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;
                                                                else
                                                                {
                                                                    Act = true;
                                                                    Less = BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];

                                                                    continue;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    RW4 = i;
                                                    CL4 = k;
                                                    Ki4 = j;

                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 4, BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -4, BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = BridgesOnTable[i].BridgeThinking[k].Row;
                                                        FormRefrigtz.LastColumn = BridgesOnTable[i].BridgeThinking[k].Column;

                                                        Act = true;
                                                        Less = BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];
                                                        TableHuristic = BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];

                                                    }
                                                }
                                                else
                                                {
                                                    try
                                                    {
                                                        if (Depti == 1)
                                                        {
                                                            bool Hit = false;
                                                            if (BridgesOnTable[RW4].BridgeThinking[CL4].HitNumberBridge[Ki4] > 0)
                                                                Hit = true;
                                                            if (Order == 1)
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 4, BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][1], BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][0], Hit, BridgesOnTable[RW4].BridgeThinking[CL4].HitNumberBridge[Ki4], ChessRules.BridgeActBrown, false);
                                                            else
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -4, BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][1], BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][0], Hit, BridgesOnTable[RW4].BridgeThinking[CL4].HitNumberBridge[Ki4], ChessRules.BridgeActBrown, false);

                                                            FormRefrigtz.LastRow = BridgesOnTable[RW4].BridgeThinking[CL4].Row;
                                                            FormRefrigtz.LastColumn = BridgesOnTable[RW4].BridgeThinking[CL4].Column;

                                                            Act = true;
                                                            Less = BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][0] + BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][1] + BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][2] + BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][3];
                                                            TableHuristic = BridgesOnTable[RW4].BridgeThinking[CL4].TableListBridge[Ki4];
                                                        }
                                                    }
                                                    catch (Exception t) { }
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        //else
                                        {
                                            try
                                            {
                                                for (int p = 0; p < BridgesOnTable[i].BridgeThinking[0].Dept.Count; p++)
                                                    BridgesOnTable[i].BridgeThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }


                        for (i = 0; i < AllDraw.MinisterMidle; i++)
                        {

                            for (int k = 0; k < AllDraw.MinisterMovments; k++)
                                try
                                {
                                    for (j = 0; MinisterOnTable[i] != null && MinisterOnTable[i] != null && MinisterOnTable[i].MinisterThinking[k] != null && MinisterOnTable[i].MinisterThinking[k] != null && j < MinisterOnTable[i].MinisterThinking[k].TableListMinister.Count; j++)
                                    {
                                        //if (Depti == 1)
                                        {

                                            if (FormRefrigtz.OrderPlate == Order)
                                                if (MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                                {
                                                    Less = -200000000;
                                                    continue;
                                                }
                                            if (Order != FormRefrigtz.OrderPlate)
                                                if (MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                                    continue;
                                            if (MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                            {
                                                int[,] TableS = MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                                int[,] TableSS = MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;

                                                    }

                                                }
                                                {
                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        if ((new ChessRules(5, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            if (Order == 1)
                                                            {
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        else
                                                        {

                                                        }
                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;

                                                        }

                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            if (null == APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false))
                                                                continue;

                                                        }
                                                    }

                                                }
                                                RW5 = i;
                                                CL5 = k;
                                                Ki5 = j;

                                                if (Depti == 1)
                                                {
                                                    bool Hit = false;
                                                    if (MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 5, MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -5, MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                                    FormRefrigtz.LastRow = MinisterOnTable[i].MinisterThinking[k].Row;
                                                    FormRefrigtz.LastColumn = MinisterOnTable[i].MinisterThinking[k].Column;

                                                    Act = true;
                                                    Less = MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3];
                                                    TableHuristic = MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];

                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (MinisterOnTable[RW5].MinisterThinking[CL5].HitNumberMinister[Ki5] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 5, MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][1], MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][0], Hit, MinisterOnTable[RW5].MinisterThinking[CL5].HitNumberBridge[Ki5], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -5, MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][1], MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][0], Hit, MinisterOnTable[RW5].MinisterThinking[CL5].HitNumberBridge[Ki5], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = MinisterOnTable[RW5].MinisterThinking[CL5].Row;
                                                        FormRefrigtz.LastColumn = MinisterOnTable[RW5].MinisterThinking[CL5].Column;

                                                        Act = true;
                                                        Less = MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][0] + MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][1] + MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][2] + MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][3];
                                                        TableHuristic = MinisterOnTable[RW5].MinisterThinking[CL5].TableListMinister[Ki5];
                                                    }
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        // else
                                        {
                                            try
                                            {
                                                for (int p = 0; p < MinisterOnTable[i].MinisterThinking[0].Dept.Count; p++)
                                                    MinisterOnTable[i].MinisterThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);

                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }

                        for (i = 0; i < AllDraw.KingMidle; i++)
                        {
                            for (int k = 0; k < AllDraw.KingMovments; k++)
                                try
                                {
                                    for (j = 0; KingOnTable[i] != null && KingOnTable[i] != null && KingOnTable[i].KingThinking[k] != null && KingOnTable[i].KingThinking[k] != null && j < KingOnTable[i].KingThinking[k].TableListKing.Count; j++)
                                    {
                                        //if (Depti == 1)
                                        {
                                            try
                                            {
                                                if (FormRefrigtz.OrderPlate == Order)
                                                    if (KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                                    {
                                                        Less = -200000000;
                                                        continue;
                                                    } if (Order != FormRefrigtz.OrderPlate)
                                                    if (KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                                        continue;
                                                if (KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                                {
                                                    int[,] TableS = KingOnTable[i].KingThinking[k].TableListKing[j];
                                                    int[,] TableSS = KingOnTable[i].KingThinking[k].TableListKing[j];
                                                    if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                    {
                                                        try
                                                        {
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;

                                                        }
                                                    }
                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        if ((new ChessRules(6, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            if (Order == 1)
                                                            {
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        else
                                                        {

                                                        }

                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;

                                                            }
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                            {
                                                                Color B;
                                                                if (a == Color.Gray)
                                                                    B = Color.Brown;
                                                                else
                                                                    B = Color.Gray;
                                                                APredict.TableList.Clear();
                                                                APredict.TableList.Add(TableS);
                                                                APredict.SetRowColumn(0);
                                                                TableHuristic = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                                if (TableHuristic == null)
                                                                    continue;
                                                                else
                                                                {
                                                                    Act = true;
                                                                    Less = KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                                    continue;
                                                                }

                                                            }
                                                        }

                                                    }


                                                    RW6 = i;
                                                    CL6 = k;
                                                    Ki6 = j;

                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (KingOnTable[i].KingThinking[k].HitNumberKing[j] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 6, KingOnTable[i].KingThinking[k].RowColumnKing[j][1], KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -6, KingOnTable[i].KingThinking[k].RowColumnKing[j][1], KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = KingOnTable[i].KingThinking[k].Row;
                                                        FormRefrigtz.LastColumn = KingOnTable[i].KingThinking[k].Column;

                                                        Act = true;
                                                        Less = KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                        TableHuristic = KingOnTable[i].KingThinking[k].TableListKing[j];
                                                    }


                                                }
                                                else
                                                {
                                                    try
                                                    {
                                                        if (Depti == 1)
                                                        {
                                                            bool Hit = false;
                                                            if (KingOnTable[RW6].KingThinking[CL6].HitNumberKing[Ki6] > 0)
                                                                Hit = true;
                                                            if (Order == 1)
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 6, KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][1], KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][0], Hit, KingOnTable[RW6].KingThinking[CL6].HitNumberKing[Ki6], ChessRules.BridgeActBrown, false);
                                                            else
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -6, KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][1], KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][0], Hit, KingOnTable[RW6].KingThinking[CL6].HitNumberKing[Ki6], ChessRules.BridgeActBrown, false);

                                                            FormRefrigtz.LastRow = KingOnTable[RW6].KingThinking[CL6].Row;
                                                            FormRefrigtz.LastColumn = KingOnTable[RW6].KingThinking[CL6].Column;

                                                            Act = true;
                                                            Less = KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][0] + KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][1] + KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][2] + KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][3];
                                                            TableHuristic = KingOnTable[RW6].KingThinking[CL6].TableListKing[Ki6];
                                                        }
                                                    }
                                                    catch (Exception t)
                                                    { Log(t); }
                                                }
                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }
                                        // else
                                        {
                                            try
                                            {
                                                for (int p = 0; p < KingOnTable[i].KingThinking[0].Dept.Count; p++)
                                                    KingOnTable[i].KingThinking[0].Dept[KingOnTable[i].KingThinking[0].Dept.Count - 1].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);

                                            }
                                            catch (Exception t)
                                            {
                                                Log(t);
                                            }
                                        }

                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                    }
                    else
                    {
                        //For Every Soldeir
                        for (i = SodierMidle; i < AllDraw.SodierHigh; i++)
                        {


                            //For Every Soldier Movments Dept.
                            for (int k = 0; k < AllDraw.SodierMovments; k++)
                                //When There is an Movment in such situation.
                                try
                                {
                                    for (j = 0; SolderesOnTable[i] != null && SolderesOnTable[i] != null && SolderesOnTable[i].SoldierThinking[k] != null && SolderesOnTable[i].SoldierThinking[k] != null && j < SolderesOnTable[i].SoldierThinking[k].TableListSolder.Count; j++)
                                    {
                                        try
                                        {
                                            //For Penalty Reagrad Mechanisam of Current Kish Mate Current Movments.

                                            if (FormRefrigtz.OrderPlate == Order)
                                                if (SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0)
                                                {
                                                    Less = -200000000;
                                                    continue;
                                                }
                                            //When There is No Movments in Such Order Enemy continue.
                                            if (Order != FormRefrigtz.OrderPlate)
                                                if (SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                                    continue;
                                            //When There is greater Huristic Movments.
                                            if (SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] >= Less)
                                            {
                                                //if (KishG || KishB)
                                                //{
                                                //retrive table of current huristic.
                                                int[,] TableS = SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];

                                                //checked for Legal Movments ArgumentOutOfRangeException curnt game.
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;

                                                    }
                                                }
                                                //When there is not Penalty regard mechanism.
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    //If there iss kish or kshachamaz Order.
                                                    if ((new ChessRules(1, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        //When Orderis Gray.
                                                        if (Order == 1)
                                                        {
                                                            //Continue When is kish KishAchmaz and DeptFirstSearch .
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            //Continue when KishBrown and DeptFirstSearch. 
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    // }
                                                    else
                                                    {

                                                    }
                                                    //When Order is gray.
                                                    if (Order == 1)
                                                    {
                                                        //When KishGrayAchmaz and There is not DeptFirst search.
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            //Predic Search.
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;
                                                            else
                                                            {
                                                                Act = true;
                                                                Less = SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];

                                                                continue;


                                                            }

                                                        }
                                                    }
                                                    else
                                                    {
                                                        //When Order is Bromn and there is not DeptFirstSearch.
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            //Prdedict Kish.
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;

                                                        }
                                                    }
                                                }
                                                RW1 = i;
                                                CL1 = k;
                                                Ki1 = j;

                                                //Set Table and Huristic Value and Syntax.
                                                if (Depti == 1)
                                                {
                                                    Act = true;
                                                    FormRefrigtz.LastRow = SolderesOnTable[i].SoldierThinking[k].Row;
                                                    FormRefrigtz.LastColumn = SolderesOnTable[i].SoldierThinking[k].Column;

                                                    Less = SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];


                                                    TableHuristic = SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                                    bool Hit = false;
                                                    if (SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);


                                                    ThingsConverter.ActOfClickEqualTow = true;
                                                    SolderesOnTable[i].ConvertOperation(SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], a, SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, false, i);
                                                    int Sign = 1;
                                                    if (a == Color.Brown)
                                                        Sign = -1;
                                                    //If there is Soldier Convert.
                                                    if (SolderesOnTable[i].Convert)
                                                    {
                                                        Hit = false;
                                                        if (SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);

                                                        if (SolderesOnTable[i].ConvertedToMinister)
                                                            TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 5 * Sign;
                                                        else if (SolderesOnTable[i].ConvertedToBridge)
                                                            TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 4 * Sign;
                                                        else if (SolderesOnTable[i].ConvertedToHourse)
                                                            TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 3 * Sign;
                                                        else if (SolderesOnTable[i].ConvertedToElefant)
                                                            TableHuristic[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 2 * Sign;
                                                        TableList.Clear();
                                                        TableList.Add(TableHuristic);
                                                        if (A.Count > 1)
                                                            SetRowColumn(0);
                                                        TableList.Clear();

                                                    }

                                                }
                                                else
                                                {  //Set Table and Huristic Value and Syntax.
                                                    try
                                                    {
                                                        if (Depti == 1)
                                                        {
                                                            Act = true;
                                                            FormRefrigtz.LastRow = SolderesOnTable[RW1].SoldierThinking[CL1].Row;
                                                            FormRefrigtz.LastColumn = SolderesOnTable[RW1].SoldierThinking[CL1].Column;

                                                            Less = SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][0] + SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][1] + SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][2] + SolderesOnTable[RW1].SoldierThinking[CL1].HuristicListSolder[Ki1][3];


                                                            TableHuristic = SolderesOnTable[RW1].SoldierThinking[CL1].TableListSolder[Ki1];
                                                            bool Hit = false;
                                                            if (SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1] > 0)
                                                                Hit = true;
                                                            if (Order == 1)
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, false);
                                                            else
                                                                SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, false);


                                                            ThingsConverter.ActOfClickEqualTow = true;
                                                            SolderesOnTable[RW1].ConvertOperation(SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], a, SolderesOnTable[RW1].SoldierThinking[CL1].TableListSolder[Ki1], Order, false, i);
                                                            int Sign = 1;
                                                            if (a == Color.Brown)
                                                                Sign = -1;
                                                            //If there is Soldier Convert.
                                                            if (SolderesOnTable[RW1].Convert)
                                                            {
                                                                Hit = false;
                                                                if (SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1] > 0)
                                                                    Hit = true;
                                                                if (Order == 1)
                                                                    SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, true);
                                                                else
                                                                    SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], Hit, SolderesOnTable[RW1].SoldierThinking[CL1].HitNumberSoldier[Ki1], ChessRules.BridgeActBrown, true);

                                                                if (SolderesOnTable[RW1].ConvertedToMinister)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 5 * Sign;
                                                                else if (SolderesOnTable[RW1].ConvertedToBridge)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 4 * Sign;
                                                                else if (SolderesOnTable[RW1].ConvertedToHourse)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 3 * Sign;
                                                                else if (SolderesOnTable[RW1].ConvertedToElefant)
                                                                    TableHuristic[SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][0], SolderesOnTable[RW1].SoldierThinking[CL1].RowColumnSoldier[Ki1][1]] = 2 * Sign;
                                                                TableList.Clear();
                                                                TableList.Add(TableHuristic);
                                                                if (A.Count > 1)
                                                                    SetRowColumn(0);
                                                                TableList.Clear();
                                                            }
                                                        }
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                    }

                                                }
                                            }

                                            //else
                                            {
                                                try
                                                {
                                                    for (int p = 0; p < SolderesOnTable[i].SoldierThinking[0].Dept.Count; p++)
                                                        SolderesOnTable[i].SoldierThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }
                        //Do For Remaining Objects same as Soldeir Documentation.
                        for (i = ElefantMidle; i < AllDraw.ElefantHigh; i++)
                        {
                            for (int k = 0; k < AllDraw.ElefantMovments; k++)
                                try
                                {
                                    for (j = 0; ElephantOnTable[i] != null && ElephantOnTable[i] != null && ElephantOnTable[i].ElefantThinking[k] != null && ElephantOnTable[i].ElefantThinking[k] != null && j < ElephantOnTable[i].ElefantThinking[k].TableListElefant.Count; j++)
                                    {
                                        try
                                        {

                                            if (FormRefrigtz.OrderPlate == Order)
                                                if (ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0)
                                                {
                                                    Less = -200000000;
                                                    continue;
                                                }
                                            if (ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0)
                                                continue;
                                            if (Order != FormRefrigtz.OrderPlate)
                                                if (ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                                    continue;
                                            if (ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] >= Less)
                                            {
                                                //if (KishG || KishB)
                                                //{

                                                int[,] TableS = ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;

                                                    }
                                                }
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(2, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;
                                                            else
                                                            {
                                                                Act = true;
                                                                Less = ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];

                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;


                                                        }
                                                    }

                                                }
                                                RW2 = i;
                                                CL2 = k;
                                                Ki2 = j;

                                                if (Depti == 1)
                                                {
                                                    bool Hit = false;
                                                    if (ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 2, ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -2, ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);

                                                    FormRefrigtz.LastRow = ElephantOnTable[i].ElefantThinking[k].Row;
                                                    FormRefrigtz.LastColumn = ElephantOnTable[i].ElefantThinking[k].Column;

                                                    Act = true;
                                                    Less = ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];
                                                    TableHuristic = ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];

                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (ElephantOnTable[RW2].ElefantThinking[CL2].HitNumberElefant[Ki2] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 2, ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][1], ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][0], Hit, ElephantOnTable[RW2].ElefantThinking[CL2].HitNumberElefant[Ki2], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -2, ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][1], ElephantOnTable[RW2].ElefantThinking[CL2].RowColumnElefant[Ki2][0], Hit, ElephantOnTable[RW2].ElefantThinking[CL2].HitNumberElefant[Ki2], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = ElephantOnTable[RW2].ElefantThinking[CL2].Row;
                                                        FormRefrigtz.LastColumn = ElephantOnTable[RW2].ElefantThinking[CL2].Column;

                                                        Act = true;
                                                        Less = ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][0] + ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][1] + ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][2] + ElephantOnTable[RW2].ElefantThinking[CL2].HuristicListElefant[Ki2][3];
                                                        TableHuristic = ElephantOnTable[RW2].ElefantThinking[CL2].TableListElefant[Ki2];
                                                    }
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }

                                            }

                                            //else
                                            {
                                                try
                                                {
                                                    for (int p = 0; p < ElephantOnTable[i].ElefantThinking[0].Dept.Count; p++)
                                                        ElephantOnTable[i].ElefantThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                        for (i = HourseMidle; i < AllDraw.HourseHight; i++)
                        {

                            for (int k = 0; k < AllDraw.HourseMovments; k++)
                                try
                                {
                                    for (j = 0; HoursesOnTable[i] != null && HoursesOnTable[i] != null && HoursesOnTable[i].HourseThinking[k] != null && HoursesOnTable[i].HourseThinking[k] != null && j < HoursesOnTable[i].HourseThinking[k].TableListHourse.Count; j++)
                                    {
                                        try
                                        {

                                            if (FormRefrigtz.OrderPlate == Order)
                                                if (HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0)
                                                {
                                                    Less = -200000000;
                                                    continue;
                                                }
                                            if (Order != FormRefrigtz.OrderPlate)
                                                if (HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)

                                                    continue;
                                            if (HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] >= Less)
                                            {
                                                int[,] TableS = HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                                {
                                                    if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                    {
                                                        try
                                                        {
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;
                                                        }
                                                        catch (Exception t)
                                                        {
                                                            Log(t);
                                                            if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                                continue;

                                                        }

                                                    }

                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        if ((new ChessRules(3, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            if (Order == 1)
                                                            {
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        else
                                                        {

                                                        }
                                                    }


                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;

                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;
                                                            else
                                                            {
                                                                Act = true;
                                                                Less = HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                                continue;
                                                            }

                                                        }
                                                    }
                                                }
                                                RW3 = i;
                                                CL3 = k;
                                                Ki3 = j;

                                                if (Depti == 1)
                                                {
                                                    bool Hit = false;
                                                    if (HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 3, HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -3, HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                                    FormRefrigtz.LastRow = HoursesOnTable[i].HourseThinking[k].Row;
                                                    FormRefrigtz.LastColumn = HoursesOnTable[i].HourseThinking[k].Column;

                                                    Act = true;
                                                    Less = HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                    TableHuristic = HoursesOnTable[i].HourseThinking[k].TableListHourse[j];

                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (HoursesOnTable[RW3].HourseThinking[CL3].HitNumberHourse[Ki3] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 3, HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][1], HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][0], Hit, HoursesOnTable[RW3].HourseThinking[CL3].HitNumberHourse[Ki3], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -3, HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][1], HoursesOnTable[RW3].HourseThinking[CL3].RowColumnHourse[Ki3][0], Hit, HoursesOnTable[RW3].HourseThinking[CL3].HitNumberHourse[Ki3], ChessRules.BridgeActBrown, false);
                                                        FormRefrigtz.LastRow = HoursesOnTable[RW3].HourseThinking[CL3].Row;
                                                        FormRefrigtz.LastColumn = HoursesOnTable[RW3].HourseThinking[CL3].Column;

                                                        Act = true;
                                                        Less = HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][0] + HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][1] + HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][2] + HoursesOnTable[RW3].HourseThinking[CL3].HuristicListHourse[Ki3][3];
                                                        TableHuristic = HoursesOnTable[RW3].HourseThinking[CL3].TableListHourse[Ki3];
                                                    }
                                                }
                                                catch (Exception t)
                                                { Log(t); }


                                            }

                                            //else
                                            {
                                                try
                                                {
                                                    for (int p = 0; p < HoursesOnTable[i].HourseThinking[0].Dept.Count; p++)
                                                        HoursesOnTable[i].HourseThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }

                        }

                        for (i = BridgeMidle; i < AllDraw.BridgeHigh; i++)
                        {
                            for (int k = 0; k < AllDraw.BridgeMovments; k++)
                                try
                                {
                                    for (j = 0; BridgesOnTable[i] != null && BridgesOnTable[i] != null && BridgesOnTable[i].BridgeThinking[k] != null && BridgesOnTable[i].BridgeThinking[k] != null && j < BridgesOnTable[i].BridgeThinking[k].TableListBridge.Count; j++)
                                    {
                                        try
                                        {

                                            if (FormRefrigtz.OrderPlate == Order)
                                                if (BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0)
                                                {
                                                    Less = -200000000;
                                                    continue;
                                                }
                                            if (Order != FormRefrigtz.OrderPlate)
                                                if (BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                                    continue;
                                            if (BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] >= Less)
                                            {
                                                int[,] TableS = BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;

                                                    }

                                                }
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(4, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.BridgesOnTable[i].Row, APredict.BridgesOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;

                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(BridgesOnTable[i].Row, BridgesOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;
                                                            else
                                                            {
                                                                Act = true;
                                                                Less = BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];

                                                                continue;
                                                            }
                                                        }
                                                    }
                                                }
                                                RW4 = i;
                                                CL4 = k;
                                                Ki4 = j;

                                                if (Depti == 1)
                                                {
                                                    bool Hit = false;
                                                    if (BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 4, BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -4, BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                                    FormRefrigtz.LastRow = BridgesOnTable[i].BridgeThinking[k].Row;
                                                    FormRefrigtz.LastColumn = BridgesOnTable[i].BridgeThinking[k].Column;

                                                    Act = true;
                                                    Less = BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];
                                                    TableHuristic = BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];

                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (BridgesOnTable[RW4].BridgeThinking[CL4].HitNumberBridge[Ki4] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 4, BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][1], BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][0], Hit, BridgesOnTable[RW4].BridgeThinking[CL4].HitNumberBridge[Ki4], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -4, BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][1], BridgesOnTable[RW4].BridgeThinking[CL4].RowColumnBridge[Ki4][0], Hit, BridgesOnTable[RW4].BridgeThinking[CL4].HitNumberBridge[Ki4], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = BridgesOnTable[RW4].BridgeThinking[CL4].Row;
                                                        FormRefrigtz.LastColumn = BridgesOnTable[RW4].BridgeThinking[CL4].Column;

                                                        Act = true;
                                                        Less = BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][0] + BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][1] + BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][2] + BridgesOnTable[RW4].BridgeThinking[CL4].HuristicListBridge[Ki4][3];
                                                        TableHuristic = BridgesOnTable[RW4].BridgeThinking[CL4].TableListBridge[Ki4];
                                                    }
                                                }
                                                catch (Exception t) { }

                                            }


                                            //else
                                            {
                                                try
                                                {
                                                    for (int p = 0; p < BridgesOnTable[i].BridgeThinking[0].Dept.Count; p++)
                                                        BridgesOnTable[i].BridgeThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }


                        for (i = MinisterMidle; i < AllDraw.MinisterHigh; i++)
                        {

                            for (int k = 0; k < AllDraw.MinisterMovments; k++)
                                try
                                {
                                    for (j = 0; MinisterOnTable[i] != null && MinisterOnTable[i] != null && MinisterOnTable[i].MinisterThinking[k] != null && MinisterOnTable[i].MinisterThinking[k] != null && j < MinisterOnTable[i].MinisterThinking[k].TableListMinister.Count; j++)
                                    {
                                        try
                                        {

                                            if (FormRefrigtz.OrderPlate == Order)
                                                if (MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                                {
                                                    Less = -200000000;
                                                    continue;
                                                }
                                            if (Order != FormRefrigtz.OrderPlate)
                                                if (MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                                    continue;
                                            if (MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] >= Less)
                                            {
                                                int[,] TableS = MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;

                                                    }
                                                }
                                                {
                                                    if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                    {
                                                        if ((new ChessRules(5, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                        {
                                                            if (Order == 1)
                                                            {
                                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                            else
                                                            {
                                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                    continue;
                                                            }
                                                        }
                                                        else
                                                        {

                                                        }
                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;

                                                        }

                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            if (null == APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false))
                                                                continue;

                                                        }
                                                    }

                                                }
                                                RW5 = i;
                                                CL5 = k;
                                                Ki5 = j;

                                                if (Depti == 1)
                                                {
                                                    bool Hit = false;
                                                    if (MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 5, MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -5, MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                                    FormRefrigtz.LastRow = MinisterOnTable[i].MinisterThinking[k].Row;
                                                    FormRefrigtz.LastColumn = MinisterOnTable[i].MinisterThinking[k].Column;

                                                    Act = true;
                                                    Less = MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3];
                                                    TableHuristic = MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];

                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (MinisterOnTable[RW5].MinisterThinking[CL5].HitNumberMinister[Ki5] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 5, MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][1], MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][0], Hit, MinisterOnTable[RW5].MinisterThinking[CL5].HitNumberBridge[Ki5], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -5, MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][1], MinisterOnTable[RW5].MinisterThinking[CL5].RowColumnMinister[Ki5][0], Hit, MinisterOnTable[RW5].MinisterThinking[CL5].HitNumberBridge[Ki5], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = MinisterOnTable[RW5].MinisterThinking[CL5].Row;
                                                        FormRefrigtz.LastColumn = MinisterOnTable[RW5].MinisterThinking[CL5].Column;

                                                        Act = true;
                                                        Less = MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][0] + MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][1] + MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][2] + MinisterOnTable[RW5].MinisterThinking[CL5].HuristicListMinister[Ki5][3];
                                                        TableHuristic = MinisterOnTable[RW5].MinisterThinking[CL5].TableListMinister[Ki5];
                                                    }
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }


                                            // else
                                            {
                                                try
                                                {
                                                    for (int p = 0; p < MinisterOnTable[i].MinisterThinking[0].Dept.Count; p++)
                                                        MinisterOnTable[i].MinisterThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }

                        for (i = KingMidle; i < AllDraw.KingHigh; i++)
                        {
                            for (int k = 0; k < AllDraw.KingMovments; k++)
                                try
                                {
                                    for (j = 0; KingOnTable[i] != null && KingOnTable[i] != null && KingOnTable[i].KingThinking[k] != null && KingOnTable[i].KingThinking[k] != null && j < KingOnTable[i].KingThinking[k].TableListKing.Count; j++)
                                    {
                                        try
                                        {

                                            if (FormRefrigtz.OrderPlate == Order)
                                                if (KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0)
                                                {
                                                    Less = -200000000;
                                                    continue;
                                                }
                                            if (Order != FormRefrigtz.OrderPlate)
                                                if (KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                                    continue;
                                            if (KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3] >= Less)
                                            {
                                                int[,] TableS = KingOnTable[i].KingThinking[k].TableListKing[j];
                                                if (DynamicDeptFirstPrograming && !CurrentTableHuristic && Depti == 1)
                                                {
                                                    try
                                                    {
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;
                                                    }
                                                    catch (Exception t)
                                                    {
                                                        Log(t);
                                                        if (!isEnemyThingsinStable(TableS, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], FormRefrigtz.OrderPlate))
                                                            continue;

                                                    }

                                                }
                                                if (!ThinkingChess.UsePenaltyRegardMechnisam)
                                                {
                                                    if ((new ChessRules(6, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                                    {
                                                        if (Order == 1)
                                                        {
                                                            if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                        else
                                                        {
                                                            if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                                continue;
                                                        }
                                                    }
                                                    else
                                                    {

                                                    }

                                                    if (Order == 1)
                                                    {
                                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;

                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                                        {
                                                            Color B;
                                                            if (a == Color.Gray)
                                                                B = Color.Brown;
                                                            else
                                                                B = Color.Gray;
                                                            APredict.TableList.Clear();
                                                            APredict.TableList.Add(TableS);
                                                            APredict.SetRowColumn(0);
                                                            TableHuristic = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                                            if (TableHuristic == null)
                                                                continue;
                                                            else
                                                            {
                                                                Act = true;
                                                                Less = KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                                continue;
                                                            }

                                                        }
                                                    }

                                                }
                                                RW6 = i;
                                                CL6 = k;
                                                Ki6 = j;

                                                if (Depti == 1)
                                                {
                                                    bool Hit = false;
                                                    if (KingOnTable[i].KingThinking[k].HitNumberKing[j] > 0)
                                                        Hit = true;
                                                    if (Order == 1)
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 6, KingOnTable[i].KingThinking[k].RowColumnKing[j][1], KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);
                                                    else
                                                        SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -6, KingOnTable[i].KingThinking[k].RowColumnKing[j][1], KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, KingOnTable[i].KingThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);

                                                    FormRefrigtz.LastRow = KingOnTable[i].KingThinking[k].Row;
                                                    FormRefrigtz.LastColumn = KingOnTable[i].KingThinking[k].Column;

                                                    Act = true;
                                                    Less = KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                    TableHuristic = KingOnTable[i].KingThinking[k].TableListKing[j];

                                                }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (Depti == 1)
                                                    {
                                                        bool Hit = false;
                                                        if (KingOnTable[RW6].KingThinking[CL6].HitNumberKing[Ki6] > 0)
                                                            Hit = true;
                                                        if (Order == 1)
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, 6, KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][1], KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][0], Hit, KingOnTable[RW6].KingThinking[CL6].HitNumberKing[Ki6], ChessRules.BridgeActBrown, false);
                                                        else
                                                            SyntaxToWrite = ChessRules.CreateStatistic(TableHuristic, FormRefrigtz.MovmentsNumber, -6, KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][1], KingOnTable[RW6].KingThinking[CL6].RowColumnKing[Ki6][0], Hit, KingOnTable[RW6].KingThinking[CL6].HitNumberKing[Ki6], ChessRules.BridgeActBrown, false);

                                                        FormRefrigtz.LastRow = KingOnTable[RW6].KingThinking[CL6].Row;
                                                        FormRefrigtz.LastColumn = KingOnTable[RW6].KingThinking[CL6].Column;

                                                        Act = true;
                                                        Less = KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][0] + KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][1] + KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][2] + KingOnTable[RW6].KingThinking[CL6].HuristicListKing[Ki6][3];
                                                        TableHuristic = KingOnTable[RW6].KingThinking[CL6].TableListKing[Ki6];
                                                    }
                                                }
                                                catch (Exception t)
                                                { Log(t); }

                                            }

                                            //else
                                            {
                                                try
                                                {
                                                    for (int p = 0; p < KingOnTable[i].KingThinking[0].Dept.Count; p++)
                                                        KingOnTable[i].KingThinking[0].Dept[p].HuristicDeptSearch(Depti, A, a, ref Less, Order * -1, false);
                                                }
                                                catch (Exception t)
                                                {
                                                    Log(t);
                                                }
                                            }
                                        }
                                        catch (Exception t)
                                        {
                                            Log(t);
                                        }
                                    }
                                }
                                catch (Exception t)
                                {
                                    Log(t);
                                }
                        }
                    }

                }

            }
            if (Act)
                return TableHuristic;
            return TableHuristic;
        }
        //Common Non Dept Huristic Method.
        public int[,] Huristic(List<AllDraw> A, Color a, int ij, ref double Less, int Order)
        {
            int i = 0, j = 0;
            int[,] Table = new int[8, 8];
            bool Act = false;
            int ii = ij;
            if (A.Count > 0)
            {
                for (i = 0; i < AllDraw.SodierHigh; i++)
                {


                    for (int k = 0; k < AllDraw.SodierMovments; k++)
                        for (j = 0; SolderesOnTable[i] != null && SolderesOnTable[i].SoldierThinking[k] != null && j < SolderesOnTable[i].SoldierThinking[k].TableListSolder.Count; j++)
                        {
                            try
                            {
                                if (SolderesOnTable[i].SoldierThinking[k].PenaltyRegardListSolder[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;


                                if (SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3] > Less)
                                {
                                    int[,] TableS = SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];

                                    {
                                        if ((new ChessRules(1, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                Act = true;
                                                Less = SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];

                                                continue;


                                            }

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.SolderesOnTable[i].Row, APredict.SolderesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    RW = i;
                                    CL = k;
                                    Ki = 1;
                                    Act = true;
                                    FormRefrigtz.LastRow = SolderesOnTable[i].SoldierThinking[k].Row;
                                    FormRefrigtz.LastColumn = SolderesOnTable[i].SoldierThinking[k].Column;

                                    Less = SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][0] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][1] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][2] + SolderesOnTable[i].SoldierThinking[k].HuristicListSolder[j][3];


                                    Table = SolderesOnTable[i].SoldierThinking[k].TableListSolder[j];
                                    bool Hit = false;
                                    if (SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, false);


                                    ThingsConverter.ActOfClickEqualTow = true;
                                    SolderesOnTable[i].ConvertOperation(SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], a, SolderesOnTable[i].SoldierThinking[k].TableListSolder[j], Order, false, i);
                                    int Sign = 1;
                                    if (a == Color.Brown)
                                        Sign = -1;
                                    if (SolderesOnTable[i].Convert)
                                    {
                                        Hit = false;
                                        if (SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j] > 0)
                                            Hit = true;
                                        if (Order == 1)
                                            SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);
                                        else
                                            SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -1, SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], Hit, SolderesOnTable[i].SoldierThinking[k].HitNumberSoldier[j], ChessRules.BridgeActBrown, true);

                                        if (SolderesOnTable[i].ConvertedToMinister)
                                            Table[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 5 * Sign;
                                        else if (SolderesOnTable[i].ConvertedToBridge)
                                            Table[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 4 * Sign;
                                        else if (SolderesOnTable[i].ConvertedToHourse)
                                            Table[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 3 * Sign;
                                        else if (SolderesOnTable[i].ConvertedToElefant)
                                            Table[SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][0], SolderesOnTable[i].SoldierThinking[k].RowColumnSoldier[j][1]] = 2 * Sign;
                                        TableList.Clear();
                                        TableList.Add(Table);
                                        SetRowColumn(0);
                                        TableList.Clear();

                                    }


                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.ElefantHigh; i++)
                {
                    for (int k = 0; k < AllDraw.ElefantMovments; k++)
                        for (j = 0; ElephantOnTable[i] != null && ElephantOnTable[i].ElefantThinking[k] != null && j < ElephantOnTable[i].ElefantThinking[k].TableListElefant.Count; j++)
                        {
                            try
                            {
                                if (ElephantOnTable[i].ElefantThinking[k].PenaltyRegardListElefant[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;

                                if (ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3] > Less)
                                {

                                    int[,] TableS = ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];
                                    {
                                        if ((new ChessRules(2, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        //}
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];

                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(ii);
                                            Table = APredict.InitiatePerdictKish(APredict.ElephantOnTable[i].Row, APredict.ElephantOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;


                                        }
                                    }
                                    bool Hit = false;
                                    if (ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 2, ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -2, ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][1], ElephantOnTable[i].ElefantThinking[k].RowColumnElefant[j][0], Hit, ElephantOnTable[i].ElefantThinking[k].HitNumberElefant[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = ElephantOnTable[i].ElefantThinking[k].Row;
                                    FormRefrigtz.LastColumn = ElephantOnTable[i].ElefantThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 2;
                                    Act = true;
                                    Less = ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][0] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][1] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][2] + ElephantOnTable[i].ElefantThinking[k].HuristicListElefant[j][3];
                                    Table = ElephantOnTable[i].ElefantThinking[k].TableListElefant[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.HourseHight; i++)
                {

                    for (int k = 0; k < AllDraw.HourseMovments; k++)
                        for (j = 0; HoursesOnTable[i] != null && HoursesOnTable[i].HourseThinking[k] != null && j < HoursesOnTable[i].HourseThinking[k].TableListHourse.Count; j++)
                        {
                            try
                            {
                                if (HoursesOnTable[i].HourseThinking[k].PenaltyRegardListHourse[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;


                                if (HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3] > Less)
                                {
                                    int[,] TableS = HoursesOnTable[i].HourseThinking[k].TableListHourse[j];
                                    {
                                        {
                                            if ((new ChessRules(3, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                            {
                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                            }
                                            else
                                            {

                                            }
                                        }
                                    }

                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.HoursesOnTable[i].Row, APredict.HoursesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                                continue;
                                            }

                                        }
                                    }
                                    bool Hit = false;
                                    if (HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 3, HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -3, HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][1], HoursesOnTable[i].HourseThinking[k].RowColumnHourse[j][0], Hit, HoursesOnTable[i].HourseThinking[k].HitNumberHourse[j], ChessRules.BridgeActBrown, false);
                                    FormRefrigtz.LastRow = HoursesOnTable[i].HourseThinking[k].Row;
                                    FormRefrigtz.LastColumn = HoursesOnTable[i].HourseThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 3;
                                    Act = true;
                                    Less = HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][0] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][1] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][2] + HoursesOnTable[i].HourseThinking[k].HuristicListHourse[j][3];
                                    Table = HoursesOnTable[i].HourseThinking[k].TableListHourse[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }


                }

                for (i = 0; i < AllDraw.BridgeHigh; i++)
                {
                    for (int k = 0; k < AllDraw.BridgeMovments; k++)
                        for (j = 0; BridgesOnTable[i] != null && BridgesOnTable[i].BridgeThinking[k] != null && j < BridgesOnTable[i].BridgeThinking[k].TableListBridge.Count; j++)
                        {
                            try
                            {
                                if (BridgesOnTable[i].BridgeThinking[k].PenaltyRegardListBridge[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;
                                if (BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] > Less)
                                {
                                    int[,] TableS = BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];
                                    {
                                        if ((new ChessRules(4, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.BridgesOnTable[i].Row, APredict.BridgesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(BridgesOnTable[i].Row, BridgesOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];

                                                continue;
                                            }
                                        }
                                    }
                                    bool Hit = false;
                                    if (BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 4, BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -4, BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][1], BridgesOnTable[i].BridgeThinking[k].RowColumnBridge[j][0], Hit, BridgesOnTable[i].BridgeThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = BridgesOnTable[i].BridgeThinking[k].Row;
                                    FormRefrigtz.LastColumn = BridgesOnTable[i].BridgeThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 4;
                                    Act = true;
                                    Less = BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][0] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][1] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][2] + BridgesOnTable[i].BridgeThinking[k].HuristicListBridge[j][3];
                                    Table = BridgesOnTable[i].BridgeThinking[k].TableListBridge[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }


                for (i = 0; i < AllDraw.MinisterHigh; i++)
                {

                    for (int k = 0; k < AllDraw.MinisterMovments; k++)
                        for (j = 0; MinisterOnTable[i] != null && MinisterOnTable[i].MinisterThinking[k] != null && j < MinisterOnTable[i].MinisterThinking[k].TableListMinister.Count; j++)
                        {
                            try
                            {
                                if (MinisterOnTable[i].MinisterThinking[k].PenaltyRegardListMinister[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;
                                if (MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3] > Less)
                                {
                                    int[,] TableS = MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];
                                    {
                                        {
                                            if ((new ChessRules(5, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                            {
                                                if (Order == 1)
                                                {
                                                    if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                                else
                                                {
                                                    if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                        continue;
                                                }
                                            }
                                            else
                                            {

                                            }
                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }

                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            if (null == APredict.InitiatePerdictKish(APredict.MinisterOnTable[i].Row, APredict.MinisterOnTable[i].Column, B, TableS, Order, false))
                                                continue;

                                        }
                                    }
                                    bool Hit = false;
                                    if (MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 5, MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -5, MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][1], MinisterOnTable[i].MinisterThinking[k].RowColumnMinister[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberBridge[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = MinisterOnTable[i].MinisterThinking[k].Row;
                                    FormRefrigtz.LastColumn = MinisterOnTable[i].MinisterThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 5;
                                    Act = true;
                                    Less = MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][0] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][1] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][2] + MinisterOnTable[i].MinisterThinking[k].HuristicListMinister[j][3];
                                    Table = MinisterOnTable[i].MinisterThinking[k].TableListMinister[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }

                for (i = 0; i < AllDraw.KingHigh; i++)
                {
                    for (int k = 0; k < AllDraw.KingMovments; k++)
                        for (j = 0; KingOnTable[i] != null && KingOnTable[i].KingThinking[k] != null && j < KingOnTable[i].KingThinking[k].TableListKing.Count; j++)
                        {
                            try
                            {
                                if (KingOnTable[i].KingThinking[k].PenaltyRegardListKing[j].IsPenaltyAction() == 0 && !NoTableFound)
                                    continue;
                                if (KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3] > Less)
                                {
                                    int[,] TableS = KingOnTable[i].KingThinking[k].TableListKing[j];
                                    {
                                        if ((new ChessRules(6, TableS, Order).AchmazKingMove(Order, TableS, false)) && !NoTableFound)
                                        {
                                            if (Order == 1)
                                            {
                                                if (ChessRules.KishGrayAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                            else
                                            {
                                                if (ChessRules.KishBrownAchmaz && DeptFirstSearch)
                                                    continue;
                                            }
                                        }
                                        else
                                        {

                                        }
                                    }
                                    if (Order == 1)
                                    {
                                        if (ChessRules.KishGrayAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;

                                        }
                                    }
                                    else
                                    {
                                        if (ChessRules.KishBrownAchmaz && !DeptFirstSearch)
                                        {
                                            Color B;
                                            if (a == Color.Gray)
                                                B = Color.Brown;
                                            else
                                                B = Color.Gray;
                                            APredict.TableList.Clear();
                                            APredict.TableList.Add(TableS);
                                            APredict.SetRowColumn(0);
                                            Table = APredict.InitiatePerdictKish(APredict.KingOnTable[i].Row, APredict.KingOnTable[i].Column, B, TableS, Order, false);
                                            if (Table == null)
                                                continue;
                                            else
                                            {
                                                RW = i;
                                                CL = k;
                                                Ki = 1;
                                                Act = true;
                                                Less = KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                                continue;
                                            }

                                        }
                                    }
                                    bool Hit = false;
                                    if (MinisterOnTable[i].MinisterThinking[k].HitNumberMinister[j] > 0)
                                        Hit = true;
                                    if (Order == 1)
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, 6, KingOnTable[i].KingThinking[k].RowColumnKing[j][1], KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);
                                    else
                                        SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, -6, KingOnTable[i].KingThinking[k].RowColumnKing[j][1], KingOnTable[i].KingThinking[k].RowColumnKing[j][0], Hit, MinisterOnTable[i].MinisterThinking[k].HitNumberKing[j], ChessRules.BridgeActBrown, false);

                                    FormRefrigtz.LastRow = KingOnTable[i].KingThinking[k].Row;
                                    FormRefrigtz.LastColumn = KingOnTable[i].KingThinking[k].Column;

                                    RW = i;
                                    CL = k;
                                    Ki = 6;
                                    Act = true;
                                    Less = KingOnTable[i].KingThinking[k].HuristicListKing[j][0] + KingOnTable[i].KingThinking[k].HuristicListKing[j][1] + KingOnTable[i].KingThinking[k].HuristicListKing[j][2] + KingOnTable[i].KingThinking[k].HuristicListKing[j][3];
                                    Table = KingOnTable[i].KingThinking[k].TableListKing[j];

                                }
                            }
                            catch (Exception t)
                            {
                                Log(t);
                            }
                        }

                }
            }
            if (Act)
                return Table;
            return Table;
        }
        //Genethic Algorithm Game Method.
        public void InitiateGenetic(int ii, int jj, Color a, int[,] Table, int Order, bool TB)
        {
            int Current = ChessRules.CurrentOrder;
            int DummyOrder = Order;
            ADraw.Clear();
            TableList.Clear();
            TableList.Add(Table);
            SetRowColumn(0);
            TableList.Clear();
            ThinkingChess.NotSolvedKingDanger = false;
            LoopHuristicIndex = 0;
            for (int i = 0; i < 1; i++)
            {
                if (Order == 1)
                {
                    THIS.SetBoxText("\r\nChess Genetic By Bob!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nChess Genetic By Alice!");
                    THIS.RefreshBoxText();

                }

                int[,] TablInit = new int[8, 8];
                if (Order == 1)
                    a = Color.Gray;
                else
                    a = Color.Brown;
                int In = 0;

                do
                {
                    if (Order == 1)
                        In = (new System.Random()).Next(0, 8);
                    else
                        In = (new System.Random()).Next(8, 16);
                } while (SolderesOnTable[In] == null);



                if (Order == 1)
                {
                    THIS.SetBoxText("\r\nGenetic Algorithm Begin Dept " + i.ToString() + " By Bob!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nGenetic Algirithm Begin Dept " + i.ToString() + " By Alice!");
                    THIS.RefreshBoxText();

                }
                ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                int[,] Tab = R.GenerateTable(TableListAction, 0, Order);
                if (Order == 1)
                {
                    THIS.SetBoxText("\r\nGenetic Algorithm Finsished Dept " + i.ToString() + " By Bob!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nGenetic Algirithm Finished Dept " + i.ToString() + " By Alice!");
                    THIS.RefreshBoxText();

                }


                if (Tab != null)
                {
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            TablInit[iii, jjj] = Tab[iii, jjj];
                        }
                    Table = new int[8, 8];
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            Table[iii, jjj] = TablInit[iii, jjj];
                        }
                    TableList.Add(TablInit);
                    ClList.Add(CL);
                    RWList.Add(RW);
                    KiList.Add(Ki);
                    // Order = Order * -1;
                    // ChessRules.CurrentOrder = Order;
                    Dept++;
                    //return;

                }
            }
            (new ChessRules(1, Table, Order)).Mate(Table, Order);


            Order = DummyOrder;
            ChessRules.CurrentOrder = Current;


        }
        //Dept First Initiat Thinking Main Method.
        public void InitiateDeptFirst(AllDraw Dummy, int iDept, int ii, int jj, Color a, int[,] Table, int Order, bool TB, ref Timer timer, ref Timer TimerColor)
        {

            if (iDept > MaxDept)
                return;
            iDept++;

            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;

            timer.MidleDeptFirstTimer(iDept);
            //Mathematicall Formula for Calculation DeptFirstMaxLevel Not Work.
            int S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
            if (S == 1)
                DeptiLevelMax += 1;
            else
                //have to Zero. Non Decreamet Algorithm not found.
                DeptiLevelMax = 0;

            if (iDept > DeptiLevelMax)
                return;
            int i = 0;
            if (Order == 1)
            {
                THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Bob!");
                THIS.RefreshBoxText();
            }
            else
            {
                THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Alice!");
                THIS.RefreshBoxText();
            }
            int[,] TablInit = new int[8, 8];
            if (Order == 1)
                a = Color.Gray;
            else
                a = Color.Brown;
            int In = 0;
            /*if (iDept == AllDraw.StoreADraw.Count)
            {
                DeptIndexVlue = Dept;
                do
                {
                    if (Order == 1)
                        In = (new System.Random()).Next(0, 8);
                    else
                        In = (new System.Random()).Next(8, 16);
                } while (SolderesOnTable[In] == null);

                this.InitiateForEveryKindThingHome(new AllDraw(ref THIS), SolderesOnTable[In].Row, SolderesOnTable[In].Column, a, Table, Order, false, In);
                Dept++;
            }
            else*/
            {


                int j = 0;
                //for (int j = DeptIndexVlue; j < ADraw.Count; j++)
                {

                    if (Order == 1)
                    {
                        for (i = 0; i < AllDraw.SodierMidle; i++)
                        {
                            try
                            {
                                if (SolderesOnTable[i] == null)
                                    continue;

                                ii = SolderesOnTable[i].Row;
                                jj = SolderesOnTable[i].Column;
                                Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                                if (SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.SodierMovments; j++)
                                    {
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Table = SolderesOnTable[i].SoldierThinking[0].Table;
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingBegin = true;
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingFinished = false;
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[0].Thinking));
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 1, false);
                                        if (Dummy.SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count == 0)
                                            break;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.SolderesOnTable[i].SoldierThinking[0] = Dummy.SolderesOnTable[i].SoldierThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Add(Dummy.SolderesOnTable[i].SoldierThinking[0].Table);
                                        //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], Order);
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Clone(ref Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SolderesOnTable[i].SoldierThinking[0], ref THIS);
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {
                                            return;
                                        }


                                    }
                                }
                                else
                                {
                                    for (j = 0; j < SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count; j++)
                                    {
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Table = SolderesOnTable[i].SoldierThinking[0].TableListSolder[j];
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingBegin = true;
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingFinished = false;
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[0].Thinking));
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 1, false);
                                        if (Dummy.SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count == 0)
                                            continue;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.SolderesOnTable[i].SoldierThinking[0] = Dummy.SolderesOnTable[i].SoldierThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        ChessRules.CurrentOrder *= -1;
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Clear();
                                        // Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Add(Dummy.SolderesOnTable[i].SoldierThinking[0].TableListSolder[j]);
                                        //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], Order);
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Clone(ref Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SolderesOnTable[i].SoldierThinking[0], ref THIS);
                                        Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }


                                    }
                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.SolderesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        for (i = 0; i < AllDraw.ElefantMidle; i++)
                        {
                            try
                            {
                                if (ElephantOnTable[i] == null)
                                    continue;
                                ii = ElephantOnTable[i].Row;
                                jj = ElephantOnTable[i].Column;
                                Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                                if (ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.ElefantMovments; j++)
                                    {
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Table = ElephantOnTable[i].ElefantThinking[0].Table;
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingBegin = true;
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingFinished = false;
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[0].Thinking));
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 2, false);
                                        if (Dummy.ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count == 0)
                                            break;
                                        // AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //  this.CopyRemeiningItems(AdumnmyConstructedD);
                                        // AdumnmyConstructedD.ElephantOnTable[i].ElefantThinking[0] = Dummy.ElephantOnTable[i].ElefantThinking[0];
                                        // Dummy = AdumnmyConstructedD;

                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        // Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Clear();
                                        // Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Add(Dummy.ElephantOnTable[i].ElefantThinking[0].Table);
                                        // Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], Order);
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Clone(ref Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].ElephantOnTable[i].ElefantThinking[0], ref THIS);
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }

                                    }
                                }
                                else
                                {
                                    for (j = 0; j < ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count; j++)
                                    {
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Table = ElephantOnTable[i].ElefantThinking[0].TableListElefant[j];
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingBegin = true;
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingFinished = false;
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[0].Thinking));
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 2, false);
                                        if (Dummy.ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count == 0)
                                            continue;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.ElephantOnTable[i].ElefantThinking[0] = Dummy.ElephantOnTable[i].ElefantThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        ChessRules.CurrentOrder *= -1;
                                        if (Order * -1 == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Add(Dummy.ElephantOnTable[i].ElefantThinking[0].TableListElefant[j]);
                                        //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        //this.CopyRemeiningItems(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1]);
                                        //AllDraw AdumnmyConstructedDF = Dummy.CopyRemeiningItems(this, Order*-1);
                                        //Dummy = AdumnmyConstructedDF;
                                        this.CopyRemeiningItems(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], Order);
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Clone(ref Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].ElephantOnTable[i].ElefantThinking[0], ref THIS);
                                        Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }

                                    }
                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.ElephantOnTable[i] = null;
                                Log(t);
                            }
                        }



                        for (i = 0; i < AllDraw.HourseMidle; i++)
                        {
                            try
                            {
                                if (HoursesOnTable[i] == null)
                                    continue;
                                ii = HoursesOnTable[i].Row;
                                jj = HoursesOnTable[i].Column;
                                Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                                if (HoursesOnTable[i].HourseThinking[0].TableListHourse.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.HourseMovments; j++)
                                    {
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Table = HoursesOnTable[i].HourseThinking[0].Table;
                                        Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingBegin = true;
                                        Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingFinished = false;
                                        Dummy.HoursesOnTable[i].HourseThinking[0].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[0].Thinking));
                                        Dummy.HoursesOnTable[i].HourseThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 3, false);
                                        if (Dummy.HoursesOnTable[i].HourseThinking[0].TableListHourse.Count == 0)
                                            break;
                                        // AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        // this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.HoursesOnTable[i].HourseThinking[0] = Dummy.HoursesOnTable[i].HourseThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Add(Dummy.HoursesOnTable[i].HourseThinking[0].Table);
                                        //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], Order);
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Clone(ref Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].HoursesOnTable[i].HourseThinking[0], ref THIS);
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }


                                    }
                                }
                                else
                                {
                                    for (j = 0; j < HoursesOnTable[i].HourseThinking[0].TableListHourse.Count; j++)
                                    {
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Table = HoursesOnTable[i].HourseThinking[0].TableListHourse[j];
                                        Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingBegin = true;
                                        Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingFinished = false;
                                        Dummy.HoursesOnTable[i].HourseThinking[0].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[0].Thinking));
                                        Dummy.HoursesOnTable[i].HourseThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 3, false);
                                        if (Dummy.HoursesOnTable[i].HourseThinking[0].TableListHourse.Count == 0)
                                            continue;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        // AdumnmyConstructedD.HoursesOnTable[i].HourseThinking[0] = Dummy.HoursesOnTable[i].HourseThinking[0];
                                        // Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Add(Dummy.HoursesOnTable[i].HourseThinking[0].Table);
                                        //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], Order);
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Clone(ref Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].HoursesOnTable[i].HourseThinking[0], ref THIS);
                                        Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }


                                    }

                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.HoursesOnTable[i] = null;
                                Log(t);
                            }
                        }




                        for (i = 0; i < AllDraw.BridgeMidle; i++)
                        {
                            try
                            {
                                if (BridgesOnTable[i] == null)
                                    continue;
                                ii = BridgesOnTable[i].Row;
                                jj = BridgesOnTable[i].Column;
                                Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                                if (BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.BridgeMovments; j++)
                                    {
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Table = BridgesOnTable[i].BridgeThinking[0].Table;
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingBegin = true;
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingFinished = false;
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[0].Thinking));
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 4, false);
                                        if (Dummy.BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count == 0)
                                            break;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        // this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.BridgesOnTable[i].BridgeThinking[0] = Dummy.BridgesOnTable[i].BridgeThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Add(Dummy.BridgesOnTable[i].BridgeThinking[0].Table);
                                        //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], Order);
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Clone(ref Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].BridgesOnTable[i].BridgeThinking[0], ref THIS);
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);

                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }
                                    }
                                }
                                else
                                {
                                    for (j = 0; j < BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count; j++)
                                    {
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Table = BridgesOnTable[i].BridgeThinking[0].TableListBridge[j];
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingBegin = true;
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingFinished = false;
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[0].Thinking));
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 4, false);
                                        if (Dummy.BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count == 0)
                                            continue;
                                        // AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        // this.CopyRemeiningItems(AdumnmyConstructedD);
                                        /// AdumnmyConstructedD.BridgesOnTable[i].BridgeThinking[0] = Dummy.BridgesOnTable[i].BridgeThinking[0];
                                        // Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Add(Dummy.BridgesOnTable[i].BridgeThinking[0].Table);
                                        //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], Order);
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Clone(ref Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].BridgesOnTable[i].BridgeThinking[0], ref THIS);
                                        Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);

                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }
                                    }

                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.BridgesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                            DeptiLevelMax = 0;

                        if (iDept > DeptiLevelMax)
                            return;
                        try
                        {
                            for (i = 0; i < MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count; i++)
                            {

                                if (MinisterOnTable[i] == null)
                                    continue;
                                ii = MinisterOnTable[i].Row;
                                jj = MinisterOnTable[i].Column;
                                Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                                if (MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.MinisterMovments; j++)
                                    {
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Table = MinisterOnTable[i].MinisterThinking[0].TableListMinister[j];
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingBegin = true;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingFinished = false;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[0].Thinking));
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 5, false);
                                        if (Dummy.MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count == 0)
                                            break;
                                        // AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        // this.CopyRemeiningItems(AdumnmyConstructedD);
                                        // AdumnmyConstructedD.MinisterOnTable[i].MinisterThinking[0] = Dummy.MinisterOnTable[i].MinisterThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Add(Dummy.MinisterOnTable[i].MinisterThinking[0].Table);
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Clone(ref Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].MinisterOnTable[i].MinisterThinking[0], ref THIS);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }
                                    }
                                }
                                else
                                {
                                    for (j = 0; j < MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count; j++)
                                    {
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Table = MinisterOnTable[i].MinisterThinking[0].TableListMinister[j];
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingBegin = true;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingFinished = false;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[0].Thinking));
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 5, false);
                                        if (Dummy.MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count == 0)
                                            continue;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.MinisterOnTable[i].MinisterThinking[0] = Dummy.MinisterOnTable[i].MinisterThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Add(Dummy.MinisterOnTable[i].MinisterThinking[0].Table);
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Clone(ref Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].MinisterOnTable[i].MinisterThinking[0], ref THIS);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        //AllDraw AdumnmyConstructedDF = Dummy.CopyRemeiningItems(this, Order*-1);
                                        //Dummy = AdumnmyConstructedDF;
                                        Dummy.InitiateDeptFirst(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception t)
                        {
                            //Dummy.MinisterOnTable[i] = null;
                            Log(t);
                        }



                        for (i = 0; i < AllDraw.KingMidle; i++)
                        {
                            try
                            {
                                if (KingOnTable[i] == null)
                                    continue;
                                ii = KingOnTable[i].Row;
                                jj = KingOnTable[i].Column;
                                Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                                if (KingOnTable[i].KingThinking[0].TableListKing.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.KingMovments; j++)
                                    {
                                        Dummy.KingOnTable[i].KingThinking[0].Table = KingOnTable[i].KingThinking[0].Table;
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingBegin = true;
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingFinished = false;
                                        Dummy.KingOnTable[i].KingThinking[0].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[0].Thinking));
                                        Dummy.KingOnTable[i].KingThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 6, false);
                                        if (Dummy.KingOnTable[i].KingThinking[0].TableListKing.Count == 0)
                                            break;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.KingOnTable[i].KingThinking[0] = Dummy.KingOnTable[i].KingThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Add(Dummy.KingOnTable[i].KingThinking[0].Table);
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Clone(ref Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].KingOnTable[i].KingThinking[0], ref THIS);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {
                                            return;
                                        }
                                    }


                                }
                                else
                                {
                                    for (j = 0; j < KingOnTable[i].KingThinking[0].TableListKing.Count; j++)
                                    {
                                        Dummy.KingOnTable[i].KingThinking[0].Table = KingOnTable[i].KingThinking[0].TableListKing[j];
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingBegin = true;
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingFinished = false;
                                        Dummy.KingOnTable[i].KingThinking[0].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[0].Thinking));
                                        Dummy.KingOnTable[i].KingThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 6, false);
                                        if (Dummy.KingOnTable[i].KingThinking[0].TableListKing.Count == 0)
                                            continue;
                                        /// AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        // this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.KingOnTable[i].KingThinking[0] = Dummy.KingOnTable[i].KingThinking[0];
                                        // Dummy = AdumnmyConstructedD;
                                        if (Order == 1)
                                            a = Color.Gray;
                                        else
                                            a = Color.Brown;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Add(Dummy.KingOnTable[i].KingThinking[0].Table);
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Clone(ref Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].KingOnTable[i].KingThinking[0], ref THIS);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }
                                    }


                                }


                            }
                            catch (Exception t)
                            {
                                // Dummy.KingOnTable[i] = null;
                                Log(t);
                            }
                        }
                    }
                    else
                    {
                        for (i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                        {
                            try
                            {
                                if (SolderesOnTable[i] == null)
                                    continue;
                                ii = SolderesOnTable[i].Row;
                                jj = SolderesOnTable[i].Column;
                                Dummy.SolderesOnTable[i] = new DrawSoldier(ii, jj, a, Table, Order, false, i);
                                {
                                    if (SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count == 0)
                                    {
                                        for (j = 0; j < AllDraw.SodierMovments; j++)
                                        {
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Table = SolderesOnTable[i].SoldierThinking[0].Table;
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingBegin = true;
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingFinished = false;
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[0].Thinking));
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 1, false);
                                            if (Dummy.SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count == 0)
                                                break;
                                            AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            // this.CopyRemeiningItems(AdumnmyConstructedD);
                                            // AdumnmyConstructedD.SolderesOnTable[i].SoldierThinking[0] = Dummy.SolderesOnTable[i].SoldierThinking[0];
                                            // Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Add(Dummy.SolderesOnTable[i].SoldierThinking[0].Table);
                                            //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], Order);
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Clone(ref Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SolderesOnTable[i].SoldierThinking[0], ref THIS);
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {

                                                return;
                                            }
                                        }

                                    }

                                    else
                                    {
                                        for (j = 0; j < SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count; j++)
                                        {
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Table = SolderesOnTable[i].SoldierThinking[0].TableListSolder[j];
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingBegin = true;
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].ThinkingFinished = false;
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].t = new Thread(new ThreadStart(Dummy.SolderesOnTable[i].SoldierThinking[0].Thinking));
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 1, false);
                                            if (Dummy.SolderesOnTable[i].SoldierThinking[0].TableListSolder.Count == 0)
                                                continue;
                                            //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            // this.CopyRemeiningItems(AdumnmyConstructedD);
                                            // AdumnmyConstructedD.SolderesOnTable[i].SoldierThinking[0] = Dummy.SolderesOnTable[i].SoldierThinking[0];
                                            //Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].TableList.Add(Dummy.SolderesOnTable[i].SoldierThinking[0].Table);
                                            //Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], Order);
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Clone(ref Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].SolderesOnTable[i].SoldierThinking[0], ref THIS);
                                            Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.SolderesOnTable[i].SoldierThinking[0].Dept[Dummy.SolderesOnTable[i].SoldierThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {

                                                return;
                                            }
                                        }

                                    }
                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.SolderesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        for (i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                        {
                            try
                            {
                                if (ElephantOnTable[i] == null)
                                    continue;
                                ii = ElephantOnTable[i].Row;
                                jj = ElephantOnTable[i].Column;
                                Dummy.ElephantOnTable[i] = new DrawElefant(ii, jj, a, Table, Order, false, i);
                                {
                                    if (ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count == 0)
                                    {
                                        for (j = 0; j < AllDraw.ElefantMovments; j++)
                                        {
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Table = ElephantOnTable[i].ElefantThinking[0].Table;
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingBegin = true;
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingFinished = false;
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[0].Thinking));
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 2, false);
                                            if (Dummy.ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count == 0)
                                                break;
                                            // AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            //this.CopyRemeiningItems(AdumnmyConstructedD);
                                            // AdumnmyConstructedD.ElephantOnTable[i].ElefantThinking[0] = Dummy.ElephantOnTable[i].ElefantThinking[0];
                                            //Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Add(Dummy.ElephantOnTable[i].ElefantThinking[0].Table);
                                            //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], Order);
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Clone(ref Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].ElephantOnTable[i].ElefantThinking[0], ref THIS);
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {

                                                return;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        for (j = 0; j < ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count; j++)
                                        {
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Table = ElephantOnTable[i].ElefantThinking[0].TableListElefant[j];
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingBegin = true;
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].ThinkingFinished = false;
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].t = new Thread(new ThreadStart(Dummy.ElephantOnTable[i].ElefantThinking[0].Thinking));
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 2, false);
                                            if (Dummy.ElephantOnTable[i].ElefantThinking[0].TableListElefant.Count == 0)
                                                continue;
                                            AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            //this.CopyRemeiningItems(AdumnmyConstructedD);
                                            //AdumnmyConstructedD.ElephantOnTable[i].ElefantThinking[0] = Dummy.ElephantOnTable[i].ElefantThinking[0];
                                            //Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].TableList.Add(Dummy.ElephantOnTable[i].ElefantThinking[0].Table);
                                            //Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], Order);
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Clone(ref Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].ElephantOnTable[i].ElefantThinking[0], ref THIS);
                                            Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.ElephantOnTable[i].ElefantThinking[0].Dept[Dummy.ElephantOnTable[i].ElefantThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {
                                                return;
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.ElephantOnTable[i] = null;
                                Log(t);
                            }
                        }



                        for (i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                        {
                            try
                            {
                                if (HoursesOnTable[i] == null)
                                    continue;
                                ii = HoursesOnTable[i].Row;
                                jj = HoursesOnTable[i].Column;
                                Dummy.HoursesOnTable[i] = new DrawHourse(ii, jj, a, Table, Order, false, i);

                                {
                                    if (HoursesOnTable[i].HourseThinking[0].TableListHourse.Count == 0)
                                    {
                                        for (j = 0; j < AllDraw.HourseMovments; j++)
                                        {
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Table = HoursesOnTable[i].HourseThinking[0].Table;
                                            Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingBegin = true;
                                            Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingFinished = false;
                                            Dummy.HoursesOnTable[i].HourseThinking[0].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[0].Thinking));
                                            Dummy.HoursesOnTable[i].HourseThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 3, false);
                                            if (Dummy.HoursesOnTable[i].HourseThinking[0].TableListHourse.Count == 0)
                                                break;
                                            AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            //this.CopyRemeiningItems(AdumnmyConstructedD);
                                            //AdumnmyConstructedD.HoursesOnTable[i].HourseThinking[0] = Dummy.HoursesOnTable[i].HourseThinking[0];
                                            //Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Add(Dummy.HoursesOnTable[i].HourseThinking[0].Table);
                                            //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], Order);
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Clone(ref Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].HoursesOnTable[i].HourseThinking[0], ref THIS);
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {

                                                return;
                                            }

                                        }
                                    }
                                    else
                                    {
                                        for (j = 0; j < HoursesOnTable[i].HourseThinking[0].TableListHourse.Count; j++)
                                        {
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Table = HoursesOnTable[i].HourseThinking[0].TableListHourse[j];
                                            Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingBegin = true;
                                            Dummy.HoursesOnTable[i].HourseThinking[0].ThinkingFinished = false;
                                            Dummy.HoursesOnTable[i].HourseThinking[0].t = new Thread(new ThreadStart(Dummy.HoursesOnTable[i].HourseThinking[0].Thinking));
                                            Dummy.HoursesOnTable[i].HourseThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 3, false);
                                            if (Dummy.HoursesOnTable[i].HourseThinking[0].TableListHourse.Count == 0)
                                                continue;
                                            //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            //this.CopyRemeiningItems(AdumnmyConstructedD);
                                            //AdumnmyConstructedD.HoursesOnTable[i].HourseThinking[0] = Dummy.HoursesOnTable[i].HourseThinking[0];
                                            //Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].TableList.Add(Dummy.HoursesOnTable[i].HourseThinking[0].Table);
                                            //Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], Order);
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Clone(ref Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].HoursesOnTable[i].HourseThinking[0], ref THIS);
                                            Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.HoursesOnTable[i].HourseThinking[0].Dept[Dummy.HoursesOnTable[i].HourseThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {

                                                return;
                                            }

                                        }
                                    }

                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.HoursesOnTable[i] = null;
                                Log(t);
                            }
                        }




                        for (i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                        {
                            try
                            {
                                if (BridgesOnTable[i] == null)
                                    continue;
                                ii = BridgesOnTable[i].Row;
                                jj = BridgesOnTable[i].Column;
                                Dummy.BridgesOnTable[i] = new DrawBridge(ii, jj, a, Table, Order, false, i);

                                {
                                    if (BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count == 0)
                                    {
                                        for (j = 0; j < AllDraw.BridgeMovments; j++)
                                        {
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Table = BridgesOnTable[i].BridgeThinking[0].Table;
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingBegin = true;
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingFinished = false;
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[0].Thinking));
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 4, false);
                                            if (Dummy.BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count == 0)
                                                break;
                                            //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            //this.CopyRemeiningItems(AdumnmyConstructedD);
                                            //AdumnmyConstructedD.BridgesOnTable[i].BridgeThinking[0] = Dummy.BridgesOnTable[i].BridgeThinking[0];
                                            //Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Add(Dummy.BridgesOnTable[i].BridgeThinking[0].Table);
                                            //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], Order);
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Clone(ref Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].BridgesOnTable[i].BridgeThinking[0], ref THIS);
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {

                                                return;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        for (j = 0; j < BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count; j++)
                                        {
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Table = BridgesOnTable[i].BridgeThinking[0].TableListBridge[j];
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingBegin = true;
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].ThinkingFinished = false;
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].t = new Thread(new ThreadStart(Dummy.BridgesOnTable[i].BridgeThinking[0].Thinking));
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].t.Start();
                                            Wait(Dummy, i, j, 0, 4, false);
                                            if (Dummy.BridgesOnTable[i].BridgeThinking[0].TableListBridge.Count == 0)
                                                continue;
                                            //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                            //this.CopyRemeiningItems(AdumnmyConstructedD);
                                            //AdumnmyConstructedD.BridgesOnTable[i].BridgeThinking[0] = Dummy.BridgesOnTable[i].BridgeThinking[0];
                                            //Dummy = AdumnmyConstructedD;
                                            //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                            ChessRules.CurrentOrder *= -1;
                                            if (Order * -1 == 1)
                                                a = Color.Gray;
                                            else
                                                a = Color.Brown;
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Add(new AllDraw(ref THIS));
                                            //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Clear();
                                            //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].TableList.Add(Dummy.BridgesOnTable[i].BridgeThinking[0].Table);
                                            //Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].SetRowColumn(0);
                                            this.CopyRemeiningItems(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], Order);
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Clone(ref Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].BridgesOnTable[i].BridgeThinking[0], ref THIS);
                                            Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.BridgesOnTable[i].BridgeThinking[0].Dept[Dummy.BridgesOnTable[i].BridgeThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;
                                            S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                            if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                                DeptiLevelMax = 0;

                                            if (iDept > DeptiLevelMax)
                                            {

                                                return;
                                            }
                                        }
                                    }

                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.BridgesOnTable[i] = null;
                                Log(t);
                            }
                        }
                        for (i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                        {
                            try
                            {
                                if (MinisterOnTable[i] == null)
                                    continue;
                                ii = MinisterOnTable[i].Row;
                                jj = MinisterOnTable[i].Column;
                                Dummy.MinisterOnTable[i] = new DrawMinister(ii, jj, a, Table, Order, false, i);

                                if (MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.MinisterMovments; j++)
                                    {
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Table = MinisterOnTable[i].MinisterThinking[0].TableListMinister[j];
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingBegin = true;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingFinished = false;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[0].Thinking));
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 5, false);
                                        if (Dummy.MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count == 0)
                                            break;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.MinisterOnTable[i].MinisterThinking[0] = Dummy.MinisterOnTable[i].MinisterThinking[0];
                                        //Dummy = AdumnmyConstructedD;  
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Add(Dummy.MinisterOnTable[i].MinisterThinking[0].Table);
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Clone(ref Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].MinisterOnTable[i].MinisterThinking[0], ref THIS);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }
                                    }
                                }
                                else
                                {
                                    for (j = 0; j < Dummy.MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count; j++)
                                    {
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Table = MinisterOnTable[i].MinisterThinking[0].TableListMinister[j];
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingBegin = true;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].ThinkingFinished = false;
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t = new Thread(new ThreadStart(Dummy.MinisterOnTable[i].MinisterThinking[0].Thinking));
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 5, false);
                                        if (Dummy.MinisterOnTable[i].MinisterThinking[0].TableListMinister.Count == 0)
                                            continue;
                                        // AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        // AdumnmyConstructedD.MinisterOnTable[i].MinisterThinking[0] = Dummy.MinisterOnTable[i].MinisterThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].TableList.Add(Dummy.MinisterOnTable[i].MinisterThinking[0].Table);
                                        //Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], Order);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Clone(ref Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].MinisterOnTable[i].MinisterThinking[0], ref THIS);
                                        Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.MinisterOnTable[i].MinisterThinking[0].Dept[Dummy.MinisterOnTable[i].MinisterThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }
                                    }

                                }
                            }
                            catch (Exception t)
                            {
                                //Dummy.MinisterOnTable[i] = null;
                                Log(t);
                            }
                        }


                        for (i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                        {
                            try
                            {
                                if (KingOnTable[i] == null)
                                    continue;
                                ii = KingOnTable[i].Row;
                                jj = KingOnTable[i].Column;
                                Dummy.KingOnTable[i] = new DrawKing(ii, jj, a, Table, Order, false, i);

                                if (KingOnTable[i].KingThinking[0].TableListKing.Count == 0)
                                {
                                    for (j = 0; j < AllDraw.KingMovments; j++)
                                    {
                                        Dummy.KingOnTable[i].KingThinking[0].Table = KingOnTable[i].KingThinking[0].Table;
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingBegin = true;
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingFinished = false;
                                        Dummy.KingOnTable[i].KingThinking[0].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[0].Thinking));
                                        Dummy.KingOnTable[i].KingThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 6, false);
                                        if (Dummy.KingOnTable[i].KingThinking[0].TableListKing.Count == 0)
                                            break;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        // this.CopyRemeiningItems(AdumnmyConstructedD);
                                        // AdumnmyConstructedD.KingOnTable[i].KingThinking[0] = Dummy.KingOnTable[i].KingThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Add(Dummy.KingOnTable[i].KingThinking[0].Table);
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Clone(ref Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].KingOnTable[i].KingThinking[0], ref THIS);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }


                                        if (Order == 1)
                                        {
                                            THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Bob Finished!");
                                            THIS.RefreshBoxText();
                                        }
                                        else
                                        {
                                            THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Alice Finished");
                                            THIS.RefreshBoxText();
                                        }

                                        DeptIndexVlue = Dept;
                                        Dept++;

                                        return;

                                    }
                                }
                                else
                                {
                                    for (j = 0; j < KingOnTable[i].KingThinking[0].TableListKing.Count; j++)
                                    {
                                        Dummy.KingOnTable[i].KingThinking[0].Table = KingOnTable[i].KingThinking[0].TableListKing[j];
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingBegin = true;
                                        Dummy.KingOnTable[i].KingThinking[0].ThinkingFinished = false;
                                        Dummy.KingOnTable[i].KingThinking[0].t = new Thread(new ThreadStart(Dummy.KingOnTable[i].KingThinking[0].Thinking));
                                        Dummy.KingOnTable[i].KingThinking[0].t.Start();
                                        Wait(Dummy, i, j, 0, 6, false);
                                        if (Dummy.KingOnTable[i].KingThinking[0].TableListKing.Count == 0)
                                            continue;
                                        //AllDraw AdumnmyConstructedD = new AllDraw(ref THIS);
                                        //this.CopyRemeiningItems(AdumnmyConstructedD);
                                        //AdumnmyConstructedD.KingOnTable[i].KingThinking[0] = Dummy.KingOnTable[i].KingThinking[0];
                                        //Dummy = AdumnmyConstructedD;
                                        //int[,] Taba = ADraw[0].HuristicCurrentTable(ADraw[0], a, Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept.Add(new AllDraw(ref THIS));
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Clear();
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].TableList.Add(Dummy.KingOnTable[i].KingThinking[0].Table);
                                        //Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].SetRowColumn(0);
                                        this.CopyRemeiningItems(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], Order);
                                        Dummy.KingOnTable[i].KingThinking[0].Clone(ref Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].KingOnTable[i].KingThinking[0], ref THIS);
                                        Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1].InitiateDeptFirst(Dummy.KingOnTable[i].KingThinking[0].Dept[Dummy.KingOnTable[i].KingThinking[0].Dept.Count - 1], iDept, ii, jj, a, Table, Order, false, ref timer, ref TimerColor);
                                        Order = DummyOrder;
                                        ChessRules.CurrentOrder = DummyCurrentOrder;
                                        S = (TimerColor.DeptiLevelMaxInitiate(TimerColor, iDept));
                                        if (S == -1)    //have to Zero. Non Decreamet Algorithm not found.
                                            DeptiLevelMax = 0;

                                        if (iDept > DeptiLevelMax)
                                        {

                                            return;
                                        }


                                        if (Order == 1)
                                        {
                                            THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Bob Finished!");
                                            THIS.RefreshBoxText();
                                        }
                                        else
                                        {
                                            THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Alice Finished");
                                            THIS.RefreshBoxText();
                                        }

                                        DeptIndexVlue = Dept;
                                        Dept++;

                                        return;

                                    }

                                }
                            }
                            catch (Exception t)
                            {
                                Dummy.KingOnTable[i] = null;
                                Log(t);
                            }
                        }
                    }
                }

                if (Order == 1)
                {
                    THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Bob Finished!");
                    THIS.RefreshBoxText();
                }
                else
                {
                    THIS.SetBoxText("\r\nChess Thinking Dept " + iDept.ToString() + " By Alice Finished");
                    THIS.RefreshBoxText();
                }
                ChessRules.CurrentOrder *= -1;
                if (Order * -1 == 1)
                    a = Color.Gray;
                else
                    a = Color.Brown;

                DeptIndexVlue = Dept;
                Dept++;
                Dummy.InitiateDeptFirst(Dummy, iDept, ii, jj, a, Table, Order * -1, false, ref timer, ref TimerColor);


            }
        }
        //Non Used Current Table Found Huristic Method.
        public int[,] HuristicCurrentTable(AllDraw ADra, Color a, int Order)
        {
            AllDraw.SyntaxToWrite = "";
            int[,] Tab = new int[8, 8];
            List<AllDraw> Ad = new List<AllDraw>();
            Ad.Add(ADra);
            double Less = -20000000;


            Tab = this.HuristicDeptSearch(0, Ad, a, ref Less, Order, true);
            /* (Tab != null)
            {
                //When Current Table Found.
                TableCurrent.Add(Tab);
                for (int i = 0; i < SodierHigh; i++)
                    try
                    {
                        SolderesOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < ElefantHigh; i++)
                    try
                    {
                        ElephantOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < HourseHight; i++)
                    try
                    {
                        HoursesOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < BridgeHigh; i++)
                    try
                    {
                        BridgesOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < MinisterHigh; i++)
                    try
                    {
                        MinisterOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
                for (int i = 0; i < KingHigh; i++)
                    try
                    {
                        KingOnTable[i].Table = Tab;
                    }
                    catch (Exception t) { Log(t); }
            }
            */
            THIS.SetBoxText("\r\nCurrent Table Syntax:" + AllDraw.SyntaxToWrite);
            THIS.RefreshBoxText();
            return Tab;

        }
        public AllDraw CopyRemeiningItems(AllDraw ADummy, int Order)
        {
            AllDraw Dummy = new AllDraw(ref THIS);
            Dummy.SolderesOnTable = new DrawSoldier[AllDraw.SodierHigh];
            Dummy.ElephantOnTable = new DrawElefant[AllDraw.ElefantHigh];
            Dummy.HoursesOnTable = new DrawHourse[AllDraw.HourseHight];
            Dummy.BridgesOnTable = new DrawBridge[AllDraw.BridgeHigh];
            Dummy.MinisterOnTable = new DrawMinister[AllDraw.MinisterHigh];
            Dummy.KingOnTable = new DrawKing[AllDraw.KingHigh];
            for (int i = 0; i < AllDraw.SodierHigh; i++)
            {
                try
                {
                    Dummy.SolderesOnTable[i] = new DrawSoldier(SolderesOnTable[i].Row, SolderesOnTable[i].Column, SolderesOnTable[i].color, SolderesOnTable[i].Table, SolderesOnTable[i].Order, false, SolderesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.ElefantHigh; i++)
            {
                try
                {
                    Dummy.ElephantOnTable[i] = new DrawElefant(ElephantOnTable[i].Row, ElephantOnTable[i].Column, ElephantOnTable[i].color, ElephantOnTable[i].Table, ElephantOnTable[i].Order, false, ElephantOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.HourseHight; i++)
            {
                try
                {
                    Dummy.HoursesOnTable[i] = new DrawHourse(HoursesOnTable[i].Row, HoursesOnTable[i].Column, HoursesOnTable[i].color, HoursesOnTable[i].Table, HoursesOnTable[i].Order, false, HoursesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.BridgeHigh; i++)
            {
                try
                {
                    Dummy.BridgesOnTable[i] = new DrawBridge(BridgesOnTable[i].Row, BridgesOnTable[i].Column, BridgesOnTable[i].color, BridgesOnTable[i].Table, BridgesOnTable[i].Order, false, BridgesOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.MinisterHigh; i++)
            {
                try
                {
                    Dummy.MinisterOnTable[i] = new DrawMinister(MinisterOnTable[i].Row, MinisterOnTable[i].Column, MinisterOnTable[i].color, MinisterOnTable[i].Table, MinisterOnTable[i].Order, false, MinisterOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            for (int i = 0; i < AllDraw.KingHigh; i++)
            {
                try
                {
                    Dummy.KingOnTable[i] = new DrawKing(KingOnTable[i].Row, KingOnTable[i].Column, KingOnTable[i].color, KingOnTable[i].Table, KingOnTable[i].Order, false, KingOnTable[i].Current);
                }
                catch (Exception t) { Log(t); }
            }
            if (Order == 1)
            {
                for (int i = 0; i < AllDraw.SodierMidle; i++)
                {
                    try
                    {
                        ADummy.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        this.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.ElefantMidle; i++)
                {
                    try
                    {

                        ADummy.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {

                        this.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                }
                for (int i = 0; i < AllDraw.HourseMidle; i++)
                {
                    try
                    {

                        ADummy.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        this.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.BridgeMidle; i++)
                {
                    try
                    {

                        ADummy.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.BridgeMidle; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {

                        this.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                }
                for (int i = 0; i < AllDraw.MinisterMidle; i++)
                {
                    try
                    {


                        ADummy.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                }
                for (int i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {

                        this.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.KingMidle; i++)
                {
                    try
                    {

                        ADummy.KingOnTable[i].Clone(ref Dummy.KingOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                }

                for (int i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                {
                    try
                    {

                        this.KingOnTable[i].Clone(ref Dummy.KingOnTable[i], ref THIS);
                    }
                    catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                }

                for (int i = 0; i < AllDraw.SodierHigh; i++)
                {
                    try
                    {
                        Dummy.SolderesOnTable[i].Table = ADummy.SolderesOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.ElefantHigh; i++)
                {
                    try
                    {
                        Dummy.ElephantOnTable[i].Table = ADummy.ElephantOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.HourseHight; i++)
                {
                    try
                    {
                        Dummy.HoursesOnTable[i].Table = ADummy.HoursesOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.BridgeHigh; i++)
                {
                    try
                    {
                        Dummy.BridgesOnTable[i].Table = ADummy.BridgesOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.MinisterHigh; i++)
                {
                    try
                    {
                        Dummy.MinisterOnTable[i].Table = ADummy.MinisterOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }
                for (int i = 0; i < AllDraw.KingHigh; i++)
                {
                    try
                    {
                        Dummy.KingOnTable[i].Table = ADummy.KingOnTable[i].Table;
                    }
                    catch (Exception t) { Log(t); }
                }

            }
            else
            {
                {
                    for (int i = 0; i < AllDraw.SodierMidle; i++)
                    {
                        try
                        {
                            this.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.SodierMidle; i < AllDraw.SodierHigh; i++)
                    {
                        try
                        {
                            ADummy.SolderesOnTable[i].Clone(ref Dummy.SolderesOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.SolderesOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.ElefantMidle; i++)
                    {
                        try
                        {

                            this.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.ElefantMidle; i < AllDraw.ElefantHigh; i++)
                    {
                        try
                        {

                            ADummy.ElephantOnTable[i].Clone(ref Dummy.ElephantOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.ElephantOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.HourseMidle; i++)
                    {
                        try
                        {

                            this.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.HourseMidle; i < AllDraw.HourseHight; i++)
                    {
                        try
                        {
                            ADummy.HoursesOnTable[i].Clone(ref Dummy.HoursesOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.HoursesOnTable[i] = null; Log(t); }
                    }

                    for (int i = 0; i < AllDraw.BridgeMidle; i++)
                    {
                        try
                        {

                            this.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.BridgeMidle; i < AllDraw.BridgeMidle; i++)
                    {
                        try
                        {

                            ADummy.BridgesOnTable[i].Clone(ref Dummy.BridgesOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.BridgesOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.MinisterMidle; i++)
                    {
                        try
                        {


                            this.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                    }
                    for (int i = AllDraw.MinisterMidle; i < AllDraw.MinisterHigh; i++)
                    {
                        try
                        {

                            ADummy.MinisterOnTable[i].Clone(ref Dummy.MinisterOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.MinisterOnTable[i] = null; Log(t); }
                    }

                    for (int i = 0; i < AllDraw.KingMidle; i++)
                    {
                        try
                        {


                            this.KingOnTable[i].Clone(ref Dummy.KingOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                    }

                    for (int i = AllDraw.KingMidle; i < AllDraw.KingHigh; i++)
                    {
                        try
                        {

                            ADummy.KingOnTable[i].Clone(ref Dummy.KingOnTable[i], ref THIS);
                        }
                        catch (Exception t) { Dummy.KingOnTable[i] = null; Log(t); }
                    }
                    for (int i = 0; i < AllDraw.SodierHigh; i++)
                    {
                        try
                        {
                            Dummy.SolderesOnTable[i].Table = ADummy.SolderesOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.ElefantHigh; i++)
                    {
                        try
                        {
                            Dummy.ElephantOnTable[i].Table = ADummy.ElephantOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.HourseHight; i++)
                    {
                        try
                        {
                            Dummy.HoursesOnTable[i].Table = ADummy.HoursesOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.BridgeHigh; i++)
                    {
                        try
                        {
                            Dummy.BridgesOnTable[i].Table = ADummy.BridgesOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.MinisterHigh; i++)
                    {
                        try
                        {
                            Dummy.MinisterOnTable[i].Table = ADummy.MinisterOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }
                    for (int i = 0; i < AllDraw.KingHigh; i++)
                    {
                        try
                        {
                            Dummy.KingOnTable[i].Table = ADummy.KingOnTable[i].Table;
                        }
                        catch (Exception t) { Log(t); }
                    }

                }
            }

            return Dummy;


        }
        //Reconstruction of AllDraw Object.
        public void RecoonstructADraw(ref List<AllDraw> ADrawAll)
        {
            if (ADraw.Count == 0)
                return;
            ADrawAll.Add(this.ADraw[0]);
            ADraw[0].RecoonstructADraw(ref ADrawAll);
        }
        //Main Initiate Thinking Method.
        public void Initiate(int ii, int jj, Color a, int[,] Table, int Order, bool TB, ref Timer timer, ref Timer TimerColor)
        {
            FormRefrigtz THISDummy;

            ChessRules.KishBrownAchmazFirstTimesOcured = false;
            ChessRules.KishGrayAchmazFirstTimesOcured = false;
            int Current = ChessRules.CurrentOrder;
            int DummyOrder = Order;

            if (!AllDraw.DeptFirstSearch)
            {
                AllDraw.StoreADraw.Clear();
                int[,] Tab = null;
                int[,] TablInit = null;

                ADraw.Clear();
                TableList.Clear();
                TableList.Add(Table);
                SetRowColumn(0);
                TableList.Clear();
                ThinkingChess.NotSolvedKingDanger = false;
                LoopHuristicIndex = 0;
                for (int i = 0; i < 1; i++)
                {
                    if (Order == 1)
                    {
                        THIS.SetBoxText("\r\nChess Thinking Dept " + i.ToString() + " By Bob!");
                        THIS.RefreshBoxText();
                    }
                    else
                    {
                        THIS.SetBoxText("\r\nChess Thinking Dept " + i.ToString() + " By Alice!");
                        THIS.RefreshBoxText();
                    }
                    TablInit = new int[8, 8];
                    if (Order == 1)
                        a = Color.Gray;
                    else
                        a = Color.Brown;
                    int In = 0;

                    do
                    {
                        if (Order == 1)
                            In = (new System.Random()).Next(0, 8);
                        else
                            In = (new System.Random()).Next(8, 16);
                    } while (SolderesOnTable[In] == null);

                    this.InitiateForEveryKindThingHome(new AllDraw(ref THIS), SolderesOnTable[In].Row, SolderesOnTable[In].Column, a, Table, Order, false, In);

                    double Less = -2000000;

                    if (ADraw.Count > 0)
                    {
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + i.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + i.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                        Tab = this.ADraw[0].Huristic(ADraw, a, i, ref Less, Order);
                    }
                    /*if(Tab!=null)
                       if ((new ChessRules(Ki, Tab, Order)).AchmazKingMove(Order,Tab))
                       {
                           A.RemoveAt(i);
                           i--;
                           continue;
                       }*/
                    if (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                    {
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nGenetic Algorithm Begin Dept " + i.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nGenetic Algirithm Begin Dept " + i.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                        ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                        Tab = R.GenerateTable(TableListAction, LoopHuristicIndex, Order);
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nGenetic Algorithm Finsished Dept " + i.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nGenetic Algirithm Finished Dept " + i.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                    }

                    if (Tab != null)
                    {
                        for (int iii = 0; iii < 8; iii++)
                            for (int jjj = 0; jjj < 8; jjj++)
                            {
                                TablInit[iii, jjj] = Tab[iii, jjj];
                            }
                        TableList.Add(TablInit);
                        ClList.Add(CL);
                        RWList.Add(RW);
                        KiList.Add(Ki);
                        // Order = Order * -1;
                        // ChessRules.CurrentOrder = Order;
                        Dept++;
                        //return;

                    }
                }


                Order = DummyOrder;
                ChessRules.CurrentOrder = Current;
                return;
            }
            else
            {
                RW1 = -1;
                CL1 = -1;
                Ki1 = -1;
                RW2 = -1;
                CL2 = -1;
                Ki2 = -1;
                RW3 = -1;
                CL3 = -1;
                Ki3 = -1;
                RW4 = -1;
                CL4 = -1;
                Ki4 = -1;
                RW5 = -1;
                CL5 = -1;
                Ki5 = -1;
                RW6 = -1;
                CL6 = -1;
                Ki6 = -1;

                TableList.Clear();
                int[,] Tab = null;
                int[,] TablInit = null;

                AllDraw.DeptiLevelMax = 2;
                THISDummy = new FormRefrigtz(true);
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        THISDummy.Table[i, j] = Table[i, j];
                    }
                THISDummy.accessDraw.TableList.Add(THISDummy.Table);
                THISDummy.accessDraw.SetRowColumn(0);
                this.Clone(THISDummy.accessDraw);


                THISDummy.accessDraw.THIS = this.THIS;
                DeptIndexVlue = 0;
                ThinkingChess.NotSolvedKingDanger = false;
                LoopHuristicIndex = 0;
                if (CurrentTable == null)
                    CurrentTable = new int[8, 8];
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        CurrentTable[i, j] = Table[i, j];
                    }
                double Less = -2000000;

                /*    int Order1 = Order;
                    Color color = a;
                    //Found of Last Movments.(+)
                    if (AllDraw.StoreADraw.Count > 0 && DynamicDeptFirstPrograming)
                    {
                        //At First Level.(Second Call)(LevelDeptFirstDynamic=1)
                        //Current Movments at this level is StoreADraw[1].(+)
                        //Last Movments is StoreADraw[StoreAdraw.Count-1].(+)
                        //Begining Order Calculation from StoreADRaw[2].(+)
                        //At Second Level.(ThirdCall)(LevelDeptFirstDynamic=2)
                        //Current Movments at this level is StoreADraw[2]
                        //Last Movments is StoreADraw[StoreAdraw.Count-1].(+)
                        //Begining Ordr Calculation from StoreADraw[3].
                        for (int i = 1 + LevelDeptFirsDynamic; i < AllDraw.StoreADraw.Count; i++)
                        {
                            Order1 *= -1;
                            if (Order1 == 1)
                                color = Color.Gray;
                            else
                                color = Color.Brown;
                        }
                        //Calculation Last Table Huristic.(+)
                        //Some times Current Table become null. Breaking of 'Long Game'.
                        //CurrentTable = HuristicCurrentTable(AllDraw.StoreADraw[AllDraw.StoreADraw.Count - 1], color, Order1);
                        //For Next of Last Table Huristic!(+)
                        Order = Order1 * -1;

                        Dept = AllDraw.StoreADraw.Count;
                        DeptiLevelMax = 2 + Dept;
                        ChessRules.CurrentOrder = Order;
                        LevelDeptFirsDynamic++;
                        if (Order == 1)
                            a = Color.Gray;
                        else
                            a = Color.Brown;
                    }
                    if (StoreADraw.Count == 0)
                        timer.SetDeptFirstTimer();
                    //Construction of Last StoreADraw[StoreADraw.Count-1] at THISDummy.accessDraw.(+)
                    if (AllDraw.StoreADraw.Count > 0 && DynamicDeptFirstPrograming && CurrentTable != null)
                    {
                        for (int i = 0; i < 8; i++)
                            for (int j = 0; j < 8; j++)
                            {
                                THISDummy.Table[i, j] = CurrentTable[i, j];
                            }
                        THISDummy.accessDraw.TableList.Clear();
                        THISDummy.accessDraw.TableList.Add(THISDummy.Table);
                        THISDummy.accessDraw.SetRowColumn(0);

                    }
                    else
                    {
                        if (DynamicDeptFirstPrograming && CurrentTable == null)
                        {
                            AllDraw.StoreADraw.Clear();
                            LevelDeptFirsDynamic = 1;
                            AllDraw.DeptiLevelMax = 2;
                            if (THISDummy == null)
                                THISDummy = new FormRefrigtz(true);
                            else
                            {
                                THISDummy.accessDraw.ADraw.Clear();
                                THISDummy.accessDraw.TableList.Clear();
                            }
                            for (int i = 0; i < 8; i++)
                                for (int j = 0; j < 8; j++)
                                {
                                    THISDummy.Table[i, j] = Table[i, j];
                                }
                            THISDummy.accessDraw.TableList.Add(THISDummy.Table);
                            THISDummy.accessDraw.SetRowColumn(0);
                            this.CopyRemeiningItems(THISDummy.accessDraw);
                            Dept = 0;
                            CurrentTable = new int[8, 8];
                            for (int i = 0; i < 8; i++)
                                for (int j = 0; j < 8; j++)
                                {
                                    CurrentTable[i, j] = Table[i, j];
                                }
                            Order = DummyOrder;
                            ChessRules.CurrentOrder = Current;
                            LastDynamicNotFound = true;


                        }
                    }
                    if (AllDraw.StoreADraw.Count > 0)
                    {
                        THISDummy.accessDraw.ADraw.Clear();
                        THISDummy.accessDraw.ADraw.Add(AllDraw.StoreADraw[AllDraw.StoreADraw.Count - 1]);
                    }
                    //Calculation of Remaining Items.(+) */
                AllDraw Dummy = new AllDraw(ref THIS);
                THISDummy.accessDraw.ADraw.Clear();
                THISDummy.accessDraw.ADraw.Add(Dummy);

                THISDummy.accessDraw.InitiateDeptFirst(THISDummy.accessDraw.ADraw[0], 0, ii, jj, a, CurrentTable, Order, false, ref timer, ref TimerColor);
                //Dummy.Clone(THISDummy.accessDraw);
                /*   List<AllDraw> Ad = new List<AllDraw>();

                THISDummy.accessDraw.RecoonstructADraw(ref Ad);
                 THISDummy.accessDraw.ADraw.Clear();
                 //Copy Constructed Ad.(+)
                 //Current Ad[0] is Next of Last StoreADraw[StoreADraw.Count-1].(+)
                 for (int i = 0; i < Ad.Count; i++)
                     THISDummy.accessDraw.ADraw.Add(Ad[i]);
                 //Adding Found to StoreDraw.(+)
                 if (DynamicDeptFirstPrograming)
                 {
                     for (int i = 0; i < THISDummy.accessDraw.ADraw.Count; i++)
                         AllDraw.StoreADraw.Add(THISDummy.accessDraw.ADraw[i]);
                 }
                 //Constructed Multiple ADraw.(+)
                 if (AllDraw.StoreADraw.Count > 0 && DynamicDeptFirstPrograming)
                 {
                     THISDummy.accessDraw.ADraw.Clear();//(At First Call LevelDeptFirsDynamic=1) Add Fromm StroeAllDraw[0]

                     //(At Second Call LevelDeptFirstDynamic=2) Add From StoreADraw[1].
                     //Copy Founded Items in order to find Huristic.(_)
                     for (int i = LevelDeptFirsDynamic - 1; i < AllDraw.StoreADraw.Count; i++)
                         THISDummy.accessDraw.ADraw.Add(AllDraw.StoreADraw[i]);
                     //Remove Last Movments of Current Table!
                     try
                     {
                         TableCurrent.RemoveAt(0);
                     }
                     catch (Exception t)
                     {
                         Log(t);
                     }

                 }
                 Order = DummyOrder;
                 ChessRules.CurrentOrder = Current;
                 if (Order == 1)
                     a = Color.Gray;
                 else
                     a = Color.Brown;


 */
                Tab = new int[8, 8];



                THISDummy.accessDraw.ADraw[0].HuristicDeptSearch(0, THISDummy.accessDraw.ADraw, a, ref Less, Order, false);
                THISDummy.accessDraw.ADraw[0].HuristicDeptSearch(0, THISDummy.accessDraw.ADraw, a, ref Less, Order, false);
                if (TimerColor.Times > 60 * 2 * 1000)
                    MaxDept++;
                else
                    MaxDept--;
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        Tab[i, j] = TableHuristic[i, j];
                TableList.Clear();
                if (Tab != null)
                {
                    LastDynamicNotFound = false;
                    THISDummy.Dispose();
                    if (THISDummy.accessDraw.ADraw.Count > 0)
                    {
                        if (Order == 1)
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + Dept.ToString() + " By Bob!");
                            THIS.RefreshBoxText();
                        }
                        else
                        {
                            THIS.SetBoxText("\r\nHuristic Find Best Movements Dept " + Dept.ToString() + " By Alice!");
                            THIS.RefreshBoxText();

                        }
                        TablInit = new int[8, 8];
                        Less = -2000000;



                        Order = DummyOrder;
                        ChessRules.CurrentOrder = Current;

                        if (ThinkingChess.ExistTableInList(Tab, TableListAction, 0))
                        {
                            if (Order == 1)
                            {
                                THIS.SetBoxText("\r\nGenetic Algorithm Begin Dept 0 By Bob!");
                                THIS.RefreshBoxText();
                            }
                            else
                            {
                                THIS.SetBoxText("\r\nGenetic Algirithm Begin Dept 0 By Alice!");
                                THIS.RefreshBoxText();

                            }
                            ChessGeneticAlgorithm R = (new ChessGeneticAlgorithm());
                            Tab = R.GenerateTable(TableListAction, LoopHuristicIndex, Order);
                            if (Tab != null)
                                AllDraw.TableCurrent.Add(Tab);
                            if (Order == 1)
                            {
                                THIS.SetBoxText("\r\nGenetic Algorithm Finsished Dept 0 By Bob!");
                                THIS.RefreshBoxText();
                            }
                            else
                            {
                                THIS.SetBoxText("\r\nGenetic Algirithm Finished Dept 0 By Alice!");
                                THIS.RefreshBoxText();

                            }
                        }
                        if (Tab != null)
                        {
                            for (int iii = 0; iii < 8; iii++)
                                for (int jjj = 0; jjj < 8; jjj++)
                                {
                                    TablInit[iii, jjj] = Tab[iii, jjj];
                                }
                            TableList.Clear();
                            TableList.Add(TablInit);
                            Dept++;


                            Order = DummyOrder;
                            ChessRules.CurrentOrder = Current;
                            try
                            {
                                ChessRules.CurrentOrder = Current;
                                ChessGeneticAlgorithm RR = new ChessGeneticAlgorithm();
                                if (RR.FindGenToModified(AllDraw.TableListAction[AllDraw.TableListAction.Count - 1], Tab, AllDraw.TableListAction, 0, Order, true))
                                {
                                    bool HitVal = false;
                                    int Hit = AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRow, RR.CromosomColumn];
                                    if (Hit != 0)
                                        HitVal = true;
                                    bool Convert = false;
                                    if (Order == 1)
                                    {
                                        if (Tab[RR.CromosomRow, RR.CromosomColumn] == 1)
                                        {
                                            if (RR.CromosomColumn == 7)
                                                Convert = true;
                                        }
                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRowFirst, RR.CromosomColumnFirst], RR.CromosomColumn, RR.CromosomRow, HitVal, Hit, ChessRules.BridgeActGray, Convert);
                                    }
                                    else
                                    {
                                        if (AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRowFirst, RR.CromosomColumnFirst] == -1)
                                        {
                                            if (RR.CromosomColumn == 0)
                                                Convert = true;
                                        }
                                        AllDraw.SyntaxToWrite = ChessRules.CreateStatistic(Table, FormRefrigtz.MovmentsNumber, AllDraw.TableListAction[AllDraw.TableListAction.Count - 1][RR.CromosomRowFirst, RR.CromosomColumnFirst], RR.CromosomColumn, RR.CromosomRow, HitVal, Hit, ChessRules.BridgeActBrown, Convert);
                                    }
                                }
                            }
                            catch (IndexOutOfRangeException t)
                            {
                                Log(t);
                            }
                        }
                        else
                        {
                            AllDraw.StoreADraw.Clear();
                            LevelDeptFirsDynamic = 1;
                            TableCurrent.Clear();
                            Dept = 0;
                        }
                    }
                }
                else
                {
                    AllDraw.StoreADraw.Clear();
                    LevelDeptFirsDynamic = 1;
                    TableCurrent.Clear();
                    Dept = 0;
                }
                Order = DummyOrder;
                ChessRules.CurrentOrder = Current;

                return;
            }

        }
        //Identification of Illegal Dept First and Common Hurist Movments.
        public bool isEnemyThingsinStable(int[,] TableHuristic, int[,] TableAction, int Order)
        {
            int[,] Cromosom1 = TableHuristic;
            int[,] Cromosom2 = TableAction;
            bool and = true;
            /* if (!LastDynamicNotFound)
             {
                 for (int i = 0; i < 8; i++)
                     for (int j = 0; j < 8; j++)
                     {
                         if (Order == 1)
                         {
                             if (TableHuristic[i, j] > 0)
                             {
                                 if (TableHuristic[i, j] != TableAction[i, j])
                                     return false; ;
                             }




                         }
                         else
                             if (Order == -1)
                             {
                                 if (TableHuristic[i, j] < 0)
                                 {
                                     if (TableHuristic[i, j] != TableAction[i, j])
                                         return false; ;
                                 }

                             }
                     }
             }*/
            bool Find = false;
            bool Hit = false;
            int FindNumber = 0;
            int CromosomRowFirst = -1, CromosomColumnFirst = -1, CromosomRow = -1, CromosomColumn = -1;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (Order == 1)
                    {

                        if (and)
                        {
                            if (Cromosom1[i, j] < 0 && Cromosom2[i, j] < 0)
                                continue;
                        }
                        else
                        {
                            if (Cromosom1[i, j] < 0 || Cromosom2[i, j] < 0)
                                continue;
                        }
                    }
                    else
                    {
                        if (and)
                        {
                            if (Cromosom1[i, j] > 0 && Cromosom2[i, j] > 0)
                                continue;

                        }
                        else
                        {
                            if (Cromosom1[i, j] > 0 || Cromosom2[i, j] > 0)
                                continue;
                        }
                    }
                    if (Order == 1)
                    {
                        if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] > 0 && Cromosom2[i, j] == 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Gray, 1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] == 0 && Cromosom2[i, j] > 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(CromosomRow, CromosomColumn, i, j, Color.Gray, 1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] > 0 && Cromosom2[i, j] < 0))
                        {
                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Gray, 1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }
                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j])
                        {
                            CromosomRow = i;
                            CromosomColumn = j;
                            FindNumber++;
                        }
                    }
                    else
                    {
                        if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] < 0 && Cromosom2[i, j] == 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Brown, -1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] == 0 && Cromosom2[i, j] < 0))
                        {

                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(CromosomRow, CromosomColumn, i, j, Color.Brown, -1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }

                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                Find = true;
                                FindNumber++;
                            }
                        }
                        else if (Cromosom1[i, j] != Cromosom2[i, j] && (Cromosom1[i, j] < 0 && Cromosom2[i, j] > 0))
                        {
                            if (CromosomRow != -1 && CromosomColumn != -1)
                            {
                                if (new ChessRules(Cromosom1[i, j], Cromosom1, 1).Rules(i, j, CromosomRow, CromosomColumn, Color.Brown, -1))
                                {
                                    CromosomRow = i;
                                    CromosomColumn = j;
                                    Find = true;
                                    FindNumber++;
                                }
                            }
                            else
                            {
                                CromosomRow = i;
                                CromosomColumn = j;
                                FindNumber++;
                            }
                        }

                        else if (Cromosom1[i, j] != Cromosom2[i, j])
                        {
                            CromosomRow = i;
                            CromosomColumn = j;
                            FindNumber++;
                        }
                    }
                }
            }
            if (FindNumber == 1 && Find)
                return true;
            if (FindNumber == 2 && Find)
                return true;

            return false;

        }
    }

}
//End of Documentation.
