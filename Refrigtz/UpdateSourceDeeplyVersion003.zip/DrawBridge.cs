﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
namespace Refrigtz
{
    public class DrawBridge
    {
        public int Row, Column;
        public Color color;
        public ThinkingChess[] BridgeThinking = new ThinkingChess[AllDraw.BridgeMovments];
        public int[,] Table = null;
        public int Current = 0;
        public int Order;
        static void Log(Exception ex)
        {
            try
            {
                string stackTrace = ex.ToString();
                File.AppendAllText("ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); // path of file where stack trace will be stored.
            }
            catch (Exception t) { }
        }
       
        public DrawBridge() { }
            public DrawBridge(int i, int j, Color a, int[,] Tab, int Ord, bool TB,int Cur)
        // : base(i, j, a, Table)
        {
            Table = Tab;
            for (int ii = 0; ii < AllDraw.BridgeMovments; ii++)
                BridgeThinking[ii] = new ThinkingChess(i, j, a, Tab, 16, Ord, TB,Cur,4);

            Row = i;
            Column = j;
            color = a;
            Order = Ord;
            Current = Cur;
    
        }
            public void Clone(ref DrawBridge AA, ref FormRefrigtz THIS)
        {
            AA = new DrawBridge(this.Row, this.Column, this.color, this.Table, this.Order, false, this.Current);
            for (int i = 0; i < AllDraw.BridgeMovments; i++)
            {
                try
                {
                    AA.BridgeThinking[i] = new ThinkingChess();
                    this.BridgeThinking[i].Clone(ref AA.BridgeThinking[i],ref THIS);
                }
                catch (Exception t)
                {
                    Log(t);
                    AA.BridgeThinking[i] = null;
                }
            }
          }
        public void DrawBridgeOnTable(ref Graphics g, int CellW, int CellH)
        {
            try
            {
                if (color == Color.Gray)
                {
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot+"BrG.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }
                else
                {
                    g.DrawImage(Image.FromFile(AllDraw.ImagesSubRoot+"BrB.png"), new Rectangle(Row * CellW, Column * CellH, CellW, CellH));
                }
            }
            catch (Exception t)
            {
                Log(t);
            }
        }
    }
}
