﻿using System;
namespace Refrigtz
{
    partial class FormRefrigtz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
                
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MenuStripChessRefrigitz = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemNewGame = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.ComputerWithComputerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.ComputerWithComputerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemRandomGeneticGames = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.VerifyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RepairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.opneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.ContinueAGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.HardestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MedumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EasestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.AboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ErrorOpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MonitorOpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ButtonNext = new System.Windows.Forms.Button();
            this.ButtonPrevious = new System.Windows.Forms.Button();
            this.TextBoxStatistic = new System.Windows.Forms.TextBox();
            this.CheckBoxAStarGreedyHuristic = new System.Windows.Forms.CheckBox();
            this.CheckBoxOnlySelf = new System.Windows.Forms.CheckBox();
            this.CheckBoxPredictHuristci = new System.Windows.Forms.CheckBox();
            this.CheckBoxBestMovments = new System.Windows.Forms.CheckBox();
            this.RadioButtonOriginalImages = new System.Windows.Forms.RadioButton();
            this.RadioButtonBigFittingImages = new System.Windows.Forms.RadioButton();
            this.RadioButtonSmallFittingImages = new System.Windows.Forms.RadioButton();
            this.ButtonStop = new System.Windows.Forms.Button();
            this.CheckBoxAStarGreadyFirstSearch = new System.Windows.Forms.CheckBox();
            this.ButtonPauseStart = new System.Windows.Forms.Button();
            this.CheckBoxAStarGreedyMovement = new System.Windows.Forms.CheckBox();
            this.CheckBoxUseDoubleTime = new System.Windows.Forms.CheckBox();
            this.CheckBoxUsePenaltyRegradMechnisam = new System.Windows.Forms.CheckBox();
            this.CheckBoxDynamicProgrammingAStarGreedyt = new System.Windows.Forms.CheckBox();
            this.helpProviderChessRefregitz2016 = new System.Windows.Forms.HelpProvider();
            this.ProgressBarVerify = new System.Windows.Forms.ProgressBar();
            this.labelTimesRemaining = new System.Windows.Forms.Label();
            this.ButtonCalculateRootGray = new System.Windows.Forms.Button();
            this.CheckBoxIgnoreSelf = new System.Windows.Forms.CheckBox();
            this.ComboBoxMaxLevel = new System.Windows.Forms.ComboBox();
            this.labelMaxTree = new System.Windows.Forms.Label();
            this.groupBoxGroupOfPowerity = new System.Windows.Forms.GroupBox();
            this.labelMovments = new System.Windows.Forms.Label();
            this.labelKiller = new System.Windows.Forms.Label();
            this.labelSupport = new System.Windows.Forms.Label();
            this.labelReducedAttacked = new System.Windows.Forms.Label();
            this.labelObjectDangour = new System.Windows.Forms.Label();
            this.labelAttack = new System.Windows.Forms.Label();
            this.ComboBoxMovments = new System.Windows.Forms.ComboBox();
            this.ComboBoxKiller = new System.Windows.Forms.ComboBox();
            this.ComboBoxSupport = new System.Windows.Forms.ComboBox();
            this.ComboBoxReducedAttacked = new System.Windows.Forms.ComboBox();
            this.ComboBoxObjectDangour = new System.Windows.Forms.ComboBox();
            this.ComboBoxAttack = new System.Windows.Forms.ComboBox();
            this.folderBrowserDialogBackup = new System.Windows.Forms.FolderBrowserDialog();
            this.ButtonChangeArrangment = new System.Windows.Forms.Button();
            this.TextBoxText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelNodesCount = new System.Windows.Forms.Label();
            this.labelNodesCountText = new System.Windows.Forms.Label();
            this.PictureBox32 = new System.Windows.Forms.PictureBox();
            this.PictureBox31 = new System.Windows.Forms.PictureBox();
            this.PictureBox30 = new System.Windows.Forms.PictureBox();
            this.PictureBox29 = new System.Windows.Forms.PictureBox();
            this.PictureBox28 = new System.Windows.Forms.PictureBox();
            this.PictureBox27 = new System.Windows.Forms.PictureBox();
            this.PictureBox26 = new System.Windows.Forms.PictureBox();
            this.PictureBox25 = new System.Windows.Forms.PictureBox();
            this.PictureBox24 = new System.Windows.Forms.PictureBox();
            this.PictureBox23 = new System.Windows.Forms.PictureBox();
            this.PictureBox22 = new System.Windows.Forms.PictureBox();
            this.PictureBox21 = new System.Windows.Forms.PictureBox();
            this.PictureBox20 = new System.Windows.Forms.PictureBox();
            this.PictureBox19 = new System.Windows.Forms.PictureBox();
            this.PictureBox18 = new System.Windows.Forms.PictureBox();
            this.PictureBox17 = new System.Windows.Forms.PictureBox();
            this.PictureBox16 = new System.Windows.Forms.PictureBox();
            this.PictureBox15 = new System.Windows.Forms.PictureBox();
            this.PictureBox14 = new System.Windows.Forms.PictureBox();
            this.PictureBox13 = new System.Windows.Forms.PictureBox();
            this.PictureBox12 = new System.Windows.Forms.PictureBox();
            this.PictureBox11 = new System.Windows.Forms.PictureBox();
            this.PictureBox10 = new System.Windows.Forms.PictureBox();
            this.PictureBox9 = new System.Windows.Forms.PictureBox();
            this.PictureBox8 = new System.Windows.Forms.PictureBox();
            this.PictureBox7 = new System.Windows.Forms.PictureBox();
            this.PictureBox6 = new System.Windows.Forms.PictureBox();
            this.PictureBox5 = new System.Windows.Forms.PictureBox();
            this.PictureBox4 = new System.Windows.Forms.PictureBox();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.PictureBoxTimerBrown = new System.Windows.Forms.PictureBox();
            this.PictureBoxTimerGray = new System.Windows.Forms.PictureBox();
            this.PictureBoxRefrigtz = new System.Windows.Forms.PictureBox();
            this.BackgroundWorkerAllOp = new System.ComponentModel.BackgroundWorker();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.TimerAllOperation = new System.Windows.Forms.Timer(this.components);
            this.BackgroundWorkerSetNode = new System.ComponentModel.BackgroundWorker();
            this.BackgroundWorkerSetRefD = new System.ComponentModel.BackgroundWorker();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonViewTree = new System.Windows.Forms.Button();
            this.MenuStripChessRefrigitz.SuspendLayout();
            this.groupBoxGroupOfPowerity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxTimerBrown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxTimerGray)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxRefrigtz)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuStripChessRefrigitz
            // 
            this.MenuStripChessRefrigitz.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem1,
            this.ToolStripMenuItem4,
            this.ToolStripMenuItem5,
            this.ToolStripMenuItem2,
            this.AboutToolStripMenuItem});
            this.MenuStripChessRefrigitz.Location = new System.Drawing.Point(0, 0);
            this.MenuStripChessRefrigitz.Name = "MenuStripChessRefrigitz";
            this.MenuStripChessRefrigitz.Size = new System.Drawing.Size(1005, 24);
            this.MenuStripChessRefrigitz.TabIndex = 1;
            this.MenuStripChessRefrigitz.Text = "MenuStrip1";
            // 
            // ToolStripMenuItem1
            // 
            this.ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemNewGame,
            this.ToolStripMenuItem11,
            this.ToolStripMenuItem14,
            this.ToolStripMenuItem13,
            this.ToolStripMenuItem12,
            this.ToolStripMenuItem15,
            this.ToolStripMenuItem21,
            this.ToolStripMenuItem6,
            this.ToolStripMenuItem7,
            this.ToolStripMenuItem8,
            this.ComputerWithComputerToolStripMenuItem,
            this.ToolStripMenuItem9,
            this.ComputerWithComputerToolStripMenuItem1,
            this.ToolStripMenuItem16,
            this.ToolStripMenuItem22,
            this.ToolStripMenuItem19,
            this.ToolStripMenuItem20,
            this.ToolStripMenuItem23,
            this.ToolStripMenuItem10,
            this.ToolStripMenuItem18,
            this.ToolStripMenuItem17,
            this.ToolStripMenuItemRandomGeneticGames,
            this.ExitToolStripMenuItem});
            this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
            this.ToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.ToolStripMenuItem1.Text = "File";
            this.ToolStripMenuItem1.Click += new System.EventHandler(this.ToolStripMenuItem1_Click);
            // 
            // ToolStripMenuItemNewGame
            // 
            this.ToolStripMenuItemNewGame.Name = "ToolStripMenuItemNewGame";
            this.ToolStripMenuItemNewGame.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItemNewGame.Text = "New Game";
            this.ToolStripMenuItemNewGame.Click += new System.EventHandler(this.ToolStripMenuItem2_Click);
            // 
            // ToolStripMenuItem11
            // 
            this.ToolStripMenuItem11.Enabled = false;
            this.ToolStripMenuItem11.Name = "ToolStripMenuItem11";
            this.ToolStripMenuItem11.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem11.Text = "Blitz Witout PR";
            this.ToolStripMenuItem11.Visible = false;
            this.ToolStripMenuItem11.Click += new System.EventHandler(this.ToolStripMenuItem11_Click);
            // 
            // ToolStripMenuItem14
            // 
            this.ToolStripMenuItem14.Name = "ToolStripMenuItem14";
            this.ToolStripMenuItem14.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem14.Text = "Full Game";
            this.ToolStripMenuItem14.Click += new System.EventHandler(this.ToolStripMenuItem14_Click);
            // 
            // ToolStripMenuItem13
            // 
            this.ToolStripMenuItem13.Name = "ToolStripMenuItem13";
            this.ToolStripMenuItem13.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem13.Text = "Full Game NO PR";
            this.ToolStripMenuItem13.Click += new System.EventHandler(this.ToolStripMenuItem13_Click);
            // 
            // ToolStripMenuItem12
            // 
            this.ToolStripMenuItem12.Name = "ToolStripMenuItem12";
            this.ToolStripMenuItem12.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem12.Text = "Blitz No PR";
            this.ToolStripMenuItem12.Click += new System.EventHandler(this.ToolStripMenuItem12_Click);
            // 
            // ToolStripMenuItem15
            // 
            this.ToolStripMenuItem15.Name = "ToolStripMenuItem15";
            this.ToolStripMenuItem15.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem15.Text = "Computer By Computer Full Game";
            this.ToolStripMenuItem15.Click += new System.EventHandler(this.ToolStripMenuItem15_Click);
            // 
            // ToolStripMenuItem21
            // 
            this.ToolStripMenuItem21.Name = "ToolStripMenuItem21";
            this.ToolStripMenuItem21.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem21.Text = "Blitz Quantum";
            this.ToolStripMenuItem21.Click += new System.EventHandler(this.ToolStripMenuItem21_Click);
            // 
            // ToolStripMenuItem6
            // 
            this.ToolStripMenuItem6.Name = "ToolStripMenuItem6";
            this.ToolStripMenuItem6.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem6.Text = "Blitz";
            this.ToolStripMenuItem6.Click += new System.EventHandler(this.ToolStripMenuItem6_Click);
            // 
            // ToolStripMenuItem7
            // 
            this.ToolStripMenuItem7.Enabled = false;
            this.ToolStripMenuItem7.Name = "ToolStripMenuItem7";
            this.ToolStripMenuItem7.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem7.Text = "Computer By Person Increamental";
            this.ToolStripMenuItem7.Visible = false;
            this.ToolStripMenuItem7.Click += new System.EventHandler(this.ToolStripMenuItem7_Click_1);
            // 
            // ToolStripMenuItem8
            // 
            this.ToolStripMenuItem8.Enabled = false;
            this.ToolStripMenuItem8.Name = "ToolStripMenuItem8";
            this.ToolStripMenuItem8.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem8.Text = "Common Increamental Computer By Computer";
            this.ToolStripMenuItem8.Visible = false;
            this.ToolStripMenuItem8.Click += new System.EventHandler(this.ToolStripMenuItem8_Click);
            // 
            // ComputerWithComputerToolStripMenuItem
            // 
            this.ComputerWithComputerToolStripMenuItem.Enabled = false;
            this.ComputerWithComputerToolStripMenuItem.Name = "ComputerWithComputerToolStripMenuItem";
            this.ComputerWithComputerToolStripMenuItem.Size = new System.Drawing.Size(327, 22);
            this.ComputerWithComputerToolStripMenuItem.Text = "Computer With Computer";
            this.ComputerWithComputerToolStripMenuItem.Visible = false;
            this.ComputerWithComputerToolStripMenuItem.Click += new System.EventHandler(this.ComputerWithComputerToolStripMenuItem_Click);
            // 
            // ToolStripMenuItem9
            // 
            this.ToolStripMenuItem9.Enabled = false;
            this.ToolStripMenuItem9.Name = "ToolStripMenuItem9";
            this.ToolStripMenuItem9.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem9.Text = "Perofesional With Computer";
            this.ToolStripMenuItem9.Visible = false;
            this.ToolStripMenuItem9.Click += new System.EventHandler(this.ToolStripMenuItem9_Click);
            // 
            // ComputerWithComputerToolStripMenuItem1
            // 
            this.ComputerWithComputerToolStripMenuItem1.Name = "ComputerWithComputerToolStripMenuItem1";
            this.ComputerWithComputerToolStripMenuItem1.Size = new System.Drawing.Size(327, 22);
            this.ComputerWithComputerToolStripMenuItem1.Text = "Computer With Person";
            this.ComputerWithComputerToolStripMenuItem1.Visible = false;
            this.ComputerWithComputerToolStripMenuItem1.Click += new System.EventHandler(this.ComputerWithComputerToolStripMenuItem1_Click);
            // 
            // ToolStripMenuItem16
            // 
            this.ToolStripMenuItem16.Enabled = false;
            this.ToolStripMenuItem16.Name = "ToolStripMenuItem16";
            this.ToolStripMenuItem16.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem16.Text = "Refregitz With Stockfish Blitz";
            this.ToolStripMenuItem16.Visible = false;
            this.ToolStripMenuItem16.Click += new System.EventHandler(this.ToolStripMenuItem16_Click);
            // 
            // ToolStripMenuItem22
            // 
            this.ToolStripMenuItem22.Name = "ToolStripMenuItem22";
            this.ToolStripMenuItem22.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem22.Text = "Blitz Game With SugR";
            this.ToolStripMenuItem22.Click += new System.EventHandler(this.ToolStripMenuItem22_Click);
            // 
            // ToolStripMenuItem19
            // 
            this.ToolStripMenuItem19.Name = "ToolStripMenuItem19";
            this.ToolStripMenuItem19.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem19.Text = "Blitz Game With Stockfish 8";
            this.ToolStripMenuItem19.Click += new System.EventHandler(this.ToolStripMenuItem19_Click);
            // 
            // ToolStripMenuItem20
            // 
            this.ToolStripMenuItem20.Enabled = false;
            this.ToolStripMenuItem20.Name = "ToolStripMenuItem20";
            this.ToolStripMenuItem20.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem20.Text = "Blitz Game With stockfish 8 with No PR";
            this.ToolStripMenuItem20.Visible = false;
            this.ToolStripMenuItem20.Click += new System.EventHandler(this.ToolStripMenuItem20_Click);
            // 
            // ToolStripMenuItem23
            // 
            this.ToolStripMenuItem23.Name = "ToolStripMenuItem23";
            this.ToolStripMenuItem23.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem23.Text = "Refregitz With SugR Full Game";
            this.ToolStripMenuItem23.Click += new System.EventHandler(this.ToolStripMenuItem23_Click);
            // 
            // ToolStripMenuItem10
            // 
            this.ToolStripMenuItem10.Name = "ToolStripMenuItem10";
            this.ToolStripMenuItem10.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem10.Text = "Refregitz With Stockfish8 Full Game";
            this.ToolStripMenuItem10.Click += new System.EventHandler(this.ToolStripMenuItem10_Click);
            // 
            // ToolStripMenuItem18
            // 
            this.ToolStripMenuItem18.Enabled = false;
            this.ToolStripMenuItem18.Name = "ToolStripMenuItem18";
            this.ToolStripMenuItem18.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem18.Text = "Refregitz With Stockfish8 Full Game witout PR";
            this.ToolStripMenuItem18.Visible = false;
            this.ToolStripMenuItem18.Click += new System.EventHandler(this.ToolStripMenuItem18_Click);
            // 
            // ToolStripMenuItem17
            // 
            this.ToolStripMenuItem17.Enabled = false;
            this.ToolStripMenuItem17.Name = "ToolStripMenuItem17";
            this.ToolStripMenuItem17.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItem17.Text = "Person with stockfish 8";
            this.ToolStripMenuItem17.Visible = false;
            this.ToolStripMenuItem17.Click += new System.EventHandler(this.ToolStripMenuItem17_Click);
            // 
            // ToolStripMenuItemRandomGeneticGames
            // 
            this.ToolStripMenuItemRandomGeneticGames.Enabled = false;
            this.ToolStripMenuItemRandomGeneticGames.Name = "ToolStripMenuItemRandomGeneticGames";
            this.ToolStripMenuItemRandomGeneticGames.Size = new System.Drawing.Size(327, 22);
            this.ToolStripMenuItemRandomGeneticGames.Text = "Random Genetic Games";
            this.ToolStripMenuItemRandomGeneticGames.Visible = false;
            this.ToolStripMenuItemRandomGeneticGames.Click += new System.EventHandler(this.ToolStripMenuItem3_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(327, 22);
            this.ExitToolStripMenuItem.Text = "Exit";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // ToolStripMenuItem4
            // 
            this.ToolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.VerifyToolStripMenuItem,
            this.ClearToolStripMenuItem,
            this.RepairToolStripMenuItem,
            this.opneToolStripMenuItem});
            this.ToolStripMenuItem4.Name = "ToolStripMenuItem4";
            this.ToolStripMenuItem4.Size = new System.Drawing.Size(39, 20);
            this.ToolStripMenuItem4.Text = "Edit";
            this.ToolStripMenuItem4.Visible = false;
            // 
            // VerifyToolStripMenuItem
            // 
            this.VerifyToolStripMenuItem.Name = "VerifyToolStripMenuItem";
            this.VerifyToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.VerifyToolStripMenuItem.Text = "Verify";
            this.VerifyToolStripMenuItem.Visible = false;
            this.VerifyToolStripMenuItem.Click += new System.EventHandler(this.VerifyToolStripMenuItem_Click);
            // 
            // ClearToolStripMenuItem
            // 
            this.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem";
            this.ClearToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.ClearToolStripMenuItem.Text = "Clear";
            this.ClearToolStripMenuItem.Visible = false;
            this.ClearToolStripMenuItem.Click += new System.EventHandler(this.ClearToolStripMenuItem_Click);
            // 
            // RepairToolStripMenuItem
            // 
            this.RepairToolStripMenuItem.Name = "RepairToolStripMenuItem";
            this.RepairToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.RepairToolStripMenuItem.Text = "Repair";
            this.RepairToolStripMenuItem.Visible = false;
            this.RepairToolStripMenuItem.Click += new System.EventHandler(this.RepairToolStripMenuItem_Click);
            // 
            // opneToolStripMenuItem
            // 
            this.opneToolStripMenuItem.Name = "opneToolStripMenuItem";
            this.opneToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            // 
            // ToolStripMenuItem5
            // 
            this.ToolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ContinueAGameToolStripMenuItem});
            this.ToolStripMenuItem5.Name = "ToolStripMenuItem5";
            this.ToolStripMenuItem5.Size = new System.Drawing.Size(45, 20);
            this.ToolStripMenuItem5.Text = "Load";
            this.ToolStripMenuItem5.Visible = false;
            // 
            // ContinueAGameToolStripMenuItem
            // 
            this.ContinueAGameToolStripMenuItem.Name = "ContinueAGameToolStripMenuItem";
            this.ContinueAGameToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.ContinueAGameToolStripMenuItem.Text = "Continue a Game";
            this.ContinueAGameToolStripMenuItem.Click += new System.EventHandler(this.ContinueAGameToolStripMenuItem_Click);
            // 
            // ToolStripMenuItem2
            // 
            this.ToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HardestToolStripMenuItem,
            this.MedumToolStripMenuItem,
            this.EasestToolStripMenuItem});
            this.ToolStripMenuItem2.Name = "ToolStripMenuItem2";
            this.ToolStripMenuItem2.Size = new System.Drawing.Size(46, 20);
            this.ToolStripMenuItem2.Text = "Level";
            this.ToolStripMenuItem2.Visible = false;
            // 
            // HardestToolStripMenuItem
            // 
            this.HardestToolStripMenuItem.Name = "HardestToolStripMenuItem";
            this.HardestToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.HardestToolStripMenuItem.Text = "Hardest";
            this.HardestToolStripMenuItem.Click += new System.EventHandler(this.HardestToolStripMenuItem_Click);
            // 
            // MedumToolStripMenuItem
            // 
            this.MedumToolStripMenuItem.Name = "MedumToolStripMenuItem";
            this.MedumToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.MedumToolStripMenuItem.Text = "Medum";
            this.MedumToolStripMenuItem.Click += new System.EventHandler(this.MedumToolStripMenuItem_Click);
            // 
            // EasestToolStripMenuItem
            // 
            this.EasestToolStripMenuItem.Name = "EasestToolStripMenuItem";
            this.EasestToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.EasestToolStripMenuItem.Text = "Easest";
            this.EasestToolStripMenuItem.Click += new System.EventHandler(this.EasestToolStripMenuItem_Click);
            // 
            // AboutToolStripMenuItem
            // 
            this.AboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem3,
            this.AboutToolStripMenuItem1});
            this.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem";
            this.AboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.AboutToolStripMenuItem.Text = "About";
            // 
            // ToolStripMenuItem3
            // 
            this.ToolStripMenuItem3.Name = "ToolStripMenuItem3";
            this.ToolStripMenuItem3.Size = new System.Drawing.Size(107, 22);
            this.ToolStripMenuItem3.Text = "Help";
            this.ToolStripMenuItem3.Click += new System.EventHandler(this.ToolStripMenuItem3_Click_1);
            // 
            // AboutToolStripMenuItem1
            // 
            this.AboutToolStripMenuItem1.Name = "AboutToolStripMenuItem1";
            this.AboutToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.AboutToolStripMenuItem1.Text = "About";
            this.AboutToolStripMenuItem1.Click += new System.EventHandler(this.AboutToolStripMenuItem1_Click);
            // 
            // ErrorOpenToolStripMenuItem
            // 
            this.ErrorOpenToolStripMenuItem.Name = "ErrorOpenToolStripMenuItem";
            this.ErrorOpenToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.ErrorOpenToolStripMenuItem.Text = "Error Open";
            this.ErrorOpenToolStripMenuItem.Visible = false;
            this.ErrorOpenToolStripMenuItem.Click += new System.EventHandler(this.ErrorOpenToolStripMenuItem_Click);
            // 
            // MonitorOpenToolStripMenuItem
            // 
            this.MonitorOpenToolStripMenuItem.Name = "MonitorOpenToolStripMenuItem";
            this.MonitorOpenToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.MonitorOpenToolStripMenuItem.Text = "Monitor Open";
            this.MonitorOpenToolStripMenuItem.Click += new System.EventHandler(this.MonitorOpenToolStripMenuItem_Click);
            // 
            // ButtonNext
            // 
            this.ButtonNext.Location = new System.Drawing.Point(691, 606);
            this.ButtonNext.Name = "ButtonNext";
            this.ButtonNext.Size = new System.Drawing.Size(75, 23);
            this.ButtonNext.TabIndex = 2;
            this.ButtonNext.Text = "Next";
            this.ButtonNext.UseVisualStyleBackColor = true;
            this.ButtonNext.Click += new System.EventHandler(this.ButtonNext_Click);
            // 
            // ButtonPrevious
            // 
            this.ButtonPrevious.Location = new System.Drawing.Point(607, 606);
            this.ButtonPrevious.Name = "ButtonPrevious";
            this.ButtonPrevious.Size = new System.Drawing.Size(75, 23);
            this.ButtonPrevious.TabIndex = 3;
            this.ButtonPrevious.Text = "Previous";
            this.ButtonPrevious.UseVisualStyleBackColor = true;
            this.ButtonPrevious.Click += new System.EventHandler(this.ButtonPrevious_Click);
            // 
            // TextBoxStatistic
            // 
            this.TextBoxStatistic.Location = new System.Drawing.Point(613, 111);
            this.TextBoxStatistic.Multiline = true;
            this.TextBoxStatistic.Name = "TextBoxStatistic";
            this.TextBoxStatistic.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBoxStatistic.Size = new System.Drawing.Size(285, 69);
            this.TextBoxStatistic.TabIndex = 9;
            this.TextBoxStatistic.TextChanged += new System.EventHandler(this.TextBoxStatistic_TextChanged);
            // 
            // CheckBoxAStarGreedyHuristic
            // 
            this.CheckBoxAStarGreedyHuristic.AutoSize = true;
            this.CheckBoxAStarGreedyHuristic.Location = new System.Drawing.Point(871, 192);
            this.CheckBoxAStarGreedyHuristic.Name = "CheckBoxAStarGreedyHuristic";
            this.CheckBoxAStarGreedyHuristic.Size = new System.Drawing.Size(124, 17);
            this.CheckBoxAStarGreedyHuristic.TabIndex = 10;
            this.CheckBoxAStarGreedyHuristic.Text = "AStarGreedy Huristic";
            this.CheckBoxAStarGreedyHuristic.UseVisualStyleBackColor = true;
            this.CheckBoxAStarGreedyHuristic.CheckedChanged += new System.EventHandler(this.CheckBoxAStarGreedyHuristic_CheckedChanged);
            this.CheckBoxAStarGreedyHuristic.CheckStateChanged += new System.EventHandler(this.CheckBoxAStarGreedyHuristic_CheckStateChanged);
            // 
            // CheckBoxOnlySelf
            // 
            this.CheckBoxOnlySelf.AutoSize = true;
            this.CheckBoxOnlySelf.Location = new System.Drawing.Point(794, 192);
            this.CheckBoxOnlySelf.Name = "CheckBoxOnlySelf";
            this.CheckBoxOnlySelf.Size = new System.Drawing.Size(71, 17);
            this.CheckBoxOnlySelf.TabIndex = 11;
            this.CheckBoxOnlySelf.Text = "Only Self ";
            this.CheckBoxOnlySelf.UseVisualStyleBackColor = true;
            this.CheckBoxOnlySelf.Visible = false;
            // 
            // CheckBoxPredictHuristci
            // 
            this.CheckBoxPredictHuristci.AutoSize = true;
            this.CheckBoxPredictHuristci.Checked = true;
            this.CheckBoxPredictHuristci.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBoxPredictHuristci.Location = new System.Drawing.Point(691, 192);
            this.CheckBoxPredictHuristci.Name = "CheckBoxPredictHuristci";
            this.CheckBoxPredictHuristci.Size = new System.Drawing.Size(97, 17);
            this.CheckBoxPredictHuristci.TabIndex = 12;
            this.CheckBoxPredictHuristci.Text = "Predict Huristic";
            this.CheckBoxPredictHuristci.UseVisualStyleBackColor = true;
            this.CheckBoxPredictHuristci.Visible = false;
            this.CheckBoxPredictHuristci.CheckedChanged += new System.EventHandler(this.CheckBoxPredictHuristci_CheckedChanged);
            // 
            // CheckBoxBestMovments
            // 
            this.CheckBoxBestMovments.AutoSize = true;
            this.CheckBoxBestMovments.Location = new System.Drawing.Point(590, 192);
            this.CheckBoxBestMovments.Name = "CheckBoxBestMovments";
            this.CheckBoxBestMovments.Size = new System.Drawing.Size(99, 17);
            this.CheckBoxBestMovments.TabIndex = 13;
            this.CheckBoxBestMovments.Text = "Best Movments";
            this.CheckBoxBestMovments.UseVisualStyleBackColor = true;
            this.CheckBoxBestMovments.Visible = false;
            // 
            // RadioButtonOriginalImages
            // 
            this.RadioButtonOriginalImages.AutoSize = true;
            this.RadioButtonOriginalImages.Location = new System.Drawing.Point(641, 216);
            this.RadioButtonOriginalImages.Name = "RadioButtonOriginalImages";
            this.RadioButtonOriginalImages.Size = new System.Drawing.Size(97, 17);
            this.RadioButtonOriginalImages.TabIndex = 14;
            this.RadioButtonOriginalImages.Text = "Original Images";
            this.RadioButtonOriginalImages.UseVisualStyleBackColor = true;
            this.RadioButtonOriginalImages.Visible = false;
            this.RadioButtonOriginalImages.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // RadioButtonBigFittingImages
            // 
            this.RadioButtonBigFittingImages.AutoSize = true;
            this.RadioButtonBigFittingImages.Location = new System.Drawing.Point(641, 239);
            this.RadioButtonBigFittingImages.Name = "RadioButtonBigFittingImages";
            this.RadioButtonBigFittingImages.Size = new System.Drawing.Size(105, 17);
            this.RadioButtonBigFittingImages.TabIndex = 15;
            this.RadioButtonBigFittingImages.Text = "Big Fiting Images";
            this.RadioButtonBigFittingImages.UseVisualStyleBackColor = true;
            this.RadioButtonBigFittingImages.Visible = false;
            this.RadioButtonBigFittingImages.CheckedChanged += new System.EventHandler(this.RadioButtonBigFittingImages_CheckedChanged);
            // 
            // RadioButtonSmallFittingImages
            // 
            this.RadioButtonSmallFittingImages.AutoSize = true;
            this.RadioButtonSmallFittingImages.Checked = true;
            this.RadioButtonSmallFittingImages.Location = new System.Drawing.Point(641, 262);
            this.RadioButtonSmallFittingImages.Name = "RadioButtonSmallFittingImages";
            this.RadioButtonSmallFittingImages.Size = new System.Drawing.Size(118, 17);
            this.RadioButtonSmallFittingImages.TabIndex = 16;
            this.RadioButtonSmallFittingImages.TabStop = true;
            this.RadioButtonSmallFittingImages.Text = "Small Fitting Images";
            this.RadioButtonSmallFittingImages.UseVisualStyleBackColor = true;
            this.RadioButtonSmallFittingImages.Visible = false;
            this.RadioButtonSmallFittingImages.CheckedChanged += new System.EventHandler(this.RadioButtonSmallFittingImages_CheckedChanged);
            // 
            // ButtonStop
            // 
            this.ButtonStop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ButtonStop.Location = new System.Drawing.Point(762, 270);
            this.ButtonStop.Name = "ButtonStop";
            this.ButtonStop.Size = new System.Drawing.Size(75, 23);
            this.ButtonStop.TabIndex = 17;
            this.ButtonStop.Text = "Stop";
            this.ButtonStop.UseVisualStyleBackColor = true;
            this.ButtonStop.Visible = false;
            this.ButtonStop.Click += new System.EventHandler(this.ButtonStop_Click);
            // 
            // CheckBoxAStarGreadyFirstSearch
            // 
            this.CheckBoxAStarGreadyFirstSearch.AutoSize = true;
            this.CheckBoxAStarGreadyFirstSearch.Checked = true;
            this.CheckBoxAStarGreadyFirstSearch.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBoxAStarGreadyFirstSearch.Location = new System.Drawing.Point(753, 210);
            this.CheckBoxAStarGreadyFirstSearch.Name = "CheckBoxAStarGreadyFirstSearch";
            this.CheckBoxAStarGreadyFirstSearch.Size = new System.Drawing.Size(145, 17);
            this.CheckBoxAStarGreadyFirstSearch.TabIndex = 18;
            this.CheckBoxAStarGreadyFirstSearch.Text = "AStarGreedy First Search";
            this.CheckBoxAStarGreadyFirstSearch.UseVisualStyleBackColor = true;
            this.CheckBoxAStarGreadyFirstSearch.Visible = false;
            this.CheckBoxAStarGreadyFirstSearch.CheckedChanged += new System.EventHandler(this.CheckBoxAStarGreadyFirstSearch_CheckedChanged);
            // 
            // ButtonPauseStart
            // 
            this.ButtonPauseStart.Location = new System.Drawing.Point(851, 270);
            this.ButtonPauseStart.Name = "ButtonPauseStart";
            this.ButtonPauseStart.Size = new System.Drawing.Size(75, 23);
            this.ButtonPauseStart.TabIndex = 19;
            this.ButtonPauseStart.Text = "Pause";
            this.ButtonPauseStart.UseVisualStyleBackColor = true;
            this.ButtonPauseStart.Visible = false;
            this.ButtonPauseStart.Click += new System.EventHandler(this.ButtonPause_Click);
            // 
            // CheckBoxAStarGreedyMovement
            // 
            this.CheckBoxAStarGreedyMovement.AutoSize = true;
            this.CheckBoxAStarGreedyMovement.Location = new System.Drawing.Point(816, 350);
            this.CheckBoxAStarGreedyMovement.Name = "CheckBoxAStarGreedyMovement";
            this.CheckBoxAStarGreedyMovement.Size = new System.Drawing.Size(160, 17);
            this.CheckBoxAStarGreedyMovement.TabIndex = 20;
            this.CheckBoxAStarGreedyMovement.Text = "Use AStarGreedy Movments";
            this.CheckBoxAStarGreedyMovement.UseVisualStyleBackColor = true;
            this.CheckBoxAStarGreedyMovement.Visible = false;
            // 
            // CheckBoxUseDoubleTime
            // 
            this.CheckBoxUseDoubleTime.AutoSize = true;
            this.CheckBoxUseDoubleTime.Location = new System.Drawing.Point(762, 233);
            this.CheckBoxUseDoubleTime.Name = "CheckBoxUseDoubleTime";
            this.CheckBoxUseDoubleTime.Size = new System.Drawing.Size(102, 17);
            this.CheckBoxUseDoubleTime.TabIndex = 21;
            this.CheckBoxUseDoubleTime.Text = "UseDoubleTime";
            this.CheckBoxUseDoubleTime.UseVisualStyleBackColor = true;
            this.CheckBoxUseDoubleTime.Visible = false;
            this.CheckBoxUseDoubleTime.CheckedChanged += new System.EventHandler(this.CheckBoxUseDoubleTime_CheckedChanged);
            // 
            // CheckBoxUsePenaltyRegradMechnisam
            // 
            this.CheckBoxUsePenaltyRegradMechnisam.AutoSize = true;
            this.CheckBoxUsePenaltyRegradMechnisam.Location = new System.Drawing.Point(580, 285);
            this.CheckBoxUsePenaltyRegradMechnisam.Name = "CheckBoxUsePenaltyRegradMechnisam";
            this.CheckBoxUsePenaltyRegradMechnisam.Size = new System.Drawing.Size(184, 17);
            this.CheckBoxUsePenaltyRegradMechnisam.TabIndex = 22;
            this.CheckBoxUsePenaltyRegradMechnisam.Text = "Use Penalty Regard Mechanisam";
            this.CheckBoxUsePenaltyRegradMechnisam.UseVisualStyleBackColor = true;
            this.CheckBoxUsePenaltyRegradMechnisam.CheckedChanged += new System.EventHandler(this.CheckBoxUsePenaltyRegradMechnisam_CheckedChanged);
            this.CheckBoxUsePenaltyRegradMechnisam.CheckStateChanged += new System.EventHandler(this.CheckBoxUsePenaltyRegradMechnisam_CheckStateChanged);
            // 
            // CheckBoxDynamicProgrammingAStarGreedyt
            // 
            this.CheckBoxDynamicProgrammingAStarGreedyt.AutoSize = true;
            this.CheckBoxDynamicProgrammingAStarGreedyt.Location = new System.Drawing.Point(590, 323);
            this.CheckBoxDynamicProgrammingAStarGreedyt.Name = "CheckBoxDynamicProgrammingAStarGreedyt";
            this.CheckBoxDynamicProgrammingAStarGreedyt.Size = new System.Drawing.Size(216, 17);
            this.CheckBoxDynamicProgrammingAStarGreedyt.TabIndex = 23;
            this.CheckBoxDynamicProgrammingAStarGreedyt.Text = "Dynamic Programming AStarGreedy First";
            this.CheckBoxDynamicProgrammingAStarGreedyt.UseVisualStyleBackColor = true;
            this.CheckBoxDynamicProgrammingAStarGreedyt.Visible = false;
            this.CheckBoxDynamicProgrammingAStarGreedyt.CheckedChanged += new System.EventHandler(this.CheckBoxDynamicProgrammingAStarGreedyt_CheckedChanged);
            // 
            // ProgressBarVerify
            // 
            this.ProgressBarVerify.Location = new System.Drawing.Point(26, 579);
            this.ProgressBarVerify.Name = "ProgressBarVerify";
            this.ProgressBarVerify.Size = new System.Drawing.Size(551, 23);
            this.ProgressBarVerify.TabIndex = 24;
            this.ProgressBarVerify.CursorChanged += new System.EventHandler(this.ProgressBarVerify_CursorChanged);
            this.ProgressBarVerify.Click += new System.EventHandler(this.ProgressBarVerify_Click);
            this.ProgressBarVerify.Validated += new System.EventHandler(this.ProgressBarVerify_Validated);
            // 
            // labelTimesRemaining
            // 
            this.labelTimesRemaining.AutoSize = true;
            this.labelTimesRemaining.Location = new System.Drawing.Point(577, 538);
            this.labelTimesRemaining.Name = "labelTimesRemaining";
            this.labelTimesRemaining.Size = new System.Drawing.Size(0, 13);
            this.labelTimesRemaining.TabIndex = 25;
            // 
            // ButtonCalculateRootGray
            // 
            this.ButtonCalculateRootGray.Location = new System.Drawing.Point(592, 350);
            this.ButtonCalculateRootGray.Name = "ButtonCalculateRootGray";
            this.ButtonCalculateRootGray.Size = new System.Drawing.Size(154, 23);
            this.ButtonCalculateRootGray.TabIndex = 26;
            this.ButtonCalculateRootGray.Text = "CalculateRootGray";
            this.ButtonCalculateRootGray.UseVisualStyleBackColor = true;
            this.ButtonCalculateRootGray.Visible = false;
            this.ButtonCalculateRootGray.Click += new System.EventHandler(this.ButtonCalculateRootGray_Click);
            // 
            // CheckBoxIgnoreSelf
            // 
            this.CheckBoxIgnoreSelf.AutoSize = true;
            this.CheckBoxIgnoreSelf.Location = new System.Drawing.Point(816, 323);
            this.CheckBoxIgnoreSelf.Name = "CheckBoxIgnoreSelf";
            this.CheckBoxIgnoreSelf.Size = new System.Drawing.Size(160, 17);
            this.CheckBoxIgnoreSelf.TabIndex = 27;
            this.CheckBoxIgnoreSelf.Text = "Ignore Self Objects Thinking";
            this.CheckBoxIgnoreSelf.UseVisualStyleBackColor = true;
            this.CheckBoxIgnoreSelf.Visible = false;
            this.CheckBoxIgnoreSelf.CheckedChanged += new System.EventHandler(this.CheckBoxIgnoreSelf_CheckedChanged);
            // 
            // ComboBoxMaxLevel
            // 
            this.ComboBoxMaxLevel.FormattingEnabled = true;
            this.ComboBoxMaxLevel.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100",
            "200",
            "300",
            "400",
            "500"});
            this.ComboBoxMaxLevel.Location = new System.Drawing.Point(842, 295);
            this.ComboBoxMaxLevel.Name = "ComboBoxMaxLevel";
            this.ComboBoxMaxLevel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ComboBoxMaxLevel.Size = new System.Drawing.Size(84, 21);
            this.ComboBoxMaxLevel.TabIndex = 28;
            this.ComboBoxMaxLevel.Text = "2";
            this.ComboBoxMaxLevel.SelectedIndexChanged += new System.EventHandler(this.ComboBoxMaxTree_SelectedIndexChanged);
            // 
            // labelMaxTree
            // 
            this.labelMaxTree.AutoSize = true;
            this.labelMaxTree.Location = new System.Drawing.Point(785, 299);
            this.labelMaxTree.Name = "labelMaxTree";
            this.labelMaxTree.Size = new System.Drawing.Size(56, 13);
            this.labelMaxTree.TabIndex = 29;
            this.labelMaxTree.Text = "Max Level";
            // 
            // groupBoxGroupOfPowerity
            // 
            this.groupBoxGroupOfPowerity.Controls.Add(this.labelMovments);
            this.groupBoxGroupOfPowerity.Controls.Add(this.labelKiller);
            this.groupBoxGroupOfPowerity.Controls.Add(this.labelSupport);
            this.groupBoxGroupOfPowerity.Controls.Add(this.labelReducedAttacked);
            this.groupBoxGroupOfPowerity.Controls.Add(this.labelObjectDangour);
            this.groupBoxGroupOfPowerity.Controls.Add(this.labelAttack);
            this.groupBoxGroupOfPowerity.Controls.Add(this.ComboBoxMovments);
            this.groupBoxGroupOfPowerity.Controls.Add(this.ComboBoxKiller);
            this.groupBoxGroupOfPowerity.Controls.Add(this.ComboBoxSupport);
            this.groupBoxGroupOfPowerity.Controls.Add(this.ComboBoxReducedAttacked);
            this.groupBoxGroupOfPowerity.Controls.Add(this.ComboBoxObjectDangour);
            this.groupBoxGroupOfPowerity.Controls.Add(this.ComboBoxAttack);
            this.groupBoxGroupOfPowerity.Location = new System.Drawing.Point(583, 528);
            this.groupBoxGroupOfPowerity.Name = "groupBoxGroupOfPowerity";
            this.groupBoxGroupOfPowerity.Size = new System.Drawing.Size(375, 72);
            this.groupBoxGroupOfPowerity.TabIndex = 42;
            this.groupBoxGroupOfPowerity.TabStop = false;
            this.groupBoxGroupOfPowerity.Text = "Group Of Powerity";
            // 
            // labelMovments
            // 
            this.labelMovments.AutoSize = true;
            this.labelMovments.Location = new System.Drawing.Point(294, 23);
            this.labelMovments.Name = "labelMovments";
            this.labelMovments.Size = new System.Drawing.Size(56, 13);
            this.labelMovments.TabIndex = 53;
            this.labelMovments.Text = "Movments";
            // 
            // labelKiller
            // 
            this.labelKiller.AutoSize = true;
            this.labelKiller.Location = new System.Drawing.Point(251, 23);
            this.labelKiller.Name = "labelKiller";
            this.labelKiller.Size = new System.Drawing.Size(29, 13);
            this.labelKiller.TabIndex = 52;
            this.labelKiller.Text = "Killer";
            // 
            // labelSupport
            // 
            this.labelSupport.AutoSize = true;
            this.labelSupport.Location = new System.Drawing.Point(202, 24);
            this.labelSupport.Name = "labelSupport";
            this.labelSupport.Size = new System.Drawing.Size(44, 13);
            this.labelSupport.TabIndex = 51;
            this.labelSupport.Text = "Support";
            // 
            // labelReducedAttacked
            // 
            this.labelReducedAttacked.AutoSize = true;
            this.labelReducedAttacked.Location = new System.Drawing.Point(111, 23);
            this.labelReducedAttacked.Name = "labelReducedAttacked";
            this.labelReducedAttacked.Size = new System.Drawing.Size(94, 13);
            this.labelReducedAttacked.TabIndex = 50;
            this.labelReducedAttacked.Text = "ReducedAttacked";
            // 
            // labelObjectDangour
            // 
            this.labelObjectDangour.AutoSize = true;
            this.labelObjectDangour.Location = new System.Drawing.Point(42, 24);
            this.labelObjectDangour.Name = "labelObjectDangour";
            this.labelObjectDangour.Size = new System.Drawing.Size(73, 13);
            this.labelObjectDangour.TabIndex = 49;
            this.labelObjectDangour.Text = "ObjectDanger";
            // 
            // labelAttack
            // 
            this.labelAttack.AutoSize = true;
            this.labelAttack.Location = new System.Drawing.Point(6, 24);
            this.labelAttack.Name = "labelAttack";
            this.labelAttack.Size = new System.Drawing.Size(38, 13);
            this.labelAttack.TabIndex = 48;
            this.labelAttack.Text = "Attack";
            // 
            // ComboBoxMovments
            // 
            this.ComboBoxMovments.FormattingEnabled = true;
            this.ComboBoxMovments.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "10",
            "100",
            "1000",
            "10000"});
            this.ComboBoxMovments.Location = new System.Drawing.Point(294, 45);
            this.ComboBoxMovments.Name = "ComboBoxMovments";
            this.ComboBoxMovments.Size = new System.Drawing.Size(55, 21);
            this.ComboBoxMovments.TabIndex = 47;
            this.ComboBoxMovments.Text = "1";
            this.ComboBoxMovments.SelectedIndexChanged += new System.EventHandler(this.ComboBoxMovments_SelectedIndexChanged);
            // 
            // ComboBoxKiller
            // 
            this.ComboBoxKiller.FormattingEnabled = true;
            this.ComboBoxKiller.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "10",
            "100",
            "1000",
            "10000"});
            this.ComboBoxKiller.Location = new System.Drawing.Point(252, 45);
            this.ComboBoxKiller.Name = "ComboBoxKiller";
            this.ComboBoxKiller.Size = new System.Drawing.Size(36, 21);
            this.ComboBoxKiller.TabIndex = 46;
            this.ComboBoxKiller.Text = "1";
            this.ComboBoxKiller.SelectedIndexChanged += new System.EventHandler(this.ComboBoxHitting_SelectedIndexChanged);
            // 
            // ComboBoxSupport
            // 
            this.ComboBoxSupport.FormattingEnabled = true;
            this.ComboBoxSupport.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "10",
            "100",
            "1000",
            "10000"});
            this.ComboBoxSupport.Location = new System.Drawing.Point(197, 45);
            this.ComboBoxSupport.Name = "ComboBoxSupport";
            this.ComboBoxSupport.Size = new System.Drawing.Size(49, 21);
            this.ComboBoxSupport.TabIndex = 45;
            this.ComboBoxSupport.Text = "1";
            this.ComboBoxSupport.SelectedIndexChanged += new System.EventHandler(this.ComboBoxSupport_SelectedIndexChanged);
            // 
            // ComboBoxReducedAttacked
            // 
            this.ComboBoxReducedAttacked.FormattingEnabled = true;
            this.ComboBoxReducedAttacked.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "10",
            "100",
            "1000",
            "10000"});
            this.ComboBoxReducedAttacked.Location = new System.Drawing.Point(105, 45);
            this.ComboBoxReducedAttacked.Name = "ComboBoxReducedAttacked";
            this.ComboBoxReducedAttacked.Size = new System.Drawing.Size(86, 21);
            this.ComboBoxReducedAttacked.TabIndex = 44;
            this.ComboBoxReducedAttacked.Text = "1";
            this.ComboBoxReducedAttacked.SelectedIndexChanged += new System.EventHandler(this.ComboBoxReducedAttacked_SelectedIndexChanged);
            // 
            // ComboBoxObjectDangour
            // 
            this.ComboBoxObjectDangour.FormattingEnabled = true;
            this.ComboBoxObjectDangour.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "10",
            "100",
            "1000",
            "10000"});
            this.ComboBoxObjectDangour.Location = new System.Drawing.Point(57, 45);
            this.ComboBoxObjectDangour.Name = "ComboBoxObjectDangour";
            this.ComboBoxObjectDangour.Size = new System.Drawing.Size(42, 21);
            this.ComboBoxObjectDangour.TabIndex = 43;
            this.ComboBoxObjectDangour.Text = "1";
            this.ComboBoxObjectDangour.SelectedIndexChanged += new System.EventHandler(this.ComboBoxObjectDangour_SelectedIndexChanged);
            // 
            // ComboBoxAttack
            // 
            this.ComboBoxAttack.FormattingEnabled = true;
            this.ComboBoxAttack.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "10",
            "100",
            "1000",
            "10000"});
            this.ComboBoxAttack.Location = new System.Drawing.Point(0, 45);
            this.ComboBoxAttack.Name = "ComboBoxAttack";
            this.ComboBoxAttack.Size = new System.Drawing.Size(51, 21);
            this.ComboBoxAttack.TabIndex = 42;
            this.ComboBoxAttack.Text = "1";
            this.ComboBoxAttack.SelectedIndexChanged += new System.EventHandler(this.ComboBoxAttack_SelectedIndexChanged);
            // 
            // ButtonChangeArrangment
            // 
            this.ButtonChangeArrangment.Enabled = false;
            this.ButtonChangeArrangment.Location = new System.Drawing.Point(592, 239);
            this.ButtonChangeArrangment.Name = "ButtonChangeArrangment";
            this.ButtonChangeArrangment.Size = new System.Drawing.Size(37, 23);
            this.ButtonChangeArrangment.TabIndex = 43;
            this.ButtonChangeArrangment.Text = "<>";
            this.ButtonChangeArrangment.UseVisualStyleBackColor = true;
            this.ButtonChangeArrangment.Visible = false;
            this.ButtonChangeArrangment.Click += new System.EventHandler(this.ButtonChangeArrangment_Click);
            // 
            // TextBoxText
            // 
            this.TextBoxText.Location = new System.Drawing.Point(590, 379);
            this.TextBoxText.Multiline = true;
            this.TextBoxText.Name = "TextBoxText";
            this.TextBoxText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBoxText.Size = new System.Drawing.Size(368, 75);
            this.TextBoxText.TabIndex = 44;
            this.TextBoxText.TextChanged += new System.EventHandler(this.TextBoxText_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(613, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 79;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(783, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 80;
            // 
            // labelNodesCount
            // 
            this.labelNodesCount.AutoSize = true;
            this.labelNodesCount.Location = new System.Drawing.Point(99, 560);
            this.labelNodesCount.Name = "labelNodesCount";
            this.labelNodesCount.Size = new System.Drawing.Size(0, 13);
            this.labelNodesCount.TabIndex = 81;
            // 
            // labelNodesCountText
            // 
            this.labelNodesCountText.AutoSize = true;
            this.labelNodesCountText.Location = new System.Drawing.Point(16, 560);
            this.labelNodesCountText.Name = "labelNodesCountText";
            this.labelNodesCountText.Size = new System.Drawing.Size(77, 13);
            this.labelNodesCountText.TabIndex = 82;
            this.labelNodesCountText.Text = "Nodes Counts:";
            // 
            // PictureBox32
            // 
            this.PictureBox32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox32.Location = new System.Drawing.Point(786, 495);
            this.PictureBox32.Name = "PictureBox32";
            this.PictureBox32.Size = new System.Drawing.Size(22, 27);
            this.PictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox32.TabIndex = 64;
            this.PictureBox32.TabStop = false;
            // 
            // PictureBox31
            // 
            this.PictureBox31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox31.Location = new System.Drawing.Point(760, 495);
            this.PictureBox31.Name = "PictureBox31";
            this.PictureBox31.Size = new System.Drawing.Size(22, 27);
            this.PictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox31.TabIndex = 65;
            this.PictureBox31.TabStop = false;
            // 
            // PictureBox30
            // 
            this.PictureBox30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox30.Location = new System.Drawing.Point(732, 495);
            this.PictureBox30.Name = "PictureBox30";
            this.PictureBox30.Size = new System.Drawing.Size(22, 27);
            this.PictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox30.TabIndex = 66;
            this.PictureBox30.TabStop = false;
            // 
            // PictureBox29
            // 
            this.PictureBox29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox29.Location = new System.Drawing.Point(704, 495);
            this.PictureBox29.Name = "PictureBox29";
            this.PictureBox29.Size = new System.Drawing.Size(22, 27);
            this.PictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox29.TabIndex = 67;
            this.PictureBox29.TabStop = false;
            // 
            // PictureBox28
            // 
            this.PictureBox28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox28.Location = new System.Drawing.Point(676, 495);
            this.PictureBox28.Name = "PictureBox28";
            this.PictureBox28.Size = new System.Drawing.Size(22, 27);
            this.PictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox28.TabIndex = 68;
            this.PictureBox28.TabStop = false;
            // 
            // PictureBox27
            // 
            this.PictureBox27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox27.Location = new System.Drawing.Point(648, 495);
            this.PictureBox27.Name = "PictureBox27";
            this.PictureBox27.Size = new System.Drawing.Size(22, 27);
            this.PictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox27.TabIndex = 69;
            this.PictureBox27.TabStop = false;
            // 
            // PictureBox26
            // 
            this.PictureBox26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox26.Location = new System.Drawing.Point(620, 495);
            this.PictureBox26.Name = "PictureBox26";
            this.PictureBox26.Size = new System.Drawing.Size(22, 27);
            this.PictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox26.TabIndex = 70;
            this.PictureBox26.TabStop = false;
            // 
            // PictureBox25
            // 
            this.PictureBox25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox25.Location = new System.Drawing.Point(593, 495);
            this.PictureBox25.Name = "PictureBox25";
            this.PictureBox25.Size = new System.Drawing.Size(22, 27);
            this.PictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox25.TabIndex = 71;
            this.PictureBox25.TabStop = false;
            // 
            // PictureBox24
            // 
            this.PictureBox24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox24.Location = new System.Drawing.Point(786, 462);
            this.PictureBox24.Name = "PictureBox24";
            this.PictureBox24.Size = new System.Drawing.Size(22, 27);
            this.PictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox24.TabIndex = 72;
            this.PictureBox24.TabStop = false;
            // 
            // PictureBox23
            // 
            this.PictureBox23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox23.Location = new System.Drawing.Point(760, 462);
            this.PictureBox23.Name = "PictureBox23";
            this.PictureBox23.Size = new System.Drawing.Size(22, 27);
            this.PictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox23.TabIndex = 73;
            this.PictureBox23.TabStop = false;
            // 
            // PictureBox22
            // 
            this.PictureBox22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox22.Location = new System.Drawing.Point(732, 462);
            this.PictureBox22.Name = "PictureBox22";
            this.PictureBox22.Size = new System.Drawing.Size(22, 27);
            this.PictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox22.TabIndex = 74;
            this.PictureBox22.TabStop = false;
            // 
            // PictureBox21
            // 
            this.PictureBox21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox21.Location = new System.Drawing.Point(704, 462);
            this.PictureBox21.Name = "PictureBox21";
            this.PictureBox21.Size = new System.Drawing.Size(22, 27);
            this.PictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox21.TabIndex = 75;
            this.PictureBox21.TabStop = false;
            // 
            // PictureBox20
            // 
            this.PictureBox20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox20.Location = new System.Drawing.Point(676, 462);
            this.PictureBox20.Name = "PictureBox20";
            this.PictureBox20.Size = new System.Drawing.Size(22, 27);
            this.PictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox20.TabIndex = 76;
            this.PictureBox20.TabStop = false;
            // 
            // PictureBox19
            // 
            this.PictureBox19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox19.Location = new System.Drawing.Point(648, 462);
            this.PictureBox19.Name = "PictureBox19";
            this.PictureBox19.Size = new System.Drawing.Size(22, 27);
            this.PictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox19.TabIndex = 77;
            this.PictureBox19.TabStop = false;
            // 
            // PictureBox18
            // 
            this.PictureBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox18.Location = new System.Drawing.Point(620, 462);
            this.PictureBox18.Name = "PictureBox18";
            this.PictureBox18.Size = new System.Drawing.Size(22, 27);
            this.PictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox18.TabIndex = 78;
            this.PictureBox18.TabStop = false;
            // 
            // PictureBox17
            // 
            this.PictureBox17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox17.Location = new System.Drawing.Point(593, 462);
            this.PictureBox17.Name = "PictureBox17";
            this.PictureBox17.Size = new System.Drawing.Size(22, 27);
            this.PictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox17.TabIndex = 63;
            this.PictureBox17.TabStop = false;
            // 
            // PictureBox16
            // 
            this.PictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox16.Location = new System.Drawing.Point(788, 346);
            this.PictureBox16.Name = "PictureBox16";
            this.PictureBox16.Size = new System.Drawing.Size(22, 27);
            this.PictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox16.TabIndex = 60;
            this.PictureBox16.TabStop = false;
            // 
            // PictureBox15
            // 
            this.PictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox15.Location = new System.Drawing.Point(760, 344);
            this.PictureBox15.Name = "PictureBox15";
            this.PictureBox15.Size = new System.Drawing.Size(22, 27);
            this.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox15.TabIndex = 59;
            this.PictureBox15.TabStop = false;
            // 
            // PictureBox14
            // 
            this.PictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox14.Location = new System.Drawing.Point(732, 345);
            this.PictureBox14.Name = "PictureBox14";
            this.PictureBox14.Size = new System.Drawing.Size(22, 27);
            this.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox14.TabIndex = 58;
            this.PictureBox14.TabStop = false;
            // 
            // PictureBox13
            // 
            this.PictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox13.Location = new System.Drawing.Point(704, 344);
            this.PictureBox13.Name = "PictureBox13";
            this.PictureBox13.Size = new System.Drawing.Size(22, 27);
            this.PictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox13.TabIndex = 57;
            this.PictureBox13.TabStop = false;
            // 
            // PictureBox12
            // 
            this.PictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox12.Location = new System.Drawing.Point(676, 344);
            this.PictureBox12.Name = "PictureBox12";
            this.PictureBox12.Size = new System.Drawing.Size(22, 27);
            this.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox12.TabIndex = 56;
            this.PictureBox12.TabStop = false;
            // 
            // PictureBox11
            // 
            this.PictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox11.Location = new System.Drawing.Point(648, 344);
            this.PictureBox11.Name = "PictureBox11";
            this.PictureBox11.Size = new System.Drawing.Size(22, 27);
            this.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox11.TabIndex = 55;
            this.PictureBox11.TabStop = false;
            // 
            // PictureBox10
            // 
            this.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox10.Location = new System.Drawing.Point(620, 344);
            this.PictureBox10.Name = "PictureBox10";
            this.PictureBox10.Size = new System.Drawing.Size(22, 27);
            this.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox10.TabIndex = 54;
            this.PictureBox10.TabStop = false;
            // 
            // PictureBox9
            // 
            this.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox9.Location = new System.Drawing.Point(593, 346);
            this.PictureBox9.Name = "PictureBox9";
            this.PictureBox9.Size = new System.Drawing.Size(22, 27);
            this.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox9.TabIndex = 53;
            this.PictureBox9.TabStop = false;
            // 
            // PictureBox8
            // 
            this.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox8.Location = new System.Drawing.Point(788, 312);
            this.PictureBox8.Name = "PictureBox8";
            this.PictureBox8.Size = new System.Drawing.Size(22, 27);
            this.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox8.TabIndex = 52;
            this.PictureBox8.TabStop = false;
            // 
            // PictureBox7
            // 
            this.PictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox7.Location = new System.Drawing.Point(760, 312);
            this.PictureBox7.Name = "PictureBox7";
            this.PictureBox7.Size = new System.Drawing.Size(22, 27);
            this.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox7.TabIndex = 51;
            this.PictureBox7.TabStop = false;
            // 
            // PictureBox6
            // 
            this.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox6.Location = new System.Drawing.Point(732, 312);
            this.PictureBox6.Name = "PictureBox6";
            this.PictureBox6.Size = new System.Drawing.Size(22, 27);
            this.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox6.TabIndex = 50;
            this.PictureBox6.TabStop = false;
            // 
            // PictureBox5
            // 
            this.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox5.Location = new System.Drawing.Point(704, 312);
            this.PictureBox5.Name = "PictureBox5";
            this.PictureBox5.Size = new System.Drawing.Size(22, 27);
            this.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox5.TabIndex = 49;
            this.PictureBox5.TabStop = false;
            // 
            // PictureBox4
            // 
            this.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox4.Location = new System.Drawing.Point(676, 312);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(22, 27);
            this.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox4.TabIndex = 48;
            this.PictureBox4.TabStop = false;
            // 
            // PictureBox3
            // 
            this.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox3.Location = new System.Drawing.Point(648, 312);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(22, 27);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox3.TabIndex = 47;
            this.PictureBox3.TabStop = false;
            this.PictureBox3.Click += new System.EventHandler(this.PictureBox3_Click);
            // 
            // PictureBox2
            // 
            this.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox2.Location = new System.Drawing.Point(620, 312);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(22, 27);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox2.TabIndex = 46;
            this.PictureBox2.TabStop = false;
            // 
            // PictureBox1
            // 
            this.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox1.Location = new System.Drawing.Point(592, 312);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(22, 27);
            this.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox1.TabIndex = 45;
            this.PictureBox1.TabStop = false;
            // 
            // PictureBoxTimerBrown
            // 
            this.PictureBoxTimerBrown.ErrorImage = global::Refrigtz.Properties.Resources.Brown;
            this.PictureBoxTimerBrown.Image = global::Refrigtz.Properties.Resources.Brown;
            this.PictureBoxTimerBrown.Location = new System.Drawing.Point(801, 38);
            this.PictureBoxTimerBrown.Name = "PictureBoxTimerBrown";
            this.PictureBoxTimerBrown.Size = new System.Drawing.Size(192, 66);
            this.PictureBoxTimerBrown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBoxTimerBrown.TabIndex = 8;
            this.PictureBoxTimerBrown.TabStop = false;
            this.PictureBoxTimerBrown.Click += new System.EventHandler(this.PictureBoxTimerBrown_Click);
            this.PictureBoxTimerBrown.Paint += new System.Windows.Forms.PaintEventHandler(this.PictureBoxTimerBrown_Paint);
            // 
            // PictureBoxTimerGray
            // 
            this.PictureBoxTimerGray.ErrorImage = global::Refrigtz.Properties.Resources.Gray;
            this.PictureBoxTimerGray.Image = global::Refrigtz.Properties.Resources.Gray;
            this.PictureBoxTimerGray.Location = new System.Drawing.Point(595, 38);
            this.PictureBoxTimerGray.Name = "PictureBoxTimerGray";
            this.PictureBoxTimerGray.Size = new System.Drawing.Size(193, 66);
            this.PictureBoxTimerGray.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBoxTimerGray.TabIndex = 7;
            this.PictureBoxTimerGray.TabStop = false;
            this.PictureBoxTimerGray.Click += new System.EventHandler(this.PictureBoxTimerGray_Click);
            this.PictureBoxTimerGray.Paint += new System.Windows.Forms.PaintEventHandler(this.PictureBoxTimerGray_Paint);
            // 
            // PictureBoxRefrigtz
            // 
            this.PictureBoxRefrigtz.InitialImage = global::Refrigtz.Properties.Resources.BrG;
            this.PictureBoxRefrigtz.Location = new System.Drawing.Point(3, 38);
            this.PictureBoxRefrigtz.Name = "PictureBoxRefrigtz";
            this.PictureBoxRefrigtz.Size = new System.Drawing.Size(574, 508);
            this.PictureBoxRefrigtz.TabIndex = 0;
            this.PictureBoxRefrigtz.TabStop = false;
            this.PictureBoxRefrigtz.Paint += new System.Windows.Forms.PaintEventHandler(this.PictureBoxRefrigtz_Paint);
            this.PictureBoxRefrigtz.MouseClick += new System.Windows.Forms.MouseEventHandler(this.PictureBoxRefrigtz_MouseClick);
            this.PictureBoxRefrigtz.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.PictureBoxRefrigtz_MouseDoubleClick);
            this.PictureBoxRefrigtz.MouseLeave += new System.EventHandler(this.PictureBoxRefrigtz_MouseLeave);
            this.PictureBoxRefrigtz.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PictureBoxRefrigtz_MouseMove);
            // 
            // BackgroundWorkerAllOp
            // 
            this.BackgroundWorkerAllOp.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorker_DoWork);
            // 
            // Timer
            // 
            this.Timer.Interval = 1000000000;
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // TimerAllOperation
            // 
            this.TimerAllOperation.Tick += new System.EventHandler(this.TimerAllOperation_Tick);
            // 
            // BackgroundWorkerSetNode
            // 
            this.BackgroundWorkerSetNode.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorkerSetNode_DoWork);
            // 
            // BackgroundWorkerSetRefD
            // 
            this.BackgroundWorkerSetRefD.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorkerSetRefD_DoWork);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(894, 213);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(99, 23);
            this.buttonClear.TabIndex = 83;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // buttonViewTree
            // 
            this.buttonViewTree.Location = new System.Drawing.Point(894, 242);
            this.buttonViewTree.Name = "buttonViewTree";
            this.buttonViewTree.Size = new System.Drawing.Size(75, 23);
            this.buttonViewTree.TabIndex = 84;
            this.buttonViewTree.Text = "ViewTree";
            this.buttonViewTree.UseVisualStyleBackColor = true;
            this.buttonViewTree.Click += new System.EventHandler(this.buttonViewTree_Click);
            // 
            // FormRefrigtz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.ButtonStop;
            this.ClientSize = new System.Drawing.Size(1005, 653);
            this.ControlBox = false;
            this.Controls.Add(this.buttonViewTree);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.labelNodesCountText);
            this.Controls.Add(this.labelNodesCount);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PictureBox32);
            this.Controls.Add(this.PictureBox31);
            this.Controls.Add(this.PictureBox30);
            this.Controls.Add(this.PictureBox29);
            this.Controls.Add(this.PictureBox28);
            this.Controls.Add(this.PictureBox27);
            this.Controls.Add(this.PictureBox26);
            this.Controls.Add(this.PictureBox25);
            this.Controls.Add(this.PictureBox24);
            this.Controls.Add(this.PictureBox23);
            this.Controls.Add(this.PictureBox22);
            this.Controls.Add(this.PictureBox21);
            this.Controls.Add(this.PictureBox20);
            this.Controls.Add(this.PictureBox19);
            this.Controls.Add(this.PictureBox18);
            this.Controls.Add(this.PictureBox17);
            this.Controls.Add(this.PictureBox16);
            this.Controls.Add(this.PictureBox15);
            this.Controls.Add(this.PictureBox14);
            this.Controls.Add(this.PictureBox13);
            this.Controls.Add(this.PictureBox12);
            this.Controls.Add(this.PictureBox11);
            this.Controls.Add(this.PictureBox10);
            this.Controls.Add(this.PictureBox9);
            this.Controls.Add(this.PictureBox8);
            this.Controls.Add(this.PictureBox7);
            this.Controls.Add(this.PictureBox6);
            this.Controls.Add(this.PictureBox5);
            this.Controls.Add(this.PictureBox4);
            this.Controls.Add(this.PictureBox3);
            this.Controls.Add(this.PictureBox2);
            this.Controls.Add(this.PictureBox1);
            this.Controls.Add(this.TextBoxText);
            this.Controls.Add(this.ButtonChangeArrangment);
            this.Controls.Add(this.groupBoxGroupOfPowerity);
            this.Controls.Add(this.labelMaxTree);
            this.Controls.Add(this.ComboBoxMaxLevel);
            this.Controls.Add(this.CheckBoxIgnoreSelf);
            this.Controls.Add(this.ButtonCalculateRootGray);
            this.Controls.Add(this.labelTimesRemaining);
            this.Controls.Add(this.ProgressBarVerify);
            this.Controls.Add(this.CheckBoxDynamicProgrammingAStarGreedyt);
            this.Controls.Add(this.CheckBoxUsePenaltyRegradMechnisam);
            this.Controls.Add(this.CheckBoxUseDoubleTime);
            this.Controls.Add(this.CheckBoxAStarGreedyMovement);
            this.Controls.Add(this.ButtonPauseStart);
            this.Controls.Add(this.CheckBoxAStarGreadyFirstSearch);
            this.Controls.Add(this.ButtonStop);
            this.Controls.Add(this.RadioButtonSmallFittingImages);
            this.Controls.Add(this.RadioButtonBigFittingImages);
            this.Controls.Add(this.RadioButtonOriginalImages);
            this.Controls.Add(this.CheckBoxBestMovments);
            this.Controls.Add(this.CheckBoxPredictHuristci);
            this.Controls.Add(this.CheckBoxOnlySelf);
            this.Controls.Add(this.CheckBoxAStarGreedyHuristic);
            this.Controls.Add(this.TextBoxStatistic);
            this.Controls.Add(this.PictureBoxTimerBrown);
            this.Controls.Add(this.PictureBoxTimerGray);
            this.Controls.Add(this.ButtonPrevious);
            this.Controls.Add(this.ButtonNext);
            this.Controls.Add(this.PictureBoxRefrigtz);
            this.Controls.Add(this.MenuStripChessRefrigitz);
            this.MainMenuStrip = this.MenuStripChessRefrigitz;
            this.Name = "FormRefrigtz";
            this.Text = "Chess Refrigtz 2018";
            this.MaximumSizeChanged += new System.EventHandler(this.FormRefrigtz_MaximumSizeChanged);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormRefrigtz_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Leave += new System.EventHandler(this.FormRefrigtz_Leave);
            this.MenuStripChessRefrigitz.ResumeLayout(false);
            this.MenuStripChessRefrigitz.PerformLayout();
            this.groupBoxGroupOfPowerity.ResumeLayout(false);
            this.groupBoxGroupOfPowerity.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxTimerBrown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxTimerGray)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxRefrigtz)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        [field: NonSerialized]
        private System.Windows.Forms.MenuStrip MenuStripChessRefrigitz;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem AboutToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem AboutToolStripMenuItem1;
        [field: NonSerialized]
        private System.Windows.Forms.Button ButtonNext;
        [field: NonSerialized]
        private System.Windows.Forms.Button ButtonPrevious;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBoxTimerGray;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBoxTimerBrown;
        [field: NonSerialized]
        private System.Windows.Forms.TextBox TextBoxStatistic;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxAStarGreedyHuristic;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxOnlySelf;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxPredictHuristci;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxBestMovments;
        [field: NonSerialized]
        private System.Windows.Forms.RadioButton RadioButtonOriginalImages;
        [field: NonSerialized]
        private System.Windows.Forms.RadioButton RadioButtonBigFittingImages;
        [field: NonSerialized]
        private System.Windows.Forms.RadioButton RadioButtonSmallFittingImages;
        [field: NonSerialized]
        private System.Windows.Forms.Button ButtonStop;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxAStarGreadyFirstSearch;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem2;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem HardestToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem MedumToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem EasestToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.Button ButtonPauseStart;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxAStarGreedyMovement;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxUseDoubleTime;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxUsePenaltyRegradMechnisam;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxDynamicProgrammingAStarGreedyt;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem3;
        [field: NonSerialized]
        private System.Windows.Forms.HelpProvider helpProviderChessRefregitz2016;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem4;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem VerifyToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ClearToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem5;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ContinueAGameToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelTimesRemaining;
        [field: NonSerialized]
        private System.Windows.Forms.Button ButtonCalculateRootGray;
        [field: NonSerialized]
        private System.Windows.Forms.CheckBox CheckBoxIgnoreSelf;
        [field: NonSerialized]
        public System.Windows.Forms.ComboBox ComboBoxMaxLevel;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelMaxTree;
        [field: NonSerialized]
        public System.Windows.Forms.ProgressBar ProgressBarVerify;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem RepairToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.GroupBox groupBoxGroupOfPowerity;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelMovments;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelKiller;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelSupport;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelReducedAttacked;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelObjectDangour;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelAttack;
        [field: NonSerialized]
        private System.Windows.Forms.ComboBox ComboBoxMovments;
        [field: NonSerialized]
        private System.Windows.Forms.ComboBox ComboBoxKiller;
        [field: NonSerialized]
        private System.Windows.Forms.ComboBox ComboBoxSupport;
        [field: NonSerialized]
        private System.Windows.Forms.ComboBox ComboBoxReducedAttacked;
        [field: NonSerialized]
        private System.Windows.Forms.ComboBox ComboBoxObjectDangour;
        [field: NonSerialized]
        private System.Windows.Forms.ComboBox ComboBoxAttack;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem opneToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ErrorOpenToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem MonitorOpenToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogBackup;
        [field: NonSerialized]
        private System.Windows.Forms.Button ButtonChangeArrangment;
        [field: NonSerialized]
        public System.Windows.Forms.TextBox TextBoxText;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox1;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox2;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox3;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox4;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox5;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox6;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox7;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox8;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox9;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox10;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox11;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox12;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox13;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox14;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox15;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox16;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBoxRefrigtz;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox32;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox31;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox30;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox29;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox28;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox27;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox26;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox25;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox24;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox23;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox22;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox21;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox20;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox19;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox18;
        [field: NonSerialized]
        private System.Windows.Forms.PictureBox PictureBox17;
        [field: NonSerialized]
        private System.Windows.Forms.Label label1;
        [field: NonSerialized]
        private System.Windows.Forms.Label label2;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem1;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemNewGame;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem11;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem14;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem13;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem12;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem15;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem6;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem7;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem8;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ComputerWithComputerToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem9;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ComputerWithComputerToolStripMenuItem1;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem16;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem10;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem18;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem17;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemRandomGeneticGames;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem19;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem20;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelNodesCount;
        [field: NonSerialized]
        private System.Windows.Forms.Label labelNodesCountText;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem21;
        [field: NonSerialized]
        private System.ComponentModel.BackgroundWorker BackgroundWorkerAllOp;
        [field: NonSerialized]
        private System.Windows.Forms.Timer Timer;
        [field: NonSerialized]
        private System.Windows.Forms.Timer TimerAllOperation;
        [field: NonSerialized]
        private System.ComponentModel.BackgroundWorker BackgroundWorkerSetNode;
        [field: NonSerialized]
        private System.ComponentModel.BackgroundWorker BackgroundWorkerSetRefD;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem22;
        [field: NonSerialized]
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem23;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonViewTree;
    }
}

